<?php
/** Small, append-only customer refresh journal. No historical index rebuild is required. */
namespace Zameria;
defined('ABSPATH') || exit;
class Customer_Changes {
    private static $pending = array();
    const FLOOR = 'zameria_customer_changes_floor';
    public static function init() {
        foreach (array('user_register','profile_update','deleted_user','woocommerce_created_customer','woocommerce_update_customer','set_user_role','add_user_role','remove_user_role') as $hook) add_action($hook,array(__CLASS__,'queue'),20,1);
        foreach (array('added_user_meta','updated_user_meta','deleted_user_meta') as $hook) add_action($hook,array(__CLASS__,'meta'),20,4);
        add_action('woocommerce_before_order_object_save',array(__CLASS__,'before_order'),10,1);
        foreach (array('woocommerce_new_order','woocommerce_update_order','woocommerce_order_status_changed','woocommerce_order_refunded','woocommerce_trash_order','woocommerce_delete_order','woocommerce_before_delete_order','woocommerce_before_trash_order') as $hook) add_action($hook,array(__CLASS__,'order'),20,1);
        foreach(array('before_delete_post','wp_trash_post') as $hook) add_action($hook,function($id){if(get_post_type($id)==='shop_order')self::order($id);},20,1);
        add_action('shutdown',array(__CLASS__,'flush'),30);
        add_action('woocommerce_refund_deleted',function($refund_id,$order_id){self::order($order_id);},20,2);
        add_action('zameria_daily',array(__CLASS__,'prune'));
        add_action('rest_api_init',function() { register_rest_route('zameria/v1','/customer-changes',array('methods'=>'GET','callback'=>array(__CLASS__,'changes'),'permission_callback'=>array(Auth::class,'authenticate'))); });
    }
    public static function queue($id) {
        if ((int)$id > 0) { self::$pending[(int)$id]=true; delete_transient('zameria_customer_'.(int)$id); }
    }
    public static function meta($meta_id,$id,$key,$value=null) {
        if (strpos($key,'billing_')===0 || strpos($key,'shipping_')===0 || in_array($key,array('first_name','last_name','last_update'),true)) self::queue($id);
    }
    public static function before_order($order) {
        if (!is_object($order) || !method_exists($order,'get_customer_id')) return;
        self::queue($order->get_customer_id());
        $old=$order->get_id() ? wc_get_order($order->get_id()) : false;
        if ($old) self::queue($old->get_customer_id());
    }
    public static function order($id) { $order=is_object($id)?$id:wc_get_order($id); if ($order) self::queue($order->get_customer_id()); }
    public static function flush() {
        if (!self::$pending) return;
        global $wpdb; $values=array();
        foreach(array_keys(self::$pending) as $id) { delete_transient('zameria_customer_'.$id); $values[]=$wpdb->prepare('(%d,%s)',$id,gmdate('Y-m-d H:i:s')); }
        // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared,WordPress.DB.DirectDatabaseQuery -- Each tuple is prepared; this append-only plugin journal must reflect committed customer/order changes.
        if (false !== $wpdb->query("INSERT INTO {$wpdb->prefix}zameria_customer_changes (customer_id,changed_at) VALUES ".implode(',',$values))) self::$pending=array();
    }
    public static function cursor() {
        global $wpdb;
        // phpcs:ignore WordPress.DB.DirectDatabaseQuery -- Current sync boundary; never cache an event cursor.
        return max((int)get_option(self::FLOOR,0),(int)$wpdb->get_var("SELECT MAX(id) FROM {$wpdb->prefix}zameria_customer_changes"));
    }
    public static function changes($request) {
        global $wpdb;
        $since=max(0,(int)$request['since']);
        if ($since < (int)get_option(self::FLOOR,0) || $since > self::cursor()) return new \WP_Error('zameria_customer_cursor_expired','Customer snapshot needs refreshing.',array('status'=>409));
        $limit=200;
        // phpcs:ignore WordPress.DB.DirectDatabaseQuery -- Prepared, bounded reads from the live plugin journal.
        $rows=$wpdb->get_results($wpdb->prepare("SELECT id,customer_id,changed_at FROM {$wpdb->prefix}zameria_customer_changes WHERE id > %d ORDER BY id ASC LIMIT %d",$since,$limit));
        $next=$since; $ids=array(); $settled=gmdate('Y-m-d H:i:s',time()-2);
        foreach($rows as $row) { if ($row->changed_at > $settled) break; $next=(int)$row->id; $ids[(int)$row->customer_id]=true; }
        $customers=array();$removed=array();
        foreach(array_keys($ids) as $id) {
            $user=get_userdata($id);
            if (!$user || (!current_user_can('list_users') && !array_intersect((array)$user->roles,array('customer','subscriber')))) { $removed[]=$id; continue; }
            $customers[]=Rest_Controller::customer_payload($user);
        }
        return rest_ensure_response(array('customers'=>$customers,'removed'=>$removed,'cursor'=>$next,'more'=>count($rows)===$limit && $next>$since));
    }
    public static function prune() {
        global $wpdb;
        // phpcs:ignore WordPress.DB.DirectDatabaseQuery -- Retain 30 days of journal events, with a persisted floor for offline devices.
        $floor=(int)$wpdb->get_var($wpdb->prepare("SELECT MAX(id) FROM {$wpdb->prefix}zameria_customer_changes WHERE changed_at < %s",gmdate('Y-m-d H:i:s',time()-30*DAY_IN_SECONDS)));
        if (!$floor) return;
        // phpcs:ignore WordPress.DB.DirectDatabaseQuery -- Only obsolete plugin journal rows are removed.
        if (false !== $wpdb->query($wpdb->prepare("DELETE FROM {$wpdb->prefix}zameria_customer_changes WHERE id <= %d",$floor))) update_option(self::FLOOR,$floor,false);
    }
}
