<?php
/**
 * WooCommerce > Zameria POS settings screen.
 *
 * @package Zameria
 */

namespace Zameria;

defined( 'ABSPATH' ) || exit;

class Admin {

	const PAGE = 'zameria';

	public static function init() {
		add_action( 'admin_menu', array( __CLASS__, 'menu' ), 60 );
		add_action( 'admin_enqueue_scripts', array( __CLASS__, 'enqueue_assets' ) );
		add_action( 'admin_post_zameria_save_settings', array( __CLASS__, 'save_settings' ) );
		add_action( 'admin_post_zameria_revoke_device', array( __CLASS__, 'revoke_device' ) );
		add_action( 'wp_ajax_zameria_admin_status', array( __CLASS__, 'ajax_status' ) );
		add_action( 'wp_ajax_zameria_admin_save_settings', array( __CLASS__, 'ajax_save_settings' ) );
		add_action( 'wp_ajax_zameria_admin_sync_catalog', array( __CLASS__, 'ajax_sync_catalog' ) );
		add_action( 'wp_ajax_zameria_admin_health_check', array( __CLASS__, 'ajax_health_check' ) );
		add_action( 'wp_ajax_zameria_admin_get_entitlement', array( __CLASS__, 'ajax_get_entitlement' ) );
		add_action( 'wp_ajax_zameria_admin_set_entitlement', array( __CLASS__, 'ajax_set_entitlement' ) );
		add_action( 'wp_ajax_zameria_admin_get_devices', array( __CLASS__, 'ajax_get_devices' ) );
		add_action( 'wp_ajax_zameria_admin_revoke_device', array( __CLASS__, 'ajax_revoke_device' ) );
		add_action( 'wp_ajax_zameria_admin_get_staff', array( __CLASS__, 'ajax_get_staff' ) );
		add_filter( 'plugin_action_links_' . plugin_basename( ZAMERIA_FILE ), array( __CLASS__, 'action_links' ) );
	}

	public static function menu() {
		$capability = 'manage_woocommerce';

		// Top-level menu strictly labeled "ZAMERIA"
		add_menu_page(
			__( 'ZAMERIA', 'zameria' ),
			'ZAMERIA',
			$capability,
			self::PAGE,
			array( __CLASS__, 'render' ),
			'dashicons-store',
			56
		);

		// First submenu page (Overview) replaces default parent duplicate title
		add_submenu_page(
			self::PAGE,
			__( 'ZAMERIA &lsaquo; Overview', 'zameria' ),
			__( 'Overview', 'zameria' ),
			$capability,
			self::PAGE,
			array( __CLASS__, 'render' )
		);

		// Submenus for existing ZAMERIA sections
		add_submenu_page(
			self::PAGE,
			__( 'ZAMERIA &lsaquo; Registers & Devices', 'zameria' ),
			__( 'Active Users', 'zameria' ),
			$capability,
			'zameria-devices',
			array( __CLASS__, 'render' )
		);

		add_submenu_page(
			self::PAGE,
			__( 'ZAMERIA &lsaquo; Cashiers & Staff', 'zameria' ),
			__( 'Cashiers & Staff', 'zameria' ),
			$capability,
			'zameria-staff',
			array( __CLASS__, 'render' )
		);

		add_submenu_page(
			self::PAGE,
			__( 'ZAMERIA &lsaquo; Subscription & Account', 'zameria' ),
			__( 'Subscription & Account', 'zameria' ),
			$capability,
			'zameria-subscription',
			array( __CLASS__, 'render' )
		);

		add_submenu_page(
			self::PAGE,
			__( 'ZAMERIA &lsaquo; Settings', 'zameria' ),
			__( 'Settings', 'zameria' ),
			$capability,
			'zameria-settings',
			array( __CLASS__, 'render' )
		);
	}

	public static function action_links( $links ) {
		array_unshift(
			$links,
			'<a href="' . esc_url( admin_url( 'admin.php?page=' . self::PAGE ) ) . '">' . esc_html__( 'Settings', 'zameria' ) . '</a>',
			'<a href="' . esc_url( App_Server::hosted_login_url() ) . '" target="_blank" rel="noopener">' . esc_html__( 'Open ZAMERIA POS', 'zameria' ) . '</a>'
		);
		return $links;
	}

	public static function render() {
		if ( ! current_user_can( 'manage_woocommerce' ) ) {
			wp_die( esc_html__( 'Not allowed.', 'zameria' ), '', array( 'response' => 403 ) );
		}
		?>
		<div class="wrap" id="zameria-admin-root"></div>
		<noscript><p><?php esc_html_e( 'Zameria POS requires JavaScript to display its dashboard.', 'zameria' ); ?></p></noscript>
		<?php
	}

	/** Loads the compiled React dashboard on ZAMERIA admin pages. */
	public static function enqueue_assets( $hook ) {
		$allowed_hooks = array(
			'toplevel_page_' . self::PAGE,
			'zameria_page_zameria-devices',
			'zameria_page_zameria-staff',
			'zameria_page_zameria-subscription',
			'zameria_page_zameria-settings',
			'woocommerce_page_' . self::PAGE,
		);

		if ( ! in_array( $hook, $allowed_hooks, true ) && false === strpos( $hook, self::PAGE ) ) {
			return;
		}

		$manifest_file = ZAMERIA_DIR . 'admin-app/.vite/manifest.json';
		if ( ! is_readable( $manifest_file ) ) {
			add_action(
				'admin_notices',
				function () {
					echo '<div class="notice notice-error"><p>' . esc_html__( 'The Zameria dashboard assets have not been built. Run "npm run build:admin" from the project root.', 'zameria' ) . '</p></div>';
				}
			);
			return;
		}

		$manifest = json_decode( (string) file_get_contents( $manifest_file ), true ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents
		$entry    = is_array( $manifest ) ? ( $manifest['src/main.tsx'] ?? $manifest['index.html'] ?? null ) : null;
		if ( ! is_array( $entry ) || empty( $entry['file'] ) ) {
			add_action(
				'admin_notices',
				function () {
					echo '<div class="notice notice-error"><p>' . esc_html__( 'The Zameria dashboard build is invalid. Reinstall the latest Zameria plugin ZIP.', 'zameria' ) . '</p></div>';
				}
			);
			return;
		}

		foreach ( $entry['css'] ?? array() as $index => $css ) {
			wp_enqueue_style( 'zameria-admin-' . $index, ZAMERIA_URL . 'admin-app/' . ltrim( $css, '/' ), array(), ZAMERIA_VERSION );
		}
		wp_enqueue_script( 'zameria-admin', ZAMERIA_URL . 'admin-app/' . ltrim( $entry['file'], '/' ), array(), ZAMERIA_VERSION, true );
		// Vite emits an ES module (it uses import.meta). WordPress otherwise
		// prints a classic script tag, which prevents the dashboard from mounting.
		add_filter( 'script_loader_tag', array( __CLASS__, 'module_script_tag' ), 10, 3 );
		wp_add_inline_script( 'zameria-admin', 'window.ZAMERIA_ADMIN=' . wp_json_encode( self::dashboard_data(), JSON_HEX_TAG | JSON_UNESCAPED_SLASHES ) . ';', 'before' );
	}

	/** Marks the Vite dashboard bundle as an ES module while keeping the config inline script classic. */
	public static function module_script_tag( $tag, $handle, $src ) {
		if ( 'zameria-admin' !== $handle ) {
			return $tag;
		}
		return str_replace( '<script ', '<script type="module" ', $tag );
	}

	/** @return array<string, mixed> */
	private static function dashboard_data() {
		global $wpdb;

		$product_counts = wp_count_posts( 'product' );
		$users          = count_users();
		$order_query    = wc_get_orders(
			array(
				'limit'    => 1,
				'paginate' => true,
				'return'   => 'ids',
			)
		);
		$last_change    = $wpdb->get_var( "SELECT MAX(changed_at) FROM {$wpdb->prefix}zameria_changes" ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		$methods        = implode( "\n", wp_list_pluck( Settings::payment_methods(), 'label' ) );

		$current_page = isset( $_GET['page'] ) ? sanitize_text_field( wp_unslash( $_GET['page'] ) ) : '';
		$current_tab  = isset( $_GET['tab'] ) ? sanitize_text_field( wp_unslash( $_GET['tab'] ) ) : '';

		$initial_tab = 'overview';
		if ( 'zameria-devices' === $current_page || 'devices' === $current_tab ) {
			$initial_tab = 'devices';
		} elseif ( 'zameria-staff' === $current_page || 'staff' === $current_tab ) {
			$initial_tab = 'staff';
		} elseif ( 'zameria-subscription' === $current_page || 'subscription' === $current_tab || 'account' === $current_tab ) {
			$initial_tab = 'subscription';
		} elseif ( 'zameria-settings' === $current_page || 'settings' === $current_tab ) {
			$initial_tab = 'settings';
		}

		return array(
			'ajaxUrl'       => admin_url( 'admin-ajax.php' ),
			'nonce'         => wp_create_nonce( 'zameria_admin' ),
			'assetsUrl'     => ZAMERIA_URL . 'admin-app/',
			'initialTab'    => $initial_tab,
			// "Open ZAMERIA POS" buttons: the hosted POS, with this store's address pre-filled.
			'posUrl'        => App_Server::hosted_login_url(),
			// The same app served by this site at /pos/ (health checks, offline fallback).
			'localPosUrl'   => App_Server::url(),
			'storeUrl'      => home_url( '/' ),
			'storeName'     => wp_specialchars_decode( get_bloginfo( 'name' ), ENT_QUOTES ),
			'adminEmail'    => function_exists( 'sanitize_email' ) ? sanitize_email( (string) get_option( 'admin_email' ) ) : (string) get_option( 'admin_email' ),
			'productCount'  => (int) ( $product_counts->publish ?? 0 ),
			'orderCount'    => isset( $order_query->total ) ? (int) $order_query->total : 0,
			'customerCount' => (int) ( $users['avail_roles']['customer'] ?? 0 ),
			'deviceCount'   => count( Auth::active_devices() ),
			'devices'       => self::format_devices( Auth::active_devices() ),
			'deviceLimits'  => Settings::plan_limits(),
			'staff'         => self::format_staff(),
			'usersUrl'      => admin_url( 'users.php' ),
			'newUserUrl'    => admin_url( 'user-new.php?role=zameria_cashier' ),
			'lastChange'    => $last_change ? mysql_to_rfc3339( $last_change ) : null,
			'health'        => self::health_data(),
			'activity'      => self::activity(),
			'paymentMethods'=> $methods,
			'receiptFooter' => Settings::receipt_footer(),
			'entitlement'   => Settings::get_entitlement(),
			'storeAccessReady' => Store_Access::has_credentials(),
			'version'       => ZAMERIA_VERSION,
		);
	}

	/** @return array<string, mixed> */
	private static function health_data() {
		$checks = array(
			'woocommerce' => class_exists( 'WooCommerce' ),
			'permalinks'  => (bool) get_option( 'permalink_structure' ),
			'posBuild'     => is_file( App_Server::build_dir() . 'index.html' ),
		);
		return array(
			'ready'  => ! in_array( false, $checks, true ),
			'checks' => $checks,
		);
	}

	/** @return array<int, array<string, mixed>> */
	private static function activity() {
		$activity = get_option( 'zameria_admin_activity', array() );
		return is_array( $activity ) ? array_slice( $activity, 0, 20 ) : array();
	}

	private static function record_activity( $title, $details, $status = 'success' ) {
		$activity   = self::activity();
		$activity[] = array(
			'id'      => wp_generate_uuid4(),
			'title'   => sanitize_text_field( $title ),
			'details' => sanitize_text_field( $details ),
			'status'  => 'success' === $status ? 'success' : 'warning',
			'time'    => current_time( 'mysql', true ),
		);
		update_option( 'zameria_admin_activity', array_slice( array_reverse( $activity ), 0, 20 ), false );
	}

	public static function ajax_status() {
		check_ajax_referer( 'zameria_admin', 'nonce' );
		if ( ! current_user_can( 'manage_woocommerce' ) ) {
			wp_send_json_error( array( 'message' => __( 'Not allowed.', 'zameria' ) ), 403 );
		}
		wp_send_json_success( self::dashboard_data() );
	}

	public static function ajax_get_entitlement() {
		check_ajax_referer( 'zameria_admin', 'nonce' );
		if ( ! current_user_can( 'manage_woocommerce' ) ) {
			wp_send_json_error( array( 'message' => __( 'Not allowed.', 'zameria' ) ), 403 );
		}
		wp_send_json_success( array( 'entitlement' => Settings::get_entitlement() ) );
	}

	public static function ajax_set_entitlement() {
		check_ajax_referer( 'zameria_admin', 'nonce' );
		if ( ! current_user_can( 'manage_woocommerce' ) ) {
			wp_send_json_error( array( 'message' => __( 'Not allowed.', 'zameria' ) ), 403 );
		}

        // Client fields are display hints, never proof of entitlement.
        $requested = isset( $_POST['status'] ) ? sanitize_text_field( wp_unslash( $_POST['status'] ) ) : '';
        if ( 'unactivated' === $requested ) {
            $entitlement = array( 'status' => 'unactivated' );
        } else {
            $entitlement = Cloud_Account::verified_entitlement();
            if ( is_wp_error( $entitlement ) ) {
                $details = $entitlement->get_error_data();
                wp_send_json_error( array( 'message' => $entitlement->get_error_message(), 'requires_reconnect'=>is_array($details) && !empty($details['requires_reconnect']) ), is_array($details) ? ($details['status'] ?? 502) : 502 );
            }
            $entitlement['trial_start'] = $entitlement['trial_start'] ?? $entitlement['trial']['started_at'] ?? null;
            $entitlement['trial_end'] = $entitlement['trial_end'] ?? $entitlement['trial']['expires_at'] ?? null;
        }
        $status = $entitlement['status'];
        $plan_name = $entitlement['plan_name'] ?? '';

		Settings::set_entitlement( $entitlement );

		self::record_activity(
			__( 'Entitlement updated', 'zameria' ),
			sprintf( __( 'Store status set to %s (%s).', 'zameria' ), $status, $plan_name )
		);

		wp_send_json_success( array( 'entitlement' => Settings::get_entitlement() ) );
	}

	public static function ajax_save_settings() {
		check_ajax_referer( 'zameria_admin', 'nonce' );
		if ( ! current_user_can( 'manage_woocommerce' ) ) {
			wp_send_json_error( array( 'message' => __( 'Not allowed.', 'zameria' ) ), 403 );
		}
		Settings::save_payment_methods( wp_unslash( $_POST['payment_methods'] ?? '' ) ); // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized
		update_option( Settings::RECEIPT_FOOTER_OPTION, sanitize_text_field( wp_unslash( $_POST['receipt_footer'] ?? '' ) ) );
		wp_send_json_success( self::dashboard_data() );
	}

	public static function ajax_sync_catalog() {
		check_ajax_referer( 'zameria_admin', 'nonce' );
		if ( ! current_user_can( 'manage_woocommerce' ) ) {
			wp_send_json_error( array( 'message' => __( 'Not allowed.', 'zameria' ) ), 403 );
		}
		$count = Change_Log::queue_catalog();
		self::record_activity(
			__( 'Catalogue refresh queued', 'zameria' ),
			sprintf( _n( '%d product was added to the POS change feed.', '%d products were added to the POS change feed.', $count, 'zameria' ), $count )
		);
		wp_send_json_success(
			array(
				'message' => sprintf( _n( '%d product queued for connected POS devices.', '%d products queued for connected POS devices.', $count, 'zameria' ), $count ),
				'data'    => self::dashboard_data(),
			)
		);
	}

	public static function ajax_health_check() {
		check_ajax_referer( 'zameria_admin', 'nonce' );
		if ( ! current_user_can( 'manage_woocommerce' ) ) {
			wp_send_json_error( array( 'message' => __( 'Not allowed.', 'zameria' ) ), 403 );
		}
		$health = self::health_data();
		wp_send_json_success(
			array(
				'health'  => $health,
				'message' => $health['ready'] ? __( 'WooCommerce, pretty permalinks, and the POS build are ready.', 'zameria' ) : __( 'The local POS bridge needs attention. Review the failed checks below.', 'zameria' ),
			)
		);
	}

	public static function save_settings() {
		if ( ! current_user_can( 'manage_woocommerce' ) ) {
			wp_die( esc_html__( 'Not allowed.', 'zameria' ), '', array( 'response' => 403 ) );
		}
		check_admin_referer( 'zameria_save_settings' );

		Settings::save_payment_methods( wp_unslash( $_POST['payment_methods'] ?? '' ) ); // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- sanitised per line.
		update_option( Settings::RECEIPT_FOOTER_OPTION, sanitize_text_field( wp_unslash( $_POST['receipt_footer'] ?? '' ) ) );

		wp_safe_redirect( admin_url( 'admin.php?page=' . self::PAGE . '&updated=1' ) );
		exit;
	}

	public static function revoke_device() {
		$device_id = absint( $_POST['device_id'] ?? 0 );
		if ( ! current_user_can( 'manage_woocommerce' ) ) {
			wp_die( esc_html__( 'Not allowed.', 'zameria' ), '', array( 'response' => 403 ) );
		}
		check_admin_referer( 'zameria_revoke_device_' . $device_id );

		if ( false === Auth::revoke( $device_id ) ) {
			wp_die( esc_html__( 'Could not sign out this user. Please try again.', 'zameria' ), '', array( 'response' => 500 ) );
		}

		wp_safe_redirect( admin_url( 'admin.php?page=' . self::PAGE . '&updated=1' ) );
		exit;
	}

	/** @param array<object> $raw_devices */
	private static function format_devices( $raw_devices ) {
		$formatted = array();
		foreach ( (array) $raw_devices as $d ) {
			$formatted[] = array(
				'id'         => (int) $d->id,
				'name'       => ! empty( $d->name ) ? $d->name : __( 'Register', 'zameria' ),
				'userId'     => (int) $d->user_id,
				'userName'   => ! empty( $d->display_name ) ? $d->display_name : __( 'Staff User', 'zameria' ),
				'username'   => $d->user_login ?? '',
				'email'      => $d->user_email ?? '',
				'createdAt'  => $d->created_at ? mysql_to_rfc3339( $d->created_at ) : null,
				'lastSeenAt' => $d->last_seen_at ? mysql_to_rfc3339( $d->last_seen_at ) : null,
			);
		}
		return $formatted;
	}

	/** @return array<int, array<string, mixed>> */
	private static function format_staff() {
		$users = get_users( array( 'capability' => Install::CAPABILITY ) );
		$staff = array();
		foreach ( $users as $u ) {
			$roles      = array_values( $u->roles );
			$role_label = in_array( 'administrator', $roles, true ) ? __( 'Administrator', 'zameria' ) : ( in_array( 'shop_manager', $roles, true ) ? __( 'Shop Manager', 'zameria' ) : ( in_array( 'zameria_cashier', $roles, true ) ? __( 'POS Cashier', 'zameria' ) : ucfirst( $roles[0] ?? 'Staff' ) ) );
			$staff[]    = array(
				'id'          => (int) $u->ID,
				'displayName' => $u->display_name,
				'username'    => $u->user_login,
				'email'       => $u->user_email,
				'roles'       => $roles,
				'roleLabel'   => $role_label,
				'editUrl'     => admin_url( 'user-edit.php?user_id=' . $u->ID ),
			);
		}
		return $staff;
	}

	public static function ajax_get_devices() {
		check_ajax_referer( 'zameria_admin', 'nonce' );
		if ( ! current_user_can( 'manage_woocommerce' ) ) {
			wp_send_json_error( array( 'message' => __( 'Not allowed.', 'zameria' ) ), 403 );
		}
		$devices = Auth::active_devices();
		wp_send_json_success(
			array(
				'devices'     => self::format_devices( $devices ),
				'deviceCount' => count( $devices ),
				'limits'      => Settings::plan_limits(),
			)
		);
	}

	public static function ajax_revoke_device() {
		check_ajax_referer( 'zameria_admin', 'nonce' );
		if ( ! current_user_can( 'manage_woocommerce' ) ) {
			wp_send_json_error( array( 'message' => __( 'Not allowed.', 'zameria' ) ), 403 );
		}
		$device_id = absint( $_POST['device_id'] ?? 0 );
		if ( ! $device_id ) {
			wp_send_json_error( array( 'message' => __( 'Invalid device ID.', 'zameria' ) ), 400 );
		}

		if ( false === Auth::revoke( $device_id ) ) {
			wp_send_json_error( array( 'message' => __( 'Could not sign out this user. Please try again.', 'zameria' ) ), 500 );
		}

		self::record_activity(
			__( 'User signed out', 'zameria' ),
			sprintf( __( 'POS session #%d was signed out.', 'zameria' ), $device_id )
		);

		$devices = Auth::active_devices();
		wp_send_json_success(
			array(
				'message'     => __( 'User signed out successfully.', 'zameria' ),
				'devices'     => self::format_devices( $devices ),
				'deviceCount' => count( $devices ),
			)
		);
	}

	public static function ajax_get_staff() {
		check_ajax_referer( 'zameria_admin', 'nonce' );
		if ( ! current_user_can( 'manage_woocommerce' ) ) {
			wp_send_json_error( array( 'message' => __( 'Not allowed.', 'zameria' ) ), 403 );
		}
		wp_send_json_success(
			array(
				'staff'       => self::format_staff(),
				'usersUrl'    => admin_url( 'users.php' ),
				'newUserUrl'  => admin_url( 'user-new.php?role=zameria_cashier' ),
			)
		);
	}
}
