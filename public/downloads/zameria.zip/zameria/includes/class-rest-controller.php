<?php
/**
 * REST API used by the POS app: /wp-json/zameria/v1/...
 *
 *   POST /auth/login     username, password, device_name -> token
 *   POST /auth/logout    revoke this device's token
 *   GET  /bootstrap      store info, currency, payment methods, categories, user, cursor
 *   GET  /products       full catalogue, paged (first sync / resync)
 *   GET  /changes        products changed since a cursor (every sync after that)
 *   POST /sales          upload sales made on the device (idempotent)
 *
 * A signed-in device may also call WooCommerce's own wc/v3 API with its token (see Auth::init).
 *
 * @package Zameria
 */

namespace Zameria;

defined( 'ABSPATH' ) || exit;

class Rest_Controller {

	const NAMESPACE_V1 = 'zameria/v1';

	public static function init() {
		add_action( 'rest_api_init', array( __CLASS__, 'register_routes' ) );
		add_filter( 'rest_post_dispatch', array( __CLASS__, 'no_cache' ), 10, 3 );
		add_filter( 'rest_allowed_cors_headers', array( __CLASS__, 'allow_token_header' ) );
		add_action( 'woocommerce_rest_insert_product_object', array( __CLASS__, 'handle_product_rest_brand' ), 10, 3 );
		add_action( 'woocommerce_rest_insert_product', array( __CLASS__, 'handle_product_rest_brand_after_save' ), 10, 3 );
		add_filter( 'woocommerce_rest_product_schema', array( __CLASS__, 'filter_product_schema' ) );
	}

	/**
	 * The hosted POS app (e.g. on Vercel) calls this store from another domain. WordPress already
	 * answers cross-origin REST requests; it only needs to accept the device-token header too.
	 * No cookies are involved (the app sends credentials: 'omit'), so this grants nothing extra.
	 */
	public static function allow_token_header( $headers ) {
		$headers[] = Auth::HEADER;
		return $headers;
	}

	public static function register_routes() {
		$auth = array( Auth::class, 'authenticate' );
        register_rest_route(self::NAMESPACE_V1,'/support/(?P<operation>start|conversation)',array('methods'=>array('GET','POST'),'callback'=>array(__CLASS__,'support'),'permission_callback'=>$auth));

		register_rest_route(
			self::NAMESPACE_V1,
			'/auth/login',
			array(
				'methods'             => 'POST',
				'callback'            => array( __CLASS__, 'login' ),
				'permission_callback' => '__return_true',
				'args'                => array(
					'username'    => array(
						'type'     => 'string',
						'required' => true,
					),
					'password'    => array(
						'type'     => 'string',
						'required' => true,
					),
					'device_name' => array(
						'type'    => 'string',
						'default' => 'Register',
					),
					'device_id'   => array(
						'type'    => 'integer',
						'default' => 0,
					),
					'register_id' => array(
						'type'    => 'integer',
						'default' => 0,
					),
				),
			)
		);

		register_rest_route(
			self::NAMESPACE_V1,
			'/auth/logout',
			array(
				'methods'             => 'POST',
				'callback'            => array( __CLASS__, 'logout' ),
				'permission_callback' => $auth,
			)
		);

		register_rest_route(
			self::NAMESPACE_V1,
			'/bootstrap',
			array(
				'methods'             => 'GET',
				'callback'            => array( __CLASS__, 'bootstrap' ),
				'permission_callback' => $auth,
			)
		);

		register_rest_route(
			self::NAMESPACE_V1,
			'/products',
			array(
				'methods'             => 'GET',
				'callback'            => array( __CLASS__, 'products' ),
				'permission_callback' => $auth,
				'args'                => array(
					'page'     => array(
						'type'    => 'integer',
						'default' => 1,
						'minimum' => 1,
					),
					'per_page' => array(
						'type'    => 'integer',
						'default' => 100,
						'minimum' => 1,
						'maximum' => 200,
					),
				),
			)
		);

		register_rest_route(
			self::NAMESPACE_V1,
			'/changes',
			array(
				'methods'             => 'GET',
				'callback'            => array( __CLASS__, 'changes' ),
				'permission_callback' => $auth,
				'args'                => array(
					'since' => array(
						'type'     => 'integer',
						'required' => true,
						'minimum'  => 0,
					),
					'limit' => array(
						'type'    => 'integer',
						'default' => 200,
						'minimum' => 1,
						'maximum' => 500,
					),
				),
			)
		);

		register_rest_route(
			self::NAMESPACE_V1,
			'/sales',
			array(
				'methods'             => 'POST',
				'callback'            => array( __CLASS__, 'sales' ),
				'permission_callback' => $auth,
			)
		);

		register_rest_route(
			self::NAMESPACE_V1,
			'/customers',
			array(
				'methods'             => 'GET',
				'callback'            => array( __CLASS__, 'customers' ),
				'permission_callback' => $auth,
				'args'                => array(
					'page'     => array(
						'type'    => 'integer',
						'default' => 1,
						'minimum' => 1,
					),
					'per_page' => array(
						'type'    => 'integer',
						'default' => 100,
						'minimum' => 1,
						'maximum' => 200,
					),
					'search'   => array(
						'type'    => 'string',
						'default' => '',
					),
					'role'     => array(
						'type'    => 'string',
						'default' => '',
					),
				),
			)
		);

		register_rest_route(
			self::NAMESPACE_V1,
			'/brands',
			array(
				'methods'             => 'GET',
				'callback'            => array( __CLASS__, 'brands' ),
				'permission_callback' => $auth,
			)
		);

		register_rest_route(
			self::NAMESPACE_V1,
			'/products/(?P<id>\d+)/brand',
			array(
				'methods'             => array( 'POST', 'PUT' ),
				'callback'            => array( __CLASS__, 'update_product_brand_route' ),
				'permission_callback' => $auth,
				'args'                => array(
					'brand_id' => array(
						'type'     => 'integer',
						'required' => true,
					),
				),
			)
		);

		if ( function_exists( 'register_rest_field' ) ) {
			register_rest_field(
				'product',
				'brands',
				array(
					'get_callback'    => array( __CLASS__, 'get_product_brands_field' ),
					'update_callback' => array( __CLASS__, 'update_product_brands_field' ),
					'schema'          => array(
						'description' => __( 'List of brands assigned to product.', 'zameria' ),
						'type'        => 'array',
						'items'       => array(
							'type' => array( 'integer', 'object' ),
						),
						'context'     => array( 'view', 'edit' ),
					),
				)
			);
			register_rest_field(
				'product',
				'brand_id',
				array(
					'update_callback' => array( __CLASS__, 'update_product_brand_id_field' ),
					'schema'          => array(
						'description' => __( 'Brand ID assigned to product.', 'zameria' ),
						'type'        => 'integer',
						'context'     => array( 'edit' ),
					),
				)
			);
		}
	}

	public static function login( \WP_REST_Request $request ) {
		$device_name = sanitize_text_field( $request['device_name'] );
		$device_id   = absint( $request['device_id'] ?? ( $request['register_id'] ?? 0 ) );
		$result      = Auth::login(
			(string) $request['username'],
			(string) $request['password'],
			'' !== $device_name ? substr( $device_name, 0, 100 ) : 'Register',
			$device_id
		);
		return is_wp_error( $result ) ? $result : rest_ensure_response( $result );
	}

	public static function logout() {
		$device = Auth::current_device();
		if ( $device ) {
			global $wpdb;
			$wpdb->update(
				"{$wpdb->prefix}zameria_devices",
				array( 'revoked_at' => gmdate( 'Y-m-d H:i:s' ) ),
				array( 'id' => (int) $device->id )
			);
		}
		return rest_ensure_response( array( 'ok' => true ) );
	}

	public static function bootstrap() {
		$access = Store_Access::check(true);
		$device      = Auth::current_device();
		$entitlement = Settings::get_entitlement();
        if (is_wp_error($access)) { $entitlement['status']='access_denied';$entitlement['is_licensed']=false; }
		$register_id = (int) ( ( $device && ! empty( $device->register_id ) ) ? $device->register_id : ( $device->id ?? 0 ) );
		return rest_ensure_response(
			array(
				'store'           => Settings::store(),
				'plan'            => $entitlement['plan'] ?? 'Business',
				'entitlement'     => $entitlement,
				'limits'          => Settings::plan_limits(),
				'currency'        => Settings::currency(),
				'payment_methods' => Settings::payment_methods(),
				'categories'      => Settings::categories(),
				'brands'          => Settings::brands(),
				// Starting point for /changes when a device downloads the catalogue for the first time.
				'cursor'          => Change_Log::current_cursor(),
				'user'            => Auth::user_payload( wp_get_current_user() ),
				'device'          => array(
					'id'          => $register_id,
					'register_id' => $register_id,
					'name'        => $device ? $device->name : 'Register',
				),
			)
		);
	}

	public static function products( \WP_REST_Request $request ) {
		$page     = (int) $request['page'];
		$per_page = (int) $request['per_page'];

		// Taken before reading products: anything that changes while the device is still
		// downloading will be picked up by the first /changes call after this cursor.
		$cursor = 1 === $page ? Change_Log::current_cursor() : null;

		$result = wc_get_products(
			array(
				'status'   => 'publish',
				'type'     => Product_Formatter::types(),
				'limit'    => $per_page,
				'page'     => $page,
				'orderby'  => 'ID',
				'order'    => 'ASC',
				'paginate' => true,
			)
		);

		$products = array();
		$current_offset = ( $page - 1 ) * $per_page;
		foreach ( $result->products as $product ) {
			if ( null !== $max_allowed_products && ( $current_offset + count( $products ) ) >= $max_allowed_products ) {
				break;
			}
			$products[] = Product_Formatter::format( $product );
		}

		$total_pages = (int) $result->max_num_pages;
		if ( null !== $max_allowed_products ) {
			$total_pages = min( $total_pages, (int) ceil( $max_allowed_products / $per_page ) );
		}

		return rest_ensure_response(
			array(
				'products'    => $products,
				'page'        => $page,
				'total_pages' => $total_pages,
				'cursor'      => $cursor,
				'plan_limit'  => $max_allowed_products,
			)
		);
	}

	public static function changes( \WP_REST_Request $request ) {
		$since = (int) $request['since'];

		if ( Change_Log::is_expired( $since ) ) {
			return rest_ensure_response( array( 'reset' => true ) );
		}

		$batch = Change_Log::since( $since, (int) $request['limit'] );
		$diff  = self::products_for_ids( $batch['ids'] );

		return rest_ensure_response(
			array(
				'reset'    => false,
				'products' => $diff['products'],
				'removed'  => $diff['removed'],
				'cursor'   => $batch['cursor'],
				'more'     => $batch['more'],
			)
		);
	}

	public static function sales( \WP_REST_Request $request ) {
		$sales = $request->get_param( 'sales' );
		if ( ! is_array( $sales ) ) {
			return new \WP_Error( 'zameria_invalid_sales', 'Expected a "sales" array.', array( 'status' => 400 ) );
		}
		if ( count( $sales ) > 50 ) {
			return new \WP_Error( 'zameria_too_many_sales', 'Send at most 50 sales per request.', array( 'status' => 400 ) );
		}

		$device   = Auth::current_device();
        $access=Store_Access::check();
		$results  = array();
		$affected = array();
		foreach ( $sales as $sale ) {
			if ( ! is_array( $sale ) ) {
				continue;
			}
            if (is_wp_error($access) && !Store_Access::queued_sale_allowed($sale,$device)) {
                $results[]=array('uuid'=>$sale['uuid'] ?? '', 'status'=>'error','message'=>'Store access is inactive. Only previously queued sales may upload.'); continue;
            }
			$results[] = Sale_Importer::import( $sale, $device );
			$affected  = array_merge( $affected, Sale_Importer::affected_item_ids( $sale ) );
		}

		// Send back fresh stock for what was just sold so the till never shows stale numbers.
		$diff = self::products_for_ids( array_unique( $affected ), true );

		return rest_ensure_response(
			array(
				'results'  => $results,
				'products' => $diff['products'],
			)
		);
	}

	/**
	 * Resolves changed product or variation ids to whole products (a changed variation sends its
	 * parent with all variations), or to removals when a product left the catalogue.
	 *
	 * @param int[] $ids
	 * @param bool  $refresh Re-read products, bypassing caches (used right after a stock change).
	 * @return array{products: array[], removed: int[]}
	 */
	private static function products_for_ids( array $ids, $refresh = false ) {
		$parents = array();
		$removed = array();

		foreach ( $ids as $id ) {
			if ( $refresh ) {
				clean_post_cache( $id );
			}
			$product = wc_get_product( $id );
			if ( $product && $product->is_type( 'variation' ) ) {
				$parent_id = $product->get_parent_id();
				if ( $refresh ) {
					clean_post_cache( $parent_id );
				}
				$product = wc_get_product( $parent_id );
				$id      = $parent_id;
			}

			if ( $product && Product_Formatter::is_listed( $product ) ) {
				$parents[ $product->get_id() ] = $product;
			} elseif ( ! $product || ! $product->is_type( 'variation' ) ) {
				$removed[] = (int) $id;
			}
		}

		return array(
			'products' => array_values( array_map( array( Product_Formatter::class, 'format' ), $parents ) ),
			'removed'  => array_values( array_unique( array_diff( $removed, array_keys( $parents ) ) ) ),
		);
	}

	public static function customers( \WP_REST_Request $request ) {
		$page           = (int) $request['page'];
		$per_page       = (int) $request['per_page'];
		$search         = sanitize_text_field( (string) $request['search'] );
		$requested_role = sanitize_text_field( (string) $request['role'] );
        if (!current_user_can('list_users')) $requested_role='customer';

		$args = array(
			'number'   => $per_page,
			'paged'    => $page,
			'orderby'  => 'ID',
			'order'    => 'ASC',
		);

		if ( 'all' === $requested_role ) {
			// Query all registered users without role restriction
		} elseif ( ! empty( $requested_role ) ) {
			$args['role__in'] = array_map( 'trim', explode( ',', $requested_role ) );
		} else {
			// Default to standard customer-eligible store roles
			$args['role__in'] = array( 'customer', 'subscriber' );
		}

		if ( '' !== $search ) {
			$args['search']         = '*' . $search . '*';
			$args['search_columns'] = array( 'user_login', 'user_nicename', 'user_email', 'display_name' );
		}

		$query       = new \WP_User_Query( $args );
		$total_users = (int) $query->get_total();
		$total_pages = $total_users > 0 ? (int) ceil( $total_users / $per_page ) : 1;

		$customers = array();
		foreach ( $query->get_results() as $user ) {
			$meta_first = (string) get_user_meta( $user->ID, 'billing_first_name', true );
			$meta_last  = (string) get_user_meta( $user->ID, 'billing_last_name', true );
			$first_name = $user->first_name ?: $meta_first;
			$last_name  = $user->last_name ?: $meta_last;

			if ( empty( $first_name ) && empty( $last_name ) && ! empty( $user->display_name ) && $user->display_name !== $user->user_login && $user->display_name !== $user->user_email ) {
				$parts = explode( ' ', trim( $user->display_name ) );
				$first_name = array_shift( $parts );
				if ( empty( $last_name ) && ! empty( $parts ) ) {
					$last_name = implode( ' ', $parts );
				}
			}

			$billing    = array(
				'first_name' => html_entity_decode( $first_name ?: ( $meta_first ?: '' ), ENT_QUOTES, 'UTF-8' ),
				'last_name'  => html_entity_decode( $last_name ?: ( $meta_last ?: '' ), ENT_QUOTES, 'UTF-8' ),
				'company'    => html_entity_decode( (string) get_user_meta( $user->ID, 'billing_company', true ), ENT_QUOTES, 'UTF-8' ),
				'address_1'  => html_entity_decode( (string) get_user_meta( $user->ID, 'billing_address_1', true ), ENT_QUOTES, 'UTF-8' ),
				'address_2'  => html_entity_decode( (string) get_user_meta( $user->ID, 'billing_address_2', true ), ENT_QUOTES, 'UTF-8' ),
				'city'       => html_entity_decode( (string) get_user_meta( $user->ID, 'billing_city', true ), ENT_QUOTES, 'UTF-8' ),
				'state'      => (string) get_user_meta( $user->ID, 'billing_state', true ),
				'postcode'   => (string) get_user_meta( $user->ID, 'billing_postcode', true ),
				'country'    => (string) get_user_meta( $user->ID, 'billing_country', true ),
				'email'      => (string) get_user_meta( $user->ID, 'billing_email', true ) ?: $user->user_email,
				'phone'      => (string) get_user_meta( $user->ID, 'billing_phone', true ),
			);

			$ship_first = (string) get_user_meta( $user->ID, 'shipping_first_name', true ) ?: $first_name;
			$ship_last  = (string) get_user_meta( $user->ID, 'shipping_last_name', true ) ?: $last_name;
			$shipping   = array(
				'first_name' => html_entity_decode( $ship_first ?: $first_name, ENT_QUOTES, 'UTF-8' ),
				'last_name'  => html_entity_decode( $ship_last ?: $last_name, ENT_QUOTES, 'UTF-8' ),
				'company'    => html_entity_decode( (string) get_user_meta( $user->ID, 'shipping_company', true ), ENT_QUOTES, 'UTF-8' ),
				'address_1'  => html_entity_decode( (string) get_user_meta( $user->ID, 'shipping_address_1', true ), ENT_QUOTES, 'UTF-8' ),
				'address_2'  => html_entity_decode( (string) get_user_meta( $user->ID, 'shipping_address_2', true ), ENT_QUOTES, 'UTF-8' ),
				'city'       => html_entity_decode( (string) get_user_meta( $user->ID, 'shipping_city', true ), ENT_QUOTES, 'UTF-8' ),
				'state'      => (string) get_user_meta( $user->ID, 'shipping_state', true ),
				'postcode'   => (string) get_user_meta( $user->ID, 'shipping_postcode', true ),
				'country'    => (string) get_user_meta( $user->ID, 'shipping_country', true ),
				'phone'      => (string) get_user_meta( $user->ID, 'shipping_phone', true ) ?: $billing['phone'],
			);

			$last_update = get_user_meta( $user->ID, 'last_update', true );

			$orders_count = 0;
			$total_spent  = '0.00';
			if ( class_exists( '\WC_Customer' ) ) {
				$wc_customer = new \WC_Customer( $user->ID );
				if ( $wc_customer ) {
					$orders_count = (int) $wc_customer->get_order_count();
					$total_spent  = (string) $wc_customer->get_total_spent();
				}
			}

            // Count purchase evidence explicitly; registrations and pending/held
            // orders must not populate the purchaser directory.
            $purchases_count = null;
            if ( function_exists( 'wc_get_orders' ) ) {
                $purchases = wc_get_orders( array(
                    'customer_id' => (int) $user->ID,
                    'status'      => array( 'wc-completed', 'wc-processing', 'wc-refunded' ),
                    'limit'       => 1,
                    'paginate'    => true,
                    'return'      => 'ids',
                ) );
                if ( is_object( $purchases ) && isset( $purchases->total ) ) $purchases_count = (int) $purchases->total;
            }

			$user_roles = (array) $user->roles;
			$primary_role = ! empty( $user_roles ) ? reset( $user_roles ) : 'customer';

			$customers[] = array(
				'id'            => (int) $user->ID,
				'date_created'  => wc_rest_prepare_date_response( $user->user_registered ),
				'date_modified' => wc_rest_prepare_date_response( $last_update ?: $user->user_registered ),
				'email'         => $user->user_email,
				'first_name'    => html_entity_decode( $first_name, ENT_QUOTES, 'UTF-8' ),
				'last_name'     => html_entity_decode( $last_name, ENT_QUOTES, 'UTF-8' ),
				'display_name'  => html_entity_decode( $user->display_name ?: ( trim( $first_name . ' ' . $last_name ) ?: $user->user_login ), ENT_QUOTES, 'UTF-8' ),
				'role'          => $primary_role,
				'username'      => $user->user_login,
				'billing'       => $billing,
				'shipping'      => $shipping,
				'orders_count'  => $orders_count,
                'purchases_count' => $purchases_count,
				'total_spent'   => $total_spent,
				'avatar_url'    => get_avatar_url( $user->ID ),
			);
		}

		return rest_ensure_response(
			array(
				'customers'   => $customers,
				'page'        => $page,
				'total_pages' => $total_pages,
				'total_items' => $total_users,
			)
		);
	}

	public static function brands() {
		return rest_ensure_response(
			array(
				'brands' => Settings::brands(),
			)
		);
	}

	/**
	 * Intercepts product creation and updates via WooCommerce REST API to assign brand terms
	 * to whichever brand taxonomy is currently active on the store.
	 *
	 * @param \WC_Product      $product  The product object.
	 * @param \WP_REST_Request $request  The REST request.
	 * @param bool             $creating True when creating a product, false when updating.
	 */
	public static function handle_product_rest_brand( $product, $request, $creating ) {
		$brand_id = null;

		if ( ! empty( $request['brands'] ) && is_array( $request['brands'] ) ) {
			$first = reset( $request['brands'] );
			$brand_id = is_array( $first ) && isset( $first['id'] ) ? (int) $first['id'] : (int) $first;
		} elseif ( isset( $request['brand_id'] ) ) {
			$brand_id = (int) $request['brand_id'];
		}

		if ( null !== $brand_id ) {
			$tax = Settings::brand_taxonomy();
			if ( taxonomy_exists( $tax ) ) {
				$pid = is_a( $product, 'WC_Product' ) ? $product->get_id() : (int) $product;
				if ( $pid > 0 ) {
					if ( $brand_id > 0 ) {
						wp_set_object_terms( $pid, array( $brand_id ), $tax, false );
					} else {
						wp_set_object_terms( $pid, array(), $tax, false );
					}
				}
			}
		}
	}

	/**
	 * Ensures brand assignment succeeds after the product has been saved and assigned an ID in database.
	 */
	public static function handle_product_rest_brand_after_save( $product_or_post, $request, $creating ) {
		$product_id = is_a( $product_or_post, 'WC_Product' ) ? $product_or_post->get_id() : (int) $product_or_post->ID;
		if ( ! $product_id ) {
			return;
		}

		$brand_id = null;
		if ( ! empty( $request['brands'] ) && is_array( $request['brands'] ) ) {
			$first = reset( $request['brands'] );
			$brand_id = is_array( $first ) && isset( $first['id'] ) ? (int) $first['id'] : (int) $first;
		} elseif ( isset( $request['brand_id'] ) ) {
			$brand_id = (int) $request['brand_id'];
		}

		if ( null !== $brand_id ) {
			$tax = Settings::brand_taxonomy();
			if ( taxonomy_exists( $tax ) ) {
				if ( $brand_id > 0 ) {
					wp_set_object_terms( $product_id, array( $brand_id ), $tax, false );
				} else {
					wp_set_object_terms( $product_id, array(), $tax, false );
				}
			}
		}
	}

	/**
	 * Dedicated endpoint for associating a brand with a product.
	 */
	public static function update_product_brand_route( \WP_REST_Request $request ) {
		$product_id = (int) $request['id'];
		$brand_id   = (int) $request['brand_id'];
		$tax        = Settings::brand_taxonomy();

        if (!current_user_can('edit_products') || !current_user_can('edit_post',$product_id)) return new \WP_Error('zameria_product_forbidden','Product editing is not permitted.',array('status'=>403));
        if (!wc_get_product($product_id)) return new \WP_Error('zameria_product_missing','Product not found.',array('status'=>404));

		if ( ! taxonomy_exists( $tax ) ) {
			return new \WP_Error( 'rest_no_taxonomy', __( 'Brand taxonomy not registered', 'zameria' ), array( 'status' => 400 ) );
		}

		if ( $brand_id > 0 ) {
			if (!term_exists($brand_id,$tax)) return new \WP_Error('zameria_brand_missing','Brand not found.',array('status'=>404));
			$result=wp_set_object_terms( $product_id, array( $brand_id ), $tax, false );
		} else {
			$result=wp_set_object_terms( $product_id, array(), $tax, false );
		}

		$terms = get_the_terms( $product_id, $tax );
		$brand = null;
		if ( ! empty( $terms ) && ! is_wp_error( $terms ) ) {
			$term = reset( $terms );
			$brand = array(
				'id'       => (int) $term->term_id,
				'name'     => wp_specialchars_decode( $term->name, ENT_QUOTES ),
				'slug'     => (string) $term->slug,
				'taxonomy' => $tax,
			);
		}

        if (is_wp_error($result)) return $result;
		Change_Log::queue_id( $product_id );

		return rest_ensure_response(
			array(
				'ok'         => true,
				'product_id' => $product_id,
				'brand'      => $brand,
			)
		);
	}

    public static function support($request) {
        $device=Auth::current_device();$key='zameria_support_device_'.(int)$device->id;$session=get_transient($key);
        $operation=$request['operation'];
        if ($operation==='start' && $request->get_method()!=='POST') return new \WP_Error('invalid_method','Use POST.',array('status'=>405));
        if ($operation==='start' && !$session) {
            $user=wp_get_current_user();$message=trim((string)$request->get_param('message'));
            if (!$message || strlen($message)>4000) return new \WP_Error('invalid_message','Enter a message of at most 4000 bytes.',array('status'=>400));
            $data=Cloud_Account::request('/store/support/start',array('name'=>$user->display_name,'email'=>$user->user_email,'message'=>$message),'',Store_Access::headers());
            if(is_wp_error($data))return $data;
            if(empty($data['token'])||empty($data['conversation']['id']))return new \WP_Error('invalid_support','Invalid support response.',array('status'=>502));
            set_transient($key,array('id'=>$data['conversation']['id'],'token'=>$data['token']),30*DAY_IN_SECONDS);
            return rest_ensure_response(array('conversation'=>$data['conversation']));
        }
        if (!$session) return rest_ensure_response(array('conversation'=>null));
        $body=null;
        if($request->get_method()==='POST')$body=array('message'=>(string)$request->get_param('message'),'action'=>(string)$request->get_param('action'));
        $data=Cloud_Account::request('/support/conversation?id='.rawurlencode($session['id']),$body,$session['token']);
        if(is_wp_error($data))return $data;
        return rest_ensure_response(array('conversation'=>$data['conversation'] ?? null));
    }
	public static function get_product_brands_field( $product_data ) {
		$product_id = isset( $product_data['id'] ) ? (int) $product_data['id'] : 0;
		if ( ! $product_id ) {
			return array();
		}
		$tax = Settings::brand_taxonomy();
		if ( ! taxonomy_exists( $tax ) ) {
			return array();
		}
		$terms = get_the_terms( $product_id, $tax );
		if ( empty( $terms ) || is_wp_error( $terms ) ) {
			return array();
		}
		return array_values(
			array_map(
				function( $term ) use ( $tax ) {
					return array(
						'id'       => (int) $term->term_id,
						'name'     => wp_specialchars_decode( $term->name, ENT_QUOTES ),
						'slug'     => $term->slug,
						'taxonomy' => $tax,
					);
				},
				$terms
			)
		);
	}

	public static function update_product_brands_field( $value, $product_object ) {
		$product_id = is_a( $product_object, 'WC_Product' ) ? $product_object->get_id() : (int) $product_object->ID;
		if ( ! $product_id ) {
			return;
		}
		$brand_id = null;
		if ( is_array( $value ) && ! empty( $value ) ) {
			$first = reset( $value );
			$brand_id = is_array( $first ) && isset( $first['id'] ) ? (int) $first['id'] : (int) $first;
		}
		if ( null !== $brand_id ) {
			$tax = Settings::brand_taxonomy();
			if ( taxonomy_exists( $tax ) ) {
				wp_set_object_terms( $product_id, $brand_id > 0 ? array( $brand_id ) : array(), $tax, false );
			}
		}
	}

	public static function update_product_brand_id_field( $value, $product_object ) {
		$product_id = is_a( $product_object, 'WC_Product' ) ? $product_object->get_id() : (int) $product_object->ID;
		if ( ! $product_id ) {
			return;
		}
		$brand_id = (int) $value;
		$tax = Settings::brand_taxonomy();
		if ( taxonomy_exists( $tax ) ) {
			wp_set_object_terms( $product_id, $brand_id > 0 ? array( $brand_id ) : array(), $tax, false );
		}
	}

	public static function filter_product_schema( $schema ) {
		if ( isset( $schema['properties'] ) ) {
			if ( ! isset( $schema['properties']['brands'] ) ) {
				$schema['properties']['brands'] = array(
					'description' => __( 'List of brands.', 'zameria' ),
					'type'        => 'array',
					'items'       => array(
						'type' => array( 'integer', 'object' ),
					),
					'context'     => array( 'view', 'edit' ),
				);
			}
			if ( ! isset( $schema['properties']['brand_id'] ) ) {
				$schema['properties']['brand_id'] = array(
					'description' => __( 'Brand ID.', 'zameria' ),
					'type'        => 'integer',
					'context'     => array( 'edit' ),
				);
			}
		}
		return $schema;
	}

	/**
	 * Stops page caches (LiteSpeed on most cPanel hosts, Cloudflare, etc.) from serving stale stock.
	 */
	public static function no_cache( $response, $server, $request ) {
		if ( 0 === strpos( $request->get_route(), '/' . self::NAMESPACE_V1 ) && $response instanceof \WP_REST_Response ) {
			$response->header( 'Cache-Control', 'no-store, no-cache, must-revalidate, max-age=0' );
			$response->header( 'X-LiteSpeed-Cache-Control', 'no-cache' );
		}
		return $response;
	}
}
