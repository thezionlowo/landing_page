<?php
/**
 * Activation, database tables and roles.
 *
 * @package Zameria
 */

namespace Zameria;

defined( 'ABSPATH' ) || exit;

class Install {

	const DB_VERSION = '4';
	const CAPABILITY = 'zameria_use_pos';

	public static function activate() {
		self::create_tables();
		self::add_roles();
		App_Server::add_rewrite_rules();
		flush_rewrite_rules();

		if ( ! wp_next_scheduled( 'zameria_daily' ) ) {
			wp_schedule_event( time() + HOUR_IN_SECONDS, 'daily', 'zameria_daily' );
		}

		if ( self::retire_duplicate_sessions() ) {
			update_option( 'zameria_db_version', self::DB_VERSION );
		}
	}

	public static function deactivate() {
		wp_clear_scheduled_hook( 'zameria_daily' );
		flush_rewrite_rules();
	}

	/**
	 * Covers plugin updates that happen without re-activation.
	 */
	public static function maybe_upgrade() {
		if ( get_option( 'zameria_db_version' ) === self::DB_VERSION ) {
			return;
		}
		self::create_tables();
		self::add_roles();
		if ( self::retire_duplicate_sessions() ) {
			update_option( 'zameria_db_version', self::DB_VERSION );
		}
	}

	/** Keep the newest session per account on upgrade; retain history and sales. */
	private static function retire_duplicate_sessions() {
		global $wpdb;
		$lock = 'zameria_login_' . md5( $wpdb->prefix . '|' . DB_NAME );
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching -- Versioned migration of custom session rows shares the admission lock; reads and writes must see current concurrent sessions.
		if ( 1 !== (int) $wpdb->get_var( $wpdb->prepare( 'SELECT GET_LOCK(%s, %d)', $lock, 10 ) ) ) return false;
		try {
			// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching -- Versioned migration of custom session rows shares the admission lock; reads and writes must see current concurrent sessions.
			return false !== $wpdb->query( $wpdb->prepare(
				"UPDATE {$wpdb->prefix}zameria_devices older
				 INNER JOIN {$wpdb->prefix}zameria_devices newer
				 ON newer.user_id = older.user_id AND newer.id > older.id AND newer.revoked_at IS NULL
				 SET older.revoked_at = %s WHERE older.revoked_at IS NULL",
				gmdate( 'Y-m-d H:i:s' )
			) );
		} finally {
			// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching -- Versioned migration of custom session rows shares the admission lock; reads and writes must see current concurrent sessions.
			$wpdb->get_var( $wpdb->prepare( 'SELECT RELEASE_LOCK(%s)', $lock ) );
		}
	}

	private static function create_tables() {
		global $wpdb;

		require_once ABSPATH . 'wp-admin/includes/upgrade.php';

		if (class_exists(Purchaser_Index::class)) Purchaser_Index::install();

		$collate = $wpdb->get_charset_collate();

		// Append-only log of product/stock changes. Its auto-increment id is the sync cursor
		// devices use to fetch "everything that changed since I last looked".
		dbDelta(
			"CREATE TABLE {$wpdb->prefix}zameria_changes (
				id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
				object_id bigint(20) unsigned NOT NULL,
				changed_at datetime NOT NULL,
				PRIMARY KEY  (id),
				KEY changed_at (changed_at)
			) $collate;"
		);

		// One row per signed-in POS session. register_id groups sessions belonging to the same register.
		dbDelta(
			"CREATE TABLE {$wpdb->prefix}zameria_devices (
				id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
				register_id bigint(20) unsigned NOT NULL DEFAULT 0,
				user_id bigint(20) unsigned NOT NULL,
				name varchar(100) NOT NULL,
				token_hash char(64) NOT NULL,
				created_at datetime NOT NULL,
				last_seen_at datetime NULL,
				revoked_at datetime NULL,
				PRIMARY KEY  (id),
				UNIQUE KEY token_hash (token_hash),
				KEY register_id (register_id),
				KEY user_id (user_id),
				KEY user_active (user_id,revoked_at,id)
			) $collate;"
		);

		// Backfill legacy rows where register_id is 0: assign the earliest id for each distinct (name, user_id) as register_id
		$table_name = "{$wpdb->prefix}zameria_devices";
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching -- Version-gated migration touches only the plugin-owned session schema; identifiers are prepared and schema reads/writes cannot be cached.
		if ( $wpdb->get_var( $wpdb->prepare( 'SHOW TABLES LIKE %s', $wpdb->esc_like( $table_name ) ) ) === $table_name ) {
			$col_exists = $wpdb->get_results( $wpdb->prepare( 'SHOW COLUMNS FROM %i LIKE %s', $table_name, 'register_id' ) );
			if ( empty( $col_exists ) ) {
				// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching,WordPress.DB.DirectDatabaseQuery.SchemaChange -- Version-gated migration touches only the plugin-owned session schema; identifiers are prepared and schema reads/writes cannot be cached.
				$wpdb->query( $wpdb->prepare( 'ALTER TABLE %i ADD COLUMN register_id bigint(20) unsigned NOT NULL DEFAULT 0 AFTER id, ADD KEY register_id (register_id)', $table_name ) );
			}
			// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching -- Version-gated migration touches only the plugin-owned session schema; identifiers are prepared and schema reads/writes cannot be cached.
			$wpdb->query(
				$wpdb->prepare(
				'UPDATE %i d
				JOIN (
					SELECT name, user_id, MIN(id) AS canonical_id 
					FROM %i
					GROUP BY name, user_id
				) canon ON d.name = canon.name AND d.user_id = canon.user_id
				SET d.register_id = canon.canonical_id
				WHERE d.register_id = 0 OR d.register_id IS NULL',
				$table_name,
				$table_name
				)
			);
		}

		// Maps each offline sale's device-generated UUID to the WooCommerce order it became.
		// The primary key makes sale uploads idempotent: a retried upload never creates a second order.
		dbDelta(
			"CREATE TABLE {$wpdb->prefix}zameria_sales (
				uuid char(36) NOT NULL,
				order_id bigint(20) unsigned NOT NULL DEFAULT 0,
				device_id bigint(20) unsigned NOT NULL,
				created_at datetime NOT NULL,
				PRIMARY KEY  (uuid),
				KEY order_id (order_id)
			) $collate;"
		);
	}

	private static function add_roles() {
		foreach ( array( 'administrator', 'shop_manager' ) as $role_name ) {
			$role = get_role( $role_name );
			if ( $role ) {
				$role->add_cap( self::CAPABILITY );
			}
		}

		if ( ! get_role( 'zameria_cashier' ) ) {
			add_role(
				'zameria_cashier',
				__( 'POS Cashier', 'zameria' ),
				array(
					'read'           => true,
					self::CAPABILITY => true,
				)
			);
		}
	}
}
