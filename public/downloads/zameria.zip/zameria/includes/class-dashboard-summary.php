<?php
/** Bounded WooCommerce report work, independent of each browser's history import. */
namespace Zameria;
defined('ABSPATH') || exit;
class Dashboard_Summary {
    const REVISION = 'zameria_summary_revision';
    public static function init() {
        foreach(array('woocommerce_new_order','woocommerce_update_order','woocommerce_order_status_changed','woocommerce_order_refunded','woocommerce_trash_order','woocommerce_delete_order','woocommerce_refund_deleted') as $hook) add_action($hook,array(__CLASS__,'invalidate'),30,0);
        add_action('zameria_summary_batch',array(__CLASS__,'work'),10,1);
        add_action('rest_api_init',function(){register_rest_route('zameria/v1','/dashboard-summary',array('methods'=>'GET','callback'=>array(__CLASS__,'get'),'permission_callback'=>array(__CLASS__,'permission')));});
    }
    public static function permission($request) {
        $auth=Auth::authenticate($request);if(is_wp_error($auth))return $auth;
        return current_user_can('manage_woocommerce') ? true : new \WP_Error('zameria_report_forbidden','Store reports require manager access.',array('status'=>403));
    }
    public static function invalidate() { update_option(self::REVISION,uniqid('',true),false); }
    private static function schedule($key) {
        $args=array($key);
        if(function_exists('as_has_scheduled_action')&&function_exists('as_schedule_single_action')) {
            if(!as_has_scheduled_action('zameria_summary_batch',$args,'zameria')) as_schedule_single_action(time()+1,'zameria_summary_batch',$args,'zameria');
        } elseif(!wp_next_scheduled('zameria_summary_batch',$args)) wp_schedule_single_event(time()+1,'zameria_summary_batch',$args);
    }
    public static function get($request) {
        $range=array();foreach(array('start','end','previous_start','previous_end') as $field) {
            $text=(string)$request[$field];$value=strtotime($text);
            if(!$value || !preg_match('/^\d{4}-\d\d-\d\dT/',$text))return new \WP_Error('zameria_report_range','A valid report date range is required.',array('status'=>400));
            $range[$field]=$value;
        }
        if($range['end']<$range['start']||$range['previous_end']<$range['previous_start']||max($range['end'],$range['previous_end'])-min($range['start'],$range['previous_start'])>740*DAY_IN_SECONDS)return new \WP_Error('zameria_report_range','Report range is invalid or exceeds two years.',array('status'=>400));
        try{$zone=new \DateTimeZone((string)$request['timezone']);}catch(\Exception $e){return new \WP_Error('zameria_report_zone','A valid report timezone is required.',array('status'=>400));}
        $range['timezone']=$zone->getName();$range['grouping']=in_array($request['grouping'],array('hour','day','month'),true)?$request['grouping']:'day';
        $uid=get_current_user_id();$key=md5(wp_json_encode(array($uid,wp_get_current_user()->roles,$range)));
        $state=get_transient('zameria_report_'.$key);$revision=(string)get_option(self::REVISION,'0');
        if(!$state||(!empty($state['complete'])&&$state['revision']!==$revision)) {
            $state=array('uid'=>$uid,'range'=>$range,'revision'=>$revision,'page'=>1,'complete'=>false,'products'=>array(),'buyers'=>array(),'series'=>array(),'payments'=>array(),'metrics'=>array('totalSales'=>0,'websiteSales'=>0,'posSales'=>0,'websiteOrdersCount'=>0,'posOrdersCount'=>0,'completedOrdersCount'=>0,'totalOrdersCount'=>0,'pendingOrdersCount'=>0,'itemsSold'=>0,'prevTotalSales'=>0));
            set_transient('zameria_report_'.$key,$state,3600);
        }
        if(empty($state['complete'])) {
            self::work($key);self::schedule($key);$state=get_transient('zameria_report_'.$key);
        }
        $last=get_transient('zameria_report_ready_'.$key);
        return rest_ensure_response(array('status'=>!empty($state['complete'])?'ready':'building','summary'=>$last?:null,'fresh'=>!empty($state['complete'])&&$state['revision']===$revision,'pages_processed'=>max(0,(int)($state['page']??1)-1)));
    }
    public static function work($key) {
        if(!preg_match('/^[a-f0-9]{32}$/',(string)$key))return;
        global $wpdb;$lock='zameria_report_'.md5($wpdb->prefix.$key);
        // phpcs:ignore WordPress.DB.DirectDatabaseQuery -- A short advisory lock prevents browser polling and scheduled jobs from aggregating a page twice.
        if(1!==(int)$wpdb->get_var($wpdb->prepare('SELECT GET_LOCK(%s,0)',$lock)))return;
        $previous=get_current_user_id();
        try {
            $state=get_transient('zameria_report_'.$key);if(!$state||!empty($state['complete']))return;
            wp_set_current_user($state['uid']);if(!current_user_can('manage_woocommerce'))return;
            $range=$state['range'];$from=min($range['start'],$range['previous_start']);$to=max($range['end'],$range['previous_end']);
            // WooCommerce selects HPOS or legacy storage. No parallel source-of-truth table.
            $response=wc_get_orders(array('type'=>'shop_order','status'=>array_keys(wc_get_order_statuses()),'date_created'=>$from.'...'.$to,'limit'=>100,'page'=>$state['page'],'orderby'=>'ID','order'=>'ASC','paginate'=>true));
            if(!is_object($response)||!isset($response->orders,$response->max_num_pages))throw new \RuntimeException('Store report page was invalid');
            foreach($response->orders as $order)if(Auth::can_read_order($order))self::add($state,$order);
            $state['page']++;
            if($state['page']>max(1,(int)$response->max_num_pages)) {
                // Never publish a mixed report if source orders changed while it was being built.
                if($state['revision']!==(string)get_option(self::REVISION,'0')) { delete_transient('zameria_report_'.$key);return; }
                $state['complete']=true;$summary=self::finish($state);$summary['verifiedAt']=gmdate('c');
                set_transient('zameria_report_ready_'.$key,$summary,DAY_IN_SECONDS);
            }
            set_transient('zameria_report_'.$key,$state,3600);
            if(!$state['complete'])self::schedule($key);
        } finally {
            wp_set_current_user($previous);
            // phpcs:ignore WordPress.DB.DirectDatabaseQuery -- Release exactly the report lock owned by this worker.
            $wpdb->get_var($wpdb->prepare('SELECT RELEASE_LOCK(%s)',$lock));
        }
    }
    public static function add(&$state,$order) {
        $created=$order->get_date_created();if(!$created)return;
        $time=$created->getTimestamp();$range=$state['range'];$status=$order->get_status();$purchase_statuses=class_exists(Rest_Controller::class)?Rest_Controller::purchase_statuses():array('processing','completed');
        $paid=!in_array($status,array('pending','on-hold','cancelled','failed','trash','refunded'),true) && (in_array($status,$purchase_statuses,true)||(method_exists($order,'get_date_paid')&&(bool)$order->get_date_paid()));
        $amount=(int)round(max(0,(float)$order->get_total()-(float)$order->get_total_refunded())*100);
        if($time<$range['start']||$time>$range['end']) { if($paid&&$time>=$range['previous_start']&&$time<=$range['previous_end'])$state['metrics']['prevTotalSales']+=$amount;return; }
        $m=&$state['metrics'];$m['totalOrdersCount']++;if(in_array($status,array('pending','on-hold'),true))$m['pendingOrdersCount']++;
        $buyer=$order->get_customer_id()?'id-'.$order->get_customer_id():($order->get_billing_email()?'email-'.strtolower(trim($order->get_billing_email())):'walk-in');$state['buyers'][$buyer]=true;
        if(!$paid)return;
        $web=$order->get_meta('_zameria_pos_order')!=='yes';$channel=$web?'website':'pos';
        $m['totalSales']+=$amount;$m[$channel.'Sales']+=$amount;$m[$channel.'OrdersCount']++;$m['completedOrdersCount']++;
        $date=(new \DateTimeImmutable('@'.$time))->setTimezone(new \DateTimeZone($range['timezone']));
        $key=$date->format($range['grouping']==='hour'?'H':($range['grouping']==='month'?'Y-m':'Y-m-d'));
        if(!isset($state['series'][$key]))$state['series'][$key]=array('website'=>0,'pos'=>0,'total'=>0);
        $state['series'][$key][$channel]+=$amount;$state['series'][$key]['total']+=$amount;
        $splits=$order->get_meta('_zameria_payment_splits');
        if(!is_array($splits)||!$splits)$splits=array(array('method'=>$order->get_payment_method(),'amount'=>(float)$order->get_total()));
        $ratio=(float)$order->get_total()>0?$amount/((float)$order->get_total()*100):0;
        foreach($splits as $split) {
            $method=preg_replace('/^zameria_/','',strtolower((string)($split['method']??'')));
            $payment=in_array($method,array('cash','cod'),true)?'cash':(in_array($method,array('transfer','bacs','bank_transfer'),true)?'transfer':(in_array($method,array('pos','card','terminal'),true)||!$web?'pos':null));
            if($payment){if(!isset($state['payments'][$payment]))$state['payments'][$payment]=array('amount'=>0,'count'=>0);$state['payments'][$payment]['amount']+=(int)round((float)($split['amount']??0)*100*$ratio);$state['payments'][$payment]['count']++;}
        }
        foreach($order->get_items() as $id=>$item) {
            $units=max(0,$item->get_quantity()+$order->get_qty_refunded_for_item($id));$m['itemsSold']+=$units;
            $revenue=(int)round(max(0,(float)$item->get_total()-(float)$order->get_total_refunded_for_item($id))*100);
            $product_key=$item->get_product_id()?:$item->get_name();
            if(!isset($state['products'][$product_key]))$state['products'][$product_key]=array('name'=>$item->get_name(),'sku'=>'N/A','unitsSold'=>0,'revenue'=>0,'hasWebsite'=>false,'hasPOS'=>false);
            $product=&$state['products'][$product_key];$product['unitsSold']+=$units;$product['revenue']+=$revenue;$product[$web?'hasWebsite':'hasPOS']=true;unset($product);
        }
    }
    public static function finish($state) {
        $m=$state['metrics'];$total=$m['totalSales'];$previous=$m['prevTotalSales'];$change=$previous?($total-$previous)/$previous*100:($total?100:0);
        $m['websiteSalesPct']=$total?round($m['websiteSales']/$total*100,1):0;$m['posSalesPct']=$total?round($m['posSales']/$total*100,1):0;
        $m['aov']=$m['completedOrdersCount']?(int)round($total/$m['completedOrdersCount']):0;$m['uniqueCustomersCount']=count($state['buyers']);
        $m['salesChangePct']=round(abs($change),1);$m['salesChangeSign']=$change>0?'pos':($change<0?'neg':'neutral');
        $products=array_values($state['products']);usort($products,function($a,$b){return $b['revenue']<=>$a['revenue'];});
        return array('metrics'=>$m,'series'=>$state['series'],'payments'=>$state['payments'],'topProducts'=>array_slice($products,0,6));
    }
}
