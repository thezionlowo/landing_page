<?php
namespace Zameria;
defined('ABSPATH') || exit;
/** Durable store verification, independent of an owner's browser session. */
class Store_Access {
    const CREDENTIALS = 'zameria_store_credentials';
    const VERIFIED_AT = 'zameria_access_verified_at';
    const DENIED_AT = 'zameria_access_denied_at';
    const REFRESH_SECONDS = 60;
    const OFFLINE_GRACE = 86400;
    public static function remember($entitlement, $merchant_token) {
        if (!in_array($entitlement['status'] ?? '', array('trial_active','paid_active','gifted_active'), true)) { self::deny($entitlement['status'] ?? 'access_denied'); return; }
        $key = $entitlement['license_key'] ?? '';
        if (!$key) $key=Settings::get_entitlement()['license_key'] ?? '';
        if (!$key || !$merchant_token) return self::error('Owner sign-in is required to provision the store.');
        $issued = Cloud_Account::request('/account/store/credentials', array('store_url'=>home_url('/'),'license_key'=>$key), $merchant_token);
        if (is_wp_error($issued)) return $issued;
        if (empty($issued['installation_token'])) return self::error('Store credential provisioning was not confirmed.');
        update_option(self::CREDENTIALS, array('license_key'=>$key,'installation_token'=>$issued['installation_token']), false);
        $entitlement['license_key']=$key;
        $entitlement['trial_start'] = $entitlement['trial_start'] ?? $entitlement['trial']['started_at'] ?? null;
        $entitlement['trial_end'] = $entitlement['trial_end'] ?? $entitlement['trial']['expires_at'] ?? null;
        if ($entitlement['status']==='trial_active') $entitlement['plan']='Business';
        Settings::set_entitlement($entitlement);
        update_option(self::VERIFIED_AT, time(), false); delete_option(self::DENIED_AT);
        return true;
    }
    public static function headers() {
        $c = get_option(self::CREDENTIALS, array());
        return array('X-Zameria-License'=>$c['license_key'] ?? '', 'X-Zameria-Installation'=>$c['installation_token'] ?? '', 'X-Zameria-Store'=>home_url('/'));
    }
    public static function check($force=false) {
        $verified = (int)get_option(self::VERIFIED_AT,0);
        if (!$force && !get_option(self::DENIED_AT) && $verified && time()-$verified < self::REFRESH_SECONDS && Settings::is_entitled()) return true;
        $headers = self::headers();
        if (!$headers['X-Zameria-License'] || !$headers['X-Zameria-Installation']) return self::error('Connect your ZAMERIA account in WordPress to verify this store.');
        $response = Cloud_Account::request('/entitlement', null, '', $headers);
        if (is_wp_error($response)) {
            $details=$response->get_error_data();$status=is_array($details)?($details['status'] ?? 0):0;
            if (in_array($status,array(400,401,403,404),true)) { self::deny('access_denied'); return self::error('This store no longer has active ZAMERIA access.'); }
            if (!get_option(self::DENIED_AT) && $verified && time()-$verified <= self::OFFLINE_GRACE && Settings::is_entitled()) return true;
            return new \WP_Error('zameria_access_unavailable','Could not verify store access. Retry online.',array('status'=>503));
        }
        $host = strtolower((string)wp_parse_url(home_url('/'),PHP_URL_HOST));
        $expected = preg_replace('/^www\./','',$host);
        $domain = preg_replace('/^www\./','',strtolower((string)($response['store_domain'] ?? '')));
        if (($response['status'] ?? '') !== 'active' || $domain !== $expected || strtotime($response['expires_at'] ?? '') <= time()) { self::deny('access_denied'); return self::error('Store access expired or belongs to another store.'); }
        $trial = ($response['plan'] ?? '') === 'trial';
        Settings::set_entitlement(array('status'=>$trial?'trial_active':(!empty($response['gifted'])?'gifted_active':'paid_active'), 'plan'=>$trial?'Business':ucfirst($response['plan']), 'plan_name'=>$trial?'Free Trial (7 Days)':ucfirst($response['plan']).' Plan', 'license_key'=>$headers['X-Zameria-License'], 'license_expires_at'=>$trial?null:$response['expires_at'], 'trial_start'=>$trial?($response['activated_at'] ?? null):null, 'trial_end'=>$trial?$response['expires_at']:null));
        update_option(self::VERIFIED_AT,time(),false);delete_option(self::DENIED_AT);
        return true;
    }
    public static function deny($status) {
        if (!get_option(self::DENIED_AT)) update_option(self::DENIED_AT,time(),false);
        Settings::set_entitlement(array('status'=>$status));
    }
    private static function error($message) { return new \WP_Error('zameria_access_denied',$message,array('status'=>403)); }
    // Staff timestamps are assertions: offline operation cannot prove when cash changed hands.
    public static function queued_sale_allowed($sale,$device) {
        $verified=(int)get_option(self::VERIFIED_AT,0);$denied=(int)get_option(self::DENIED_AT,0);
        $created=strtotime($sale['created_at'] ?? '');$issued=strtotime(($device->created_at ?? '').' UTC');
        $e=Settings::get_entitlement();$expiry=strtotime($e['trial_end'] ?? $e['license_expires_at'] ?? '');
        $cutoff=min(array_filter(array($denied,$expiry,$verified+self::OFFLINE_GRACE)));
        return $verified && $issued && $issued <= $verified && $created && $created <= $cutoff && $created <= time()+60;
    }
}
