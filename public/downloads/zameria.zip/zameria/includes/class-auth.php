<?php
/**
 * Device sign-in and token authentication.
 *
 * Each POS device signs in once with a WordPress username/password and receives a long-lived
 * token, so it keeps working through days offline. Tokens travel in a custom header because
 * many shared hosts (Apache/cPanel) strip the Authorization header before PHP sees it.
 *
 * @package Zameria
 */

namespace Zameria;

defined( 'ABSPATH' ) || exit;

class Auth {

	const HEADER           = 'X-Zameria-Token';
	const MAX_ATTEMPTS     = 5;
	const LOCKOUT_SECONDS  = 15 * MINUTE_IN_SECONDS;
	const SEEN_INTERVAL    = 5 * MINUTE_IN_SECONDS;

	/** @var object|null Device row for the current request. */
	private static $device = null;

	public static function init() {
		// Lets a signed-in device call WooCommerce's own REST API (wc/v3, wp/v2/media) as its user,
		// so no store-wide consumer keys ever live in the browser.
		add_filter( 'determine_current_user', array( __CLASS__, 'determine_current_user' ), 30 );
		add_filter( 'woocommerce_rest_check_permissions', array( __CLASS__, 'grant_pos_permissions' ), 10, 4 );
		add_filter( 'woocommerce_rest_customer_query', array( __CLASS__, 'customer_query' ) );
		add_filter('woocommerce_rest_shop_order_object_query',array(__CLASS__,'order_query'),10,2);
		add_filter('rest_pre_dispatch',array(__CLASS__,'protect_device_request'),10,3);
	}

	public static function determine_current_user( $user_id ) {
		if ( $user_id || ! self::is_rest_request() ) {
			return $user_id;
		}
		$token = isset( $_SERVER['HTTP_X_ZAMERIA_TOKEN'] ) ? sanitize_text_field( wp_unslash( $_SERVER['HTTP_X_ZAMERIA_TOKEN'] ) ) : '';
		if ( '' === $token ) {
			return $user_id;
		}
		$device = self::device_for_token( $token );
		if ( ! $device ) {
			return $user_id;
		}
		$user = get_user_by( 'id', $device->user_id );
		if ( ! $user || ! self::user_can_use_pos( $user ) ) {
			return $user_id;
		}
		self::$device = $device;
		return (int) $user->ID;
	}

	/**
	 * Cashiers get the read access the till needs (products, coupons, orders, customers) and may
	 * add customers, but only on requests made from a POS device. Shop managers and admins
	 * already have these through their own WooCommerce capabilities.
	 */
	public static function grant_pos_permissions( $permission, $context, $object_id, $type ) {
		if ( $permission || ! self::$device || ! current_user_can( Install::CAPABILITY ) ) {
			return $permission;
		}

		$readable = array( 'product', 'product_variation', 'product_cat', 'product_tag', 'shop_coupon', 'shop_order' );
		if ( 'read' === $context && in_array( $type, $readable, true ) ) {
			return true;
		}

		if ( 'user' === $type || 'customer' === $type ) {
			if ( 'create' === $context ) {
				return true;
			}
			// Customer listing is narrowed to the customer role in customer_query().
			if ( 'read' === $context && ! $object_id ) {
				return true;
			}
			// A single account may be read or edited only if it is a plain customer, so a cashier
			// can never see or change a staff login.
			if ( in_array( $context, array( 'read', 'edit' ), true ) && $object_id ) {
				$target = get_userdata( $object_id );
				return $target && array( 'customer' ) === array_values( $target->roles );
			}
		}

		return $permission;
	}

	/**
	 * Staff without list_users only ever see customer accounts in wc/v3/customers.
	 */
	public static function customer_query( $args ) {
		if ( self::$device ) {
			if ( ! current_user_can( 'list_users' ) ) {
				unset( $args['role__in'] );
				$args['role'] = 'customer';
			} elseif ( isset( $args['role'] ) && 'all' === $args['role'] ) {
				// 'all' is a WooCommerce REST query pseudo-role; WP_User_Query has no 'all' role.
				unset( $args['role'] );
			}
		}
		return $args;
	}

	private static function is_rest_request() {
		if ( defined( 'REST_REQUEST' ) && REST_REQUEST ) {
			return true;
		}
		// determine_current_user can run before REST_REQUEST is defined; fall back to the URL.
		$uri    = isset( $_SERVER['REQUEST_URI'] ) ? wp_unslash( $_SERVER['REQUEST_URI'] ) : ''; // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized
		$prefix = '/' . rest_get_url_prefix() . '/';
		return false !== strpos( $uri, $prefix ) || false !== strpos( $uri, 'rest_route=' );
	}

	private static function device_for_token( $token ) {
		global $wpdb;
		return $wpdb->get_row(
			$wpdb->prepare(
				"SELECT * FROM {$wpdb->prefix}zameria_devices WHERE token_hash = %s AND revoked_at IS NULL",
				hash( 'sha256', $token )
			)
		);
	}

	public static function user_can_use_pos( $user ) {
		return user_can( $user, Install::CAPABILITY ) || user_can( $user, 'manage_woocommerce' );
	}

	/**
	 * @param string $username
	 * @param string $password
	 * @param string $device_name
	 * @param int $requested_register_id
	 * @return array|\WP_Error
	 */
	public static function login( $username, $password, $device_name, $requested_register_id = 0 ) {
		$throttle_key = 'zameria_login_' . md5( strtolower( $username ) . '|' . self::client_ip() );
		$attempts     = (int) get_transient( $throttle_key );
		if ( $attempts >= self::MAX_ATTEMPTS ) {
			return new \WP_Error( 'zameria_too_many_attempts', __( 'Too many failed sign-in attempts. Try again in 15 minutes.', 'zameria' ), array( 'status' => 429 ) );
		}

		$user = wp_authenticate( $username, $password );
		if ( is_wp_error( $user ) ) {
			set_transient( $throttle_key, $attempts + 1, self::LOCKOUT_SECONDS );
			return new \WP_Error( 'zameria_invalid_login', __( 'Incorrect username or password.', 'zameria' ), array( 'status' => 401 ) );
		}
		delete_transient( $throttle_key );

		if ( ! self::user_can_use_pos( $user ) ) {
			return new \WP_Error( 'zameria_forbidden', __( 'This account is not allowed to use the POS. Ask the store owner to give you the POS Cashier role.', 'zameria' ), array( 'status' => 403 ) );
		}

		$access = Store_Access::check(true);
		if (is_wp_error($access)) return $access;

		global $wpdb;
		// Admission and session insertion must be one operation across PHP workers.
		// Authenticate and refresh cloud access first, without holding a database lock.
		$lock_name = 'zameria_login_' . md5( $wpdb->prefix . '|' . DB_NAME );
		if ( 1 !== (int) $wpdb->get_var( $wpdb->prepare( 'SELECT GET_LOCK(%s, %d)', $lock_name, 10 ) ) ) {
			return new \WP_Error( 'zameria_register_busy', __( 'Another register is signing in. Please try again.', 'zameria' ), array( 'status' => 503 ) );
		}
		try {
			$requested_register_id = absint( $requested_register_id );

			// Check if connecting to an existing active register (by ID or matching register name)
			$existing_register = null;
			if ( $requested_register_id > 0 ) {
				$existing_register = $wpdb->get_row(
					$wpdb->prepare(
						"SELECT * FROM {$wpdb->prefix}zameria_devices
						WHERE (id = %d OR register_id = %d) AND revoked_at IS NULL
						ORDER BY id ASC LIMIT 1",
						$requested_register_id,
						$requested_register_id
					)
				);
			}

			if ( ! $existing_register && '' !== $device_name ) {
				$existing_register = $wpdb->get_row(
					$wpdb->prepare(
						"SELECT * FROM {$wpdb->prefix}zameria_devices
						WHERE name = %s AND revoked_at IS NULL
						ORDER BY id ASC LIMIT 1",
						$device_name
					)
				);
			}

			// Only enforce register limits when a NEW register is being provisioned
			if ( ! $existing_register ) {
				$limits = Settings::plan_limits();
				if ( null !== $limits['max_devices'] ) {
					$active_count = count( self::active_devices() );
					if ( $active_count >= $limits['max_devices'] ) {
						return new \WP_Error(
							'zameria_plan_limit_exceeded',
							sprintf(
								__( 'Starter plan device limit reached (maximum %d active registers). Please revoke an existing register or upgrade to the Business plan for unlimited registers.', 'zameria' ),
								$limits['max_devices']
							),
							array( 'status' => 403, 'limit_type' => 'devices', 'max' => $limits['max_devices'] )
						);
					}
				}
			}


			// Count people, not sessions: a staff member can reconnect or use another register.
			$staff_limit = Settings::plan_limits()['max_staff'];
			if ( null !== $staff_limit ) {
				$staff_ids = array_map( 'intval', $wpdb->get_col( "SELECT DISTINCT user_id FROM {$wpdb->prefix}zameria_devices WHERE revoked_at IS NULL" ) );
				if ( ! in_array( (int) $user->ID, $staff_ids, true ) && count( $staff_ids ) >= $staff_limit ) {
					return new \WP_Error( 'zameria_staff_limit_exceeded', __( 'Starter allows two active staff. Sign out an existing staff member or choose Business.', 'zameria' ), array( 'status' => 403, 'limit_type' => 'staff', 'max' => $staff_limit ) );
				}
			}

			$token            = bin2hex( random_bytes( 32 ) );
			$now              = gmdate( 'Y-m-d H:i:s' );
			$canonical_reg_id = $existing_register ? (int) ( $existing_register->register_id ?: $existing_register->id ) : 0;

			$inserted = $wpdb->insert(
				"{$wpdb->prefix}zameria_devices",
				array(
					'register_id'  => $canonical_reg_id,
					'user_id'      => $user->ID,
					'name'         => $device_name,
					'token_hash'   => hash( 'sha256', $token ),
					'created_at'   => $now,
					'last_seen_at' => $now,
				)
			);

			// If insert failed (e.g. legacy table missing register_id), trigger upgrade/schema healing and retry
			if ( false === $inserted || empty( $wpdb->insert_id ) ) {
				Install::maybe_upgrade();
				$table_name = "{$wpdb->prefix}zameria_devices";
				$col_check  = $wpdb->get_results( "SHOW COLUMNS FROM `{$table_name}` LIKE 'register_id'" );
				if ( empty( $col_check ) ) {
					$wpdb->query( "ALTER TABLE `{$table_name}` ADD COLUMN register_id bigint(20) unsigned NOT NULL DEFAULT 0 AFTER id, ADD KEY register_id (register_id)" );
				}
				$inserted = $wpdb->insert(
					"{$wpdb->prefix}zameria_devices",
					array(
						'register_id'  => $canonical_reg_id,
						'user_id'      => $user->ID,
						'name'         => $device_name,
						'token_hash'   => hash( 'sha256', $token ),
						'created_at'   => $now,
						'last_seen_at' => $now,
					)
				);
				if ( false === $inserted || empty( $wpdb->insert_id ) ) {
					return new \WP_Error(
						'zameria_session_error',
						__( 'Could not save register session to the database. Please check MySQL table permissions.', 'zameria' ),
						array( 'status' => 500 )
					);
				}
			}

			$session_id = (int) $wpdb->insert_id;
			if ( 0 === $canonical_reg_id ) {
				$canonical_reg_id = $session_id;
				$wpdb->update(
					"{$wpdb->prefix}zameria_devices",
					array( 'register_id' => $canonical_reg_id ),
					array( 'id' => $session_id )
				);
			}

			$entitlement = Settings::get_entitlement();
			return array(
				'token'  => $token,
				'device' => array(
					'id'          => $canonical_reg_id,
					'register_id' => $canonical_reg_id,
					'name'        => $device_name,
				),
				'user'        => self::user_payload( $user ),
				'store'       => Settings::store(),
				'plan'        => $entitlement['plan'] ?? 'Business',
				'entitlement' => $entitlement,
				'limits'      => Settings::plan_limits(),
				'currency'    => Settings::currency(),
			);
		} finally {
			$wpdb->get_var( $wpdb->prepare( 'SELECT RELEASE_LOCK(%s)', $lock_name ) );
		}
	}

	/**
	 * REST permission callback for every authenticated route.
	 *
	 * @return true|\WP_Error
	 */
	public static function authenticate( \WP_REST_Request $request ) {
		$token = (string) $request->get_header( self::HEADER );
		if ( '' === $token ) {
			return new \WP_Error( 'zameria_unauthorized', __( 'Sign in required.', 'zameria' ), array( 'status' => 401 ) );
		}

		global $wpdb;
		$device = self::device_for_token( $token );
		if ( ! $device ) {
			return new \WP_Error( 'zameria_unauthorized', __( 'This device has been signed out. Please sign in again.', 'zameria' ), array( 'status' => 401 ) );
		}

		$user = get_user_by( 'id', $device->user_id );
		if ( ! $user || ! self::user_can_use_pos( $user ) ) {
			return new \WP_Error( 'zameria_forbidden', __( 'This account can no longer use the POS.', 'zameria' ), array( 'status' => 403 ) );
		}

		wp_set_current_user( $user->ID );
		self::$device = $device;

		if ( ! $device->last_seen_at || strtotime( $device->last_seen_at . ' UTC' ) < time() - self::SEEN_INTERVAL ) {
			$wpdb->update(
				"{$wpdb->prefix}zameria_devices",
				array( 'last_seen_at' => gmdate( 'Y-m-d H:i:s' ) ),
				array( 'id' => $device->id )
			);
		}

		return true;
	}

	public static function current_device() {
		return self::$device;
	}

    public static function can_read_order($order) {
        if (!$order || $order->get_meta('_zameria_pos_order') !== 'yes') return true;
        $owner=(int)($order->get_meta('_zameria_created_by_user_id') ?: $order->get_meta('_zameria_attended_by_user_id'));
        if ($order->has_status(array('pending','on-hold'))) return $owner === get_current_user_id();
        return current_user_can('manage_woocommerce') || $owner === get_current_user_id();
    }
    public static function order_query($args,$request) {
        if (!self::$device) return $args;
        $uid=get_current_user_id();
        $own=array('relation'=>'OR',array('key'=>'_zameria_created_by_user_id','value'=>$uid),array('relation'=>'AND',array('relation'=>'OR',array('key'=>'_zameria_created_by_user_id','compare'=>'NOT EXISTS'),array('key'=>'_zameria_created_by_user_id','value'=>array('','0'),'compare'=>'IN')),array('key'=>'_zameria_attended_by_user_id','value'=>$uid)));
        if (!current_user_can('manage_woocommerce')) {
            $visible=array('relation'=>'OR',array('key'=>'_zameria_pos_order','compare'=>'NOT EXISTS'),array('key'=>'_zameria_pos_order','value'=>'yes','compare'=>'!='),$own);
            $args['meta_query']=empty($args['meta_query'])?array($visible):array('relation'=>'AND',$args['meta_query'],$visible);
        }
        // Held POS orders remain private even for managers; this also covers HPOS and legacy storage.
        $held=wc_get_orders(array('status'=>array('pending','on-hold'),'limit'=>-1,'meta_query'=>array(array('key'=>'_zameria_pos_order','value'=>'yes'))));
        foreach($held as $order) if(!self::can_read_order($order)) $args['exclude'][]=$order->get_id();
        return $args;
    }
    public static function protect_device_request($result,$server,$request) {
        get_current_user_id(); // Resolve the token before checking device scope.
        if (!self::$device) return $result;
        $route=$request->get_route();$method=$request->get_method();
        if (preg_match('#^/wc/v[1-3]/orders/(\d+)(?:/|$)#',$route,$m)) {
            $order=wc_get_order((int)$m[1]);
            if ($order && !self::can_read_order($order)) return new \WP_Error('zameria_order_forbidden','This order belongs to another cashier.',array('status'=>403));
        }
        if (in_array($method,array('POST','PUT','PATCH','DELETE'),true) && (strpos($route,'/wc/')===0 || strpos($route,'/wp/v2/media')===0 || preg_match('#^/zameria/v1/products/#',$route))) {
            $access=Store_Access::check();if(is_wp_error($access))return $access;
        }
        return $result;
    }

	public static function revoke( $device_id ) {
		global $wpdb;
		$device_id = absint( $device_id );
		$now       = gmdate( 'Y-m-d H:i:s' );
		$wpdb->query(
			$wpdb->prepare(
				"UPDATE {$wpdb->prefix}zameria_devices
				SET revoked_at = %s
				WHERE id = %d OR register_id = %d",
				$now,
				$device_id,
				$device_id
			)
		);
	}

	public static function active_devices() {
		global $wpdb;
		// Returns distinct active registers grouped by canonical register_id.
		return $wpdb->get_results(
			"SELECT
				COALESCE(NULLIF(d.register_id, 0), d.id) AS id,
				COALESCE(NULLIF(d.register_id, 0), d.id) AS register_id,
				d.name,
				d.user_id,
				d.token_hash,
				MIN(d.created_at) AS created_at,
				MAX(d.last_seen_at) AS last_seen_at,
				d.revoked_at,
				u.display_name
			FROM {$wpdb->prefix}zameria_devices d
			LEFT JOIN {$wpdb->users} u ON u.ID = d.user_id
			WHERE d.revoked_at IS NULL
			GROUP BY COALESCE(NULLIF(d.register_id, 0), d.id)
			ORDER BY last_seen_at DESC"
		);
	}

	/**
	 * Who is signed in and what they may do. The app uses this for its menus; the server still
	 * enforces every permission itself.
	 */
	public static function user_payload( $user ) {
		$roles = array_values( $user->roles );
		if ( in_array( 'zameria_cashier', $roles, true ) ) {
			$roles[] = 'cashier';
		}

		$capabilities = array();
		foreach ( array( 'manage_options', 'manage_woocommerce', 'edit_products', 'publish_products', 'edit_shop_orders', 'list_users' ) as $cap ) {
			$capabilities[ $cap ] = user_can( $user, $cap );
		}

		return array(
			'id'           => (int) $user->ID,
			'name'         => $user->display_name,
			'username'     => $user->user_login,
			'email'        => $user->user_email,
			'roles'        => $roles,
			'capabilities' => $capabilities,
		);
	}

	private static function client_ip() {
		return isset( $_SERVER['REMOTE_ADDR'] ) ? sanitize_text_field( wp_unslash( $_SERVER['REMOTE_ADDR'] ) ) : '';
	}
}
