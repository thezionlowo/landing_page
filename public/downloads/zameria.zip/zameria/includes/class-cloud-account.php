<?php
/** Server-side merchant account gateway. Upstream tokens never enter browser storage. */
namespace Zameria;
defined( 'ABSPATH' ) || exit;
class Cloud_Account {
    public static function init() {
        add_action( 'wp_ajax_zameria_cloud_account', array( __CLASS__, 'ajax' ) );
        add_action( 'zameria_retry_signup_lead', array( __CLASS__, 'retry_signup_lead' ), 10, 1 );
    }
    private static function session_key() {
        return 'zameria_cloud_' . hash( 'sha256', get_current_user_id() . ':' . wp_get_session_token() );
    }
    public static function base_url() {
        return rtrim( (string) apply_filters( 'zameria_cloud_api_url', 'https://scoreflip-go-hwsgspeycq-uc.a.run.app/api/v1/zameria' ), '/' );
    }
    public static function scrub( $data ) {
        if ( ! is_array( $data ) ) return $data;
        foreach ( $data as $key => $value ) {
            if ( is_string( $key ) && preg_match( '/password|^(token|installation_token|access_token|refresh_token|accessToken|refreshToken|authorization|secret)$/i', $key ) ) unset( $data[ $key ] );
            else $data[ $key ] = self::scrub( $value );
        }
        return $data;
    }
    public static function request( $route, $body = null, $token = '', $headers = array() ) {
        $args = array( 'method' => null === $body ? 'GET' : 'POST', 'timeout' => 12, 'redirection' => 0, 'headers' => array( 'Content-Type' => 'application/json' ) );
        if ( $token ) $args['headers']['Authorization'] = 'Bearer ' . $token;
        $args['headers'] = array_merge($args['headers'],$headers);
        if ( null !== $body ) $args['body'] = wp_json_encode( $body );
        if ( '/lead/capture' === $route && ! empty( $body['event_id'] ) ) $args['headers']['Idempotency-Key'] = $body['event_id'];
        if ( '/lead/capture' === $route ) $args['timeout'] = 4;
        $response = wp_remote_request( self::base_url() . $route, $args );
        if ( is_wp_error( $response ) ) return $response;
        $data = json_decode( wp_remote_retrieve_body( $response ), true );
        $status = wp_remote_retrieve_response_code( $response );
        if ( $status < 200 || $status >= 300 || ! is_array( $data ) || ( isset( $data['success'] ) && false === $data['success'] ) ) {
            return new \WP_Error( 'cloud_rejected', isset( $data['error'] ) && is_string( $data['error'] ) ? $data['error'] : 'ZAMERIA could not verify this request.', array( 'status' => ( $status >= 200 && $status < 300 ) ? 400 : ( $status ?: 502 ) ) );
        }
        return $data;
    }
    public static function verified_entitlement($merchant_token = null) {
        $explicit_owner = null !== $merchant_token;
        $session = $explicit_owner ? array('token'=>$merchant_token) : get_transient( self::session_key() );
        // An owner's short-lived account session is not the store connection.
        // Already provisioned stores continue to verify after logout/session expiry.
        if (!$explicit_owner && empty($session['token']) && class_exists(Store_Access::class)) return self::store_entitlement();
        $data = self::request( '/account/entitlement?store=' . rawurlencode( home_url( '/' ) ), null, $session['token'] ?? '' );
        if ( is_wp_error( $data ) ) {
            $details = $data->get_error_data();
            if (!$explicit_owner && is_array($details) && ($details['status'] ?? 0) === 401 && class_exists(Store_Access::class) && Store_Access::has_credentials()) return self::store_entitlement();
            return $data;
        }
        if ( empty( $data['entitlement'] ) || ! is_array( $data['entitlement'] ) ) return new \WP_Error( 'invalid_entitlement', 'Invalid entitlement response.' );
        $entitlement = $data['entitlement'];
        $domain = $entitlement['store_url'] ?? $entitlement['store_domain'] ?? '';
        if ( ! $domain || self::store_identity( $domain ) !== self::store_identity( home_url( '/' ) ) ) return new \WP_Error( 'wrong_store', 'Entitlement belongs to another store.' );
        $status = $entitlement['status'] ?? '';
        if ( 'trial_active' === $status ) {
            $end = $entitlement['trial_end'] ?? $entitlement['trial']['expires_at'] ?? '';
            if ( ! $end || ! strtotime( $end ) ) return new \WP_Error( 'invalid_expiry', 'Trial expiry missing.' );
            if ( strtotime( $end ) <= time() ) $entitlement['status'] = 'trial_expired';
        }
        if ( in_array( $status, array( 'paid_active', 'gifted_active' ), true ) ) {
            $end = $entitlement['license_expires_at'] ?? '';
            if ( ! $end || ! strtotime( $end ) ) return new \WP_Error( 'invalid_expiry', 'License expiry missing.' );
            if ( strtotime( $end ) <= time() ) $entitlement['status'] = 'paid_active' === $status ? 'paid_expired' : 'gifted_expired';
        }
        if (class_exists(Store_Access::class)) {
            $remembered=Store_Access::remember($entitlement, $session['token'] ?? '');
            if(is_wp_error($remembered))return $remembered;
        }
        return $entitlement;
    }
    /** Finish connection with the freshly authenticated token, without rereading a transient. */
    private static function connect_account($account, $token) {
        $entitlement = self::verified_entitlement($token);
        if (is_wp_error($entitlement)) return $entitlement;
        if (!in_array($entitlement['status'] ?? '', array('unactivated','trial_not_started'), true)) return $entitlement;

        $code = '';
        foreach (($account['licenses'] ?? array()) as $license) {
            if (!empty($license['is_trial']) || ($license['status'] ?? '') !== 'active') continue;
            $bound = $license['store_domain'] ?? '';
            if ($bound && self::store_identity($bound) !== self::store_identity(home_url('/'))) continue;
            $code = $license['code'] ?? $license['license_key'] ?? $license['licenseKey'] ?? '';
            if (!$code) return new \WP_Error('missing_license_key', 'Your existing license is missing its activation key. Contact ZAMERIA support to restore it.', array('status'=>409));
            break;
        }
        if (!$code) $code = $account['trial']['activationCode'] ?? $account['activationCode'] ?? '';
        if (!$code) {
            $trial = self::request('/trial/request', array('business_name'=>$account['business_name'] ?? get_bloginfo('name'), 'store_url'=>home_url('/')), $token);
            if (is_wp_error($trial)) return $trial;
            $code = $trial['trial_code'] ?? '';
        }
        if (!$code) return new \WP_Error('missing_activation_code', 'No server-issued activation code is available.', array('status'=>502));
        $activation = self::request('/license/activate', array('license_key'=>$code, 'store_url'=>home_url('/')), $token);
        if (is_wp_error($activation)) return $activation;
        $entitlement = self::verified_entitlement($token);
        if (!is_wp_error($entitlement) && in_array($entitlement['status'] ?? '', array('unactivated','trial_not_started'), true)) return new \WP_Error('connection_unconfirmed', 'Store activation was not confirmed. Please retry connecting your account.', array('status'=>502));
        return $entitlement;
    }
    private static function store_entitlement() {
        $access = Store_Access::check(true);
        if (is_wp_error($access)) return $access;
        return array_merge(Settings::get_entitlement(), array('store_url'=>home_url('/')));
    }
    private static function store_identity( $url ) {
        if ( ! preg_match( '#^https?://#i', $url ) ) $url = 'https://' . $url;
        return strtolower( (string) wp_parse_url( $url, PHP_URL_HOST ) ) . rtrim( (string) wp_parse_url( $url, PHP_URL_PATH ), '/' );
    }
    /** The pending event contains profile fields only, never passwords or bearer tokens. */
    public static function capture_signup_lead( $account, $submitted ) {
        $id = (string) $account['id'];
        $key = 'zameria_signup_lead_' . hash( 'sha256', $id );
        $payload = array(
            'event' => 'signup', 'event_id' => 'signup:' . $id, 'account_id' => $id,
            'email' => strtolower( trim( (string) $account['email'] ) ),
            'name' => sanitize_text_field( $account['full_name'] ?? $submitted['full_name'] ?? '' ),
            'business_name' => sanitize_text_field( $account['business_name'] ?? $submitted['business_name'] ?? '' ),
            'phone' => sanitize_text_field( $account['phone'] ?? $submitted['phone'] ?? '' ),
            'store_url' => home_url( '/' ), 'source' => 'Plugin Signup', 'registration_source' => 'plugin',
        );
        // Write before sending so an interrupted HTTP request can be retried by WordPress cron.
        update_option( $key, $payload, false );
        self::schedule_signup_retry( $key );
        return self::retry_signup_lead( $key );
    }
    private static function schedule_signup_retry( $key ) {
        if ( ! wp_next_scheduled( 'zameria_retry_signup_lead', array( $key ) ) )
            wp_schedule_single_event( time() + 300, 'zameria_retry_signup_lead', array( $key ) );
    }
    public static function retry_signup_lead( $key ) {
        if ( ! is_string( $key ) || ! preg_match( '/^zameria_signup_lead_[a-f0-9]{64}$/', $key ) ) return false;
        $payload = get_option( $key );
        if ( ! is_array( $payload ) || empty( $payload['account_id'] ) ) return false;
        $data = self::request( '/lead/capture', $payload );
        $captured = ! is_wp_error( $data ) && ( true === ( $data['success'] ?? null ) || ! empty( $data['lead']['id'] ) || ! empty( $data['lead_id'] ) || ! empty( $data['leadId'] ) );
        if ( $captured ) {
            delete_option( $key );
            wp_clear_scheduled_hook( 'zameria_retry_signup_lead', array( $key ) );
        } else self::schedule_signup_retry( $key );
        return $captured;
    }
    /** Validate the JSON envelope and operation-specific scalars; never alter passwords. */
    public static function validated_payload( $operation, $raw ) {
        if ( ! is_string( $raw ) || strlen( $raw ) > 65536 || '{' !== substr( ltrim( $raw ), 0, 1 ) ) {
            return new \WP_Error( 'invalid_payload', 'Invalid account payload.', array( 'status' => 400 ) );
        }
        $decoded = json_decode( $raw, true, 16 );
        if ( ! is_array( $decoded ) || JSON_ERROR_NONE !== json_last_error() ) {
            return new \WP_Error( 'invalid_payload', 'Invalid account payload.', array( 'status' => 400 ) );
        }
        $fields = array(
            'login' => array( 'email', 'password' ),
            'register' => array( 'email', 'password', 'full_name', 'business_name', 'phone', 'store_address' ),
            'trial/request' => array( 'business_name' ),
            'trial/activate' => array( 'license_key' ),
            'entitlement' => array(),
            'store/disconnect' => array(),
        );
        $body = array();
        foreach ( $fields[ $operation ] ?? array() as $field ) {
            if ( ! array_key_exists( $field, $decoded ) ) continue;
            if ( ! is_string( $decoded[ $field ] ) ) {
                return new \WP_Error( 'invalid_field', 'Account fields must be text.', array( 'status' => 400 ) );
            }
            $body[ $field ] = 'password' === $field ? $decoded[ $field ] : sanitize_text_field( $decoded[ $field ] );
        }
        if ( in_array( $operation, array( 'login', 'register' ), true ) ) {
            if ( empty( $body['email'] ) || ! isset( $body['password'] ) || '' === $body['password'] ) {
                return new \WP_Error( 'missing_credentials', 'Email and password are required.', array( 'status' => 400 ) );
            }
            $body['email'] = strtolower( trim( $body['email'] ) );
            if ( ! is_email( $body['email'] ) ) {
                return new \WP_Error( 'invalid_email', 'Enter a valid email address.', array( 'status' => 400 ) );
            }
        }
        // Store identity is authoritative even if a client submits another URL.
        $body['store_url'] = home_url( '/' );
        return $body;
    }

    public static function ajax() {
        check_ajax_referer( 'zameria_admin', 'nonce' );
        if ( ! current_user_can( 'manage_woocommerce' ) ) wp_send_json_error( array( 'message' => 'Not allowed.' ), 403 );
        $operation = isset( $_POST['operation'] ) ? sanitize_text_field( wp_unslash( $_POST['operation'] ) ) : '';
        $routes = array( 'login' => '/account/login', 'register' => '/account/register', 'trial/request' => '/trial/request', 'trial/activate' => '/license/activate', 'entitlement' => '/entitlement', 'store/disconnect'=>'/account/store/disconnect' );
        if ( 'logout' === $operation ) { delete_transient( self::session_key() ); wp_send_json_success( array( 'success' => true ) ); }
        if ( ! isset( $routes[ $operation ] ) ) wp_send_json_error( array( 'message' => 'Unknown operation.' ), 400 );
        // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- JSON is type/field-validated below; text sanitizing the envelope would corrupt passwords.
        $raw_payload = isset( $_POST['payload'] ) && is_string( $_POST['payload'] ) ? wp_unslash( $_POST['payload'] ) : ( isset( $_POST['payload'] ) ? null : '{}' );
        $body = self::validated_payload( $operation, $raw_payload );
        if ( is_wp_error( $body ) ) wp_send_json_error( array( 'message' => $body->get_error_message() ), 400 );
        $session = get_transient( self::session_key() );
        if ('store/disconnect' === $operation && empty($session['token'])) wp_send_json_error(array('message'=>'Sign in to your ZAMERIA website account to disconnect this store, or sign in again in the plugin.'),401);
        if ( in_array( $operation, array( 'trial/request' ), true ) && empty( $session['token'] ) ) wp_send_json_error( array( 'message' => 'Sign in to ZAMERIA first.' ), 401 );
        $auth = in_array( $operation, array( 'login', 'register' ), true );
        if ( 'register' === $operation ) { $body['source'] = 'Plugin Signup'; $body['registration_source'] = 'plugin'; }
        $body['store_url'] = home_url( '/' );
        if ( 'entitlement' === $operation ) $data = array( 'entitlement' => self::verified_entitlement() );
        else $data = self::request( $routes[ $operation ], $body, $auth ? '' : ( $session['token'] ?? '' ) );
        if ( is_array( $data ) && isset( $data['entitlement'] ) && is_wp_error( $data['entitlement'] ) ) $data = $data['entitlement'];
        if ( is_wp_error( $data ) ) {
            $details = $data->get_error_data();
            wp_send_json_error( array( 'message' => $data->get_error_message(), 'requires_reconnect' => is_array($details) && !empty($details['requires_reconnect']) ), is_array( $details ) ? ( $details['status'] ?? 502 ) : 502 );
        }
        if ('store/disconnect' === $operation) {
            if (($data['success'] ?? false)!==true) wp_send_json_error(array('message'=>'Store disconnection was not confirmed.'),502);
            Store_Access::deny('unactivated');
            delete_transient(self::session_key());
        }
        if ( in_array( $operation, array( 'login', 'register' ), true ) ) {
            if ( empty( $data['token'] ) || ! is_string( $data['token'] ) || empty( $data['account']['id'] ) || ! is_scalar( $data['account']['id'] ) || empty( $data['account']['email'] ) || ! is_string( $data['account']['email'] ) || strtolower( trim( $data['account']['email'] ) ) !== $body['email'] ) wp_send_json_error( array( 'message' => 'Invalid account response.' ), 502 );
            set_transient( self::session_key(), array( 'token' => $data['token'], 'account_id' => $data['account']['id'] ), min( 24 * HOUR_IN_SECONDS, max( 1, (int) ( $data['expires_in'] ?? HOUR_IN_SECONDS ) ) ) );
            if ( 'register' === $operation ) $data['lead_capture'] = array( 'status' => self::capture_signup_lead( $data['account'], $body ) ? 'captured' : 'pending' );
            if (class_exists(Store_Access::class)) {
                $entitlement = self::connect_account($data['account'], $data['token']);
                if (is_wp_error($entitlement)) {
                    $details = $entitlement->get_error_data();
                    $data['connection_error'] = array('message'=>'Account sign-in succeeded, but the store connection failed: '.$entitlement->get_error_message(), 'status'=>is_array($details) ? ($details['status'] ?? 502) : 502);
                } else {
                    $data['entitlement'] = $entitlement;
                    $data['connection_complete'] = true;
                }
            }
        }
        wp_send_json_success( self::scrub( $data ) );
    }
}
