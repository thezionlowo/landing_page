<?php
/**
 * Serves the built POS app at https://yourstore.com/pos/.
 *
 * Serving from the store's own domain means no CORS setup, and the service worker's scope
 * covers /pos/ so the app opens with no internet once it has been loaded once.
 *
 * @package Zameria
 */

namespace Zameria;

defined( 'ABSPATH' ) || exit;

class App_Server {

	const QUERY_VAR = 'zameria_pos';
	const PATH_VAR  = 'zameria_pos_path';

	const MIME_TYPES = array(
		'html'        => 'text/html; charset=utf-8',
		'js'          => 'application/javascript; charset=utf-8',
		'css'         => 'text/css; charset=utf-8',
		'json'        => 'application/json',
		'webmanifest' => 'application/manifest+json',
		'svg'         => 'image/svg+xml',
		'png'         => 'image/png',
		'ico'         => 'image/x-icon',
		'woff2'       => 'font/woff2',
		'txt'         => 'text/plain; charset=utf-8',
	);

	public static function init() {
		add_action( 'init', array( __CLASS__, 'add_rewrite_rules' ) );
		add_filter( 'query_vars', array( __CLASS__, 'query_vars' ) );
		add_action( 'template_redirect', array( __CLASS__, 'maybe_serve' ), 0 );
	}

	public static function slug() {
		return trim( (string) apply_filters( 'zameria_app_slug', 'pos' ), '/' );
	}

	public static function url() {
		return home_url( '/' . self::slug() . '/' );
	}

	/**
	 * Returns the primary POS launch URL.
	 * This defaults to the ZAMERIA
	 * Cloud PWA with this store pre-configured, while allowing the local /pos/ endpoint
	 * for offline-first or custom deployments via filter.
	 */
	public static function hosted_login_url() {
		$cloud_url = 'https://pos.zameria.co/?store=' . rawurlencode( home_url( '/' ) );
		return (string) apply_filters( 'zameria_hosted_pos_url', $cloud_url );
	}

	public static function build_dir() {
		return ZAMERIA_DIR . 'pos-app/';
	}

	public static function add_rewrite_rules() {
		$slug = preg_quote( self::slug(), '#' );
		add_rewrite_rule( '^' . $slug . '/?$', 'index.php?' . self::QUERY_VAR . '=1', 'top' );
		add_rewrite_rule( '^' . $slug . '/(.+)$', 'index.php?' . self::QUERY_VAR . '=1&' . self::PATH_VAR . '=$matches[1]', 'top' );
	}

	public static function query_vars( $vars ) {
		$vars[] = self::QUERY_VAR;
		$vars[] = self::PATH_VAR;
		return $vars;
	}

	public static function maybe_serve() {
		if ( ! get_query_var( self::QUERY_VAR ) ) {
			return;
		}

		$path = ltrim( (string) get_query_var( self::PATH_VAR ), '/' );

		// The app uses relative asset paths, so /pos must become /pos/.
		$request_path = isset( $_SERVER['REQUEST_URI'] ) && is_string( $_SERVER['REQUEST_URI'] ) ? (string) wp_parse_url( wp_unslash( $_SERVER['REQUEST_URI'] ), PHP_URL_PATH ) : ''; // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- URI only determines trailing-slash redirect to the fixed POS URL; asset paths are separately constrained by realpath.
		if ( '' === $path && '/' !== substr( $request_path, -1 ) ) {
			wp_safe_redirect( self::url(), 301 );
			exit;
		}

		$dir = self::build_dir();
		if ( ! is_file( $dir . 'index.html' ) ) {
			wp_die( esc_html__( 'The POS app has not been built yet. Run "npm run build" in the project root.', 'zameria' ), '', array( 'response' => 503 ) );
		}

		if ( '' === $path ) {
			$path = 'index.html';
		}

		$base = realpath( $dir );
		$file = realpath( $dir . $path );
		$safe = $file && is_file( $file ) && 0 === strpos( $file, $base . DIRECTORY_SEPARATOR );

		if ( ! $safe ) {
			// Missing files with an extension are real 404s (a JS file must never get HTML back).
			if ( pathinfo( $path, PATHINFO_EXTENSION ) ) {
				status_header( 404 );
				nocache_headers();
				exit;
			}
			$file = $dir . 'index.html';
		}

		self::send( $file );
		exit;
	}

	private static function send( $file ) {
		$ext  = strtolower( pathinfo( $file, PATHINFO_EXTENSION ) );
		$name = basename( $file );

		status_header( 200 );
		header( 'Content-Type: ' . ( self::MIME_TYPES[ $ext ] ?? 'application/octet-stream' ) );
		header( 'X-Content-Type-Options: nosniff' );

		if ( false !== strpos( $file, DIRECTORY_SEPARATOR . 'assets' . DIRECTORY_SEPARATOR ) ) {
			// Vite puts a content hash in every asset filename, so they never change.
			header( 'Cache-Control: public, max-age=31536000, immutable' );
		} else {
			// index.html, sw.js and the manifest must always be fresh so app updates roll out.
			nocache_headers();
			header( 'X-LiteSpeed-Cache-Control: no-cache' );
		}

		if ( 'index.html' === $name ) {
			echo self::render_index( $file ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
			return;
		}

		// These are validated, installed local assets. The direct filesystem
		// reader avoids invoking FTP/SSH credentials on a public asset request.
		if ( ! class_exists( '\WP_Filesystem_Direct' ) ) {
			require_once ABSPATH . 'wp-admin/includes/class-wp-filesystem-base.php';
			require_once ABSPATH . 'wp-admin/includes/class-wp-filesystem-direct.php';
		}
		$filesystem = new \WP_Filesystem_Direct( null );
		$contents   = $filesystem->get_contents( $file );
		if ( false === $contents ) {
			status_header( 500 );
			nocache_headers();
			return;
		}
		if ( 'sw.js' === $name ) {
			$contents = self::runtime_worker() . $contents;
		}
		// File resolution is constrained to this plugin's POS build above.
		echo $contents; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
	}

	/** Use core-registered libraries only in the WordPress-specific build. */
	private static function runtime_scripts() {
		if ( ! is_readable( self::build_dir() . 'wordpress-runtime.json' ) ) {
			return array( 'html' => '', 'urls' => array() );
		}
		ob_start();
		wp_print_scripts( array( 'wp-element' ) );
		$html = ob_get_clean();
		preg_match_all( '/<script[^>]+src=["\']([^"\']+)["\']/i', $html, $matches );
		$urls = array_map(
			static function ( $url ) {
				return html_entity_decode( $url, ENT_QUOTES, 'UTF-8' );
			},
			$matches[1]
		);
		return array( 'html' => $html, 'urls' => $urls );
	}

	/** Cache the core scripts during worker installation, including the first visit. */
	private static function runtime_worker() {
		$runtime = self::runtime_scripts();
		if ( ! $runtime['urls'] ) {
			return '';
		}
		$urls = wp_json_encode( $runtime['urls'], JSON_HEX_TAG | JSON_UNESCAPED_SLASHES );
		// Keep prior versioned URLs: an already-open client may still use the old
		// cached index during a WordPress update. No store data is in this cache.
		return 'const zameriaCoreScripts=' . $urls . ';'
			. 'const zameriaCoreCache="zameria-wordpress-runtime-v1";'
			. 'self.addEventListener("install",event=>event.waitUntil(caches.open(zameriaCoreCache).then(cache=>cache.addAll(zameriaCoreScripts))));'
			. 'self.addEventListener("fetch",event=>{const url=new URL(event.request.url);'
			. 'if(event.request.mode==="navigate"&&(url.origin!==self.location.origin||!url.pathname.startsWith(new URL(self.registration.scope).pathname))){'
			. 'event.respondWith(fetch(event.request));event.stopImmediatePropagation();return;}'
			. 'if(event.request.method!=="GET"||!zameriaCoreScripts.some(asset=>{const core=new URL(asset,self.location.href);return core.origin===url.origin&&core.pathname===url.pathname;}))return;'
			. 'event.respondWith(caches.open(zameriaCoreCache).then(async cache=>{const saved=await cache.match(event.request);if(saved)return saved;'
			. 'const response=await fetch(event.request);if(response.ok)await cache.put(event.request,response.clone());return response;}));});' . "\n";
	}

	/**
	 * Injects the store's API location so the same build works on any domain or sub-folder, and a
	 * <base> so the app's routes (/pos/sale, /pos/orders...) and relative assets resolve correctly.
	 */
	private static function render_index( $file ) {
		$config = array(
			'restRoot'  => esc_url_raw( rest_url() ),
			'apiRoot'   => esc_url_raw( rest_url( Rest_Controller::NAMESPACE_V1 . '/' ) ),
			'storeUrl'  => esc_url_raw( home_url( '/' ) ),
			'storeName' => wp_specialchars_decode( get_bloginfo( 'name' ), ENT_QUOTES ),
		);
		$base   = '<base href="' . esc_attr( (string) wp_parse_url( self::url(), PHP_URL_PATH ) ) . '">';
		$script = '<script>window.ZAMERIA_CONFIG=' . wp_json_encode( $config, JSON_HEX_TAG | JSON_UNESCAPED_SLASHES ) . ';</script>';
		$html   = (string) file_get_contents( $file ); // phpcs:ignore WordPress.WP_Filesystem.AlternativeFunctions.file_get_contents_file_get_contents

		// Swap the build's own <base href="/"> for the POS path; add one if the build has none.
		// It must come before any relative URL in the document.
		$html = preg_match( '/<base\s[^>]*>/i', $html )
			? preg_replace( '/<base\s[^>]*>/i', $base, $html, 1 )
			: preg_replace( '/<head>/i', '<head>' . $base, $html, 1 );
		$runtime = self::runtime_scripts();
		return str_replace( '</head>', $runtime['html'] . $script . '</head>', $html );
	}
}
