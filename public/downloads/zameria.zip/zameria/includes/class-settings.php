<?php
/**
 * Store settings exposed to the POS app.
 *
 * @package Zameria
 */

namespace Zameria;

defined( 'ABSPATH' ) || exit;

class Settings {

	const STARTER_STAFF_LIMIT = 5;

	const PAYMENT_METHODS_OPTION = 'zameria_payment_methods';
	const RECEIPT_FOOTER_OPTION  = 'zameria_receipt_footer';
	const ENTITLEMENT_OPTION     = 'zameria_entitlement';

	/**
	 * Returns the store's authoritative ZAMERIA entitlement data.
	 * Evaluates trial and paid expiration dynamically based on UTC timestamps.
	 *
	 * @return array<string, mixed>
	 */
	public static function get_entitlement() {
		$data = get_option( self::ENTITLEMENT_OPTION );
		if ( ! is_array( $data ) || empty( $data ) ) {
			return array(
				'status'             => 'trial_not_started',
				'plan'               => null,
				'plan_name'          => 'None (Trial Eligible)',
				'trial_start'        => null,
				'trial_end'          => null,
				'days_remaining'     => 7,
				'license_key'        => null,
				'license_expires_at' => null,
				'max_products'       => 500,
				'max_devices'        => self::STARTER_STAFF_LIMIT,
				'is_licensed'        => false,
			);
		}

		$status = $data['status'] ?? 'trial_not_started';
		$now    = time();

		// Priority 1 & 2: Paid or Gifted active entitlement is authoritative.
		// Old trial fields must never drive a countdown, expiry message, or limit.
		if ( 'paid_active' === $status || 'gifted_active' === $status ) {
			$data['trial_start']    = null;
			$data['trial_end']      = null;
			$data['days_remaining'] = 0;
		}

		// Dynamic UTC timestamp checks to ensure expiration cannot be bypassed
		if ( 'trial_active' === $status && ! empty( $data['trial_end'] ) ) {
			$end_timestamp = strtotime( $data['trial_end'] );
			if ( $end_timestamp && $end_timestamp <= $now ) {
				$status = 'trial_expired';
				$data['status'] = 'trial_expired';
				$data['days_remaining'] = 0;
			} else if ( $end_timestamp ) {
				$data['days_remaining'] = max( 0, (int) ceil( ( $end_timestamp - $now ) / DAY_IN_SECONDS ) );
			}
		} elseif ( in_array( $status, array( 'paid_active', 'gifted_active' ), true ) && ! empty( $data['license_expires_at'] ) ) {
			$exp_timestamp = strtotime( $data['license_expires_at'] );
			if ( $exp_timestamp && $exp_timestamp <= $now ) {
				$status = ( 'gifted_active' === $status ) ? 'gifted_expired' : 'paid_expired';
				$data['status'] = $status;
			}
			$data['days_remaining'] = 0;
		}


		// Authoritative plan resolution (explicit plan takes precedence over plan_name):
		$raw_plan      = strtolower( (string) ( $data['plan'] ?? '' ) );
		$raw_plan_name = strtolower( (string) ( $data['plan_name'] ?? '' ) );

		if ('trial_active' === $status) {
			$plan = 'Business';
		} elseif ( strpos( $raw_plan, 'starter' ) !== false ) {
			$plan = 'Starter';
		} elseif ( strpos( $raw_plan, 'business' ) !== false ) {
			$plan = 'Business';
		} elseif ( strpos( $raw_plan_name, 'starter' ) !== false ) {
			$plan = 'Starter';
		} elseif ( strpos( $raw_plan_name, 'business' ) !== false ) {
			$plan = 'Business';
		} elseif ( in_array( $status, array( 'paid_active', 'gifted_active' ), true ) ) {
			$plan = 'Business';
		} elseif ( 'trial_active' === $status ) {
			$plan = 'Starter';
		} else {
			$plan = $data['plan'] ?? null;
		}

		$is_starter = ( 'Starter' === $plan );

		$default_plan_name = $is_starter ? 'Starter Plan' : 'Business Plan';
		if ( 'gifted_active' === $status ) {
			$default_plan_name = $plan . ' (Gifted Plan)';
		} elseif ( 'trial_active' === $status ) {
			$default_plan_name = 'Free Trial (7 Days)';
		}

		return array(
			'status'             => $status,
			'plan'               => $plan,
			'plan_name'          => ( ! empty( $data['plan_name'] ) && ( $is_starter ? strpos( strtolower( $data['plan_name'] ), 'business' ) === false : strpos( strtolower( $data['plan_name'] ), 'starter' ) === false ) ) ? $data['plan_name'] : $default_plan_name,
			'trial_start'        => $data['trial_start'] ?? null,
			'trial_end'          => $data['trial_end'] ?? null,
			'days_remaining'     => $data['days_remaining'] ?? 0,
			'license_key'        => $data['license_key'] ?? null,
			'license_expires_at' => $data['license_expires_at'] ?? null,
			'offline_until'      => ($verified = (int)get_option('zameria_access_verified_at',0)) ? gmdate('c',$verified+86400) : null,
			'max_products'       => $is_starter ? 500 : null,
			'max_devices'        => $is_starter ? self::STARTER_STAFF_LIMIT : null,
			'is_licensed'        => in_array( $status, array( 'trial_active', 'paid_active', 'gifted_active' ), true ),
		);
	}

	/**
	 * Persists updated authoritative entitlement to WordPress options.
	 *
	 * @param array<string, mixed> $data
	 * @return bool
	 */
	public static function set_entitlement( $data ) {
		if ( ! is_array( $data ) ) {
			return false;
		}
		$current = self::get_entitlement();
		// If explicit plan is specified without plan_name, clear old conflicting plan_name
		if ( isset( $data['plan'] ) && ( ! isset( $data['plan_name'] ) || '' === trim( $data['plan_name'] ) ) ) {
			unset( $current['plan_name'] );
		}
		if ( isset( $data['plan_name'] ) && ( ! isset( $data['plan'] ) || '' === trim( $data['plan'] ) ) ) {
			unset( $current['plan'] );
		}
		$merged  = array_merge( $current, $data );
		$status  = $merged['status'] ?? 'trial_not_started';

		if ( in_array( $status, array( 'paid_active', 'gifted_active' ), true ) ) {
			$merged['trial_start']    = null;
			$merged['trial_end']      = null;
			$merged['days_remaining'] = 0;
		}

		// Recompute plan and capacity limits cleanly so old trial limits never poison Business
		$raw_plan      = strtolower( (string) ( $merged['plan'] ?? '' ) );
		$raw_plan_name = strtolower( (string) ( $merged['plan_name'] ?? '' ) );

		if ('trial_active' === $status) {
			$resolved_plan = 'Business';
		} elseif ( strpos( $raw_plan, 'starter' ) !== false ) {
			$resolved_plan = 'Starter';
		} elseif ( strpos( $raw_plan, 'business' ) !== false ) {
			$resolved_plan = 'Business';
		} elseif ( strpos( $raw_plan_name, 'starter' ) !== false ) {
			$resolved_plan = 'Starter';
		} elseif ( strpos( $raw_plan_name, 'business' ) !== false ) {
			$resolved_plan = 'Business';
		} elseif ( in_array( $status, array( 'paid_active', 'gifted_active' ), true ) ) {
			$resolved_plan = 'Business';
		} elseif ( 'trial_active' === $status ) {
			$resolved_plan = 'Starter';
		} else {
			$resolved_plan = $merged['plan'] ?? null;
		}

		$merged['plan'] = $resolved_plan;
		if ( 'Business' === $resolved_plan ) {
			$merged['plan_name'] = ( empty( $merged['plan_name'] ) || strpos( strtolower( $merged['plan_name'] ), 'starter' ) !== false )
				? ( 'gifted_active' === $status ? 'Business (Gifted Plan)' : 'Business Plan' )
				: $merged['plan_name'];
			$merged['max_products'] = null;
			$merged['max_devices']  = null;
		} elseif ( 'Starter' === $resolved_plan ) {
			$merged['plan_name'] = ( empty( $merged['plan_name'] ) || strpos( strtolower( $merged['plan_name'] ), 'business' ) !== false )
				? ( 'gifted_active' === $status ? 'Starter (Gifted Plan)' : 'Starter Plan' )
				: $merged['plan_name'];
			$merged['max_products'] = 500;
			$merged['max_devices']  = self::STARTER_STAFF_LIMIT;
		}
		$merged['updated_at'] = gmdate( 'Y-m-d H:i:s' );

		return update_option( self::ENTITLEMENT_OPTION, $merged );
	}

	/**
	 * Checks whether the store holds an active entitlement.
	 *
	 * @return bool
	 */
	public static function is_entitled() {
		// Allow explicit local bypass only if environment flag is set
		if ( defined( 'ZAMERIA_DISABLE_LICENSING' ) && ZAMERIA_DISABLE_LICENSING ) {
			return true;
		}

		$entitlement = self::get_entitlement();
		$status      = $entitlement['status'] ?? 'trial_not_started';

		$expiry = 'trial_active' === $status ? ($entitlement['trial_end'] ?? $entitlement['trial']['expires_at'] ?? '') : ($entitlement['license_expires_at'] ?? '');
		return in_array( $status, array( 'trial_active', 'paid_active', 'gifted_active' ), true ) && strtotime($expiry) > time();
	}

	/**
	 * Returns Starter and Business plan capacity limits.
	 *
	 * @return array{max_products: int|null, max_devices: int|null, max_staff: int|null}
	 */
	public static function plan_limits() {
		$entitlement = self::get_entitlement();
		$raw_plan    = strtolower( (string) ( $entitlement['plan'] ?? '' ) );
		$raw_name    = strtolower( (string) ( $entitlement['plan_name'] ?? '' ) );
		$is_business = strpos( $raw_plan, 'business' ) !== false || strpos( $raw_name, 'business' ) !== false;
		$is_starter  = ! $is_business && ( 'Starter' === ( $entitlement['plan'] ?? 'Starter' ) || strpos( $raw_plan, 'starter' ) !== false || strpos( $raw_name, 'starter' ) !== false );
		return array(
			'max_products' => $is_starter ? 500 : null,
			'max_devices'  => $is_starter ? self::STARTER_STAFF_LIMIT : null,
			'max_staff'    => $is_starter ? self::STARTER_STAFF_LIMIT : null,
		);
	}

	/**
	 * @return array<int, array{id: string, label: string}>
	 */
	public static function payment_methods() {
		$methods = get_option( self::PAYMENT_METHODS_OPTION );
		if ( ! is_array( $methods ) || ! $methods ) {
			$methods = array(
				array(
					'id'    => 'cash',
					'label' => __( 'Cash', 'zameria' ),
				),
				array(
					'id'    => 'transfer',
					'label' => __( 'Bank transfer', 'zameria' ),
				),
				array(
					'id'    => 'card',
					'label' => __( 'Card (POS terminal)', 'zameria' ),
				),
			);
		}
		return $methods;
	}

	/**
	 * Parses the admin textarea (one label per line) into payment methods.
	 */
	public static function save_payment_methods( $text ) {
		$methods = array();
		foreach ( preg_split( '/\r\n|\r|\n/', (string) $text ) as $line ) {
			$label = sanitize_text_field( $line );
			$id    = sanitize_key( str_replace( ' ', '_', strtolower( $label ) ) );
			if ( '' === $label || '' === $id ) {
				continue;
			}
			$methods[ $id ] = array(
				'id'    => $id,
				'label' => $label,
			);
		}
		update_option( self::PAYMENT_METHODS_OPTION, array_values( $methods ) );
	}

	public static function payment_method_label( $id ) {
		foreach ( self::payment_methods() as $method ) {
			if ( $method['id'] === $id ) {
				return $method['label'];
			}
		}
		return $id;
	}

	public static function receipt_footer() {
		return (string) get_option( self::RECEIPT_FOOTER_OPTION, __( 'Thank you for your patronage!', 'zameria' ) );
	}

	public static function store() {
		$address = array_filter(
			array(
				get_option( 'woocommerce_store_address' ),
				get_option( 'woocommerce_store_address_2' ),
				get_option( 'woocommerce_store_city' ),
			)
		);

		$logo_id  = get_theme_mod( 'custom_logo' );
		$logo_url = $logo_id ? wp_get_attachment_image_url( $logo_id, 'full' ) : get_site_icon_url();

		return array(
			'name'           => wp_specialchars_decode( get_bloginfo( 'name' ), ENT_QUOTES ),
			'address'        => implode( ', ', $address ),
			'receipt_footer' => self::receipt_footer(),
			'logo'           => $logo_url ? $logo_url : '',
		);
	}

	public static function currency() {
		$code     = function_exists( 'get_woocommerce_currency' ) ? get_woocommerce_currency() : get_option( 'woocommerce_currency', 'NGN' );
		$symbol   = function_exists( 'get_woocommerce_currency_symbol' ) ? get_woocommerce_currency_symbol() : get_option( 'woocommerce_currency_symbol', '₦' );
		$decimals = function_exists( 'wc_get_price_decimals' ) ? wc_get_price_decimals() : (int) get_option( 'woocommerce_price_num_decimals', 2 );
		$dec_sep  = function_exists( 'wc_get_price_decimal_separator' ) ? wc_get_price_decimal_separator() : get_option( 'woocommerce_price_decimal_sep', '.' );
		$thou_sep = function_exists( 'wc_get_price_thousand_separator' ) ? wc_get_price_thousand_separator() : get_option( 'woocommerce_price_thousand_sep', ',' );

		return array(
			'code'               => $code ? $code : 'NGN',
			'symbol'             => html_entity_decode( $symbol ? $symbol : '₦', ENT_QUOTES, 'UTF-8' ),
			'position'           => get_option( 'woocommerce_currency_pos', 'left' ),
			'decimals'           => $decimals,
			'decimal_separator'  => $dec_sep,
			'thousand_separator' => $thou_sep,
		);
	}

	public static function categories() {
		$terms = get_terms(
			array(
				'taxonomy'   => 'product_cat',
				'hide_empty' => true,
			)
		);
		if ( is_wp_error( $terms ) ) {
			return array();
		}
		return array_map(
			function ( $term ) {
				return array(
					'id'     => (int) $term->term_id,
					'name'   => wp_specialchars_decode( $term->name, ENT_QUOTES ),
					'parent' => (int) $term->parent,
				);
			},
			$terms
		);
	}

	/**
	 * Detects the active brand taxonomy used on the WooCommerce store.
	 * Supports official WooCommerce Brands (product_brand), Perfect Brands (pwb-brand),
	 * YITH Brands (yith_product_brand), generic brand, and product attribute pa_brand.
	 *
	 * @return string Active taxonomy slug.
	 */
	public static function brand_taxonomy() {
		$candidates = array( 'product_brand', 'pwb-brand', 'yith_product_brand', 'brand', 'pa_brand' );
		foreach ( $candidates as $tax ) {
			if ( taxonomy_exists( $tax ) ) {
				return $tax;
			}
		}
		if ( ! taxonomy_exists( 'product_brand' ) && function_exists( 'register_taxonomy' ) ) {
			register_taxonomy(
				'product_brand',
				'product',
				array(
					'hierarchical'      => true,
					'label'             => __( 'Brands', 'zameria' ),
					'show_ui'           => true,
					'show_in_rest'      => true,
					'show_admin_column' => true,
					'query_var'         => true,
					'rewrite'           => array( 'slug' => 'brand' ),
				)
			);
		}
		return 'product_brand';
	}

	/**
	 * Retrieves all brands from the detected brand taxonomy.
	 *
	 * @return array<int, array{id: int, name: string, slug: string, taxonomy: string, count: int, description: string}>
	 */
	public static function brands() {
		$tax = self::brand_taxonomy();
		if ( ! taxonomy_exists( $tax ) ) {
			return array();
		}

		$terms = get_terms(
			array(
				'taxonomy'   => $tax,
				'hide_empty' => false,
			)
		);

		if ( is_wp_error( $terms ) || ! is_array( $terms ) ) {
			return array();
		}

		return array_values(
			array_map(
				function ( $term ) use ( $tax ) {
					return array(
						'id'          => (int) $term->term_id,
						'name'        => wp_specialchars_decode( $term->name, ENT_QUOTES ),
						'slug'        => (string) $term->slug,
						'taxonomy'    => $tax,
						'count'       => (int) $term->count,
						'description' => (string) $term->description,
					);
				},
				$terms
			)
		);
	}
}
