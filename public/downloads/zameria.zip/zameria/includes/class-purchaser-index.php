<?php
/** Order-derived purchaser directory. Never writes orders or user accounts. */
namespace Zameria;

defined( 'ABSPATH' ) || exit;

class Purchaser_Index {
    const STATE = 'zameria_purchaser_index';
    const JOB = 'zameria_purchaser_batch';
    const FLOOR = 'zameria_purchaser_floor';
    const BATCH = 50;
    private static $pending = array();

    public static function install() {
        global $wpdb;
        $collate = $wpdb->get_charset_collate();
        dbDelta("CREATE TABLE {$wpdb->prefix}zameria_purchases (
            order_id bigint(20) unsigned NOT NULL,
            buyer_key varchar(80) NOT NULL DEFAULT '',
            customer_id bigint(20) unsigned NOT NULL DEFAULT 0,
            billing_email varchar(320) NOT NULL DEFAULT '',
            qualifies tinyint(1) NOT NULL DEFAULT 0,
            net_total decimal(26,8) NOT NULL DEFAULT 0,
            is_pos tinyint(1) NOT NULL DEFAULT 0,
            owner_id bigint(20) unsigned NOT NULL DEFAULT 0,
            private_order tinyint(1) NOT NULL DEFAULT 0,
            purchased_at varchar(32) NOT NULL DEFAULT '',
            profile longtext NOT NULL,
            fingerprint char(64) NOT NULL,
            PRIMARY KEY (order_id),
            KEY buyer_key (buyer_key),
            KEY billing_email (billing_email(191)),
            KEY qualifies (qualifies)
        ) ENGINE=InnoDB $collate;");
        dbDelta("CREATE TABLE {$wpdb->prefix}zameria_purchaser_changes (
            id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
            buyer_key varchar(80) NOT NULL,
            PRIMARY KEY (id),
            KEY buyer_key (buyer_key)
        ) ENGINE=InnoDB $collate;");
    }

    public static function init() {
        add_action('rest_api_init', array(__CLASS__, 'routes'));
        add_action(self::JOB, array(__CLASS__, 'batch'));
        add_action('zameria_purchaser_order', array(__CLASS__, 'changed'));
        add_action('zameria_purchaser_identity', array(__CLASS__, 'identity_batch'), 10, 2);
        // Previously queued jobs may finish as no-ops; do not enqueue new work.
        if (!self::enabled()) return;
        add_action('user_register', array(__CLASS__, 'user_changed'));
        add_action('profile_update', array(__CLASS__, 'user_changed'), 10, 2);
        add_action('shutdown', array(__CLASS__, 'flush_queued'));
        add_action('zameria_daily', array(__CLASS__, 'reconcile'));
        foreach (array('woocommerce_new_order', 'woocommerce_update_order', 'woocommerce_order_status_changed') as $hook) {
            add_action($hook, array(__CLASS__, 'queue_order'), 20, 1);
        }
        add_action('woocommerce_order_refunded', array(__CLASS__, 'queue_order'), 20, 1);
        add_action('woocommerce_refund_deleted', array(__CLASS__, 'refund_deleted'), 20, 2);
        foreach (array('woocommerce_delete_order', 'woocommerce_trash_order', 'woocommerce_untrash_order') as $hook) {
            add_action($hook, array(__CLASS__, 'queue_order'), 20, 1);
        }
        // The source query stays on WooCommerce's storage adapter in HPOS and legacy stores.
        add_filter('woocommerce_order_data_store_cpt_get_orders_query', array(__CLASS__, 'legacy_query'), 10, 2);
        add_filter('posts_where', array(__CLASS__, 'legacy_where'), 10, 2);
        if (self::enabled()) {
            if (!get_option(self::STATE)) self::reconcile();
            elseif (empty(get_option(self::STATE)['complete'])) self::schedule();
        }
    }

    public static function enabled() {
        if (defined('WC_VERSION') && version_compare(WC_VERSION, '8.2', '<') && class_exists('\Automattic\WooCommerce\Utilities\OrderUtil') && \Automattic\WooCommerce\Utilities\OrderUtil::custom_orders_table_usage_is_enabled()) return false;
        // Kept for compatibility with existing installations, but no longer a
        // prerequisite for customer/history reads. Normal POS sync uses Woo APIs.
        return (bool) apply_filters('zameria_purchasers_enabled', false);
    }

    public static function routes() {
        $auth = array(__CLASS__, 'permission');
        register_rest_route('zameria/v1', '/purchasers', array('methods'=>'GET', 'permission_callback'=>$auth, 'callback'=>array(__CLASS__, 'directory')));
        register_rest_route('zameria/v1', '/purchaser-changes', array('methods'=>'GET', 'permission_callback'=>$auth, 'callback'=>array(__CLASS__, 'changes')));
        register_rest_route('zameria/v1', '/purchasers/(?P<key>[a-z0-9-]+)/orders', array('methods'=>'GET', 'permission_callback'=>$auth, 'callback'=>array(__CLASS__, 'history')));
    }

    public static function permission($request) {
        $auth = Auth::authenticate($request);
        if (is_wp_error($auth)) return $auth;
        if (!self::enabled()) return new \WP_Error('zameria_purchasers_disabled', 'Purchaser directory is disabled.', array('status'=>404));
        return true;
    }

    public static function schedule($continuation = false) {
        if (function_exists('as_has_scheduled_action') && function_exists('as_schedule_single_action')) {
            if ($continuation || !as_has_scheduled_action(self::JOB, array(), 'zameria')) as_schedule_single_action(time()+5, self::JOB, array(), 'zameria');
        } elseif (!wp_next_scheduled(self::JOB)) {
            wp_schedule_single_event(time()+5, self::JOB);
        }
    }

    public static function reconcile() {
        if (!self::enabled()) return;
        global $wpdb;
        $floor = max(0, self::cursor() - 100000);
        if ($floor > (int)get_option(self::FLOOR, 0)) {
            // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching -- Prune the custom change feed at its current snapshot floor; cached writes/cursors would corrupt incremental purchaser recovery.
            if (false !== $wpdb->query($wpdb->prepare("DELETE FROM {$wpdb->prefix}zameria_purchaser_changes WHERE id <= %d", $floor))) update_option(self::FLOOR, $floor, false);
        }
        $state = get_option(self::STATE, array());
        if (!empty($state) && empty($state['complete'])) { self::schedule(); return; }
        // Existing summaries remain readable during the next verification scan.
        update_option(self::STATE, array('after'=>0, 'prune_after'=>0, 'phase'=>'orders', 'complete'=>false, 'error'=>null), false);
        self::schedule();
    }

    public static function legacy_query($query, $vars) {
        if (isset($vars['zameria_after_id'])) $query['zameria_after_id'] = (int)$vars['zameria_after_id'];
        return $query;
    }

    public static function legacy_where($where, $query) {
        global $wpdb;
        $after = $query->get('zameria_after_id');
        return '' !== $after && null !== $after ? $where . $wpdb->prepare(" AND {$wpdb->posts}.ID > %d", $after) : $where;
    }

    public static function source_ids($after) {
        $args = array('type'=>'shop_order', 'status'=>array_keys(wc_get_order_statuses()), 'limit'=>self::BATCH, 'orderby'=>'ID', 'order'=>'ASC', 'return'=>'ids');
        $hpos = class_exists('\Automattic\WooCommerce\Utilities\OrderUtil') && \Automattic\WooCommerce\Utilities\OrderUtil::custom_orders_table_usage_is_enabled();
        if ($hpos) $args['field_query'] = array(array('field'=>'id', 'value'=>$after, 'compare'=>'>'));
        else $args['zameria_after_id'] = $after;
        return wc_get_orders($args);
    }

    private static function lock() {
        global $wpdb;
        return 'zameria-purchasers-' . md5($wpdb->prefix);
    }

    public static function batch() {
        global $wpdb;
        if (!self::enabled()) return;
        // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching -- Custom purchaser backfill uses database advisory locking and ordered live pages; caching can skip or duplicate contributions.
        if ('1' !== (string)$wpdb->get_var($wpdb->prepare('SELECT GET_LOCK(%s, 0)', self::lock()))) { self::schedule(); return; }
        try {
            $state = get_option(self::STATE, array('after'=>0, 'prune_after'=>0, 'phase'=>'orders', 'complete'=>false));
            if (!empty($state['complete'])) return;
            if ('orders' === $state['phase']) {
                $ids = self::source_ids((int)$state['after']);
                if (!is_array($ids)) throw new \RuntimeException('Invalid order scan response.');
                foreach ($ids as $id) {
                    if ((int)$id <= (int)$state['after']) throw new \RuntimeException('Order scan did not advance.');
                    self::write_order((int)$id);
                    $state['after'] = (int)$id;
                }
                if (count($ids) < self::BATCH) $state['phase'] = 'prune';
            } else {
                // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching -- Custom purchaser backfill uses database advisory locking and ordered live pages; caching can skip or duplicate contributions.
                $ids = $wpdb->get_col($wpdb->prepare("SELECT order_id FROM {$wpdb->prefix}zameria_purchases WHERE order_id > %d ORDER BY order_id ASC LIMIT %d", $state['prune_after'], self::BATCH));
                foreach ($ids as $id) { self::write_order((int)$id); $state['prune_after'] = (int)$id; }
                if (count($ids) < self::BATCH) $state['complete'] = true;
            }
            $state['error'] = null;
            update_option(self::STATE, $state, false);
        } catch (\Throwable $e) {
            $state['error'] = 'Purchaser import interrupted; retrying.';
            update_option(self::STATE, $state, false);
        } finally {
            // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching -- Custom purchaser backfill uses database advisory locking and ordered live pages; caching can skip or duplicate contributions.
            $wpdb->get_var($wpdb->prepare('SELECT RELEASE_LOCK(%s)', self::lock()));
        }
        if (empty($state['complete'])) self::schedule(true);
    }

    public static function changed($id) {
        global $wpdb;
        if (!self::enabled()) return;
        // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching -- Serialize writes to the custom purchaser projection with the backfill lock; the lock result and writes must remain live.
        if ('1' !== (string)$wpdb->get_var($wpdb->prepare('SELECT GET_LOCK(%s, 0)', self::lock()))) {
            // No change is lost if a background scan currently owns the lock.
            self::schedule_order((int)$id, true);
            return;
        }
        try { self::write_order((int)$id); }
        catch (\Throwable $e) {
            self::schedule_order((int)$id, true);
        // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching -- Serialize writes to the custom purchaser projection with the backfill lock; the lock result and writes must remain live.
        } finally { $wpdb->get_var($wpdb->prepare('SELECT RELEASE_LOCK(%s)', self::lock())); }
    }

    public static function queue_order($id) { self::$pending[(int)$id] = true; }

    public static function flush_queued() {
        foreach(array_keys(self::$pending) as $id) self::schedule_order($id);
        self::$pending = array();
    }

    private static function schedule_order($id, $retry = false) {
        if (function_exists('as_has_scheduled_action') && function_exists('as_schedule_single_action')) {
            if ($retry || !as_has_scheduled_action('zameria_purchaser_order', array($id), 'zameria')) as_schedule_single_action(time()+5, 'zameria_purchaser_order', array($id), 'zameria');
        } elseif (!wp_next_scheduled('zameria_purchaser_order', array($id))) {
            wp_schedule_single_event(time()+5, 'zameria_purchaser_order', array($id));
        }
    }

    public static function refund_deleted($refund_id, $order_id) { self::queue_order($order_id); }

    public static function user_changed($id, $old = null) {
        $user = get_userdata($id);
        foreach (array_unique(array_filter(array($user ? $user->user_email : '', $old ? $old->user_email : ''))) as $email) {
            wp_schedule_single_event(time()+5, 'zameria_purchaser_identity', array(strtolower(trim($email)), 0));
        }
    }

    public static function identity_batch($email, $after = 0) {
        if (!self::enabled()) return;
        global $wpdb;
        // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching -- Read current custom guest contributions in bounded ID order to reconcile account changes without skipping newly linked orders.
        $ids=$wpdb->get_col($wpdb->prepare("SELECT order_id FROM {$wpdb->prefix}zameria_purchases WHERE customer_id = 0 AND billing_email = %s AND order_id > %d ORDER BY order_id ASC LIMIT %d",$email,$after,self::BATCH));
        foreach($ids as $id) self::changed((int)$id);
        if(count($ids)===self::BATCH) wp_schedule_single_event(time()+5, 'zameria_purchaser_identity', array($email,(int)end($ids)));
    }

    public static function contribution($order) {
        if (!$order || 'shop_order' !== $order->get_type() || 'trash' === $order->get_status()) return null;
        $billing = $order->get_address('billing');
        $email = strtolower(trim($billing['email'] ?? ''));
        $id = (int)$order->get_customer_id();
        $identity_id = $id;
        if (!$id && is_email($email)) {
            $matches=get_users(array('search'=>$email,'search_columns'=>array('user_email'),'fields'=>'ID','number'=>2));
            if(count($matches)===1) $identity_id=(int)$matches[0];
        }
        // No synthetic people for anonymous orders; phone-only guests stay order-specific.
        $key = $identity_id > 0 ? 'u-'.$identity_id : (is_email($email) ? 'g-'.hash('sha256', $email) : (!empty($billing['phone']) ? 'o-'.$order->get_id() : ''));
        $status = $order->get_status();
        $statuses = apply_filters('zameria_purchaser_statuses', array_unique(array_merge(wc_get_is_paid_statuses(), array('completed','processing','refunded'))));
        $qualifies = !in_array($status, array('pending','on-hold','failed','cancelled','trash'), true) && (in_array($status, $statuses, true) || (bool)$order->get_date_paid());
        $date = $order->get_date_created();
        return array(
            'order_id'=>(int)$order->get_id(), 'buyer_key'=>$key, 'customer_id'=>$id,
            'billing_email'=>$email,
            'qualifies'=>(int)($qualifies && '' !== $key),
            'net_total'=>$qualifies ? max(0, (float)$order->get_total() - (float)$order->get_total_refunded()) : 0,
            'is_pos'=>(int)('yes' === $order->get_meta('_zameria_pos_order')),
            'owner_id'=>(int)($order->get_meta('_zameria_created_by_user_id') ?: $order->get_meta('_zameria_attended_by_user_id')),
            'private_order'=>(int)in_array($status, array('pending','on-hold'), true),
            'purchased_at'=>$date ? $date->date('c') : '',
            'profile'=>wp_json_encode(array('id'=>$identity_id, 'email'=>$email, 'first_name'=>$billing['first_name'] ?? '', 'last_name'=>$billing['last_name'] ?? '', 'billing'=>$billing)),
        );
    }

    private static function write_order($id) {
        global $wpdb;
        $table = $wpdb->prefix.'zameria_purchases';
        // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching -- Read/write custom purchaser contributions and change cursors atomically; stale fingerprints or transaction state could hide changed orders.
        $old = $wpdb->get_row($wpdb->prepare('SELECT buyer_key, fingerprint FROM %i WHERE order_id = %d', $table, $id));
        $row = self::contribution(wc_get_order($id));
        if ($row) {
            $row['fingerprint'] = hash('sha256', wp_json_encode($row));
            if ($old && $old->fingerprint === $row['fingerprint']) return;
        } elseif (!$old) return;
        // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching -- Read/write custom purchaser contributions and change cursors atomically; stale fingerprints or transaction state could hide changed orders.
        $wpdb->query('START TRANSACTION');
        try {
            // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching -- Read/write custom purchaser contributions and change cursors atomically; stale fingerprints or transaction state could hide changed orders.
            $ok = $row ? $wpdb->replace($table, $row) : $wpdb->delete($table, array('order_id'=>$id));
            if (false === $ok) throw new \RuntimeException('Could not save purchaser contribution.');
            $keys = array_unique(array_filter(array($old ? $old->buyer_key : '', $row ? $row['buyer_key'] : '')));
            foreach ($keys as $key) {
                // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery -- Read/write custom purchaser contributions and change cursors atomically; stale fingerprints or transaction state could hide changed orders.
                if (false === $wpdb->insert($wpdb->prefix.'zameria_purchaser_changes', array('buyer_key'=>$key))) throw new \RuntimeException('Could not save purchaser cursor.');
            }
            // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching -- Read/write custom purchaser contributions and change cursors atomically; stale fingerprints or transaction state could hide changed orders.
            $wpdb->query('COMMIT');
        // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching -- Read/write custom purchaser contributions and change cursors atomically; stale fingerprints or transaction state could hide changed orders.
        } catch (\Throwable $e) { $wpdb->query('ROLLBACK'); throw $e; }
    }

    private static function cursor() {
        global $wpdb;
        // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching -- Read the authoritative purchaser snapshot cursor so concurrent changes force retry rather than checkpointing incomplete data.
        return (int)$wpdb->get_var("SELECT MAX(id) FROM {$wpdb->prefix}zameria_purchaser_changes");
    }

    private static function scope_id() {
        return get_current_user_id().'-'.(int)current_user_can('manage_woocommerce');
    }

    private static function summary($key) {
        global $wpdb;
        $table = $wpdb->prefix.'zameria_purchases';
        $manager = (int)current_user_can('manage_woocommerce'); $uid = get_current_user_id();
        // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching -- Read the current permission-scoped custom projection under its checked snapshot; cached profiles could expose stale order ownership.
        $row = $wpdb->get_row($wpdb->prepare('SELECT COUNT(*) AS orders_count, SUM(qualifies) AS purchases_count, SUM(net_total) AS total_spent, MAX(CASE WHEN qualifies = 1 THEN purchased_at ELSE NULL END) AS last_purchase_at FROM %i WHERE buyer_key = %s AND (is_pos = 0 OR (%d = 1 AND private_order = 0) OR owner_id = %d)', $table, $key, $manager, $uid), ARRAY_A);
        if (!$row || (int)$row['purchases_count'] < 1) return null;
        // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching -- Read the current permission-scoped custom projection under its checked snapshot; cached profiles could expose stale order ownership.
        $profile = $wpdb->get_var($wpdb->prepare('SELECT profile FROM %i WHERE buyer_key = %s AND (is_pos = 0 OR (%d = 1 AND private_order = 0) OR owner_id = %d) ORDER BY qualifies DESC, order_id DESC LIMIT 1', $table, $key, $manager, $uid));
        $profile = json_decode($profile, true);
        return array_merge($profile, array('purchaser_key'=>$key, 'profile_type'=>0 === strpos($key,'u-') ? 'registered' : 'guest', 'orders_count'=>(int)$row['orders_count'], 'purchases_count'=>(int)$row['purchases_count'], 'total_spent'=>(string)$row['total_spent'], 'last_purchase_at'=>$row['last_purchase_at']));
    }

    private static function metadata() {
        return array('schema'=>1, 'scope'=>self::scope_id(), 'index'=>get_option(self::STATE, array('complete'=>false)));
    }

    public static function directory($request) {
        global $wpdb;
        $cursor = self::cursor();
        if (isset($request['snapshot']) && (int)$request['snapshot'] !== $cursor) return new \WP_Error('zameria_purchaser_snapshot_changed','Purchasers changed during download; retrying.',array('status'=>409));
        $after = sanitize_text_field((string)($request['after'] ?? ''));
        $limit = max(1,min(100,(int)($request['limit'] ?? 100)));
        $table = $wpdb->prefix.'zameria_purchases';
        $manager = (int)current_user_can('manage_woocommerce'); $uid = get_current_user_id();
        // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching -- Custom purchaser pages are bounded by a live snapshot and permission scope; the total alone is transient-cached by that snapshot/scope.
        $keys = $wpdb->get_col($wpdb->prepare('SELECT buyer_key FROM %i WHERE buyer_key > %s AND (is_pos = 0 OR (%d = 1 AND private_order = 0) OR owner_id = %d) GROUP BY buyer_key HAVING SUM(qualifies) > 0 ORDER BY buyer_key ASC LIMIT %d', $table, $after, $manager, $uid, $limit+1));
        $total_key = 'zameria_buyers_' . md5($cursor . '-' . self::scope_id());
        $total = get_transient($total_key);
        if (false === $total) {
            // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching -- Custom purchaser pages are bounded by a live snapshot and permission scope; the total alone is transient-cached by that snapshot/scope.
            $total = (int)$wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM (SELECT buyer_key FROM %i WHERE buyer_key <> '' AND (is_pos = 0 OR (%d = 1 AND private_order = 0) OR owner_id = %d) GROUP BY buyer_key HAVING SUM(qualifies) > 0) AS buyers", $table, $manager, $uid));
            set_transient($total_key, $total, 600);
        }
        $more = count($keys)>$limit; $keys = array_slice($keys,0,$limit);
        $buyers = array(); foreach ($keys as $key) { $buyer = self::summary($key); if ($buyer) $buyers[]=$buyer; }
        if ($cursor !== self::cursor()) return new \WP_Error('zameria_purchaser_snapshot_changed','Purchasers changed during download; retrying.',array('status'=>409));
        return rest_ensure_response(array_merge(self::metadata(),array('purchasers'=>$buyers,'cursor'=>$cursor,'more'=>$more,'next_after'=>$keys ? end($keys) : $after,'total_items'=>(int)$total)));
    }

    public static function changes($request) {
        global $wpdb;
        $since = max(0,(int)($request['since'] ?? 0)); $cursor = self::cursor();
        if (($request['scope'] ?? '') !== self::scope_id() || $since > $cursor || $since < (int)get_option(self::FLOOR, 0)) return rest_ensure_response(array('reset'=>true));
        // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching -- Read ordered custom purchaser change rows at a live cursor; caching could miss removal/reassignment and violate snapshot checks.
        $rows = $wpdb->get_results($wpdb->prepare("SELECT id, buyer_key FROM {$wpdb->prefix}zameria_purchaser_changes WHERE id > %d ORDER BY id ASC LIMIT 101",$since));
        $more = count($rows)>100; $rows = array_slice($rows,0,100); $keys=array(); $next=$since;
        foreach ($rows as $row) { $keys[$row->buyer_key]=true; $next=(int)$row->id; }
        $buyers=array(); $removed=array();
        foreach (array_keys($keys) as $key) { $buyer=self::summary($key); if ($buyer) $buyers[]=$buyer; else $removed[]=$key; }
        // Don't checkpoint a summary computed across concurrent writes.
        if ($cursor !== self::cursor()) return new \WP_Error('zameria_purchaser_snapshot_changed','Purchasers changed during download; retrying.',array('status'=>409));
        return rest_ensure_response(array_merge(self::metadata(),array('reset'=>false,'purchasers'=>$buyers,'removed'=>$removed,'cursor'=>$next,'more'=>$more)));
    }

    public static function history($request) {
        global $wpdb;
        $key = sanitize_text_field((string)$request['key']);
        $summary=self::summary($key);
        if (!$summary) return new \WP_Error('zameria_purchaser_missing','Purchaser is not available.',array('status'=>404));
        $cursor = self::cursor();
        if (isset($request['snapshot']) && (int)$request['snapshot'] !== $cursor) return new \WP_Error('zameria_purchaser_snapshot_changed','History changed during download; retrying.',array('status'=>409));
        $before = max(0,(int)($request['before'] ?? 0));
        $table = $wpdb->prefix.'zameria_purchases';
        $manager = (int)current_user_can('manage_woocommerce'); $uid = get_current_user_id();
        // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching -- Read current permission-scoped custom history IDs inside snapshot checks; caching could retain an order after its ownership changes.
        $ids=$wpdb->get_col($wpdb->prepare('SELECT order_id FROM %i WHERE buyer_key = %s AND (is_pos = 0 OR (%d = 1 AND private_order = 0) OR owner_id = %d) AND (%d = 0 OR order_id < %d) ORDER BY order_id DESC LIMIT 51', $table, $key, $manager, $uid, $before, $before));
        $more=count($ids)>50; $ids=array_slice($ids,0,50); $orders=array();
        $controller=new \WC_REST_Orders_Controller();
        foreach($ids as $id) {
            $order=wc_get_order($id);
            if (!$order || !Auth::can_read_order($order)) return new \WP_Error('zameria_purchaser_history_changed','History changed; retrying.',array('status'=>409));
            $response=$controller->prepare_object_for_response($order,$request);
            if (is_wp_error($response)) return $response;
            $payload=$response->get_data();
            $contribution=self::contribution($order);
            if (!$contribution || $contribution['buyer_key'] !== $key) return new \WP_Error('zameria_purchaser_history_changed','History changed; retrying.',array('status'=>409));
            $payload['zameria_purchase']=(bool)$contribution['qualifies'];
            $payload['zameria_purchaser_key']=$key;
            $orders[]=$payload;
        }
        if ($cursor !== self::cursor()) return new \WP_Error('zameria_purchaser_snapshot_changed','History changed during download; retrying.',array('status'=>409));
        return rest_ensure_response(array_merge(self::metadata(),array('orders'=>$orders,'total_items'=>$summary['orders_count'],'more'=>$more,'next_before'=>$ids ? (int)end($ids) : $before,'cursor'=>$cursor)));
    }
}
