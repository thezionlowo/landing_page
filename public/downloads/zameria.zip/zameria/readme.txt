=== Zameria POS ===
Contributors: zameriahq
Tags: woocommerce pos, point of sale, inventory sync, retail pos, barcode scanner
Requires at least: 6.3
Tested up to: 7.1
Requires PHP: 7.4
Requires Plugins: woocommerce
WC requires at least: 8.0
WC tested up to: 11.2
Stable tag: 0.2.18
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Manage in-store sales, products, stock and purchasing customers with your WooCommerce store. Requires a ZAMERIA service account and active access.

== Description ==

Zameria POS connects your shop counter to WooCommerce. It includes the WordPress connector, merchant dashboard and a browser POS application. Products, orders, inventory and customer records sync between the authorised POS browser and your store.

**A ZAMERIA merchant account and active service access are required.** Eligible stores can start a seven-day trial. Continued POS use requires a paid Starter or Business annual plan, or access granted by ZAMERIA. This is not a permanently free POS. Account services include merchant registration, store activation, subscription checkout and payment verification, billing records, installation credentials, onboarding records and support. See https://www.zameria.co/#pricing for current prices and limits.

* Sell with a locally cached catalogue and queue offline sales for upload when the connection returns.
* Sync products, variations, stock, orders and customers who have purchased from your store.
* Sign staff in using their authorised WordPress username/email and password; permissions remain store-controlled.
* Count active users by WordPress account. Signing the same account in again replaces its previous POS session.
* Record split payments and print receipts through supported browser/device integrations. Recording payment does not process or verify a card or bank-transfer transaction.
* Use WooCommerce order APIs with HPOS or legacy order storage.

Sync depends on connection, store load and permissions. Background refresh normally polls at intervals; there is no guaranteed sub-second update. Adding a product to the cart does not reserve stock. An offline register can have older inventory information. Check sync status before relying on a stock count or clearing browser storage.

The plugin includes a local POS at your store's `/pos/` address. The default Open POS button launches https://pos.zameria.co in a separate tab, configured for your store. Hosted and local POS addresses have separate browser storage: upload pending work before switching between them. The WordPress dashboard loads its local assets and WordPress-registered React dependencies. The packaged local POS uses those same core libraries with a React 18-compatible router; the hosted build retains its standalone React runtime.

== External services ==

= ZAMERIA account service =

Default API: https://scoreflip-go-hwsgspeycq-uc.a.run.app/api/v1/zameria
Account website: https://www.zameria.co
Hosted POS: https://pos.zameria.co

When you explicitly create or connect a merchant account, the plugin sends the ZAMERIA email/password and store URL over HTTPS to `/account/register` or `/account/login`. Registration can also send name, business name, phone and store address when supplied. These are merchant-account credentials, separate from staff WordPress credentials.

Activation and access checks send store URL/domain, account or licence identifier and installation credential to `/trial/request`, `/license/activate`, `/account/store/credentials`, `/account/entitlement` and `/entitlement` as appropriate. Connected stores are rechecked during use without requiring the owner to stay signed in. Normal access verification has a 60-second interval; explicit checks can run sooner. A previously verified store can receive up to 24 hours of grace on transient account-service failure, subject to existing access state. Expiry, suspension or disconnection can restrict POS access; they do not delete WooCommerce records.

Account registration also sends a signup event to `/lead/capture`: event/event ID, account ID, email, name, business name, phone when available, store URL, source and registration source. This creates an onboarding/follow-up record. Failed events are stored locally and retried by WordPress scheduling; the retry payload excludes passwords and bearer credentials.

When staff choose support, `/store/support/start` and `/support/conversation` receive the staff name/email, submitted messages, store installation credentials and conversation identifiers/credential. Include customer data in support messages only when appropriate. Website forms, account operations and checkout send their submitted fields to the service; Paystack processes subscription payment.

**Store data path:** normal product, order, inventory and customer sync goes between the POS browser and the merchant's WordPress/WooCommerce API, not to the central account-check API. Customer details, orders, staff session tokens, carts and pending offline work can be held in browser storage. The hosted POS uses storage under pos.zameria.co. This is not a central cloud backup of the store database.

Connecting the service authorises its required ongoing access checks. Account setup displays this disclosure and policy links before submission. Logging out or uninstalling does not automatically delete the cloud account or all browser data. Uninstall removes plugin tables, connection settings, pending signup payloads and persisted plugin transient rows. Browser storage and the cloud account remain separate; non-enumerable object-cache transients expire by their TTL.

Terms of Service: https://www.zameria.co/terms
Privacy Policy: https://www.zameria.co/privacy
Support/privacy requests: support@zameria.co

= Google Fonts and merchant image hosts =

The POS can request fonts from https://fonts.googleapis.com and https://fonts.gstatic.com. Google receives normal network request information, including IP address and browser headers. Font privacy information: https://developers.google.com/fonts/faq/privacy

Product images are fetched from the image URLs configured by the merchant. Network and hosting providers also process ordinary connection metadata. Further provider and storage information is in the Privacy Policy.

== Source code and build instructions ==

The downloadable plugin ZIP contains readable frontend source, not only compiled assets:

* `source/pos/`: POS TypeScript/TSX, CSS, public assets, configuration and exact npm dependency lockfile.
* `source/admin/`: WordPress dashboard source, configuration and exact npm dependency lockfile.
* `SOURCE.txt`: isolated build instructions using Node.js 24+ and npm 11+.
* `source/manifest.json` and `build-info.json`: source mappings and SHA-256 hashes.
* `ARCHITECTURE.txt`: local/hosted client behaviour, account service endpoints and data flows.
* `THIRD_PARTY_NOTICES.txt`, `LICENSE.txt` and `licenses/GPL-3.0.txt`: licences and attribution. Apache-2.0 components retain their licences; the GPLv3 option is available for combined distribution.

Download including source: https://www.zameria.co/downloads/zameria.zip

From the extracted `source/pos` and `source/admin` directories, run `npm ci`, then build using the explicit output paths in `SOURCE.txt`. Use ZAMERIA_WORDPRESS_BUILD=1 for the packaged WordPress target. No ZAMERIA account or merchant credentials are needed to build. PHP is supplied directly in readable form. The separate account-service implementation is not included in this client plugin.

== Installation ==

1. Back up your store and confirm that WooCommerce is installed and active.
2. Install and activate Zameria POS through WordPress Plugins, or upload `zameria.zip`.
3. Open ZAMERIA in WordPress admin and review the service disclosure and policies.
4. Create or sign in to the merchant's ZAMERIA account and connect this store. An eligible trial starts on activation; otherwise active plan access is required.
5. Open POS and sign in using an authorised WordPress store account. Allow the initial catalogue, customer and order sync to finish.
6. Check hardware and sync behaviour in a test sale before using the register for retail transactions.

== Frequently Asked Questions ==

= Is an account or payment required? =
Yes. A ZAMERIA service account is required. Eligible stores can use a seven-day trial, followed by paid annual access. Starter currently allows five active staff accounts and 500 catalogue products; Business has no configured staff or catalogue count limit. The same WordPress account uses one active POS session across devices.

= Does the plugin include the POS application? =
Yes. The complete local build is served from your store's `/pos/` address. The default launch button opens the hosted client in a separate tab. Both use your store API. Switching origins does not migrate pending browser data.

= What happens offline? =
The previously loaded app can use cached data and queue supported sales/edits. Synchronisation resumes when connectivity and access permit. Do not clear browser storage while work is pending. Offline stock may be out of date and offline operation does not extend paid access.

= Which hardware works? =
Browser printing and scanner/printer integrations depend on the browser, operating system and connection type. Receipt layouts support 58 mm and 80 mm formats; this is not a guarantee that every USB/Bluetooth printer works. Test your actual hardware before purchase or rollout.

= How does HPOS work? =
The plugin declares HPOS compatibility and uses WooCommerce order APIs. WooCommerce chooses the store's configured order storage; the plugin does not force all stores onto HPOS.

= How do I request account deletion or support? =
Email support@zameria.co. Account deletion is separate from uninstalling the plugin. Contact the merchant directly about its shoppers' WooCommerce records.

== Changelog ==

= 0.2.18 =
* Refresh all POS workspaces with consistent navigation, page headers, readable controls and responsive layouts.
* Keep payment actions visible and improve nested dialog keyboard focus, touch controls and receipt access.
* Prioritise sales trends and key dashboard metrics; group store, printing and interface settings.
* Preserve existing checkout, stock, offline queues, customer history and role permissions.

= 0.2.17 =
* Refresh newest orders independently of catalogue imports and display orders by creation date, newest first.
* Resume complete purchase history and refresh changed customer profiles through a small store-local change journal.
* Page and search the cached purchaser directory using scoped, indexed summaries.
* Build cached dashboard totals from all orders in the selected period, including partial refunds and products beyond the first 100 orders.
* Apply staff order privacy inside HPOS and legacy pagination queries without scanning all held orders.
* Preserve offline sales, customer identities, full history and existing plan/session limits.

= 0.2.16 =
* Starter now includes up to five active staff accounts, with one session per account.
* Update Nigerian Business annual pricing to NGN 350,000; Starter remains NGN 200,000.
* Apply the Starter allowance to existing entitlements and align account and staff displays.

= 0.2.15 =
* Use WordPress-provided React/ReactDOM in the packaged dashboard and local POS while retaining the hosted POS runtime.
* Cache core dependencies for local offline startup and constrain worker navigation to the POS scope.
* Prepare SQL identifiers and literal permission predicates; validate account payloads without altering passwords.
* Review custom-table, concurrency and read-only navigation advisories with per-operation explanations.
* Remove plugin connection, retry and persisted transient records on uninstall while preserving WooCommerce data.


= 0.2.14 =
* Document account-service endpoints, transmitted data, paid access, local/hosted POS behaviour and cleanup limitations.
* Add readable frontend source, dependency locks, build instructions, architecture and third-party licence notices to every packaged ZIP.
* Link Terms and Privacy information before account setup and correct unsupported readme claims.
* Align directory metadata and clarify translation placeholders.

= 0.2.13 =
* Count active POS users by WordPress account; signing in replaces that account's earlier session across devices.
* Retire existing duplicate sessions on upgrade while preserving session history and store data.
* Check online session access independently of catalogue imports, keeping pending offline sales intact.
* Redesign the WordPress workspace with ZAMERIA navy and light blue, clearer plan usage and active-user controls.


= 0.2.12 =
* Restore the existing customer and WooCommerce order sync without requiring a purchaser index.
* Repair historical checkpoints, validate pagination, resume failures, and discover genuine guest/custom-role buyers from orders.
* Load exact customer histories and preserve carts, login, pending edits and sales.

= 0.2.11 =
* Adds an order-derived purchaser directory with resumable backfill, incremental refresh and paged order history.
* Includes genuine guest and custom-role buyers while excluding unpaid-only accounts; preserves carts, pending sales and customer edits.
* Reports incomplete imports and retains compatibility with older POS clients.

= 0.2.10 =
* Complete owner connection and save installation credentials during sign-in, with specific connection errors.

= 0.2.9 =
* Remove sample merchant lifecycle data and fabricated account/trial defaults.
* Remove demo accounts and seeding from the production POS build.
* Preserve the isolated website product demonstration.

= 0.2.8 =
* Restore the compact POS sign-in form and original sign-in labels.
* Verify connected stores independently of the owner's account session.
* Preserve installation credentials during routine account refreshes.
* Guide older stores through the one-time connection update before showing POS access as connected.

= 0.2.6 =
* Verify store access on the server, preserve historical queued sales and persist access denials.
* Enforce cashier order privacy and protect product brand edits.
* Connect POS support to the central support inbox.

= 0.2.5 =
* Fix: Prevent duplicate website order imports during concurrent synchronization.
* Fix: Repair duplicate synced order copies on device upgrade, retaining backup snapshots and order references.
* Fix: Enforce unique normalized remote order identities and reconcile simultaneous sale upload/download acknowledgements.
* Preserve unsynced sales and local held orders during repair.

= 0.2.4 =
* Feature: High-Performance Order Storage (HPOS) native compatibility declaration.
* Improvement: Inventory synchronization via REST endpoints.
* Improvement: Mathematical stock valuation aggregation (Current Stock Value = Σ quantity × selling price).
* Fix: Session persistence enhancements for multi-cashier terminal switches.

= 0.2.3 =
* Feature: IndexedDB offline sale queuing with chronological replay.
* Improvement: 80mm and 58mm thermal receipt formatting engine.

= 0.2.0 =
* Initial public release with WooCommerce REST API companion controller.
