=== ZAMERIA POS Connector — Point of Sale & In-Store Inventory Sync for WooCommerce ===
Contributors: zameriahq
Tags: woocommerce pos, point of sale, inventory sync, retail pos, barcode scanner, pos plugin
Requires at least: 6.3
Tested up to: 6.7
Requires PHP: 7.4
WC requires at least: 8.0
WC tested up to: 9.6
Stable tag: 0.2.12
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Manage your in-store and website orders in one place.

== Description ==

**Manage your in-store and website orders in one place.**

Keep your products, stock and customers in sync across your shop and website.

Turn any laptop, desktop PC, iPad, or Android tablet into a lightning-fast retail register for your brick-and-mortar storefront. Eliminate overselling, stockouts, and manual spreadsheets by synchronizing your physical store counter with your online WooCommerce catalog in real time.

This plugin acts as the official WooCommerce connector and synchronization bridge for the ZAMERIA Point of Sale cloud service. Unlike legacy POS plugins that slow down your WordPress dashboard with bloated queries, ZAMERIA uses an externalized, offline-first client architecture with High-Performance Order Storage (HPOS) compatibility.

### Why WooCommerce Retailers Choose ZAMERIA

* **Sub-Second Bi-Directional Stock Sync**: When an item sells at your physical register, online WooCommerce inventory updates in under 0.5 seconds. When an online order arrives, POS registers reflect the updated count immediately.
* **True Offline-First Resilience**: Internet dropped? No problem. ZAMERIA caches your product catalog in local IndexedDB. Cashiers can continue barcode scanning, ringing up sales, and printing receipts. Transactions automatically sync when the connection restores.
* **Atomic Inventory Locking**: Prevents race conditions during busy retail hours and flash sales. If one unit remains and an in-store cashier adds it to the cart, online shoppers cannot buy the same unit.
* **Hardware Freedom**: Zero proprietary hardware leases. Works with standard 80mm and 58mm ESC/POS thermal receipt printers, USB/Bluetooth barcode scanners, and standard cash drawers.
* **Complex Variable Product Support**: Native variation matrices for fashion sizes, apparel colors, beauty shades, and custom SKUs.
* **Native Split Tender**: Accept mixed payments on a single sale (e.g., cash, credit card POS terminal, and bank transfer) with exact change calculation.
* **Staff PIN Sign-Ins**: Support for multiple cashiers and managers with role-based permissions, shift balancing, and sales tracking.

== External Service Disclosure ==

This plugin connects your WooCommerce store to the ZAMERIA Point of Sale cloud service (SaaS) to provide physical register operations, account pairing, plan entitlements, and real-time stock synchronization.

* External Service: ZAMERIA Cloud Service (https://zameria.co, https://pos.zameria.co, and cloud API services)
* What data is transmitted: Store URL, store name, staff device tokens, and product/order sync payloads.
* Terms of Service: https://zameria.co/terms
* Privacy Policy: https://zameria.co/privacy

== Installation ==

1. Download the `zameria.zip` plugin file.
2. Log in to your WordPress Admin Dashboard.
3. Navigate to **Plugins > Add New > Upload Plugin**.
4. Choose the `zameria.zip` file and click **Install Now**.
5. Click **Activate Plugin**.
6. Navigate to **ZAMERIA** in your WordPress admin sidebar.
7. Open the POS register on your device and sign in with your authorized merchant credentials.

== Frequently Asked Questions ==

= Does ZAMERIA require custom hardware? =
No. ZAMERIA runs in any modern web browser (Google Chrome, Safari, Microsoft Edge) on Windows, macOS, iPadOS, iOS, or Android. You can connect standard USB or Bluetooth barcode scanners and thermal receipt printers.

= Is ZAMERIA compatible with WooCommerce HPOS (High-Performance Order Storage)? =
Yes. ZAMERIA declares full native compatibility with WooCommerce Custom Order Tables (HPOS). Orders created at your counter are written directly to optimized database tables with zero legacy postmeta bloat.

= What happens when my shop loses internet connection? =
ZAMERIA continues operating seamlessly. It saves offline orders locally in browser IndexedDB storage and queues them for automatic background synchronization as soon as internet connectivity returns.

= Does ZAMERIA charge per-transaction fees? =
No. ZAMERIA operates on transparent annual plans with unlimited transactions and zero commission cuts.

== Screenshots ==

1. `screenshot-1.png` - Real-Time POS Counter Register with barcode product search and variation selector.
2. `screenshot-2.png` - Split payment tender modal supporting cash, card terminal, and bank transfer.
3. `screenshot-3.png` - Inventory Overview showing live stock value and bi-directional WooCommerce sync status.
4. `screenshot-4.png` - Custom thermal receipt preview for 80mm ESC/POS printers.

== Changelog ==

= 0.2.12 =
* Restore the existing customer and WooCommerce order sync without requiring a purchaser index.
* Repair historical checkpoints, validate pagination, resume failures, and discover genuine guest/custom-role buyers from orders.
* Load exact customer histories and preserve carts, login, pending edits and sales.

= 0.2.11 =
* Adds an order-derived purchaser directory with resumable backfill, incremental refresh and paged order history.
* Includes genuine guest and custom-role buyers while excluding unpaid-only accounts; preserves carts, pending sales and customer edits.
* Reports incomplete imports and retains compatibility with older POS clients.

= 0.2.10 =
* Complete owner connection and save installation credentials during sign-in, with specific connection errors.

= 0.2.9 =
* Remove sample merchant lifecycle data and fabricated account/trial defaults.
* Remove demo accounts and seeding from the production POS build.
* Preserve the isolated website product demonstration.

= 0.2.8 =
* Restore the compact POS sign-in form and original sign-in labels.
* Verify connected stores independently of the owner's account session.
* Preserve installation credentials during routine account refreshes.
* Guide older stores through the one-time connection update before showing POS access as connected.

= 0.2.6 =
* Verify store access on the server, preserve historical queued sales and persist access denials.
* Enforce cashier order privacy and protect product brand edits.
* Connect POS support to the central support inbox.

= 0.2.5 =
* Fix: Prevent duplicate website order imports during concurrent synchronization.
* Fix: Repair duplicate synced order copies on device upgrade, retaining backup snapshots and order references.
* Fix: Enforce unique normalized remote order identities and reconcile simultaneous sale upload/download acknowledgements.
* Preserve unsynced sales and local held orders during repair.

= 0.2.4 =
* Feature: High-Performance Order Storage (HPOS) native compatibility declaration.
* Improvement: Sub-second atomic inventory synchronization via REST endpoints.
* Improvement: Mathematical stock valuation aggregation (Current Stock Value = Σ quantity × selling price).
* Fix: Session persistence enhancements for multi-cashier terminal switches.

= 0.2.3 =
* Feature: IndexedDB offline sale queuing with chronological replay.
* Improvement: 80mm and 58mm thermal receipt formatting engine.

= 0.2.0 =
* Initial public release with WooCommerce REST API companion controller.
