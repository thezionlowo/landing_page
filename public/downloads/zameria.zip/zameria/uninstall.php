<?php
/**
 * Removes Zameria's tables and settings when the plugin is deleted.
 * WooCommerce orders created by the POS are kept.
 *
 * @package Zameria
 */

defined( 'WP_UNINSTALL_PLUGIN' ) || exit;

global $wpdb;

foreach ( array( 'zameria_changes', 'zameria_devices', 'zameria_sales', 'zameria_purchases', 'zameria_purchaser_changes' ) as $zameria_table ) {
	// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching,WordPress.DB.DirectDatabaseQuery.SchemaChange -- Explicit WordPress uninstall removes only fixed plugin-owned tables/options; prepared identifiers and live cleanup prevent retained connection data.
	$wpdb->query( $wpdb->prepare( 'DROP TABLE IF EXISTS %i', $wpdb->prefix . $zameria_table ) );
}

foreach ( array( 'zameria_db_version', 'zameria_changes_floor', 'zameria_payment_methods', 'zameria_receipt_footer', 'zameria_entitlement', 'zameria_admin_activity', 'zameria_store_credentials', 'zameria_access_verified_at', 'zameria_access_denied_at' ) as $zameria_option ) {
	delete_option( $zameria_option );
}

remove_role( 'zameria_cashier' );
foreach ( array( 'administrator', 'shop_manager' ) as $zameria_role_name ) {
	$zameria_role = get_role( $zameria_role_name );
	if ( $zameria_role ) {
		$zameria_role->remove_cap( 'zameria_use_pos' );
	}
}

wp_clear_scheduled_hook( 'zameria_daily' );
wp_clear_scheduled_hook( 'zameria_purchaser_batch' );
delete_option( 'zameria_purchaser_index' );
delete_option( 'zameria_purchaser_floor' );
wp_unschedule_hook( 'zameria_purchaser_order' );
wp_unschedule_hook( 'zameria_purchaser_identity' );
if (function_exists('as_unschedule_all_actions')) {
    as_unschedule_all_actions('zameria_purchaser_batch', null, 'zameria');
    as_unschedule_all_actions('zameria_purchaser_order', null, 'zameria');
}

// Delete only this plugin's persisted signup payloads and transient rows. Core
// order/customer tables, other plugins' options and unrelated cache entries stay intact.
// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching -- Explicit WordPress uninstall removes only fixed plugin-owned tables/options; prepared identifiers and live cleanup prevent retained connection data.
$zameria_option_names = $wpdb->get_col( $wpdb->prepare(
    'SELECT option_name FROM %i WHERE option_name LIKE %s OR option_name LIKE %s OR option_name LIKE %s',
    $wpdb->options,
    $wpdb->esc_like( 'zameria_signup_lead_' ) . '%',
    $wpdb->esc_like( '_transient_zameria_' ) . '%',
    $wpdb->esc_like( '_transient_timeout_zameria_' ) . '%'
) );
foreach ( $zameria_option_names as $zameria_option_name ) {
    if ( 0 === strpos( $zameria_option_name, '_transient_timeout_' ) ) {
        delete_transient( substr( $zameria_option_name, strlen( '_transient_timeout_' ) ) );
    } elseif ( 0 === strpos( $zameria_option_name, '_transient_' ) ) {
        delete_transient( substr( $zameria_option_name, strlen( '_transient_' ) ) );
    } else {
        delete_option( $zameria_option_name );
    }
}
wp_unschedule_hook( 'zameria_retry_signup_lead' );
