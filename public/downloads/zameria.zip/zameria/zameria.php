<?php
/**
 * Plugin Name:       Zameria POS
 * Plugin URI:        https://zameria.co
 * Description:       Manage your in-store and website orders in one place. Keep your products, stock and customers in sync across your shop and website. WooCommerce point of sale with offline selling.
 * Version:           0.2.17
 * Requires at least: 6.3
 * Requires PHP:      7.4
 * Requires Plugins:  woocommerce
 * Author:            Zameria
 * Author URI:        https://zameria.co
 * License:           GPL-2.0-or-later
 * License URI:       https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain:       zameria
 * WC requires at least: 8.0
 *
 * @package Zameria
 */

defined( 'ABSPATH' ) || exit;

define( 'ZAMERIA_VERSION', '0.2.17' );
define( 'ZAMERIA_FILE', __FILE__ );
define( 'ZAMERIA_DIR', plugin_dir_path( __FILE__ ) );
define( 'ZAMERIA_URL', plugin_dir_url( __FILE__ ) );
// The package includes a local /pos/ app. The primary launch action currently
// opens pos.zameria.co; both clients connect to the merchant's store API.

require_once ZAMERIA_DIR . 'includes/class-install.php';
require_once ZAMERIA_DIR . 'includes/class-settings.php';
require_once ZAMERIA_DIR . 'includes/class-change-log.php';
require_once ZAMERIA_DIR . 'includes/class-customer-changes.php';
require_once ZAMERIA_DIR . 'includes/class-dashboard-summary.php';
require_once ZAMERIA_DIR . 'includes/class-auth.php';
require_once ZAMERIA_DIR . 'includes/class-purchaser-index.php';
require_once ZAMERIA_DIR . 'includes/class-product-formatter.php';
require_once ZAMERIA_DIR . 'includes/class-sale-importer.php';
require_once ZAMERIA_DIR . 'includes/class-rest-controller.php';
require_once ZAMERIA_DIR . 'includes/class-app-server.php';
require_once ZAMERIA_DIR . 'includes/class-cloud-account.php';
require_once ZAMERIA_DIR . 'includes/class-store-access.php';
require_once ZAMERIA_DIR . 'includes/class-admin.php';

register_activation_hook( __FILE__, array( 'Zameria\\Install', 'activate' ) );
register_deactivation_hook( __FILE__, array( 'Zameria\\Install', 'deactivate' ) );

add_action(
	'before_woocommerce_init',
	function () {
		if ( class_exists( \Automattic\WooCommerce\Utilities\FeaturesUtil::class ) ) {
			\Automattic\WooCommerce\Utilities\FeaturesUtil::declare_compatibility( 'custom_order_tables', ZAMERIA_FILE, true );
		}
	}
);

add_action(
	'plugins_loaded',
	function () {
		if ( ! class_exists( 'WooCommerce' ) ) {
			add_action(
				'admin_notices',
				function () {
					echo '<div class="notice notice-error"><p>' . esc_html__( 'Zameria POS needs WooCommerce to be installed and active.', 'zameria' ) . '</p></div>';
				}
			);
			return;
		}

		Zameria\Install::maybe_upgrade();
		Zameria\Auth::init();
		Zameria\Purchaser_Index::init();
		Zameria\Change_Log::init();
        Zameria\Customer_Changes::init();
        Zameria\Dashboard_Summary::init();
		Zameria\Rest_Controller::init();
		Zameria\App_Server::init();
		Zameria\Cloud_Account::init();
		Zameria\Admin::init();
	}
);
