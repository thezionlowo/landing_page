import { BRAND_HEADLINE, BRAND_SUPPORT } from './src/lib/brandMessaging.ts';
import react from '@vitejs/plugin-react'
import tailwindcss from '@tailwindcss/vite'
import { VitePWA } from 'vite-plugin-pwa'
import { defineConfig } from 'vite'
import path from 'node:path'
import { wordpressReact } from './build/wordpress-react.ts'

// Local WordPress + WooCommerce + Zameria plugin (see the Zion repo's `npm run wp:start`).
const wordpressBuild = process.env.ZAMERIA_WORDPRESS_BUILD === '1'
const WP_DEV_URL = process.env.WP_DEV_URL ?? 'http://localhost:8888'

// https://vite.dev/config/
export default defineConfig({
  // Relative paths: the Zameria plugin serves this build from /pos/ on any domain or sub-folder.
  base: './',
  build: {
    // The Zion repo's build sets this to plugin/zameria/pos-app so the plugin ships the app.
    outDir: process.env.ZAMERIA_OUT_DIR ?? 'dist',
    emptyOutDir: true,
  },
  server: {
    port: 5176,
    host: '0.0.0.0',
    proxy: {
      '/wp-json': { target: WP_DEV_URL, changeOrigin: true },
    },
  },
  plugins: [
    wordpressReact(wordpressBuild),
    react(),
    tailwindcss(),
    VitePWA({
      registerType: 'prompt',
      devOptions: { enabled: false },
      includeAssets: ['favicon.svg', 'favicon.ico', 'apple-touch-icon-180x180.png', 'zameria-logo.png'],
      manifest: {
        name: 'ZAMERIA POS',
        short_name: 'ZAMERIA',
        description: `${BRAND_HEADLINE}. ${BRAND_SUPPORT}`,
        theme_color: '#0f172a',
        background_color: '#0f172a',
        display: 'standalone',
        orientation: 'any',
        start_url: './',
        scope: './',
        icons: [
          { src: 'pwa-64x64.png', sizes: '64x64', type: 'image/png' },
          { src: 'pwa-192x192.png', sizes: '192x192', type: 'image/png' },
          { src: 'pwa-512x512.png', sizes: '512x512', type: 'image/png' },
          { src: 'maskable-icon-512x512.png', sizes: '512x512', type: 'image/png', purpose: 'maskable' },
        ],
      },
      workbox: {
        globPatterns: ['**/*.{js,css,html,ico,png,svg,woff2}'],
        navigateFallback: 'index.html',
        // Store data lives in IndexedDB; never serve the app shell for API calls.
        navigateFallbackDenylist: [/\/wp-json\//],
        runtimeCaching: [
          {
            // Product images from the store (any host), so the catalogue has pictures offline.
            urlPattern: ({ request }) => request.destination === 'image',
            handler: 'StaleWhileRevalidate',
            options: {
              cacheName: 'product-images',
              expiration: { maxEntries: 3000, maxAgeSeconds: 60 * 60 * 24 * 60 },
              cacheableResponse: { statuses: [0, 200] },
            },
          },
          {
            // Inter font, so the till looks the same offline.
            urlPattern: /^https:\/\/fonts\.(googleapis|gstatic)\.com\/.*/i,
            handler: 'CacheFirst',
            options: {
              cacheName: 'google-fonts',
              expiration: { maxEntries: 30, maxAgeSeconds: 60 * 60 * 24 * 365 },
              cacheableResponse: { statuses: [0, 200] },
            },
          },
        ],
      },
    }),
  ],
  resolve: {
    alias: {
      '@': path.resolve(import.meta.dirname, './src'),
      ...(wordpressBuild ? { 'react-router': path.resolve(import.meta.dirname, 'node_modules/react-router-wordpress') } : {}),
    },
  },
})
