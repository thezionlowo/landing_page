import './mocks/demoStorage';
import React from 'react';
import { createRoot } from 'react-dom/client';
import { MemoryRouter } from 'react-router';
import { Toaster } from 'sonner';
import App from './App';
import { seedSkincareDemo } from './mocks/skincareDemo';
import { installDemoSupport } from './mocks/demoSupport';
import { DEMO_USERS } from './services/auth/permissions';
import { useAuthStore, useUIStore, useCartStore, useConnectionStore } from './store';
import './index.css';

async function renderPreview() {
  if (import.meta.env.MODE !== 'product-preview') throw new Error('Use the dedicated product-preview build.');
  const initializeDemo = async () => {
    await seedSkincareDemo(window.location.href);
    installDemoSupport();
    const sampleUser = { ...DEMO_USERS.admin, displayName: 'Demo store owner', storeName: 'Skincare Demo Store', token: undefined };
    useAuthStore.setState({ user: sampleUser, isAuthenticated: true, isLoading: false });
    useUIStore.setState({ isDemoMode: true, sidebarCollapsed: window.innerWidth < 1024, theme: 'light' });
    useConnectionStore.setState({ isOnline: true, isConnectedToStore: false, storeName: 'Skincare Demo Store', storeUrl: '', status: 'ONLINE' });
    await useCartStore.getState().initCart();
  };
  // Device mockups and the interactive demo share one store. Serialize first-visit
  // seeding and cart creation across same-origin frames so neither is duplicated.
  if (navigator.locks) {
    await navigator.locks.request('zameria-product-demo-initialization', initializeDemo);
  } else {
    await initializeDemo();
  }
  // Start device previews on a real app screen without changing normal POS routing.
  const previewScreens = new Set(['sale', 'dashboard', 'products', 'customers', 'orders', 'settings']);
  const requestedScreen = new URLSearchParams(window.location.search).get('screen') ?? 'sale';
  const initialScreen = previewScreens.has(requestedScreen) ? requestedScreen : 'sale';
  // Fetch the requested screen before mounting so scaled, non-interactive device
  // frames never depend on a background Suspense render to start the download.
  const screenLoaders: Record<string, () => Promise<unknown>> = {
    dashboard: () => import('./pages/DashboardPage'),
    products: () => import('./pages/ProductsPage'),
    orders: () => import('./pages/OrdersPage'),
    customers: () => import('./pages/CustomersPage'),
    settings: () => import('./pages/SettingsPage'),
  };
  if (screenLoaders[initialScreen]) await screenLoaders[initialScreen]();
  const root = document.getElementById('root')!;
  createRoot(root).render(
    <MemoryRouter initialEntries={[`/${initialScreen}`]}>
      <App />
      <Toaster position="top-right" richColors />
    </MemoryRouter>
  );
  if (window.parent !== window) {
    // AppShell appears only after app startup and the requested lazy screen load.
    // Notify same-origin device frames once the actual interface has painted.
    const ready = new MutationObserver(() => {
      if (!root.querySelector('main')) return;
      ready.disconnect();
      requestAnimationFrame(() => window.parent.postMessage({
        type: 'zameria-product-ready', screen: initialScreen,
      }, window.location.origin));
    });
    ready.observe(root, { childList: true, subtree: true });
  }
}

void renderPreview().catch((error) => {
  console.error('POS demo failed to load', error);
  const root = document.getElementById('root');
  if (root) root.textContent = 'The demo could not load. Refresh to try again.';
});
