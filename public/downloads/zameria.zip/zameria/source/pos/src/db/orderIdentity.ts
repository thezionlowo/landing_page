import type { Transaction } from 'dexie';
import type { Order, OrderItem } from '@/types';

export const ORDER_IDENTITY_TABLES = ['orders', 'orderItems', 'cart', 'syncQueue', 'syncConflicts', 'orderRepairBackups'];

export interface OrderRepairBackup {
  id?: number;
  wooId: number;
  retainedOrderId: number;
  repairedAt: string;
  order: Order;
  items: OrderItem[];
}

export function canonicalWooOrderId(value: unknown): number | null {
  if (typeof value !== 'number' && (typeof value !== 'string' || !/^\d+$/.test(value.trim()))) return null;
  const id = Number(value);
  return Number.isSafeInteger(id) && id > 0 ? id : null;
}

/** One store is cached per database. Unsent sales and local held carts have no remote cache key. */
export function remoteOrderIdentity(order: Partial<Order>): string | undefined {
  const id = canonicalWooOrderId(order.wooId);
  const localHold = order.source !== 'website' && ['on-hold', 'pending'].includes(order.status || '');
  return id && order.syncStatus === 'SYNCED' && !localHold ? `woo:${id}` : undefined;
}

const versionTime = (order: Order) => {
  const value = Date.parse(order.remoteVersion || order.updatedAt || order.createdAt);
  return Number.isFinite(value) ? value : 0;
};

async function mergeCopies(tx: Transaction, wooId: number, copies: Order[], preferred?: Order): Promise<Order | undefined> {
  const candidates = copies.filter(order => Boolean(remoteOrderIdentity(order)) || order.id === preferred?.id);
  if (preferred && !candidates.some(order => order.id === preferred.id)) candidates.push(preferred);
  if (candidates.length < 2) return candidates[0];
  const orders = tx.table<Order, number>('orders');
  const items = tx.table<OrderItem, number>('orderItems');
  const primary = preferred || [...candidates].sort((a, b) => a.id - b.id)[0];
  // Keep a single complete snapshot, never add duplicate amounts or quantities together.
  const newest = preferred || [...candidates].sort((a, b) => versionTime(b) - versionTime(a) || b.id - a.id)[0];
  const snapshots = new Map<number, OrderItem[]>();
  const repairedAt = new Date().toISOString();
  for (const order of candidates) {
    const snapshot = await items.where('orderId').equals(order.id).toArray();
    snapshots.set(order.id, snapshot);
    await tx.table('orderRepairBackups').add({ wooId, retainedOrderId: primary.id, repairedAt, order, items: snapshot });
  }
  const snapshot = snapshots.get(newest.id)?.length ? snapshots.get(newest.id)!
    : snapshots.get(primary.id)?.length ? snapshots.get(primary.id)! : [...snapshots.values()].find(value => value.length) || [];
  const keepLocalIdentity = primary.source === 'pos' || Boolean(preferred);
  const merged: Order = { ...newest, id: primary.id, wooId,
    ...(keepLocalIdentity ? { localTransactionId: primary.localTransactionId, receiptNumber: primary.receiptNumber } : {}),
  };
  const removed = candidates.filter(order => order.id !== primary.id).map(order => order.id);
  for (const id of removed) {
    await tx.table('cart').where('id').aboveOrEqual(0).filter(cart => cart.resumedOrderId === id).modify({ resumedOrderId: primary.id });
    await tx.table('syncConflicts').where('orderId').equals(id).modify({ orderId: primary.id });
    await tx.table('syncQueue').where('entityType').equals('order').filter(entry => entry.entityId === id).modify(entry => {
      entry.entityId = primary.id;
      try {
        const payload = JSON.parse(entry.payload);
        if (payload && typeof payload === 'object' && !Array.isArray(payload)) {
          for (const key of ['orderId', 'localOrderId']) if (payload[key] === id) payload[key] = primary.id;
          entry.payload = JSON.stringify(payload);
        }
      } catch { /* Preserve an opaque payload verbatim. */ }
    });
  }
  await orders.bulkDelete(removed);
  await items.where('orderId').anyOf(candidates.map(order => order.id)).delete();
  await orders.put(merged);
  for (const item of snapshot) {
    const { id: _id, ...data } = item;
    await items.add({ ...data, orderId: primary.id } as OrderItem);
  }
  return merged;
}

/** Must be called inside a transaction containing ORDER_IDENTITY_TABLES. */
export async function reconcileOrderCopies(tx: Transaction, wooId: number, preferredOrderId?: number): Promise<Order | undefined> {
  const table = tx.table<Order, number>('orders');
  const copies = await table.where('wooId').equals(wooId).toArray();
  const preferred = preferredOrderId ? await table.get(preferredOrderId) : undefined;
  const merged = await mergeCopies(tx, wooId, copies, preferred);
  return merged || copies[0];
}

/** Runs once on upgrade, before new imports. Pending/held local records are never discarded. */
export async function repairLegacyOrderDuplicates(tx: Transaction): Promise<void> {
  const table = tx.table<Order, number>('orders');
  const groups = new Map<number, Order[]>();
  for (const order of await table.toArray()) {
    const id = canonicalWooOrderId(order.wooId);
    if (id && remoteOrderIdentity(order)) groups.set(id, [...(groups.get(id) || []), order]);
  }
  let removed = 0;
  for (const [id, group] of groups) {
    if (group.length > 1) { await mergeCopies(tx, id, group); removed += group.length - 1; }
  }
  // Normalize numeric/string aliases only after consolidation, then populate the unique cache key.
  for (const order of await table.toArray()) {
    const id = canonicalWooOrderId(order.wooId);
    await table.update(order.id, { ...(id ? { wooId: id } : {}), remoteIdentity: remoteOrderIdentity(order) });
  }
  if (removed) {
    // Re-fetch authoritative snapshots, including old orders, on the next complete delta sync.
    await tx.table('settings').where('key').equals('orders_modified_cursor').delete();
    await tx.table('settings').put({ key: 'orders_identity_repair_v6', value: JSON.stringify({ removed, repairedAt: new Date().toISOString() }) });
  }
}
