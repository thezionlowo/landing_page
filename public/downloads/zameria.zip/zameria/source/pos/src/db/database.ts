import Dexie, { type EntityTable, type Table } from 'dexie';
import type { Product, Category, Brand, Customer, Order, OrderItem, Cart, CartItem, StoreConfig, AppSettings } from '@/types';
import type { SyncQueueItem, SyncConflict } from '@/types';
import { canonicalWooOrderId, remoteOrderIdentity, repairLegacyOrderDuplicates, type OrderRepairBackup } from './orderIdentity';

/**
 * ZAMERIA POS IndexedDB Database
 * 
 * This is the local persistence layer. All data the POS needs to function
 * offline is stored here. Zustand stores ephemeral UI state; Dexie stores
 * persistent business data.
 */
export class ZameriaDatabase extends Dexie {
  customerSummaries!: Table<import('@/services/woocommerce/customerProjection').CustomerSummaryRow, [string, number]>;

  stores!: EntityTable<StoreConfig, 'id'>;
  products!: EntityTable<Product, 'id'>;
  categories!: EntityTable<Category, 'id'>;
  brands!: EntityTable<Brand, 'id'>;
  customers!: EntityTable<Customer, 'id'>;
  orders!: EntityTable<Order, 'id'>;
  orderItems!: EntityTable<OrderItem, 'id'>;
  cart!: EntityTable<Cart, 'id'>;
  cartItems!: EntityTable<CartItem, 'id'>;
  syncQueue!: EntityTable<SyncQueueItem, 'id'>;
  syncConflicts!: EntityTable<SyncConflict, 'id'>;
  settings!: EntityTable<AppSettings, 'id'>;
  orderRepairBackups!: EntityTable<OrderRepairBackup, 'id'>;

  constructor(name = 'ZameriaPOS') {
    super(name);

    this.version(1).stores({
      // Store configuration
      stores: '++id, wooId, url, &name',

      // Products with multiple search indexes
      products: '++id, wooId, name, sku, barcode, *categoryIds, *wooCategoryIds, stockStatus, syncStatus, gtin, upc, ean, isbn',

      // Product categories
      categories: '++id, wooId, name, slug, parent',

      // Customers
      customers: '++id, wooId, email, firstName, lastName',

      // Orders with date and status indexes
      orders: '++id, wooId, status, syncStatus, createdAt, customerId, localTransactionId',

      // Order line items
      orderItems: '++id, orderId, productId, wooProductId',

      // Active cart (in-progress transaction)
      cart: '++id, storeId',

      // Cart line items
      cartItems: '++id, cartId, productId',

      // Offline sync queue
      syncQueue: '++id, type, entityType, status, createdAt, localTransactionId',

      // Sync conflicts requiring manual resolution
      syncConflicts: '++id, orderId, productId, type, resolved, createdAt',

      // Application settings (key-value)
      settings: '++id, &key',
    });

    this.version(2).stores({
      brands: '++id, wooId, name, slug',
      products: '++id, wooId, name, sku, barcode, *categoryIds, *wooCategoryIds, brandId, wooBrandId, stockStatus, syncStatus, gtin, upc, ean, isbn',
    });

    this.version(3).stores({
      // Add syncStatus index to customers store to allow fast pending pushes and queries without crashes
      customers: '++id, wooId, email, firstName, lastName, syncStatus',
    }).upgrade(async (tx) => {
      // Non-destructively populate default syncStatus on existing customer records
      await tx.table('customers').toCollection().modify((customer: any) => {
        if (!customer.syncStatus) {
          customer.syncStatus = 'SYNCED';
        }
      });
    });

    this.version(4).stores({
      // High-performance index additions: status on products, orderNumber on orders
      products: '++id, wooId, name, sku, barcode, *categoryIds, *wooCategoryIds, brandId, wooBrandId, status, stockStatus, syncStatus, gtin, upc, ean, isbn',
      orders: '++id, wooId, orderNumber, status, syncStatus, createdAt, customerId, localTransactionId',
    });

    this.version(5).stores({
      // Targeted indexes for customer-order joins, order customer tracking, and fast customer lookups
      customers: '++id, wooId, email, firstName, lastName, syncStatus',
      orders: '++id, wooId, orderNumber, status, syncStatus, createdAt, customerId, wooCustomerId, customerEmail, localTransactionId',
    }).upgrade(async (tx) => {
      // Automated deduplication, ghost record cleanup, and order re-linkage migration
      const customersTable = tx.table('customers');
      const ordersTable = tx.table('orders');
      const allCustomers = await customersTable.toArray();
      const allOrders = await ordersTable.toArray();

      const toDeleteCustomerIds = new Set<number>();
      const idRemap = new Map<number, number | null>();

      // 1. Group by wooId (authoritative external identity)
      const byWoo = new Map<number, any[]>();
      for (const c of allCustomers) {
        if (c.wooId && c.wooId > 0) {
          if (!byWoo.has(c.wooId)) byWoo.set(c.wooId, []);
          byWoo.get(c.wooId)!.push(c);
        }
      }

      for (const group of byWoo.values()) {
        if (group.length > 1) {
          group.sort((a, b) => (b.syncStatus === 'SYNCED' ? 1 : 0) - (a.syncStatus === 'SYNCED' ? 1 : 0) || b.id - a.id);
          const primary = group[0];
          for (let i = 1; i < group.length; i++) {
            const dup = group[i];
            toDeleteCustomerIds.add(dup.id);
            idRemap.set(dup.id, primary.id);
            if (!primary.billing?.phone && dup.billing?.phone) {
              primary.billing = { ...primary.billing, phone: dup.billing.phone };
              await customersTable.update(primary.id, { billing: primary.billing });
            }
          }
        }
      }

      // 2. Group by normalized email for records without conflicting wooIds
      const remainingCusts = allCustomers.filter((c) => !toDeleteCustomerIds.has(c.id));
      const byEmail = new Map<string, any[]>();
      for (const c of remainingCusts) {
        const em = (c.email || '').trim().toLowerCase();
        if (em && !em.endsWith('@store.local')) {
          if (!byEmail.has(em)) byEmail.set(em, []);
          byEmail.get(em)!.push(c);
        }
      }

      for (const group of byEmail.values()) {
        if (group.length > 1) {
          group.sort((a, b) => (b.wooId ? 1 : 0) - (a.wooId ? 1 : 0) || b.id - a.id);
          const primary = group[0];
          for (let i = 1; i < group.length; i++) {
            const dup = group[i];
            if (!dup.wooId || dup.wooId === primary.wooId) {
              toDeleteCustomerIds.add(dup.id);
              idRemap.set(dup.id, primary.id);
            }
          }
        }
      }

      // 3. Flag ghost records created with @store.local emails from guest orders
      for (const c of allCustomers) {
        const em = (c.email || '').trim().toLowerCase();
        if (em.endsWith('@store.local') && !c.wooId) {
          toDeleteCustomerIds.add(c.id);
          idRemap.set(c.id, null);
        }
      }

      // Prune duplicates and ghost records
      if (toDeleteCustomerIds.size > 0) {
        await customersTable.bulkDelete(Array.from(toDeleteCustomerIds));
      }

      // 4. Update orders: remap merged customers, populate wooCustomerId/customerEmail, link unlinked orders
      const finalCustomers = await customersTable.toArray();
      const finalWooMap = new Map<number, number>();
      const finalEmailMap = new Map<string, number>();
      for (const c of finalCustomers) {
        if (c.wooId) finalWooMap.set(c.wooId, c.id);
        if (c.email && !c.email.endsWith('@store.local')) {
          finalEmailMap.set(c.email.trim().toLowerCase(), c.id);
        }
      }

      for (const o of allOrders) {
        let newCustId = o.customerId;
        if (newCustId && idRemap.has(newCustId)) {
          newCustId = idRemap.get(newCustId) ?? null;
        }
        if (!newCustId) {
          if (o.wooCustomerId && finalWooMap.has(o.wooCustomerId)) {
            newCustId = finalWooMap.get(o.wooCustomerId);
          } else if (o.customerEmail && finalEmailMap.has(o.customerEmail.trim().toLowerCase())) {
            newCustId = finalEmailMap.get(o.customerEmail.trim().toLowerCase());
          }
        }

        const rawWooCustId = o.wooCustomerId ? Number(o.wooCustomerId) : null;
        const custEmail = o.customerEmail || '';

        await ordersTable.update(o.id, {
          customerId: newCustId ?? null,
          wooCustomerId: rawWooCustId,
          customerEmail: custEmail,
        });
      }
    });

    this.version(6).stores({
      orders: '++id, wooId, &remoteIdentity, orderNumber, status, syncStatus, createdAt, customerId, wooCustomerId, customerEmail, localTransactionId',
      orderRepairBackups: '++id, wooId, retainedOrderId, repairedAt',
    }).upgrade(repairLegacyOrderDuplicates);

    this.version(7).stores({
      customers: '++id, wooId, email, firstName, lastName, syncStatus, purchaserKey',
    });

    this.version(8).stores({
      customers: '++id, wooId, email, firstName, lastName, syncStatus, purchaserKey, guestOrderId',
      customerSummaries: '[scope+customerId], [scope+name], [scope+totalSpent], [scope+purchaseCount], [scope+orderCount], [scope+lastOrderDate], [scope+createdAt]',
    }).upgrade(async tx => {
      await tx.table('orders').toCollection().modify(order => { const ms=Date.parse(order.createdAt);if(Number.isFinite(ms))order.createdAt=new Date(ms).toISOString(); });
    });

    this.orders.hook('creating', (_key, order) => {
      const id = canonicalWooOrderId(order.wooId);
      if (id) order.wooId = id;
      order.remoteIdentity = remoteOrderIdentity(order);
    });
    this.orders.hook('updating', (changes, _key, order) => {
      const next = { ...order, ...changes };
      const id = canonicalWooOrderId(next.wooId);
      return { ...(id ? { wooId: id } : {}), remoteIdentity: remoteOrderIdentity(next) };
    });
  }
}

// Singleton database instance
export const db = new ZameriaDatabase(import.meta.env?.MODE === 'product-preview' ? 'ZameriaSkincareDemo-v2' : 'ZameriaPOS');

// Helper to clear all data (for logout/disconnect)
export async function clearDatabase(): Promise<void> {
  await db.transaction('rw',
    [db.stores, db.products, db.categories, db.brands, db.customers, db.orders, db.orderItems, db.cart, db.cartItems, db.syncQueue, db.syncConflicts, db.settings, db.orderRepairBackups, db.customerSummaries],
    async () => {
      await db.stores.clear();
      await db.products.clear();
      await db.categories.clear();
      await db.brands.clear();
      await db.customers.clear();
      await db.orders.clear();
      await db.orderItems.clear();
      await db.cart.clear();
      await db.cartItems.clear();
      await db.syncQueue.clear();
      await db.syncConflicts.clear();
      await db.settings.clear();
      await db.orderRepairBackups.clear();
      await db.customerSummaries.clear();
    }
  );
  if(typeof localStorage !== 'undefined' && typeof localStorage.key === 'function') {
    for(let n=localStorage.length-1;n>=0;n--){const key=localStorage.key(n);if(key?.startsWith('zameria_historical_sync_checkpoint'))localStorage.removeItem(key);}
  }
}

// Helper to get or create a setting
export async function getSetting(key: string): Promise<string | undefined> {
  const setting = await db.settings.where('key').equals(key).first();
  return setting?.value;
}

export async function setSetting(key: string, value: string): Promise<void> {
  const existing = await db.settings.where('key').equals(key).first();
  if (existing) {
    await db.settings.update(existing.id, { value });
  } else {
    await db.settings.add({ key, value } as AppSettings);
  }
}
