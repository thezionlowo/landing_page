export { db, clearDatabase, getSetting, setSetting, ZameriaDatabase } from './database';
