import type { SyncMetadata } from './common';

export interface BillingAddress {
  firstName: string;
  lastName: string;
  company: string;
  address1: string;
  address2: string;
  city: string;
  state: string;
  postcode: string;
  country: string;
  email: string;
  phone: string;
}

export interface Customer {
  id: number; // Local ID
  wooId: number | null;
  email: string;
  firstName: string;
  lastName: string;
  username: string;
  billing: BillingAddress;
  avatarUrl: string;
  // Sync metadata
  syncStatus: SyncMetadata['syncStatus'];
  lastSyncedAt: string | null;
  localVersion: number;
  remoteVersion: string | null;
  // Timestamps
  createdAt: string;
  updatedAt: string;
  // Authoritative WooCommerce store metrics
  orderHistorySyncedAt?: string;
  ordersCount?: number;
  purchasesCount?: number; // Server-confirmed completed, processing, or refunded purchases.
  totalSpent?: number; // In kobo (₦1 = 100 kobo)
  purchaserKey?: string;
  remoteDeleted?: boolean;
  profileType?: 'registered' | 'guest';
  purchaserActive?: boolean;
  purchaserScope?: string;
  lastPurchaseAt?: string | null;
  historyOrderIds?: number[];
  guestOrderId?: number; // Phone-only buyer; never merge unrelated people by phone alone.
}

export interface CustomerFilters {
  search: string;
}
