// All monetary values stored as integers in kobo (1 NGN = 100 kobo)
// This prevents floating-point rounding errors
export type MoneyKobo = number;

export type SyncStatus =
  | 'LOCAL_ONLY'
  | 'SYNCED'
  | 'PENDING_SYNC'
  | 'SYNCING'
  | 'SYNC_ERROR'
  | 'SYNC_CONFLICT';

export type ConnectionStatus =
  | 'DISCONNECTED'
  | 'CONNECTING'
  | 'ONLINE'
  | 'OFFLINE'
  | 'SYNCING'
  | 'SYNC_ERROR';

export type QueueItemStatus =
  | 'PENDING'
  | 'PROCESSING'
  | 'SYNCED'
  | 'FAILED'
  | 'CONFLICT';

export type QueueItemType =
  | 'CREATE_ORDER'
  | 'UPDATE_ORDER'
  | 'CREATE_PRODUCT'
  | 'UPDATE_PRODUCT'
  | 'DELETE_PRODUCT'
  | 'UPDATE_STOCK'
  | 'CREATE_CUSTOMER';

export type OrderStatus =
  | 'pending'
  | 'processing'
  | 'on-hold'
  | 'completed'
  | 'cancelled'
  | 'refunded'
  | 'failed'
  | 'trash';

export type StockStatus =
  | 'instock'
  | 'outofstock'
  | 'onbackorder';

export type Theme = 'system' | 'light' | 'dark';
export type ListMode = 'grid' | 'list';

export type DiscountType = 'price_override' | 'fixed_amount' | 'percentage';

export interface Discount {
  type: DiscountType;
  value: number; // kobo for price_override/fixed_amount, percentage for percentage
}

export interface Timestamps {
  createdAt: string;
  updatedAt: string;
}

export interface SyncMetadata {
  syncStatus: SyncStatus;
  lastSyncedAt: string | null;
  localVersion: number;
  remoteVersion: string | null; // WooCommerce date_modified
}

export interface PaginationParams {
  page: number;
  perPage: number;
}

export interface PaginatedResponse<T> {
  data: T[];
  totalItems: number;
  totalPages: number;
  currentPage: number;
}
