/**
 * ZAMERIA POS Authentication & Authorization Types
 * 
 * WooCommerce/WordPress is the single source of truth for user identity,
 * roles, capabilities, and permissions.
 */

export type ZameriaRole = 'administrator' | 'shop_manager' | 'cashier' | 'restricted';

export interface RolePermissions {
  // Navigation / Route Access
  canAccessPOS: boolean;
  canAccessDashboard: boolean;
  canAccessSale: boolean;
  canAccessOrders: boolean;
  canAccessCustomers: boolean;
  canAccessProducts: boolean;
  canAccessSettings: boolean;

  // Product & Inventory Capabilities
  canCreateProduct: boolean;
  canEditProduct: boolean;
  canDeleteProduct: boolean;
  canEditProductPrice: boolean;
  canEditStockManually: boolean;
  canUploadProductMedia: boolean;

  // POS & Order Capabilities
  canCompleteSale: boolean;
  canApplyDiscount: boolean;
  canHoldOrder: boolean;
  canResumeOrder: boolean;
  canCancelOrder: boolean;
  canViewAllOrders: boolean;
  canRefundOrder: boolean;

  // System & Store Management
  canManageSettings: boolean;
  canManageStoreLogo: boolean;
  canManageWooConnection: boolean;
  canManageStaff: boolean;
  canExportData: boolean;
}

export interface AuthEntitlement {
  status: string;
  plan: string | null;
  plan_name?: string;
  trial_start?: string | null;
  trial_end?: string | null;
  days_remaining?: number;
  license_key?: string | null;
  license_expires_at?: string | null;
  offline_until?: string | null;
  max_products?: number | null;
  max_devices?: number | null;
  is_licensed: boolean;
}

export interface AuthUser {
  id: number;
  username: string;
  displayName: string;
  email: string;
  avatarUrl?: string;
  wooRoles: string[]; // Raw roles from WordPress/WooCommerce (e.g. ['administrator'], ['shop_manager'], ['cashier'])
  wooCapabilities?: Record<string, boolean>; // Raw capabilities from WordPress
  role: ZameriaRole; // Resolved Zameria access level
  roleLabel: string;
  permissions: RolePermissions;
  lastValidatedAt: string;
  /** Zameria device token; sent as X-Zameria-Token on every store request. */
  token?: string;
  /** The physical device and register this session signed in on. */
  deviceId?: number;
  deviceName?: string;
  registerId?: number;
  registerName?: string;
  locationId?: number;
  locationName?: string;
  storeName?: string;
  storeUrl?: string;
  storeAddress?: string;
  storeFooter?: string;
  /** Store subscription and plan entitlement from ZAMERIA cloud. */
  entitlement?: AuthEntitlement;
}

export class PermissionDeniedError extends Error {
  public permission: keyof RolePermissions;
  public userRole: ZameriaRole;

  constructor(permission: keyof RolePermissions, userRole: ZameriaRole, customMessage?: string) {
    const msg = customMessage || `Permission denied: '${userRole}' role is not authorized for '${String(permission)}'.`;
    super(msg);
    this.name = 'PermissionDeniedError';
    this.permission = permission;
    this.userRole = userRole;
  }
}
