import type { MoneyKobo, StockStatus, SyncMetadata } from './common';

export interface ProductImage {
  id: number;
  src: string;
  name: string;
  alt: string;
}

export interface ProductAttribute {
  id: number;
  name: string;
  position: number;
  visible: boolean;
  variation: boolean;
  options: string[];
}

export interface ProductVariation {
  id: number;
  wooId: number;
  sku: string;
  barcode?: string;
  price: MoneyKobo;
  regularPrice: MoneyKobo;
  salePrice: MoneyKobo | null;
  stockStatus: StockStatus;
  stockQuantity: number | null;
  manageStock: boolean;
  attributes: { name: string; option: string }[];
  image?: ProductImage;
  /** WooCommerce id whose stock this variation uses (itself, or its parent when stock is shared). */
  stockOwnerWooId?: number;
}

export interface Product {
  id: number; // Local ID
  wooId: number | null; // WooCommerce ID
  name: string;
  slug: string;
  type: 'simple' | 'variable' | 'grouped' | 'external';
  status: 'publish' | 'draft' | 'pending' | 'private';
  description: string;
  shortDescription: string;
  sku: string;
  barcode?: string; // Dedicated barcode field for physical/scanning identification
  price: MoneyKobo;
  regularPrice: MoneyKobo;
  salePrice: MoneyKobo | null;
  costPrice?: MoneyKobo | null;
  onSale: boolean;
  stockStatus: StockStatus;
  stockQuantity: number | null;
  manageStock: boolean;
  /** WooCommerce id whose stock this product uses; sales are counted against it. */
  stockOwnerWooId?: number;
  lowStockThreshold?: number | null;
  weight: string;
  dimensions: {
    length: string;
    width: string;
    height: string;
  };
  categoryIds: number[]; // Local category IDs
  wooCategoryIds: number[]; // WooCommerce category IDs
  brandId?: number | null; // Local Brand ID
  wooBrandId?: number | null; // WooCommerce Brand ID
  brandName?: string | null;
  brand?: { id: number; name: string; slug: string; taxonomy?: string } | null;
  images: ProductImage[];
  variations?: ProductVariation[];
  attributes?: ProductAttribute[];
  // Barcode identifiers
  gtin: string;
  upc: string;
  ean: string;
  isbn: string;
  // Sync metadata
  syncStatus: SyncMetadata['syncStatus'];
  lastSyncedAt: string | null;
  localVersion: number;
  remoteVersion: string | null;
  // Timestamps
  createdAt: string;
  updatedAt: string;
}

export interface Brand {
  id: number;
  wooId: number | null;
  name: string;
  slug: string;
  taxonomy?: string;
  count?: number;
  description?: string;
  syncStatus: SyncMetadata['syncStatus'];
  lastSyncedAt: string | null;
}

export interface Category {
  id: number;
  wooId: number | null;
  name: string;
  slug: string;
  parent: number;
  description: string;
  count: number;
  image: ProductImage | null;
  syncStatus: SyncMetadata['syncStatus'];
  lastSyncedAt: string | null;
}

export interface ProductFilters {
  search: string;
  categoryId: number | null;
  brandId?: number | null;
  stockStatus: StockStatus | null;
  onSale: boolean | null;
}
