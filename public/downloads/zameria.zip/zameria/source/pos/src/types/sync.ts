import type { QueueItemStatus, QueueItemType } from './common';

export interface SyncQueueItem {
  id: number;
  type: QueueItemType;
  entityType: 'order' | 'product' | 'customer';
  entityId: number; // Local entity ID
  payload: string; // JSON stringified payload
  localTransactionId: string; // For idempotency
  createdAt: string;
  status: QueueItemStatus;
  attemptCount: number;
  maxAttempts: number;
  lastAttemptAt: string | null;
  nextAttemptAt: string | null;
  error: string | null;
  wooCommerceId: number | null;
  resolvedAt: string | null;
}

export interface SyncConflict {
  id: number;
  orderId: number;
  productId: number;
  type: 'STOCK_INSUFFICIENT' | 'PRODUCT_NOT_FOUND' | 'PRICE_CHANGED' | 'OTHER';
  description: string;
  localData: string; // JSON
  remoteData: string; // JSON
  resolved: boolean;
  resolvedAt: string | null;
  resolution: string | null;
  createdAt: string;
}

export type SyncScope =
  | 'full'
  | 'products'
  | 'inventory'
  | 'orders'
  | 'customers'
  | 'coupons'
  | 'pos'
  | 'dashboard';

export type SyncEntity =
  | 'products'
  | 'categories'
  | 'inventory'
  | 'orders'
  | 'customers'
  | 'coupons';

export interface SyncEntityResult {
  entity: SyncEntity;
  importedCount: number;
  updatedCount: number;
  failedCount: number;
  errors: string[];
}

export interface SyncSummary {
  scope: SyncScope;
  status: 'success' | 'partial' | 'failed';
  startedAt: string;
  completedAt: string;
  durationMs: number;
  entities: Partial<Record<SyncEntity, SyncEntityResult>>;
  totalImported: number;
  totalUpdated: number;
  totalFailed: number;
  error?: string;
}

export interface FailedSyncItem {
  id: string;
  entity: SyncEntity;
  entityId?: string | number;
  localTransactionId?: string;
  operation: 'fetch' | 'create' | 'update' | 'delete';
  error: string;
  timestamp: string;
  retryCount: number;
}

export interface SyncLogEntry {
  id: string;
  timestamp: string;
  scope: SyncScope;
  status: 'success' | 'partial' | 'failed';
  durationMs: number;
  summary: string;
  errors?: string[];
}
