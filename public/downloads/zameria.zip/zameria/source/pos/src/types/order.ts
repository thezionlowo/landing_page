import type { MoneyKobo, OrderStatus, SyncMetadata, Discount } from './common';
import type { AppliedCoupon } from './cart';

export interface OrderItem {
  id: number;
  orderId: number;
  productId: number; // Local product ID
  wooProductId: number | null;
  /** WooCommerce variation id when a variation was sold. */
  wooVariationId?: number | null;
  /** WooCommerce id whose stock the sale reduces (see Product.stockOwnerWooId). */
  stockOwnerWooId?: number | null;
  name: string;
  sku: string;
  price: MoneyKobo; // Unit price
  quantity: number;
  subtotal: MoneyKobo; // Before discount
  total: MoneyKobo; // After discount
  discount: Discount | null;
  image: string;
}

export interface PaymentSplit {
  id: string;
  method: string;
  methodTitle: string;
  amount: MoneyKobo; // Amount in integer kobo
}

export interface Order {
  id: number; // Local ID
  wooId: number | null; // WooCommerce ID
  /** Unique identity of a synced remote snapshot; absent for unsent/local held sales. */
  remoteIdentity?: string;
  localTransactionId: string; // UUID for idempotency
  orderNumber: string;
  /** Receipt number printed at the till (e.g. R3-00042); kept after the WooCommerce number arrives. */
  receiptNumber?: string;
  status: OrderStatus;
  remoteStatus?: string;
  purchaseConfirmed?: boolean;
  netTotal?: MoneyKobo; // Remote total after refunds, for customer spending summaries.
  purchaserKey?: string;
  customerId: number | null; // Local customer ID
  wooCustomerId: number | null;
  customerName: string;
  customerEmail: string;
  customerPhone?: string;
  deliveryAddress?: {
    first_name?: string;
    last_name?: string;
    company?: string;
    address_1?: string;
    address_2?: string;
    city?: string;
    state?: string;
    postcode?: string;
    country?: string;
    phone?: string;
  } | null;
  formattedDeliveryAddress?: string;
  source?: 'pos' | 'website'; // Channel: 'pos' (in-store till) vs 'website' (WooCommerce)
  attendedBy?: string | null; // Name of staff who attended/created the sale
  attendedByUserId?: number | null; // ID of staff user
  createdByUserId?: number | null; // Unique account ID of creator (authoritative ownership)
  // Totals
  subtotal: MoneyKobo;
  couponDiscount?: MoneyKobo;
  couponCode?: string | null;
  appliedCoupon?: AppliedCoupon | null;
  couponLines?: Array<{
    code: string;
    discount: MoneyKobo;
    discountTax?: MoneyKobo;
  }>;
  transactionFee: MoneyKobo;
  total: MoneyKobo;
  // Payment
  paymentMethod: string;
  paymentMethodTitle: string;
  paymentSplits?: PaymentSplit[];
  // Shipping
  shippingMethod: string;
  // Items stored separately in orderItems table
  itemCount: number;
  // Notes
  customerNote: string;
  // Sync metadata
  syncStatus: SyncMetadata['syncStatus'];
  /** Why the store rejected this sale, when syncStatus is SYNC_ERROR. */
  syncError?: string;
  lastSyncedAt: string | null;
  localVersion: number;
  remoteVersion: string | null;
  // Timestamps
  createdAt: string;
  updatedAt: string;
  completedAt: string | null;
}

export interface OrderFilters {
  status: OrderStatus | 'all' | 'incomplete';
  search: string;
  dateFrom: string | null;
  dateTo: string | null;
}

export type OrderGroup = {
  label: string;
  date: string;
  orders: Order[];
  isCollapsed: boolean;
};
