import type { MoneyKobo, Discount } from './common';

export interface CartItem {
  id: number; // Local auto-increment
  cartId: number;
  productId: number; // Local product ID
  wooProductId: number | null;
  variationId?: number;
  variationTitle?: string;
  name: string;
  sku: string;
  image: string;
  unitPrice: MoneyKobo;
  regularPrice: MoneyKobo;
  salePrice: MoneyKobo | null;
  quantity: number;
  discount: Discount | null;
  lineTotal: MoneyKobo; // Calculated: (unitPrice * quantity) - discount
}

export interface AppliedCoupon {
  code: string;
  amount: string; // Original amount from WooCommerce (e.g. "10" for 10% or "5000" for ₦5,000)
  discountType: 'percent' | 'fixed_cart' | 'fixed_product';
  discountKobo: MoneyKobo; // Calculated discount in integer kobo
  description?: string;
  wooCouponId?: number;
  minimumAmount?: MoneyKobo;
  maximumAmount?: MoneyKobo;
  productIds?: number[];
  excludedProductIds?: number[];
  categoryIds?: number[];
  excludedCategoryIds?: number[];
  emailRestrictions?: string[];
  excludeSaleItems?: boolean;
  usageLimit?: number | null;
  usageCount?: number;
  individualUse?: boolean;
}

export interface Cart {
  id: number;
  storeId: number;
  customerId: number | null;
  customerName: string;
  customerEmail: string;
  paymentMethod: string;
  paymentMethodTitle: string;
  note: string;
  appliedCoupon?: AppliedCoupon | null;
  resumedOrderId?: number | null;
  resumedOrderNumber?: string | null;
  resumedWooId?: number | null;
  resumedAttendedBy?: string | null;
  resumedCreatedByUserId?: number | null;
  createdAt: string;
  updatedAt: string;
}

export interface CartTotals {
  itemCount: number;
  subtotal: MoneyKobo; // Item totals before coupon
  couponDiscount: MoneyKobo; // Discount from WooCommerce coupon
  discountedSubtotal: MoneyKobo; // Subtotal minus coupon discount
  transactionFee: MoneyKobo; // 1.5% Paystack fee on discounted subtotal
  total: MoneyKobo; // Final total amount to collect
}
