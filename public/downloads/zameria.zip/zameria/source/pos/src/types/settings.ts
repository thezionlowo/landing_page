import type { Theme, ListMode } from './common';

export interface StoreConfig {
  id: number;
  wooId: number | null;
  url: string;
  name: string;
  description: string;
  currency: string;
  currencySymbol: string;
  consumerKey: string; // Encrypted/obfuscated in storage
  consumerSecret: string; // Encrypted/obfuscated in storage
  isConnected: boolean;
  connectedAt: string | null;
  lastSyncedAt: string | null;
  userId: number | null;
  userName: string;
  userEmail: string;
}

export interface AppSettings {
  id: number;
  key: string;
  value: string; // JSON stringified
}

export interface SettingsState {
  // Interface
  theme: Theme;
  listMode: ListMode;
  showCartThumbnails: boolean;
  sidebarCollapsed: boolean;
  // Sync
  syncIntervalMinutes: number;
  lastSyncTimestamp: string | null;
  // Payment
  paymentFeePercentage: number;
  paymentFeeLabel: string;
  // Offline
  offlineModeEnabled: boolean;
  // Alerts
  alertsEnabled: boolean;
  alertOrderStatuses: string[];
  alertShippingMethods: string[];
  // Printer
  autoPrintReceipt: boolean;
  // Account
  trialActive: boolean;
  trialEndsAt: string | null;
  plan: string;
}

export const DEFAULT_SETTINGS: SettingsState = {
  theme: 'system',
  listMode: 'grid',
  showCartThumbnails: true,
  sidebarCollapsed: false,
  syncIntervalMinutes: 1,
  lastSyncTimestamp: null,
  paymentFeePercentage: 0,
  paymentFeeLabel: '',
  offlineModeEnabled: true,
  alertsEnabled: true,
  alertOrderStatuses: ['completed', 'processing', 'on-hold'],
  alertShippingMethods: ['delivery', 'pickup', 'shipping'],
  autoPrintReceipt: false,
  trialActive: true,
  trialEndsAt: null,
  plan: '7-Day Free Trial',
};
