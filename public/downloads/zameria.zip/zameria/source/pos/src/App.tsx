import { lazy, Suspense, useState, useEffect } from 'react';
import { Routes, Route, Navigate } from 'react-router';
import { AppShell } from '@/components/layout';
import { SalePage } from '@/pages/SalePage';
const DashboardPage = lazy(() => import('@/pages/DashboardPage').then(module => ({ default: module.DashboardPage })));
const OrdersPage = lazy(() => import('@/pages/OrdersPage').then(module => ({ default: module.OrdersPage })));
const CustomersPage = lazy(() => import('@/pages/CustomersPage').then(module => ({ default: module.CustomersPage })));
const ProductsPage = lazy(() => import('@/pages/ProductsPage').then(module => ({ default: module.ProductsPage })));
const SettingsPage = lazy(() => import('@/pages/SettingsPage').then(module => ({ default: module.SettingsPage })));
import { LoginPage } from '@/pages/LoginPage';
import { ProtectedRoute } from '@/components/auth/ProtectedRoute';
import { useConnectionStore, useUIStore, useAuthStore } from '@/store';
import { db } from '@/db';
import { startPosSyncLoop, runPosSync, refreshPendingCount } from '@/services/zameria/posSync';
import { startSessionWatch } from '@/services/zameria/session';
import { demoLoginEnabled } from '@/services/zameria/config';

function App() {
  const { setOnline } = useConnectionStore();
  const { setDemoMode } = useUIStore();
  const { isAuthenticated, revalidate } = useAuthStore();
  const token = useAuthStore((s) => s.user?.token);
  const [isLoading, setIsLoading] = useState(true);

  // Development demo only: fill an empty database with sample data. A real store's till is
  // filled by the sync loop below and must never receive fake products or orders.
  useEffect(() => {
    const init = async () => {
      try {
        if ((import.meta.env.DEV || import.meta.env.MODE === 'product-preview') && demoLoginEnabled() && isAuthenticated && !token && (await db.products.count()) === 0) {
          if (import.meta.env.MODE === 'product-preview') {
            const { seedSkincareDemo } = await import('@/mocks/skincareDemo');
            await seedSkincareDemo(window.location.href);
          } else {
            const { seedDemoData } = await import('@/mocks/data');
            await seedDemoData(db);
          }
          setDemoMode(true);
        } else if (token) {
          setDemoMode(false);
        }
        // Always hydrate actual pending count from IndexedDB on startup
        await refreshPendingCount();
      } catch {
        // Ignore DB errors on init
      } finally {
        setIsLoading(false);
      }
    };
    init();
  }, [setDemoMode, isAuthenticated, token]);

  useEffect(() => (token ? startSessionWatch() : undefined), [token]);

  // Real store: upload sales and pull stock changes in the background.
  useEffect(() => (token ? startPosSyncLoop() : undefined), [token]);

  // Listen for online/offline events and immediately flush pending sales on reconnection
  useEffect(() => {
    const handleOnline = () => {
      setOnline(true);
      void runPosSync(); // Proactively sync immediately on reconnect!
    };
    const handleOffline = () => setOnline(false);
    window.addEventListener('online', handleOnline);
    window.addEventListener('offline', handleOffline);
    return () => {
      window.removeEventListener('online', handleOnline);
      window.removeEventListener('offline', handleOffline);
    };
  }, [setOnline]);

  // Dynamic session revalidation for active WooCommerce sessions
  useEffect(() => {
    if (useAuthStore.getState().isAuthenticated && navigator.onLine) void revalidate();
    // Revalidate every 10 minutes when online and authenticated
    const interval = setInterval(() => {
      if (useAuthStore.getState().isAuthenticated && navigator.onLine) {
        revalidate().catch(() => {
          // Failure handled inside authStore (revocation will auto-logout)
        });
      }
    }, 10 * 60 * 1000);

    // Also revalidate when the user switches back to this tab
    const handleVisibilityChange = () => {
      if (document.visibilityState === 'visible' && useAuthStore.getState().isAuthenticated && navigator.onLine) {
        revalidate().catch(() => {});
      }
    };
    document.addEventListener('visibilitychange', handleVisibilityChange);

    return () => {
      clearInterval(interval);
      document.removeEventListener('visibilitychange', handleVisibilityChange);
    };
  }, [revalidate]);

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-surface-50">
        <div className="text-center space-y-3">
          <img src="zameria-logo.png" alt="ZAMERIA" className="h-10 w-auto object-contain mx-auto" />
          <div className="w-5 h-5 border-2 border-surface-300 border-t-[#60A5FA] rounded-full animate-spin mx-auto" />
        </div>
      </div>
    );
  }

  return (
    <Suspense fallback={<div role="status" className="p-6 text-sm">Loading…</div>}>
    <Routes>
      {/* Standalone Login Route */}
      <Route path="/login" element={<LoginPage />} />

      {/* Main Authenticated Application Wrapped in AppShell & ProtectedRoute */}
      <Route
        path="/*"
        element={
          <ProtectedRoute>
            <AppShell>
              <Routes>
                <Route path="/" element={<Navigate to="/sale" replace />} />
                <Route
                  path="/dashboard"
                  element={
                    <ProtectedRoute requiredPermission="canAccessDashboard">
                      <DashboardPage />
                    </ProtectedRoute>
                  }
                />
                <Route
                  path="/sale"
                  element={
                    <ProtectedRoute requiredPermission="canAccessSale">
                      <SalePage />
                    </ProtectedRoute>
                  }
                />
                <Route
                  path="/orders"
                  element={
                    <ProtectedRoute requiredPermission="canAccessOrders">
                      <OrdersPage />
                    </ProtectedRoute>
                  }
                />
                <Route
                  path="/customers"
                  element={
                    <ProtectedRoute requiredPermission="canAccessCustomers">
                      <CustomersPage />
                    </ProtectedRoute>
                  }
                />
                <Route
                  path="/products"
                  element={
                    <ProtectedRoute requiredPermission="canAccessProducts">
                      <ProductsPage />
                    </ProtectedRoute>
                  }
                />
                <Route
                  path="/settings"
                  element={
                    <ProtectedRoute requiredPermission="canAccessSettings">
                      <SettingsPage />
                    </ProtectedRoute>
                  }
                />
                <Route path="*" element={<Navigate to="/sale" replace />} />
              </Routes>
            </AppShell>
          </ProtectedRoute>
        }
      />
    </Routes>
    </Suspense>
  );
}

export default App;
