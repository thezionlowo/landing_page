/**
 * ZAMERIA Hardware Network Adapter
 * 
 * Provides network online/offline state detection across browser and native wrappers.
 */

import type { INetworkService } from './types';

export class HardwareNetworkAdapter implements INetworkService {
  public isOnline(): boolean {
    if (typeof navigator === 'undefined') return true;
    return navigator.onLine;
  }

  public onStatusChange(callback: (online: boolean) => void): () => void {
    if (typeof window === 'undefined') return () => {};

    const handleOnline = () => callback(true);
    const handleOffline = () => callback(false);

    window.addEventListener('online', handleOnline);
    window.addEventListener('offline', handleOffline);

    // Support Capacitor Network plugin if present
    const cap = (window as any).Capacitor;
    let removeNativeListener: (() => void) | null = null;
    if (cap?.Plugins?.Network) {
      cap.Plugins.Network.addListener('networkStatusChange', (status: { connected: boolean }) => {
        callback(Boolean(status.connected));
      }).then((handle: any) => {
        removeNativeListener = () => handle?.remove?.();
      }).catch(() => {});
    }

    return () => {
      window.removeEventListener('online', handleOnline);
      window.removeEventListener('offline', handleOffline);
      if (removeNativeListener) {
        removeNativeListener();
      }
    };
  }
}

export const hardwareNetwork = new HardwareNetworkAdapter();
