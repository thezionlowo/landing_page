import { clearDatabase, db } from '@/db';
import {
  clearStoreConnection,
  connectedStore,
  restUrl,
  setStoreConnection,
  type StoreConnection,
} from './config';

/*
 * Hosted app only: staff type their store's address ("myshop.com") and the app finds that
 * store's REST API, checks the Zameria plugin is active, and remembers it on this device.
 */

function hostOf(url: string): string {
  try {
    return new URL(url).host;
  } catch {
    return url;
  }
}

function normaliseHome(input: string): URL {
  let raw = input.trim();
  if (!raw) throw new Error('Enter your store address, for example myshop.com');
  if (!/^https?:\/\//i.test(raw)) raw = `https://${raw}`;

  let url: URL;
  try {
    url = new URL(raw);
  } catch {
    throw new Error("That doesn't look like a web address. Try something like myshop.com");
  }

  const isLocal = ['localhost', '127.0.0.1'].includes(url.hostname);
  if (url.protocol === 'http:' && window.location.protocol === 'https:' && !isLocal) {
    throw new Error('Your store must use https:// to work with the POS.');
  }

  // People often paste the POS, admin or login URL; the store's home is what we need.
  url.pathname = url.pathname.replace(/\/(pos|wp-admin|wp-login\.php)(\/.*)?$/i, '/').replace(/\/+$/, '') + '/';
  url.search = '';
  url.hash = '';
  return url;
}

/** Finds the store's REST API and confirms the Zameria POS plugin is installed there. */
export async function discoverStore(input: string): Promise<StoreConnection> {
  const home = normaliseHome(input);
  // Pretty permalinks first; plain-permalink sites only answer on ?rest_route=.
  const candidates = [new URL('wp-json/', home).toString(), new URL('?rest_route=/', home).toString()];

  let sawWordPress = false;
  for (const root of candidates) {
    let index: { name?: string; home?: string; namespaces?: string[] } | null = null;
    try {
      const response = await fetch(restUrl(root, ''), { credentials: 'omit', cache: 'no-store' });
      if (!response.ok) continue;
      index = await response.json();
    } catch {
      continue;
    }
    if (!Array.isArray(index?.namespaces)) continue;

    sawWordPress = true;
    if (!index.namespaces.includes('zameria/v1')) continue;

    return {
      restRoot: root,
      apiRoot: restUrl(root, 'zameria/v1/'),
      storeUrl: index.home ? index.home.replace(/\/?$/, '/') : home.toString(),
      storeName: index.name || home.host,
    };
  }

  if (sawWordPress) {
    throw new Error(`${home.host} is a WordPress site, but the Zameria POS plugin isn't active on it.`);
  }
  throw new Error(
    `Couldn't reach a store at ${home.host}. Check the address, that the site uses https, and your internet connection.`
  );
}

function sameStore(a: StoreConnection, b: StoreConnection): boolean {
  return a.apiRoot.replace(/\/+$/, '') === b.apiRoot.replace(/\/+$/, '');
}

/** Sales on this device that the current store hasn't received yet. */
async function unsentSaleCount(): Promise<number> {
  return db.orders.where('syncStatus').anyOf('PENDING_SYNC', 'SYNC_ERROR').count();
}

/**
 * Makes `next` the store for this device. A device holds one store's data at a time, so the
 * local database is wiped when switching (demo data included) — but never while the current
 * store still has sales waiting to upload.
 */
export async function connectStore(next: StoreConnection): Promise<{ switched: boolean }> {
  const current = connectedStore();
  if (current && sameStore(current, next)) {
    setStoreConnection(next);
    return { switched: false };
  }
  if (current) {
    const unsent = await unsentSaleCount();
    if (unsent > 0) {
      throw new Error(
        `This device still has ${unsent} sale(s) for ${current.storeName} that haven't uploaded. ` +
          `Sign in to ${hostOf(current.storeUrl)} first so they can upload, then switch stores.`
      );
    }
  }
  const pendingCustomers = await db.customers.where('syncStatus').anyOf('PENDING_SYNC', 'LOCAL_ONLY').count();
  if (current && pendingCustomers > 0) {
    throw new Error(`${pendingCustomers} customer change(s) have not uploaded yet. Sync customers before disconnecting or switching stores.`);
  }
  await clearDatabase();
  try { localStorage.removeItem('zameria_historical_sync_checkpoint'); } catch {}
  setStoreConnection(next);
  return { switched: true };
}

/** Forgets the connected store (and its data on this device), with the same unsent-sales guard. */
export async function forgetStore(): Promise<void> {
  const current = connectedStore();
  if (!current) return;
  const unsent = await unsentSaleCount();
  if (unsent > 0) {
    throw new Error(`${unsent} sale(s) for ${current.storeName} haven't uploaded yet. Sign in so they can upload first.`);
  }
  const pendingCustomers = await db.customers.where('syncStatus').anyOf('PENDING_SYNC', 'LOCAL_ONLY').count();
  if (current && pendingCustomers > 0) {
    throw new Error(`${pendingCustomers} customer change(s) have not uploaded yet. Sync customers before disconnecting or switching stores.`);
  }
  await clearDatabase();
  try { localStorage.removeItem('zameria_historical_sync_checkpoint'); } catch {}
  clearStoreConnection();
}

export { hostOf };
