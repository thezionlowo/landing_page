import type { RegisterSWOptions } from 'vite-plugin-pwa/types';

type Register = (options: RegisterSWOptions) => (reloadPage?: boolean) => Promise<void>;

/** Checks while online/visible; a new worker never forces an in-progress tab to reload. */
export function startAppUpdates(register: Register, onAvailable: () => void, onError: (error: unknown) => void) {
  let registration: ServiceWorkerRegistration | undefined;
  let approved = false, controlling = false, checking = false, disposed = false;
  const check = async () => {
    if (disposed || checking || !registration || !navigator.onLine || document.visibilityState !== 'visible') return;
    checking = true;
    try { await registration.update(); } catch (error) { onError(error); } finally { checking = false; }
  };
  const activate = register({
    immediate: true,
    onNeedRefresh: () => { if (!disposed) onAvailable(); },
    onNeedReload: () => {
      controlling = true;
      if (approved) window.location.reload();
      else if (!disposed) onAvailable();
    },
    onRegisteredSW: (_url, value) => { registration = value; void check(); },
    onRegisterError: onError,
  });
  const timer = window.setInterval(() => void check(), 2 * 60_000);
  const onForeground = () => void check();
  window.addEventListener('online', onForeground);
  window.addEventListener('focus', onForeground);
  document.addEventListener('visibilitychange', onForeground);
  return {
    check,
    async apply() {
      approved = true;
      try {
        if (controlling) window.location.reload();
        else await activate(true);
      } catch (error) { approved = false; throw error; }
    },
    dispose() {
      disposed = true;
      window.clearInterval(timer);
      window.removeEventListener('online', onForeground);
      window.removeEventListener('focus', onForeground);
      document.removeEventListener('visibilitychange', onForeground);
    },
  };
}

export function canApplyAppUpdate(cartItems: number, cartBusy: boolean, syncing: boolean, formOpen: boolean): boolean {
  return cartItems === 0 && !cartBusy && !syncing && !formOpen;
}
