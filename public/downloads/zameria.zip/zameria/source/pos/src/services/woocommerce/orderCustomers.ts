import { db } from '@/db';
import type { Customer } from '@/types';
import { decodeHtmlEntities } from '@/lib';
import { customerEmail } from './customerIdentity';

export function isPurchasedOrder(order: any): boolean {
  if (typeof order.zameria_purchase === 'boolean') return order.zameria_purchase;
  if (['pending', 'on-hold', 'cancelled', 'failed', 'trash'].includes(order.status)) return false;
  return ['completed', 'processing', 'refunded'].includes(order.status) || Boolean(order.date_paid || order.date_paid_gmt);
}

/** Called inside the order write transaction. These are profiles, never new WP accounts. */
export async function ensureOrderCustomers(orders: any[], now: string): Promise<void> {
  const customers = await db.customers.toArray();
  const byWoo = new Map(customers.filter(c => c.wooId).map(c => [c.wooId, c]));
  const byEmail = new Map<string, Customer[]>();
  const byGuestOrder = new Map(customers.filter(c => c.guestOrderId).map(c => [c.guestOrderId, c]));
  for (const c of customers) {
    const email = customerEmail(c.email);
    if (email) byEmail.set(email, [...(byEmail.get(email) || []), c]);
  }
  for (const order of orders) {
    if (!isPurchasedOrder(order)) continue;
    const wooId = Number(order.customer_id) > 0 ? Number(order.customer_id) : null;
    const email = customerEmail(order.billing?.email);
    const phone = String(order.billing?.phone || '').trim();
    if (!wooId && !email && !phone) continue;
    const matches = email ? byEmail.get(email) || [] : [];
    const accounts = matches.filter(c => c.profileType !== 'guest');
    const existing = wooId ? byWoo.get(wooId)
      : accounts.length === 1 ? accounts[0]
      : matches.find(c => c.profileType === 'guest') || (!email ? byGuestOrder.get(Number(order.id)) : undefined);
    if (existing) continue;
    const raw = order.billing || {};
    const firstName = decodeHtmlEntities(raw.first_name || '');
    const lastName = decodeHtmlEntities(raw.last_name || '');
    const profile = {
      wooId, email, firstName, lastName, username: '', avatarUrl: '',
      profileType: wooId ? 'registered' : 'guest',
      ...(!wooId && !email ? { guestOrderId: Number(order.id) } : {}),
      billing: { firstName, lastName, email, phone,
        company: decodeHtmlEntities(raw.company || ''), address1: decodeHtmlEntities(raw.address_1 || ''),
        address2: decodeHtmlEntities(raw.address_2 || ''), city: decodeHtmlEntities(raw.city || ''),
        state: raw.state || '', postcode: raw.postcode || '', country: raw.country || '',
      },
      syncStatus: 'SYNCED', lastSyncedAt: now, localVersion: 1, remoteVersion: null,
      createdAt: order.date_created || now, updatedAt: now,
    } as Customer;
    profile.id = await db.customers.add(profile);
    if (wooId) byWoo.set(wooId, profile);
    if (email) byEmail.set(email, [...matches, profile]);
    else byGuestOrder.set(Number(order.id), profile);
  }
}
