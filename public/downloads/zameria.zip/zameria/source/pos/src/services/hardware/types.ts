/**
 * ZAMERIA Hardware Abstraction Layer (HAL) Types
 * 
 * Provides unified interfaces for printers, barcode scanners,
 * persistent storage, and network detection across Web, Desktop,
 * Tablet, iOS, and Android platforms.
 */

import type { ThermalPaperWidth } from '../printService';

export interface PrinterDevice {
  id: string;
  name: string;
  type: 'browser' | 'bluetooth' | 'network' | 'usb';
  address?: string; // MAC address, IP, or USB VID/PID
  isConnected: boolean;
  paperWidth: ThermalPaperWidth;
}

export interface CashDrawerKickOptions {
  pin?: 2 | 5; // RJ11 pulse pin
  pulseMs?: number;
}

export interface IPrinterService {
  getPrinters(): Promise<PrinterDevice[]>;
  getActivePrinter(): PrinterDevice;
  setActivePrinter(printer: PrinterDevice): Promise<boolean>;
  getPaperWidth(): ThermalPaperWidth;
  setPaperWidth(width: ThermalPaperWidth): void;
  printHtml(html: string): Promise<boolean>;
  printRawEscPos?(bytes: Uint8Array): Promise<boolean>;
  openCashDrawer(options?: CashDrawerKickOptions): Promise<boolean>;
  isHardwarePrintingSupported(): boolean;
}

export interface IScannerService {
  /**
   * Listens for high-speed keystrokes from USB or Bluetooth HID barcode scanners.
   * Automatically buffers characters and differentiates scanner input from manual typing.
   */
  startKeyboardListener(onScan: (barcode: string) => void): () => void;
  
  /**
   * Tests whether a native camera scanner plugin is available (e.g. Capacitor Barcode Scanner / ML Kit).
   */
  isNativeScannerAvailable(): boolean;
}

export interface IStorageService {
  getItem(key: string): string | null;
  setItem(key: string, value: string): void;
  removeItem(key: string): void;
  /**
   * Requests persistent storage quota from browser / WebKit engine to prevent
   * 7-day eviction of IndexedDB on iOS Safari.
   */
  ensurePersistentStorage(): Promise<boolean>;
}

export interface INetworkService {
  isOnline(): boolean;
  onStatusChange(callback: (online: boolean) => void): () => void;
}
