import { db, getSetting } from '@/db';
import { getWooClient, type WooCommerceClient } from './client';
import { useSyncStore } from '@/store/syncStore';
import { useConnectionStore } from '@/store/connectionStore';
import { toKobo } from '@/lib';
import { syncAllCategories } from './categoryService';
import { syncAllBrands } from './brandService';
import type { Product, StockStatus, ProductImage, SyncEntityResult, Brand } from '@/types';
import { assertAuthorized } from '@/services/auth';
import { isDemoSession, sessionToken } from '@/services/zameria/session';
import { downloadCatalogue, pullChanges, resetCatalogueCursor } from '@/services/zameria/catalog';
import { zameriaApi } from '@/services/zameria/api';

export interface CreateProductInput {
  name: string;
  sku?: string;
  barcode?: string; // Dedicated barcode field for physical/scanning identification
  regularPrice: number; // in kobo
  salePrice?: number | null; // in kobo
  costPrice?: number | null; // in kobo
  categoryIds?: number[]; // Array of local category IDs
  categoryId?: number | null; // Legacy single category support
  wooCategoryIds?: number[];
  brandId?: number | null;
  wooBrandId?: number | null;
  manageStock: boolean;
  stockQuantity?: number | null;
  lowStockThreshold?: number | null;
  stockStatus: StockStatus;
  status: 'publish' | 'draft';
  description?: string;
  imageFile?: File | null; // Direct uploaded image file
  imageUrl?: string;
  images?: ProductImage[];
}

export interface UpdateProductInput {
  name?: string;
  sku?: string;
  barcode?: string | null;
  regularPrice?: number;
  salePrice?: number | null;
  costPrice?: number | null;
  categoryIds?: number[]; // Array of local category IDs
  categoryId?: number | null; // Legacy single category support
  brandId?: number | null;
  wooBrandId?: number | null;
  manageStock?: boolean;
  stockQuantity?: number | null;
  lowStockThreshold?: number | null;
  stockStatus?: StockStatus;
  status?: 'publish' | 'draft';
  description?: string;
  imageFile?: File | null; // New uploaded image file
  imageUrl?: string;
  removeImage?: boolean; // Explicit flag to delete product image
}

export interface ProductSyncResult {
  product: Product;
  synced: boolean;
  error?: string;
}

/**
 * Converts a browser File object to a base64 Data URL for local persistence/preview.
 */
export function fileToDataUrl(file: File): Promise<string> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => resolve(reader.result as string);
    reader.onerror = () => reject(new Error('Failed to read image file'));
    reader.readAsDataURL(file);
  });
}

/**
 * Helper to extract barcode / GTIN from WooCommerce remote product object or meta_data.
 */
export function extractBarcodeFromRemote(rp: any): string {
  if (rp.barcode) return String(rp.barcode).trim();
  if (rp.gtin) return String(rp.gtin).trim();
  if (Array.isArray(rp.meta_data)) {
    const keys = ['_barcode', 'barcode', '_gtin', 'gtin', 'hwp_product_gtin', '_wpm_gtin_code', '_sku_barcode'];
    for (const k of keys) {
      const entry = rp.meta_data.find((m: any) => m.key === k);
      if (entry && entry.value !== undefined && entry.value !== null && String(entry.value).trim() !== '') {
        return String(entry.value).trim();
      }
    }
  }
  return '';
}

/**
 * Resolves a brand from input brandId (Dexie ID or wooId) or wooBrandId with fallback.
 */
async function resolveBrand(
  inputBrandId?: number | null,
  inputWooBrandId?: number | null
): Promise<{
  brandId: number | null;
  wooBrandId: number | null;
  brandName: string | null;
  brandObj: { id: number; name: string; slug: string; taxonomy?: string } | null;
}> {
  let brand: Brand | undefined;

  // 1. Try local Dexie ID
  if (inputBrandId) {
    brand = await db.brands.get(inputBrandId);
    // 2. If not found by Dexie id, check if inputBrandId was actually a wooId
    if (!brand) {
      brand = await db.brands.where('wooId').equals(inputBrandId).first();
    }
  }

  // 3. Try wooBrandId
  if (!brand && inputWooBrandId) {
    brand = await db.brands.where('wooId').equals(inputWooBrandId).first();
    if (!brand) {
      brand = await db.brands.get(inputWooBrandId);
    }
  }

  if (brand) {
    const bId = brand.id;
    const wId = brand.wooId ?? null;
    return {
      brandId: bId,
      wooBrandId: wId,
      brandName: brand.name,
      brandObj: {
        id: wId ?? bId,
        name: brand.name,
        slug: brand.slug,
        taxonomy: brand.taxonomy || 'product_brand',
      },
    };
  }

  // Fallback: If wooBrandId or inputBrandId is a valid positive number
  const rawId = inputWooBrandId || inputBrandId || null;
  if (rawId && rawId > 0) {
    return {
      brandId: null,
      wooBrandId: rawId,
      brandName: null,
      brandObj: {
        id: rawId,
        name: `Brand #${rawId}`,
        slug: `brand-${rawId}`,
        taxonomy: 'product_brand',
      },
    };
  }

  return {
    brandId: null,
    wooBrandId: null,
    brandName: null,
    brandObj: null,
  };
}

/**
 * Synchronizes product creation or update with WooCommerce with resilient brand fallback.
 * If WooCommerce rejects direct assignment of `brands` (e.g. store lacks native brands schema),
 * it strips the parameter, ensures product creation/update succeeds, and attaches the brand via
 * dedicated plugin endpoints or term metadata without failing the whole sync.
 */
async function syncProductWithBrandFallback(
  client: WooCommerceClient,
  method: 'POST' | 'PUT',
  endpoint: string,
  wcPayload: Record<string, any>,
  wooBrandId: number | null
): Promise<{
  data: { id: number; date_modified?: string; images?: any[] };
  brandSynced: boolean;
  warning?: string;
}> {
  try {
    const res = method === 'POST'
      ? await client.post<{ id: number; date_modified?: string; images?: any[] }>(endpoint, wcPayload)
      : await client.put<{ id: number; date_modified?: string; images?: any[] }>(endpoint, wcPayload);
    return { data: res.data, brandSynced: true };
  } catch (err: any) {
    const isBrandErr =
      err?.isBrandError ||
      (err?.status === 400 && (
        String(err?.message || '').toLowerCase().includes('brand') ||
        String(err?.code || '').toLowerCase().includes('brand') ||
        JSON.stringify(err?.data || '').toLowerCase().includes('brand')
      ));

    // If the error has nothing to do with brands, or if brands wasn't in the payload, rethrow
    if (!isBrandErr || !('brands' in wcPayload)) {
      throw err;
    }

    // Strip brands parameter from payload and retry product create/update
    const sanitizedPayload = { ...wcPayload };
    delete sanitizedPayload.brands;

    const fallbackRes = method === 'POST'
      ? await client.post<{ id: number; date_modified?: string; images?: any[] }>(endpoint, sanitizedPayload)
      : await client.put<{ id: number; date_modified?: string; images?: any[] }>(endpoint, sanitizedPayload);

    const remoteProductId = Number(fallbackRes.data.id || (method === 'PUT' ? endpoint.split('/').pop() : 0));

    let brandSynced = false;
    let warning: string | undefined;

    if (remoteProductId && wooBrandId && wooBrandId > 0) {
      // Strategy 1: Zameria plugin route /products/:id/brand
      const token = sessionToken();
      if (token) {
        try {
          await zameriaApi.setProductBrand(token, remoteProductId, wooBrandId);
          brandSynced = true;
        } catch {
          // Fall through to Strategy 2
        }
      }

      // Strategy 2: Array of integer IDs on WooCommerce endpoint
      if (!brandSynced) {
        try {
          await client.put(`/products/${remoteProductId}`, {
            brands: [wooBrandId],
          });
          brandSynced = true;
        } catch {
          // Fall through to Strategy 3
        }
      }

      // Strategy 3: Assign via meta_data
      if (!brandSynced) {
        try {
          await client.put(`/products/${remoteProductId}`, {
            meta_data: [{ key: '_brand_id', value: String(wooBrandId) }],
          });
          brandSynced = true;
        } catch (metaErr: any) {
          warning = `Product synced, but brand could not be attached: ${metaErr?.message || 'Unsupported brand schema'}`;
        }
      }
    }

    return { data: fallbackRes.data, brandSynced, warning };
  }
}

/**
 * Creates a new product in Zameria and synchronizes it to WooCommerce.
 * If offline or WooCommerce fails, saves locally and queues for synchronization.
 */
export async function createProduct(input: CreateProductInput): Promise<ProductSyncResult> {
  // Authorization check (Server/Service layer)
  assertAuthorized('canCreateProduct', 'Cashiers and unauthorized staff cannot create products.');

  const now = new Date().toISOString();
  const client = getWooClient();
  const isOnline = useConnectionStore.getState().isOnline;

  // 1. Validation
  const trimmedName = input.name.trim();
  const trimmedSku = input.sku ? input.sku.trim() : '';
  const trimmedBarcode = input.barcode ? input.barcode.trim() : '';

  if (!trimmedName) {
    throw new Error('Product name is required');
  }

  // Check SKU uniqueness locally (only when SKU is provided)
  if (trimmedSku) {
    const existingWithSku = await db.products.where('sku').equals(trimmedSku).first();
    if (existingWithSku) {
      throw new Error(`A product with SKU "${trimmedSku}" already exists (${existingWithSku.name})`);
    }
  }

  // Check Barcode uniqueness locally
  if (trimmedBarcode) {
    const existingWithBarcode = await db.products.where('barcode').equals(trimmedBarcode).first();
    if (existingWithBarcode) {
      throw new Error(`This barcode is already assigned to "${existingWithBarcode.name}".`);
    }
  }

  // Check Starter plan 500-product limit
  const currentPlan = (await getSetting('zameria_plan')) || (await getSetting('plan'));
  if (currentPlan === 'Starter') {
    const totalProducts = await db.products.count();
    if (totalProducts >= 500) {
      throw new Error('Product limit reached (500 products max on Starter plan). Please upgrade to Business for unlimited products.');
    }
  }

  const finalPrice =
    input.salePrice !== null && input.salePrice !== undefined && input.salePrice < input.regularPrice
      ? input.salePrice
      : input.regularPrice;

  // Resolve multiple categories
  let categoryIds: number[] = [];
  let wooCategoryIds: number[] = [];

  if (Array.isArray(input.categoryIds) && input.categoryIds.length > 0) {
    categoryIds = input.categoryIds;
    const cats = await db.categories.where('id').anyOf(input.categoryIds).toArray();
    wooCategoryIds = cats.map((c) => c.wooId).filter((id): id is number => id !== null);
  } else if (input.categoryId) {
    categoryIds = [input.categoryId];
    const cat = await db.categories.get(input.categoryId);
    if (cat?.wooId) {
      wooCategoryIds = [cat.wooId];
    }
  }

  // 2. Handle image upload / local storage
  let images: ProductImage[] = [];
  let imageUploadWarning: string | null = null;

  if (input.imageFile) {
    if (client && isOnline) {
      try {
        const uploadedMedia = await client.uploadMedia(input.imageFile);
        images = [
          {
            id: uploadedMedia.id,
            src: uploadedMedia.src,
            name: trimmedName,
            alt: trimmedName,
          },
        ];
      } catch (err: any) {
        imageUploadWarning = `Image upload failed: ${err?.message || 'Server error'}. Saved locally.`;
        // Fallback to local Data URL
        const dataUrl = await fileToDataUrl(input.imageFile);
        images = [
          {
            id: Date.now(),
            src: dataUrl,
            name: trimmedName,
            alt: trimmedName,
          },
        ];
      }
    } else {
      // Demo / Offline Mode: store as local Data URL
      const dataUrl = await fileToDataUrl(input.imageFile);
      images = [
        {
          id: Date.now(),
          src: dataUrl,
          name: trimmedName,
          alt: trimmedName,
        },
      ];
    }
  } else if (input.imageUrl?.trim()) {
    images = [
      {
        id: 1,
        src: input.imageUrl.trim(),
        name: trimmedName,
        alt: trimmedName,
      },
    ];
  } else if (input.images && input.images.length > 0) {
    images = input.images;
  }

  // Resolve brand reliably (supporting both Dexie id and wooId)
  const { brandId, wooBrandId, brandName, brandObj } = await resolveBrand(input.brandId, input.wooBrandId);

  // 3. Insert into local Dexie database first (optimistic local-first persistence)
  const localId = await db.products.add({
    wooId: null,
    name: trimmedName,
    slug: trimmedName.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/(^-|-$)/g, ''),
    type: 'simple',
    status: input.status,
    description: input.description || '',
    shortDescription: '',
    sku: trimmedSku,
    barcode: trimmedBarcode || undefined,
    price: finalPrice,
    regularPrice: input.regularPrice,
    salePrice: input.salePrice ?? null,
    costPrice: input.costPrice ?? null,
    onSale: input.salePrice !== null && input.salePrice !== undefined && input.salePrice < input.regularPrice,
    stockStatus: input.stockStatus,
    stockQuantity: input.manageStock ? (input.stockQuantity ?? 0) : null,
    manageStock: input.manageStock,
    lowStockThreshold: input.lowStockThreshold ?? null,
    weight: '',
    dimensions: { length: '', width: '', height: '' },
    categoryIds,
    wooCategoryIds,
    brandId,
    wooBrandId,
    brandName,
    brand: brandObj,
    images,
    gtin: '',
    upc: '',
    ean: '',
    isbn: '',
    syncStatus: client && isOnline ? 'SYNCING' : 'PENDING_SYNC',
    lastSyncedAt: null,
    localVersion: 1,
    remoteVersion: null,
    createdAt: now,
    updatedAt: now,
  } as unknown as Product);

  let createdProduct = (await db.products.get(localId)) as Product;

  // 4. WooCommerce Synchronization Payload
  const wcImages = images.map((img) => {
    if (img.id && img.id < 1000000000000 && !img.src.startsWith('data:')) {
      return { id: img.id, src: img.src };
    }
    return { src: img.src };
  });

  const wcMetaData = trimmedBarcode
    ? [
        { key: '_barcode', value: trimmedBarcode },
        { key: 'barcode', value: trimmedBarcode },
        { key: '_gtin', value: trimmedBarcode },
      ]
    : [];

  const wcPayload: Record<string, any> = {
    name: trimmedName,
    type: 'simple',
    status: input.status,
    sku: trimmedSku,
    regular_price: (input.regularPrice / 100).toString(),
    sale_price: input.salePrice ? (input.salePrice / 100).toString() : '',
    manage_stock: input.manageStock,
    stock_quantity: input.manageStock ? (input.stockQuantity ?? 0) : null,
    stock_status: input.stockStatus,
    description: input.description || '',
    images: wcImages,
    categories: wooCategoryIds.map((id) => ({ id })),
    ...(wooBrandId ? { brands: [{ id: wooBrandId }] } : {}),
    ...(wcMetaData.length > 0 ? { meta_data: wcMetaData } : {}),
  };

  if (client && isOnline) {
    try {
      const { data: responseData, warning: brandWarning } = await syncProductWithBrandFallback(
        client,
        'POST',
        '/products',
        wcPayload,
        wooBrandId
      );
      const wooId = Number(responseData.id);

      // If WooCommerce returned updated remote image references, save them
      let syncedImages = images;
      if (Array.isArray(responseData.images) && responseData.images.length > 0) {
        syncedImages = responseData.images.map((img) => ({
          id: img.id,
          src: img.src,
          name: img.name || trimmedName,
          alt: img.alt || trimmedName,
        }));
      }

      await db.products.update(localId, {
        wooId,
        images: syncedImages,
        syncStatus: 'SYNCED',
        lastSyncedAt: now,
        remoteVersion: responseData.date_modified || now,
      });

      createdProduct = (await db.products.get(localId)) as Product;
      return {
        product: createdProduct,
        synced: true,
        error: imageUploadWarning || brandWarning || undefined,
      };
    } catch (err: any) {
      const errorMsg = err?.message || 'Failed to sync with WooCommerce';

      // Record in offline syncQueue for subsequent automatic retry
      await db.syncQueue.add({
        type: 'CREATE_PRODUCT',
        entityType: 'product',
        entityId: localId as number,
        payload: JSON.stringify(wcPayload),
        localTransactionId: `prod-create-${localId}`,
        createdAt: now,
        status: 'PENDING',
        attemptCount: 1,
        maxAttempts: 5,
        lastAttemptAt: now,
        nextAttemptAt: now,
        error: errorMsg,
        wooCommerceId: null,
        resolvedAt: null,
      });

      await db.products.update(localId, {
        syncStatus: 'PENDING_SYNC',
      });

      createdProduct = (await db.products.get(localId)) as Product;
      return { product: createdProduct, synced: false, error: errorMsg };
    }
  } else {
    // In Demo Mode or Offline
    const mockWooId = 2000 + (localId as number);
    await db.products.update(localId, {
      wooId: mockWooId,
      syncStatus: 'SYNCED',
      lastSyncedAt: now,
    });

    createdProduct = (await db.products.get(localId)) as Product;
    return { product: createdProduct, synced: true };
  }
}

/**
 * Updates an existing product in Zameria and syncs the changes to WooCommerce.
 */
export async function updateProduct(
  productId: number,
  input: UpdateProductInput
): Promise<ProductSyncResult> {
  // Authorization checks (Server/Service layer)
  assertAuthorized('canEditProduct', 'Cashiers and unauthorized staff cannot edit products.');
  if (input.regularPrice !== undefined || input.salePrice !== undefined) {
    assertAuthorized('canEditProductPrice', 'Cashiers and unauthorized staff cannot modify product prices.');
  }
  if (input.stockQuantity !== undefined || input.stockStatus !== undefined) {
    assertAuthorized('canEditStockManually', 'Cashiers and unauthorized staff cannot manually adjust product stock.');
  }

  const now = new Date().toISOString();
  const client = getWooClient();
  const isOnline = useConnectionStore.getState().isOnline;

  const product = await db.products.get(productId);
  if (!product) {
    throw new Error('Product not found');
  }

  // Calculate prices
  const regPrice = input.regularPrice ?? product.regularPrice;
  const salePrice = input.salePrice !== undefined ? input.salePrice : product.salePrice;
  const finalPrice =
    salePrice !== null && salePrice !== undefined && salePrice < regPrice ? salePrice : regPrice;

  // Resolve multiple categories
  let categoryIds = product.categoryIds || [];
  let wooCategoryIds = product.wooCategoryIds || [];

  if (input.categoryIds !== undefined) {
    categoryIds = input.categoryIds;
    if (categoryIds.length > 0) {
      const cats = await db.categories.where('id').anyOf(categoryIds).toArray();
      wooCategoryIds = cats.map((c) => c.wooId).filter((id): id is number => id !== null);
    } else {
      wooCategoryIds = [];
    }
  } else if (input.categoryId !== undefined) {
    if (input.categoryId === null) {
      categoryIds = [];
      wooCategoryIds = [];
    } else {
      categoryIds = [input.categoryId];
      const cat = await db.categories.get(input.categoryId);
      wooCategoryIds = cat?.wooId ? [cat.wooId] : [];
    }
  }

  // Resolve image update
  let images = [...(product.images || [])];
  let imageUploadWarning: string | null = null;

  if (input.removeImage) {
    // User explicitly removed image
    images = [];
  } else if (input.imageFile) {
    // User selected a new image file
    if (client && isOnline) {
      try {
        const uploaded = await client.uploadMedia(input.imageFile);
        images = [
          {
            id: uploaded.id,
            src: uploaded.src,
            name: input.name || product.name,
            alt: input.name || product.name,
          },
        ];
      } catch (err: any) {
        imageUploadWarning = `Image upload failed: ${err?.message || 'Server error'}. Kept local preview.`;
        const dataUrl = await fileToDataUrl(input.imageFile);
        images = [
          {
            id: Date.now(),
            src: dataUrl,
            name: input.name || product.name,
            alt: input.name || product.name,
          },
        ];
      }
    } else {
      const dataUrl = await fileToDataUrl(input.imageFile);
      images = [
        {
          id: Date.now(),
          src: dataUrl,
          name: input.name || product.name,
          alt: input.name || product.name,
        },
      ];
    }
  } else if (input.imageUrl !== undefined) {
    images = input.imageUrl.trim()
      ? [
          {
            id: product.images?.[0]?.id || 1,
            src: input.imageUrl.trim(),
            name: input.name || product.name,
            alt: input.name || product.name,
          },
        ]
      : [];
  }

  // Resolve barcode update & uniqueness check
  let finalBarcode = product.barcode;
  if (input.barcode !== undefined) {
    const trimmedBarcode = input.barcode ? input.barcode.trim() : '';
    if (trimmedBarcode && trimmedBarcode !== product.barcode) {
      const existingWithBarcode = await db.products.where('barcode').equals(trimmedBarcode).first();
      if (existingWithBarcode && existingWithBarcode.id !== productId) {
        throw new Error(`This barcode is already assigned to "${existingWithBarcode.name}".`);
      }
    }
    finalBarcode = trimmedBarcode || undefined;
  }

  // Resolve brand update reliably (supporting both Dexie id and wooId)
  let brandId = product.brandId;
  let wooBrandId = product.wooBrandId;
  let brandName = product.brandName;
  let brandObj = product.brand;

  if (input.brandId !== undefined || input.wooBrandId !== undefined) {
    if (input.brandId === null && input.wooBrandId === null) {
      brandId = null;
      wooBrandId = null;
      brandName = null;
      brandObj = null;
    } else {
      const resolved = await resolveBrand(input.brandId, input.wooBrandId);
      brandId = resolved.brandId;
      wooBrandId = resolved.wooBrandId;
      brandName = resolved.brandName;
      brandObj = resolved.brandObj;
    }
  }

  const updateFields: Partial<Product> = {
    name: input.name !== undefined ? input.name.trim() : product.name,
    sku: input.sku !== undefined ? input.sku.trim() : product.sku,
    barcode: finalBarcode,
    price: finalPrice,
    regularPrice: regPrice,
    salePrice: salePrice ?? null,
    costPrice: input.costPrice !== undefined ? input.costPrice : product.costPrice,
    onSale: salePrice !== null && salePrice !== undefined && salePrice < regPrice,
    stockStatus: input.stockStatus ?? product.stockStatus,
    stockQuantity:
      input.manageStock !== undefined
        ? input.manageStock
          ? (input.stockQuantity ?? product.stockQuantity ?? 0)
          : null
        : input.stockQuantity !== undefined
        ? input.stockQuantity
        : product.stockQuantity,
    manageStock: input.manageStock !== undefined ? input.manageStock : product.manageStock,
    lowStockThreshold:
      input.lowStockThreshold !== undefined ? input.lowStockThreshold : product.lowStockThreshold,
    status: input.status ?? product.status,
    description: input.description !== undefined ? input.description : product.description,
    categoryIds,
    wooCategoryIds,
    brandId,
    wooBrandId,
    brandName,
    brand: brandObj,
    images,
    updatedAt: now,
  };

  await db.products.update(productId, updateFields);
  let updatedProduct = (await db.products.get(productId)) as Product;

  // WooCommerce Sync Payload
  const wcImages = images.map((img) => {
    if (img.id && img.id < 1000000000000 && !img.src.startsWith('data:')) {
      return { id: img.id, src: img.src };
    }
    return { src: img.src };
  });

  const wcPayload: Record<string, any> = {
    name: updateFields.name,
    sku: updateFields.sku,
    regular_price: (regPrice / 100).toString(),
    sale_price: salePrice ? (salePrice / 100).toString() : '',
    manage_stock: updateFields.manageStock,
    stock_quantity: updateFields.manageStock ? updateFields.stockQuantity : null,
    stock_status: updateFields.stockStatus,
    status: updateFields.status,
    description: updateFields.description,
    categories: wooCategoryIds.map((id) => ({ id })),
    images: wcImages,
    ...(input.brandId !== undefined || input.wooBrandId !== undefined
      ? { brands: wooBrandId ? [{ id: wooBrandId }] : [] }
      : {}),
  };

  if (input.barcode !== undefined) {
    wcPayload.meta_data = [
      { key: '_barcode', value: finalBarcode || '' },
      { key: 'barcode', value: finalBarcode || '' },
      { key: '_gtin', value: finalBarcode || '' },
    ];
  }

  if (product.wooId && client && isOnline) {
    try {
      const { data: responseData, warning: brandWarning } = await syncProductWithBrandFallback(
        client,
        'PUT',
        `/products/${product.wooId}`,
        wcPayload,
        wooBrandId ?? null
      );

      // If remote returned canonical images, update locally
      let syncedImages = images;
      if (Array.isArray(responseData.images) && responseData.images.length > 0) {
        syncedImages = responseData.images.map((img: any) => ({
          id: img.id,
          src: img.src,
          name: img.name || updateFields.name || product.name,
          alt: img.alt || updateFields.name || product.name,
        }));
      }

      await db.products.update(productId, {
        images: syncedImages,
        syncStatus: 'SYNCED',
        lastSyncedAt: now,
        remoteVersion: responseData.date_modified || now,
      });

      updatedProduct = (await db.products.get(productId)) as Product;
      return { product: updatedProduct, synced: true, error: imageUploadWarning || brandWarning || undefined };
    } catch (err: any) {
      const errorMsg = err?.message || 'Failed to sync update to WooCommerce';

      await db.syncQueue.add({
        type: 'UPDATE_PRODUCT',
        entityType: 'product',
        entityId: productId,
        payload: JSON.stringify(wcPayload),
        localTransactionId: `prod-upd-${productId}-${Date.now()}`,
        createdAt: now,
        status: 'PENDING',
        attemptCount: 1,
        maxAttempts: 5,
        lastAttemptAt: now,
        nextAttemptAt: now,
        error: errorMsg,
        wooCommerceId: product.wooId,
        resolvedAt: null,
      });

      await db.products.update(productId, { syncStatus: 'PENDING_SYNC' });
      updatedProduct = (await db.products.get(productId)) as Product;
      return { product: updatedProduct, synced: false, error: errorMsg };
    }
  } else {
    // In Demo Mode or product without wooId yet
    await db.products.update(productId, {
      syncStatus: 'SYNCED',
      lastSyncedAt: now,
    });

    updatedProduct = (await db.products.get(productId)) as Product;
    return { product: updatedProduct, synced: true };
  }
}

/**
 * Synchronizes inventory level from a POS sale to WooCommerce safely.
 */
export async function syncProductStock(
  productId: number,
  newStock: number,
  newStatus?: StockStatus,
  isManualEdit: boolean = false
): Promise<boolean> {
  if (isManualEdit) {
    assertAuthorized('canEditStockManually', 'Cashiers and unauthorized staff cannot manually adjust product stock.');
  }

  const now = new Date().toISOString();
  const client = getWooClient();
  const isOnline = useConnectionStore.getState().isOnline;

  const product = await db.products.get(productId);
  if (!product) return false;

  const resolvedStatus: StockStatus =
    newStatus || (newStock <= 0 ? 'outofstock' : 'instock');

  // Update locally first
  await db.products.update(productId, {
    stockQuantity: newStock,
    stockStatus: resolvedStatus,
    updatedAt: now,
  });

  if (product.wooId && client && isOnline) {
    try {
      await client.put(`/products/${product.wooId}`, {
        manage_stock: true,
        stock_quantity: newStock,
        stock_status: resolvedStatus,
      });

      await db.products.update(productId, {
        syncStatus: 'SYNCED',
        lastSyncedAt: now,
      });
      return true;
    } catch {
      // Queue update for retry when connection returns
      await db.syncQueue.add({
        type: 'UPDATE_STOCK',
        entityType: 'product',
        entityId: productId,
        payload: JSON.stringify({
          stock_quantity: newStock,
          stock_status: resolvedStatus,
        }),
        localTransactionId: `stock-sync-${productId}-${Date.now()}`,
        createdAt: now,
        status: 'PENDING',
        attemptCount: 1,
        maxAttempts: 5,
        lastAttemptAt: now,
        nextAttemptAt: now,
        error: 'Network failure during POS stock update',
        wooCommerceId: product.wooId,
        resolvedAt: null,
      });

      await db.products.update(productId, { syncStatus: 'PENDING_SYNC' });
      return false;
    }
  }

  return true;
}

let isProcessingProductQueue = false;

/**
 * Flushes all pending product updates from `db.syncQueue` to WooCommerce.
 */
export async function processPendingProductQueue(): Promise<number> {
  const client = getWooClient();
  const isOnline = useConnectionStore.getState().isOnline;
  if (!client || !isOnline) return 0;

  if (isProcessingProductQueue) return 0;
  isProcessingProductQueue = true;

  try {
    const pendingItems = await db.syncQueue
      .where('status')
      .equals('PENDING')
      .and((item) => item.entityType === 'product')
      .sortBy('createdAt');

    let processedCount = 0;
    const now = new Date().toISOString();

    for (const item of pendingItems) {
      try {
        const payload = JSON.parse(item.payload);
        const wooBrandId = payload.brands?.[0]?.id ?? (typeof payload.brands?.[0] === 'number' ? payload.brands[0] : null) ?? null;

        if (item.type === 'CREATE_PRODUCT') {
          const { data: resData } = await syncProductWithBrandFallback(
            client,
            'POST',
            '/products',
            payload,
            wooBrandId
          );
          const wooId = Number(resData.id);
          await db.products.update(item.entityId, {
            wooId,
            syncStatus: 'SYNCED',
            lastSyncedAt: now,
          });

          // Cascade wooId to any pending update items for the same entity
          const pendingUpdates = await db.syncQueue
            .where('status')
            .equals('PENDING')
            .and((q) => q.entityId === item.entityId && !q.wooCommerceId)
            .toArray();
          for (const pu of pendingUpdates) {
            await db.syncQueue.update(pu.id, { wooCommerceId: wooId });
          }
        } else if (item.type === 'UPDATE_PRODUCT' || item.type === 'UPDATE_STOCK') {
          let targetWooId = item.wooCommerceId;
          if (!targetWooId) {
            const localProd = await db.products.get(item.entityId);
            targetWooId = localProd?.wooId ?? null;
          }
          if (targetWooId) {
            await syncProductWithBrandFallback(
              client,
              'PUT',
              `/products/${targetWooId}`,
              payload,
              wooBrandId
            );
            await db.products.update(item.entityId, {
              syncStatus: 'SYNCED',
              lastSyncedAt: now,
            });
          }
        } else if (item.type === 'DELETE_PRODUCT') {
          let targetWooId = item.wooCommerceId;
          if (!targetWooId) {
            const localProd = await db.products.get(item.entityId);
            targetWooId = localProd?.wooId ?? null;
          }
          if (targetWooId) {
            await client.delete(`/products/${targetWooId}`);
          }
        }

        await db.syncQueue.update(item.id, {
          status: 'SYNCED',
          resolvedAt: now,
          error: undefined,
        });
        processedCount++;
      } catch (err: any) {
        const errorMsg = err?.message || 'Sync failed';
        const nextAttempts = item.attemptCount + 1;
        await db.syncQueue.update(item.id, {
          attemptCount: nextAttempts,
          lastAttemptAt: now,
          error: errorMsg,
          status: nextAttempts >= item.maxAttempts ? 'FAILED' : 'PENDING',
        });
      }
    }

    return processedCount;
  } finally {
    isProcessingProductQueue = false;
  }
}

/**
 * Pulls all products and categories from WooCommerce and reconciles them into Zameria.
 * Idempotent: repeated runs update existing products without creating duplicates.
 */
export interface ProductSyncOptions {
  incremental?: boolean;
  modifiedAfter?: string | null;
  onProgress?: (current: number, total: number) => void;
}

/**
 * Pulls the latest WooCommerce products and safely synchronizes them into local Dexie.
 * Idempotent: repeated runs update existing products without creating duplicates.
 * Supports incremental sync with modified_after and pagination across large catalogues.
 */
export async function syncAllProducts(options?: ProductSyncOptions): Promise<
  SyncEntityResult & { importedCount: number; updatedCount: number; failedCount: number }
> {
  const client = getWooClient();
  const isOnline = useConnectionStore.getState().isOnline;
  const now = new Date().toISOString();

  const result: SyncEntityResult & { importedCount: number; updatedCount: number; failedCount: number } = {
    entity: 'products',
    importedCount: 0,
    updatedCount: 0,
    failedCount: 0,
    errors: [],
  };

  // Signed in to a real store: the Zameria plugin feed carries full products with variations
  // and only sends what changed since the last sync.
  const token = sessionToken();
  if (token) {
    await processPendingProductQueue();
    if (!options?.incremental) {
      await resetCatalogueCursor();
      const { importedCount } = await downloadCatalogue(token, options?.onProgress);
      result.importedCount = importedCount;
    } else {
      result.updatedCount = (await pullChanges(token)).updatedCount;
    }
    return result;
  }

  // 1. Synchronize categories and brands first so local mapping is up-to-date
  await syncAllCategories();
  await syncAllBrands();

  // 2. Process any pending local changes first so they are not lost
  await processPendingProductQueue();

  if (client && isOnline) {
    try {
      const params: Record<string, string | number> = {
        per_page: 100,
        status: 'publish',
      };

      if (options?.incremental && options.modifiedAfter) {
        params.modified_after = options.modifiedAfter;
      }

      const firstPage = await client.get<any[]>('/products', { ...params, page: 1 });
      const totalPages = firstPage.totalPages || 1;
      const remoteProducts: any[] = [...(firstPage.data || [])];
      options?.onProgress?.(1, totalPages);

      for (let page = 2; page <= totalPages; page++) {
        try {
          const pageRes = await client.get<any[]>('/products', { ...params, page });
          if (pageRes.data) {
            remoteProducts.push(...pageRes.data);
          }
          options?.onProgress?.(page, totalPages);
        } catch (pErr: any) {
          result.failedCount++;
          result.errors.push(`Products page ${page} error: ${pErr.message}`);
        }
      }

      const publishedRemoteWooIds = new Set<number>();

      for (const rp of remoteProducts) {
        // Enforce publication rule: only published products enter active catalogue
        if (rp.status && rp.status !== 'publish') {
          continue;
        }

        const wooId = Number(rp.id);
        publishedRemoteWooIds.add(wooId);

        const regularPriceKobo = toKobo(parseFloat(rp.regular_price || rp.price) || 0);
        const salePriceKobo = rp.sale_price ? toKobo(parseFloat(rp.sale_price)) : null;
        const finalPriceKobo = toKobo(parseFloat(rp.price) || 0);
        const stockQty = rp.manage_stock && rp.stock_quantity !== null ? Number(rp.stock_quantity) : null;
        const stockStatus: StockStatus = rp.stock_status || 'instock';

        // Extract WooCommerce Category IDs and map to local Dexie category IDs
        const rpWooCategoryIds: number[] = Array.isArray(rp.categories)
          ? rp.categories.map((c: any) => Number(c.id))
          : [];

        let resolvedCategoryIds: number[] = [];
        if (rpWooCategoryIds.length > 0) {
          const localCats = await db.categories
            .where('wooId')
            .anyOf(rpWooCategoryIds)
            .toArray();
          resolvedCategoryIds = localCats.map((c) => c.id);
        }

        // Extract Brand from WooCommerce
        let rpBrandObj: { id: number; name: string; slug: string; taxonomy?: string } | null = null;
        if (Array.isArray(rp.brands) && rp.brands.length > 0) {
          rpBrandObj = {
            id: Number(rp.brands[0].id),
            name: rp.brands[0].name || '',
            slug: rp.brands[0].slug || '',
            taxonomy: 'product_brand',
          };
        } else if (rp.brand && typeof rp.brand === 'object') {
          rpBrandObj = {
            id: Number(rp.brand.id),
            name: rp.brand.name || '',
            slug: rp.brand.slug || '',
            taxonomy: 'product_brand',
          };
        } else if (Array.isArray(rp.attributes)) {
          const brandAttr = rp.attributes.find(
            (a: any) => (a.name || '').toLowerCase() === 'brand' || (a.slug || '').toLowerCase() === 'pa_brand'
          );
          if (brandAttr && Array.isArray(brandAttr.options) && brandAttr.options.length > 0) {
            const opt = String(brandAttr.options[0]);
            rpBrandObj = { id: 0, name: opt, slug: opt.toLowerCase().replace(/\s+/g, '-'), taxonomy: 'pa_brand' };
          }
        }

        let brandId: number | null = null;
        let wooBrandId: number | null = null;
        let brandName: string | null = null;
        if (rpBrandObj && rpBrandObj.name) {
          wooBrandId = rpBrandObj.id > 0 ? rpBrandObj.id : null;
          brandName = rpBrandObj.name;
          let localBrand = wooBrandId ? await db.brands.where('wooId').equals(wooBrandId).first() : null;
          if (!localBrand && rpBrandObj.slug) {
            localBrand = await db.brands.where('slug').equals(rpBrandObj.slug).first();
          }
          if (localBrand) {
            brandId = localBrand.id;
            await db.brands.update(localBrand.id, {
              name: rpBrandObj.name,
              slug: rpBrandObj.slug,
              syncStatus: 'SYNCED',
              lastSyncedAt: now,
            });
          } else {
            brandId = await db.brands.add({
              wooId: wooBrandId,
              name: rpBrandObj.name,
              slug: rpBrandObj.slug,
              taxonomy: rpBrandObj.taxonomy || 'product_brand',
              syncStatus: 'SYNCED',
              lastSyncedAt: now,
            } as any);
          }
        }

        const resolvedImages = Array.isArray(rp.images)
          ? rp.images.map((img: any) => ({
              id: img.id,
              src: img.src,
              name: img.name || rp.name || '',
              alt: img.alt || rp.name || '',
            }))
          : [];

        const remoteBarcode = extractBarcodeFromRemote(rp);

        // Check if product already exists by wooId
        let existing = await db.products.where('wooId').equals(wooId).first();

        // Fallback: match by SKU if present
        if (!existing && rp.sku) {
          existing = await db.products.where('sku').equals(rp.sku.trim()).first();
        }

        // Fallback: match by Barcode if present
        if (!existing && remoteBarcode) {
          existing = await db.products.where('barcode').equals(remoteBarcode).first();
        }

        if (existing) {
          // If local has un-synced edits, don't silently overwrite
          if (existing.syncStatus === 'PENDING_SYNC') {
            continue;
          }

          // Update existing product without creating duplicate (restore to publish if previously draft)
          await db.products.update(existing.id, {
            wooId,
            name: rp.name || existing.name,
            sku: rp.sku || existing.sku,
            barcode: remoteBarcode || existing.barcode,
            price: finalPriceKobo,
            regularPrice: regularPriceKobo,
            salePrice: salePriceKobo,
            onSale: rp.on_sale || false,
            stockQuantity: stockQty,
            stockStatus,
            manageStock: Boolean(rp.manage_stock),
            status: 'publish',
            description: rp.description || existing.description,
            categoryIds: resolvedCategoryIds,
            wooCategoryIds: rpWooCategoryIds,
            brandId,
            wooBrandId,
            brandName,
            brand: rpBrandObj,
            images: resolvedImages.length > 0 ? resolvedImages : existing.images,
            syncStatus: 'SYNCED',
            lastSyncedAt: now,
            remoteVersion: rp.date_modified || now,
            updatedAt: now,
          });
          result.updatedCount++;
        } else {
          // Insert new imported published product
          await db.products.add({
            wooId,
            name: rp.name || 'Untitled Product',
            slug: rp.slug || `prod-${wooId}`,
            type: rp.type || 'simple',
            status: 'publish',
            description: rp.description || '',
            shortDescription: rp.short_description || '',
            sku: rp.sku || `SKU-${wooId}`,
            barcode: remoteBarcode || undefined,
            price: finalPriceKobo,
            regularPrice: regularPriceKobo,
            salePrice: salePriceKobo,
            costPrice: null,
            onSale: rp.on_sale || false,
            stockStatus,
            stockQuantity: stockQty,
            manageStock: Boolean(rp.manage_stock),
            weight: rp.weight || '',
            dimensions: {
              length: rp.dimensions?.length || '',
              width: rp.dimensions?.width || '',
              height: rp.dimensions?.height || '',
            },
            categoryIds: resolvedCategoryIds,
            wooCategoryIds: rpWooCategoryIds,
            brandId,
            wooBrandId,
            brandName,
            brand: rpBrandObj,
            images: resolvedImages,
            gtin: remoteBarcode || '',
            upc: '',
            ean: '',
            isbn: '',
            syncStatus: 'SYNCED',
            lastSyncedAt: now,
            localVersion: 1,
            remoteVersion: rp.date_modified || now,
            createdAt: rp.date_created || now,
            updatedAt: now,
          } as unknown as Product);
          result.importedCount++;
        }
      }

      // Detect previously synced products that are no longer published on WooCommerce
      // Deactivate them from the active catalogue (status: 'draft') while preserving historical sales/orders
      if (!options?.incremental) {
        const localPublishedWithWoo = await db.products
          .filter((p) => p.wooId !== null && (p.status || 'publish') === 'publish')
          .toArray();

        for (const lp of localPublishedWithWoo) {
          if (lp.wooId && !publishedRemoteWooIds.has(lp.wooId)) {
            await db.products.update(lp.id, {
              status: 'draft',
              updatedAt: now,
            });
            result.updatedCount++;
          }
        }
      }
    } catch (err: any) {
      result.failedCount++;
      result.errors.push(err.message || 'Failed to sync products from WooCommerce');
    }
  } else if (isDemoSession()) {
    // Demo Mode: mark all local products as SYNCED with fresh timestamp
    const allProds = await db.products.toArray();
    for (const p of allProds) {
      await db.products.update(p.id, {
        syncStatus: 'SYNCED',
        lastSyncedAt: now,
      });
      result.updatedCount++;
    }
  }

  return result;
}

/**
 * Fast inventory stock level synchronization with WooCommerce.
 * Pulls current stock quantities and stock statuses without re-importing the full catalogue.
 */
export async function syncInventoryStock(options?: {
  onProgress?: (current: number, total: number) => void;
}): Promise<SyncEntityResult> {
  const client = getWooClient();
  const isOnline = useConnectionStore.getState().isOnline;
  const now = new Date().toISOString();

  const result: SyncEntityResult = {
    entity: 'inventory',
    importedCount: 0,
    updatedCount: 0,
    failedCount: 0,
    errors: [],
  };

  // Real store: fetch only changed stock from the plugin instead of re-reading every product.
  const token = sessionToken();
  if (token) {
    result.updatedCount = (await pullChanges(token)).updatedCount;
    return result;
  }

  if (client && isOnline) {
    try {
      const firstPage = await client.get<any[]>('/products', { per_page: 100, page: 1, status: 'publish' });
      const totalPages = firstPage.totalPages || 1;
      const remoteProducts: any[] = [...(firstPage.data || [])];
      options?.onProgress?.(1, totalPages);

      for (let page = 2; page <= totalPages; page++) {
        try {
          const pageRes = await client.get<any[]>('/products', { per_page: 100, page, status: 'publish' });
          if (pageRes.data) {
            remoteProducts.push(...pageRes.data);
          }
          options?.onProgress?.(page, totalPages);
        } catch (pErr: any) {
          result.failedCount++;
          result.errors.push(`Inventory page ${page} error: ${pErr.message}`);
        }
      }

      for (const rp of remoteProducts) {
        const wooId = Number(rp.id);
        const stockQty = rp.manage_stock && rp.stock_quantity !== null ? Number(rp.stock_quantity) : null;
        const stockStatus: StockStatus = rp.stock_status || 'instock';

        const existing = await db.products.where('wooId').equals(wooId).first();
        if (existing) {
          await db.products.update(existing.id, {
            stockQuantity: stockQty,
            stockStatus,
            manageStock: Boolean(rp.manage_stock),
            lastSyncedAt: now,
            updatedAt: now,
          });
          result.updatedCount++;
        }
      }
    } catch (err: any) {
      result.failedCount++;
      result.errors.push(err.message || 'Failed to sync inventory from WooCommerce');
    }
  } else {
    // Demo Mode: mark stock as synced
    const allProds = await db.products.toArray();
    result.updatedCount = allProds.length;
  }

  return result;
}

/**
 * Deletes a product from the local catalogue and WooCommerce.
 * Requires 'canDeleteProduct' permission (Admin or Shop Manager).
 * Ensures safety for historical orders:
 * - Snapshot items in db.orderItems remain 100% intact.
 * - Active cart items for this product are removed.
 * - Synced remote product is deleted or queued for sync.
 * - Local product is removed from db.products.
 */
export async function deleteProduct(
  productId: number
): Promise<{ success: boolean; error?: string; orderCount?: number }> {
  // 1. Authorization check
  assertAuthorized('canDeleteProduct', 'Cashiers and unauthorized staff cannot delete products.');

  const product = await db.products.get(productId);
  if (!product) {
    return { success: false, error: 'Product not found' };
  }

  // 2. Clean up active cart items containing this product
  try {
    await db.cartItems.where('productId').equals(productId).delete();
  } catch (err) {
    console.warn('Failed to clean cart items for deleted product:', err);
  }

  // 3. Count historical orders referencing this product (informational only - orderItems remain intact)
  let orderCount = 0;
  try {
    orderCount = await db.orderItems.where('productId').equals(productId).count();
  } catch {}

  // 4. Remote WooCommerce deletion if connected and online
  const client = getWooClient();
  const isOnline = useConnectionStore.getState().isOnline;
  const now = new Date().toISOString();

  if (product.wooId && client && isOnline) {
    try {
      await client.delete(`/products/${product.wooId}`);
    } catch (err: any) {
      console.warn('Failed to delete product remotely on WooCommerce:', err.message);
      await db.syncQueue.add({
        type: 'DELETE_PRODUCT',
        entityType: 'product',
        entityId: productId,
        payload: JSON.stringify({ wooId: product.wooId }),
        localTransactionId: `prod-del-${productId}-${Date.now()}`,
        createdAt: now,
        status: 'PENDING',
        attemptCount: 1,
        maxAttempts: 5,
        lastAttemptAt: now,
        nextAttemptAt: now,
        error: err.message,
        wooCommerceId: product.wooId,
        resolvedAt: null,
      });
    }
  } else if (product.wooId && (!client || !isOnline)) {
    await db.syncQueue.add({
      type: 'DELETE_PRODUCT',
      entityType: 'product',
      entityId: productId,
      payload: JSON.stringify({ wooId: product.wooId }),
      localTransactionId: `prod-del-${productId}-${Date.now()}`,
      createdAt: now,
      status: 'PENDING',
      attemptCount: 0,
      maxAttempts: 5,
      lastAttemptAt: null,
      nextAttemptAt: now,
      error: null,
      wooCommerceId: product.wooId,
      resolvedAt: null,
    });
  }

  // 5. Delete product from local database
  await db.products.delete(productId);

  return { success: true, orderCount };
}

