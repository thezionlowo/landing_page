import { toast } from 'sonner';
import { zameriaApi, ZameriaApiError } from './api';
import { useAuthStore } from '@/store/authStore';
import { demoLoginEnabled } from './config';

/** Device token for the signed-in staff member, or null in a demo session. */
export function sessionToken(): string | null {
  return useAuthStore.getState().user?.token ?? null;
}

/**
 * True only for the development demo (no store behind it). Services use this to decide whether
 * they may fake a sync; a real session that is merely offline must never fake one, or unsent
 * sales and customers would be marked as synced and lost.
 */
export function isDemoSession(): boolean {
  return demoLoginEnabled() && sessionToken() === null;
}

/** Revocation checks stay independent of long catalogue/history imports. */
export const SESSION_CHECK_INTERVAL_MS = 15_000;
export async function checkActiveSession(): Promise<void> {
  const token = sessionToken();
  if (!token || (typeof navigator !== 'undefined' && navigator.onLine === false)) return;
  try {
    await zameriaApi.session(token);
  } catch (error) {
    // A delayed response for an old token must never sign out a newer login.
    if (sessionToken() !== token) return;
    if (error instanceof ZameriaApiError && (error.status === 401 || (error.status === 403 && error.code === 'zameria_forbidden'))) {
      useAuthStore.getState().logout();
      toast.error('Your POS session has ended.', { description: 'Your account may have signed in on another device. Sign in again to continue.' });
    }
    // A network outage or an older plugin without this route preserves offline work.
  }
}

export function startSessionWatch(): () => void {
  let checking = false;
  let stopped = false;
  const check = async () => {
    if (stopped || checking) return;
    checking = true;
    try { await checkActiveSession(); } finally { checking = false; }
  };
  const onVisible = () => { if (document.visibilityState === 'visible') void check(); };
  void check();
  const timer = setInterval(() => void check(), SESSION_CHECK_INTERVAL_MS);
  window.addEventListener('online', check);
  window.addEventListener('focus', check);
  document.addEventListener('visibilitychange', onVisible);
  return () => {
    stopped = true;
    clearInterval(timer);
    window.removeEventListener('online', check);
    window.removeEventListener('focus', check);
    document.removeEventListener('visibilitychange', onVisible);
  };
}
