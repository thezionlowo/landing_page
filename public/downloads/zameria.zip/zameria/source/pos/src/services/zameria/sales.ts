import { db, getSetting, setSetting } from '@/db';
import { fromKobo } from '@/lib';
import { getWooClient } from '@/services/woocommerce/client';
import type { Order, OrderItem } from '@/types';
import { zameriaApi, type SalePayload } from './api';
import { applyServerProducts } from './catalog';
import { canonicalWooOrderId, ORDER_IDENTITY_TABLES, reconcileOrderCopies } from '@/db/orderIdentity';

const SALES_PER_REQUEST = 20;
const RECEIPT_SEQ_KEY = 'zameria_receipt_seq';

const money = (kobo: number) => fromKobo(kobo).toFixed(2);

/** Next till receipt number for this register, e.g. R3-00042. Works offline. */
export async function nextReceiptNumber(deviceId: number | undefined): Promise<string> {
  const seq = (Number(await getSetting(RECEIPT_SEQ_KEY)) || 0) + 1;
  await setSetting(RECEIPT_SEQ_KEY, String(seq));
  return `R${deviceId ?? 0}-${String(seq).padStart(5, '0')}`;
}

function toPayload(order: Order, items: OrderItem[]): SalePayload {
  const coupons = order.couponLines?.length
    ? order.couponLines
    : order.couponCode
      ? [{ code: order.couponCode, discount: order.couponDiscount ?? 0 }]
      : [];

  return {
    uuid: order.localTransactionId,
    receipt_number: order.receiptNumber ?? order.orderNumber,
    created_at: order.completedAt ?? order.createdAt,
    total: money(order.total),
    lines: items.map((item) => ({
      item_id: item.wooVariationId ?? item.wooProductId ?? 0,
      name: item.name,
      quantity: item.quantity,
      unit_price: money(item.price),
      subtotal: money(item.subtotal),
      total: money(item.total),
    })),
    coupons: coupons.map((c) => ({ code: c.code, discount: money(c.discount) })),
    fees: order.transactionFee > 0 ? [{ name: 'Transaction fee', total: money(order.transactionFee) }] : [],
    payment: {
      method: order.paymentMethod,
      title: order.paymentMethodTitle,
      splits: (order.paymentSplits ?? []).map((s) => ({ method: s.method, title: s.methodTitle, amount: money(s.amount) })),
    },
    customer: {
      id: order.wooCustomerId,
      name: order.customerName === 'Walk-in Customer' ? '' : order.customerName,
      email: (order.customerEmail || '').trim(),
      phone: (order.customerPhone || '').trim(),
    },
    note: order.customerNote ?? '',
    attended_by: order.attendedBy ?? '',
  };
}

/**
 * Uploads completed sales that the store hasn't recorded yet. Safe to call repeatedly and
 * from several tabs: each sale's UUID makes the upload idempotent on the server.
 */
export async function pushPendingSales(token: string): Promise<{ pushedCount: number; failedCount: number }> {
  const pending = await db.orders
    .where('syncStatus')
    .equals('PENDING_SYNC')
    .filter((order) => order.status === 'completed' && !order.wooId)
    .sortBy('createdAt');

  let pushedCount = 0;
  let failedCount = 0;

  for (let i = 0; i < pending.length; i += SALES_PER_REQUEST) {
    const batch = pending.slice(i, i + SALES_PER_REQUEST);
    const payloads: SalePayload[] = [];
    for (const order of batch) {
      payloads.push(toPayload(order, await db.orderItems.where('orderId').equals(order.id).toArray()));
    }

    const response = await zameriaApi.pushSales(token, payloads);
    const now = new Date().toISOString();

    await db.transaction('rw', ORDER_IDENTITY_TABLES, async (tx) => {
      for (const result of response.results) {
        const order = batch.find((o) => o.localTransactionId === result.uuid);
        if (!order) continue;
        if (result.status === 'created' || result.status === 'duplicate') {
          const remoteId = canonicalWooOrderId(result.order_id);
          if (!remoteId) throw new Error('Store did not return a valid order ID; sale remains queued.');
          // A simultaneous download may already have cached this acknowledged sale.
          await reconcileOrderCopies(tx, remoteId, order.id);
          await db.orders.update(order.id, {
            wooId: remoteId,
            orderNumber: result.order_number ? `#${result.order_number}` : order.orderNumber,
            syncStatus: 'SYNCED',
            syncError: undefined,
            lastSyncedAt: now,
            remoteVersion: now,
          });
          pushedCount++;
        } else if (result.status === 'error') {
          await db.orders.update(order.id, { syncStatus: 'SYNC_ERROR', syncError: result.message });
          failedCount++;
        }
        // 'pending': another request is still importing it; it is retried next sync.
      }
    });

    // A sale cancelled on this till while its upload was in flight: cancel the new order too.
    for (const result of response.results) {
      const order = batch.find((o) => o.localTransactionId === result.uuid);
      const current = order ? await db.orders.get(order.id) : undefined;
      if (result.order_id && current?.status === 'cancelled') {
        await getWooClient()
          ?.put(`/orders/${result.order_id}`, { status: 'cancelled' })
          .catch((err) => console.warn('Could not cancel uploaded order', result.order_id, err));
      }
    }

    // Fresh stock for what was just sold (after the orders are marked synced).
    await applyServerProducts(response.products);
  }

  return { pushedCount, failedCount };
}

/** Puts a sale the store rejected back in the upload queue. */
export async function retrySale(orderId: number): Promise<void> {
  await db.orders.update(orderId, { syncStatus: 'PENDING_SYNC', syncError: undefined });
}
