import { db } from '@/db';
import { getWooClient } from './client';
import type { Category } from '@/types';
import { isDemoSession } from '@/services/zameria/session';

export interface CategoryTreeNode {
  id: number;
  wooId: number | null;
  name: string;
  slug: string;
  parent: number; // parent wooId
  count: number;
  level: number;
  path: string; // e.g. "Beauty > Skincare"
  children: CategoryTreeNode[];
}

/**
 * Builds a hierarchical category tree respecting WooCommerce parent-child relationships.
 */
export function buildCategoryTree(categories: Category[]): CategoryTreeNode[] {
  const map = new Map<number, CategoryTreeNode>();
  const roots: CategoryTreeNode[] = [];

  // 1. Initialize nodes keyed by wooId (or local id if wooId is null)
  for (const cat of categories) {
    const key = cat.wooId ?? cat.id;
    map.set(key, {
      id: cat.id,
      wooId: cat.wooId,
      name: cat.name,
      slug: cat.slug,
      parent: cat.parent || 0,
      count: cat.count || 0,
      level: 0,
      path: cat.name,
      children: [],
    });
  }

  // 2. Build parent-child relationships
  for (const cat of categories) {
    const key = cat.wooId ?? cat.id;
    const node = map.get(key)!;
    if (cat.parent && cat.parent !== 0 && map.has(cat.parent)) {
      const parentNode = map.get(cat.parent)!;
      parentNode.children.push(node);
    } else {
      roots.push(node);
    }
  }

  // 3. Assign levels and paths recursively
  function setHierarchy(nodes: CategoryTreeNode[], level: number, parentPath = '') {
    for (const node of nodes) {
      node.level = level;
      node.path = parentPath ? `${parentPath} > ${node.name}` : node.name;
      if (node.children.length > 0) {
        setHierarchy(node.children, level + 1, node.path);
      }
    }
  }
  setHierarchy(roots, 0);

  return roots;
}

/**
 * Flattens a category tree into an ordered list with indentation levels.
 */
export function flattenCategoryTree(nodes: CategoryTreeNode[]): CategoryTreeNode[] {
  const result: CategoryTreeNode[] = [];
  function traverse(list: CategoryTreeNode[]) {
    for (const node of list) {
      result.push(node);
      if (node.children.length > 0) {
        traverse(node.children);
      }
    }
  }
  traverse(nodes);
  return result;
}

/**
 * Pulls the latest WooCommerce categories and safely synchronizes them into local Dexie.
 * Idempotent: repeated runs update existing categories without creating duplicates.
 */
export async function syncAllCategories(): Promise<{
  importedCount: number;
  updatedCount: number;
  categories: Category[];
}> {
  const client = getWooClient();
  const now = new Date().toISOString();
  let importedCount = 0;
  let updatedCount = 0;

  if (client) {
    try {
      const response = await client.get<any[]>('/products/categories', { per_page: 100 });
      const remoteCategories = response.data || [];

      for (const rc of remoteCategories) {
        const wooId = Number(rc.id);
        const parentWooId = Number(rc.parent || 0);
        const name = rc.name || 'Uncategorized';
        const slug = rc.slug || '';
        const description = rc.description || '';
        const count = Number(rc.count || 0);
        const image = rc.image
          ? {
              id: Number(rc.image.id || 0),
              src: rc.image.src || '',
              name: rc.image.name || name,
              alt: rc.image.alt || name,
            }
          : null;

        const existing = await db.categories.where('wooId').equals(wooId).first();
        if (existing) {
          await db.categories.update(existing.id, {
            name,
            slug,
            parent: parentWooId,
            description,
            count,
            image,
            syncStatus: 'SYNCED',
            lastSyncedAt: now,
          });
          updatedCount++;
        } else {
          await db.categories.add({
            wooId,
            name,
            slug,
            parent: parentWooId,
            description,
            count,
            image,
            syncStatus: 'SYNCED',
            lastSyncedAt: now,
          } as unknown as Category);
          importedCount++;
        }
      }
    } catch (err) {
      console.error('Failed to sync categories from WooCommerce:', err);
    }
  } else if (isDemoSession()) {
    // In Demo / Local mode: stamp existing categories as synced
    const allCats = await db.categories.toArray();
    for (const c of allCats) {
      await db.categories.update(c.id, {
        syncStatus: 'SYNCED',
        lastSyncedAt: now,
      });
      updatedCount++;
    }
  }

  const allCategories = await db.categories.toArray();
  return { importedCount, updatedCount, categories: allCategories };
}
