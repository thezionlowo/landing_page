import type { Order, AuthUser } from '@/types';

/**
 * Checks if an order originated from the WooCommerce website/store.
 * Website orders are shared business-level orders, not personal cashier orders.
 */
export function isWooCommerceWebsiteOrder(order: Order): boolean {
  if (order.source === 'website') return true;
  if (order.source === 'pos') return false;

  // Fallback for legacy or synced orders without explicit source field:
  // If order has a WooCommerce ID and was not an in-store / walk-in POS order
  return Boolean(
    order.wooId &&
    order.shippingMethod !== 'in-store' &&
    order.shippingMethod !== 'walk-in'
  );
}

/**
 * Resolves the creator's unique account ID for an order.
 * Strictly uses unique user account ID (order.createdByUserId or order.attendedByUserId).
 */
export function getOrderCreatorId(order: Order): number | null {
  if (order.createdByUserId !== undefined && order.createdByUserId !== null) {
    const num = Number(order.createdByUserId);
    return isNaN(num) ? null : num;
  }
  if (order.attendedByUserId !== undefined && order.attendedByUserId !== null) {
    const num = Number(order.attendedByUserId);
    return isNaN(num) ? null : num;
  }
  return null;
}

/**
 * Authoritative Order Accessibility and Permission Evaluator.
 *
 * CORE RULES:
 * 1. POS On-Hold orders are STRICTLY PRIVATE to the user who created them (creatorId === user.id).
 *    Role DOES NOT override ownership for On-Hold POS orders. Neither Admins nor Shop Managers
 *    have access to other staff members' On-Hold POS orders.
 * 2. Completed POS sales follow role permissions:
 *    - Admin & Shop Manager (canViewAllOrders = true): Can see all completed POS sales across all staff.
 *    - Cashier (canViewAllOrders = false): Can only see their own completed POS sales.
 * 3. WooCommerce website orders are shared business orders accessible to all authenticated users
 *    who have permission to access orders (canAccessOrders = true).
 */
export function isOrderAccessibleToUser(order: Order, user: AuthUser | null): boolean {
  if (!user) return false;

  // 1. User must have general orders access
  if (!user.permissions?.canAccessOrders) {
    return false;
  }

  // 2. WooCommerce website orders are shared across all authorized staff
  if (isWooCommerceWebsiteOrder(order)) {
    return true;
  }

  // 3. Resolve creator ID
  const creatorId = getOrderCreatorId(order);

  // 4. POS On-Hold orders (and pending unfinished orders):
  // STRICTLY PRIVATE to the creating user. Zero role-based overrides.
  const isHoldOrUnfinished = order.status === 'on-hold' || order.status === 'pending';
  if (isHoldOrUnfinished) {
    return creatorId !== null && creatorId === user.id;
  }

  // 5. Completed POS sales and sales history:
  // Admin & Shop Manager see all completed sales; Cashiers see only their own completed sales.
  if (user.permissions.canViewAllOrders) {
    return true;
  }

  return creatorId !== null && creatorId === user.id;
}
