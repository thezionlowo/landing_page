import type { Customer, Order } from '@/types';

export function customerEmail(value: unknown): string {
  const email = typeof value === 'string' ? value.trim().toLowerCase() : '';
  return email.endsWith('@store.local') ? '' : email;
}

export function customerIndex(customers: Customer[]) {
  const byId = new Map(customers.map(c => [c.id, c]));
  const byWooId = new Map(customers.filter(c => c.wooId).map(c => [Number(c.wooId), c]));
  const byEmail = new Map<string, Customer | null>();
  const byGuestEmail = new Map<string, Customer | null>();
  const byPurchaserKey = new Map(customers.filter(c => c.purchaserKey).map(c => [c.purchaserKey!, c]));
  for (const c of customers) {
    const email = customerEmail(c.email);
    if (email && c.profileType !== 'guest') byEmail.set(email, byEmail.has(email) ? null : c);
    if (email && c.profileType === 'guest') byGuestEmail.set(email, byGuestEmail.has(email) ? null : c);
  }
  return { byId, byWooId, byEmail, byGuestEmail, byPurchaserKey };
}

/** A registered customer's ID wins over a historical billing email. Email only
 * identifies guest orders; ambiguous shared addresses never establish ownership. */
export function resolveOrderCustomer(
  order: Pick<Order, 'wooCustomerId' | 'customerEmail' | 'customerId' | 'customerName' | 'purchaserKey'> & Partial<Pick<Order, 'wooId'>>,
  index: ReturnType<typeof customerIndex>,
): number | null {
  if (order.wooCustomerId && order.wooCustomerId > 0) {
    return index.byWooId.get(Number(order.wooCustomerId))?.id ?? null;
  }
  const email = customerEmail(order.customerEmail);
  const account = email ? index.byEmail.get(email) : undefined;
  if (account) return account.id;
  if (email && index.byGuestEmail.has(email)) return index.byGuestEmail.get(email)?.id ?? null;
  if (email && index.byEmail.has(email)) return null;
  const assigned = order.customerId ? index.byId.get(order.customerId) : undefined;
  if (assigned?.profileType === 'guest' && assigned.guestOrderId === order.wooId && order.wooId) return assigned.id;
  if (!assigned || order.customerName === 'Walk-in Customer') return null;
  if (email && customerEmail(assigned.email) !== email) return null;
  return assigned.id;
}

export function customerOrderStats(customer: Customer, orders: Order[]) {
  const purchases = orders.filter(o => o.status !== 'refunded' && (o.purchaseConfirmed || o.status === 'completed' || o.status === 'processing'));
  // Refunded purchases still establish a real purchase history; held, pending,
  // failed and cancelled orders alone never turn a registration into a buyer.
  const purchasedOrders = orders.filter(o => o.purchaseConfirmed || ['completed', 'processing', 'refunded'].includes(o.status));
  const remotePurchases = Number.isSafeInteger(customer.purchasesCount) && customer.purchasesCount! > 0 ? customer.purchasesCount! : 0;
  const verifiedHistory = Boolean(customer.orderHistorySyncedAt) && Array.isArray(customer.historyOrderIds);
  const purchaseCount = verifiedHistory ? purchasedOrders.length : Math.max(remotePurchases, purchasedOrders.length);
  const historyComplete = verifiedHistory || (Boolean(customer.orderHistorySyncedAt) && purchasedOrders.length >= remotePurchases);
  const localSpent = purchases.reduce((sum, o) => sum + (Number.isFinite(o.netTotal) ? o.netTotal! : Number.isFinite(o.total) ? o.total : 0), 0);
  const totalSpent = historyComplete ? localSpent : Math.max(customer.totalSpent || 0, localSpent);
  const paidCount = historyComplete ? purchases.length : Math.max(customer.ordersCount || 0, purchases.length);
  return {
    totalSpent,
    purchaseCount,
    orderCount: historyComplete ? orders.length : Math.max(customer.ordersCount || 0, orders.length, purchaseCount),
    averageOrderValue: paidCount ? Math.round(totalSpent / paidCount) : 0,
    lastOrderDate: orders.map(o => o.createdAt).filter(d => Number.isFinite(Date.parse(d)))
      .sort((a, b) => Date.parse(b) - Date.parse(a))[0] ?? null,
  };
}
