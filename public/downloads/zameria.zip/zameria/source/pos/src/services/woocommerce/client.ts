import type { PaginatedResponse } from '@/types';
import { restUrl } from '@/services/zameria/config';
import { TOKEN_HEADER } from '@/services/zameria/api';

export interface WooCommerceConfig {
  /** Store home URL; used as a key for per-store settings such as the receipt logo. */
  url: string;
  /** WordPress REST root, e.g. https://shop.com/wp-json/ */
  restRoot: string;
  /** Device token from the Zameria plugin sign-in. Requests run as the signed-in staff member. */
  token: string;
}

export class WooCommerceApiError extends Error {
  public isBrandError: boolean;
  public paramErrors: Record<string, string>;

  constructor(
    message: string,
    public status: number,
    public code: string,
    public data?: unknown
  ) {
    super(message);
    this.name = 'WooCommerceApiError';

    this.paramErrors = {};
    const d = data as any;
    if (d?.data?.params && typeof d.data.params === 'object') {
      for (const [k, v] of Object.entries(d.data.params)) {
        this.paramErrors[k] = String(v);
      }
    } else if (d?.data?.details && typeof d.data.details === 'object') {
      for (const [k, v] of Object.entries(d.data.details)) {
        this.paramErrors[k] = (v as any)?.message || String(v);
      }
    }

    const fullText = `${message} ${code} ${JSON.stringify(data || '')}`.toLowerCase();
    this.isBrandError = fullText.includes('brand');
  }
}

/**
 * WooCommerce REST API Client
 *
 * Isolated abstraction layer. All WooCommerce API calls go through this client.
 * Authenticates with the Zameria device token, so WordPress enforces the signed-in staff
 * member's real permissions and no store-wide API keys are kept on the device.
 */
export class WooCommerceClient {
  private abortController: AbortController | null = null;

  constructor(private config: WooCommerceConfig) {}

  private url(route: string): string {
    return restUrl(this.config.restRoot, route);
  }

  private async request<T>(
    endpoint: string,
    options: RequestInit = {},
    parseHeaders = false
  ): Promise<{ data: T; totalItems?: number; totalPages?: number }> {
    this.abortController = new AbortController();
    const controller = this.abortController;
    const timeout = setTimeout(() => controller.abort(), 30_000);
    try {
    const [path, query] = endpoint.split('?');
    const url = new URL(this.url(`wc/v3${path}`));
    new URLSearchParams(query ?? '').forEach((value, key) => url.searchParams.set(key, value));
    const response = await fetch(url.toString(), {
      ...options,
      signal: controller.signal,
      cache: 'no-store',
      credentials: 'omit',
      headers: {
        'Content-Type': 'application/json',
        ...(this.config.token
          ? {
              [TOKEN_HEADER]: this.config.token,
            }
          : {}),
        ...options.headers,
      },
    });

    if (!response.ok) {
      let errorData: unknown;
      try {
        errorData = await response.json();
      } catch {
        errorData = null;
      }

      const dataObj = errorData as any;
      let detailedMessage = '';
      if (dataObj?.data?.params && typeof dataObj.data.params === 'object') {
        const paramMsgs = Object.entries(dataObj.data.params)
          .map(([k, v]) => `${k}: ${v}`)
          .join('; ');
        if (paramMsgs) detailedMessage = paramMsgs;
      } else if (dataObj?.data?.details && typeof dataObj.data.details === 'object') {
        const detailMsgs = Object.entries(dataObj.data.details)
          .map(([k, v]: [string, any]) => `${k}: ${v?.message || JSON.stringify(v)}`)
          .join('; ');
        if (detailMsgs) detailedMessage = detailMsgs;
      }

      let rawMessage = dataObj?.message || response.statusText || 'WooCommerce API Error';
      // Strip HTML tags if present (e.g. from WordPress error notices)
      rawMessage = rawMessage.replace(/<[^>]+>/g, '').trim();

      const errorMessage = detailedMessage && !rawMessage.includes(detailedMessage)
        ? `${rawMessage} (${detailedMessage})`
        : rawMessage;
      const errorCode = dataObj?.code || 'unknown_error';

      throw new WooCommerceApiError(
        errorMessage,
        response.status,
        errorCode,
        errorData
      );
    }

    const data = await response.json() as T;

    if (parseHeaders) {
      return {
        data,
        totalItems: response.headers.has('X-WP-Total') ? parseInt(response.headers.get('X-WP-Total')!, 10) : undefined,
        totalPages: response.headers.has('X-WP-TotalPages') ? parseInt(response.headers.get('X-WP-TotalPages')!, 10) : undefined,
      };
    }

    return { data };
    } finally { clearTimeout(timeout); }
  }

  async get<T>(endpoint: string, params?: Record<string, string | number>): Promise<{ data: T; totalItems?: number; totalPages?: number }> {
    let url = endpoint;
    if (params) {
      const searchParams = new URLSearchParams();
      Object.entries(params).forEach(([key, value]) => {
        searchParams.set(key, String(value));
      });
      url += `?${searchParams.toString()}`;
    }
    return this.request<T>(url, { method: 'GET' }, true);
  }

  async post<T>(endpoint: string, body: unknown): Promise<{ data: T }> {
    return this.request<T>(endpoint, {
      method: 'POST',
      body: JSON.stringify(body),
    });
  }

  async put<T>(endpoint: string, body: unknown): Promise<{ data: T }> {
    return this.request<T>(endpoint, {
      method: 'PUT',
      body: JSON.stringify(body),
    });
  }

  async delete<T>(endpoint: string): Promise<{ data: T }> {
    return this.request<T>(endpoint, { method: 'DELETE' });
  }

  /**
   * Upload an image file to the WordPress media library.
   * Endpoint: /wp-json/wp/v2/media
   */
  async uploadMedia(file: File): Promise<{ id: number; src: string; name: string }> {
    const response = await fetch(this.url('wp/v2/media'), {
      method: 'POST',
      credentials: 'omit',
      headers: {
        [TOKEN_HEADER]: this.config.token,
        'Content-Disposition': `attachment; filename="${encodeURIComponent(file.name)}"`,
        'Content-Type': file.type || 'image/jpeg',
      },
      body: file,
    });

    if (!response.ok) {
      let errData: any = null;
      try {
        errData = await response.json();
      } catch {}
      throw new WooCommerceApiError(
        errData?.message || `Media upload failed (${response.statusText})`,
        response.status,
        errData?.code || 'media_upload_failed',
        errData
      );
    }

    const data = await response.json();
    return {
      id: Number(data.id),
      src: data.source_url || data.guid?.rendered || '',
      name: file.name,
    };
  }

  /**
   * Fetch all items from a paginated endpoint.
   */
  async fetchAll<T>(
    endpoint: string,
    params: Record<string, string | number> = {},
    onProgress?: (current: number, total: number) => void
  ): Promise<T[]> {
    const perPage = 100;
    const allItems: T[] = [];

    // First request to get total
    const first = await this.get<T[]>(endpoint, { ...params, per_page: perPage, page: 1 });
    allItems.push(...first.data);

    const totalPages = first.totalPages || 1;
    onProgress?.(1, totalPages);

    // Fetch remaining pages
    for (let page = 2; page <= totalPages; page++) {
      const result = await this.get<T[]>(endpoint, { ...params, per_page: perPage, page });
      allItems.push(...result.data);
      onProgress?.(page, totalPages);
    }

    return allItems;
  }

  /**
   * Fetch a single page of results.
   */
  async fetchPage<T>(
    endpoint: string,
    page: number,
    perPage: number = 20,
    params: Record<string, string | number> = {}
  ): Promise<PaginatedResponse<T>> {
    const result = await this.get<T[]>(endpoint, { ...params, per_page: perPage, page });
    return {
      data: result.data,
      totalItems: result.totalItems || 0,
      totalPages: result.totalPages || 0,
      currentPage: page,
    };
  }

  abort(): void {
    this.abortController?.abort();
  }

  getConfig(): WooCommerceConfig {
    return { ...this.config };
  }
}

// Singleton client instance — set when a staff member signs in
let clientInstance: WooCommerceClient | null = null;

export function setWooClient(configOrClient: WooCommerceConfig | WooCommerceClient | any): WooCommerceClient {
  if (configOrClient instanceof WooCommerceClient || typeof configOrClient?.get === 'function' || typeof configOrClient?.post === 'function') {
    clientInstance = configOrClient as WooCommerceClient;
  } else {
    clientInstance = new WooCommerceClient(configOrClient);
  }
  return clientInstance;
}

export function getWooClient(): WooCommerceClient | null {
  return clientInstance;
}

export function clearWooClient(): void {
  clientInstance?.abort();
  clientInstance = null;
}
