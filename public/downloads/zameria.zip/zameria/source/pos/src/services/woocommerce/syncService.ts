import { syncEngine } from './syncEngine';
import type { SyncSummary } from '@/types';

export interface SyncResult {
  success: boolean;
  ordersUpdated: number;
  newOrdersAdded: number;
  productsSynced?: number;
  error?: string;
  syncedAt: string;
}

/**
 * Backward-compatible wrapper delegating to the centralized SyncEngine.
 */
export async function syncWooCommerce(): Promise<SyncResult> {
  const now = new Date().toISOString();

  try {
    const summary: SyncSummary = await syncEngine.sync({ scope: 'full' });

    const ordersRes = summary.entities.orders;
    const productsRes = summary.entities.products;

    return {
      success: summary.status === 'success' || summary.status === 'partial',
      ordersUpdated: ordersRes?.updatedCount || 0,
      newOrdersAdded: ordersRes?.importedCount || 0,
      productsSynced: (productsRes?.importedCount || 0) + (productsRes?.updatedCount || 0),
      syncedAt: summary.completedAt || now,
      error: summary.error,
    };
  } catch (err: any) {
    return {
      success: false,
      ordersUpdated: 0,
      newOrdersAdded: 0,
      syncedAt: now,
      error: err?.message || 'Sync failed. Please check network connection.',
    };
  }
}
