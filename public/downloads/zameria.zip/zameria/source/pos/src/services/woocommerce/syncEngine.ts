import { useSyncStore } from '@/store/syncStore';
import { useConnectionStore } from '@/store/connectionStore';
import { useAuthStore } from '@/store/authStore';
import { assertAuthorized } from '@/services/auth';
import { syncAllCategories } from './categoryService';
import { syncAllBrands } from './brandService';
import { syncAllProducts, syncInventoryStock } from './productService';
import { syncAllOrders, pushPendingOrders } from './orderSyncService';
import { syncAllCustomers } from './customerService';
import { syncAllCoupons } from './couponService';
import { historicalSyncService } from './historicalSyncService';
import { pullChanges } from '@/services/zameria/catalog';
import { sessionToken } from '@/services/zameria/session';
import type {
  SyncScope,
  SyncEntity,
  SyncSummary,
  SyncEntityResult,
} from '@/types';

export interface SyncOptions {
  scope: SyncScope;
  forceFull?: boolean;
  onProgress?: (entity: string, current: number, total: number) => void;
}

export class SyncEngine {
  private isRunning = false;

  /**
   * Evaluates role-based authorization for the requested sync scope.
   */
  private checkScopeAuthorization(scope: SyncScope): void {
    const role = useAuthStore.getState().user?.role || 'restricted';

    if (role === 'restricted') {
      assertAuthorized('canAccessSettings', 'Restricted staff cannot trigger synchronization.');
    }

    if (scope === 'full' && role === 'cashier') {
      assertAuthorized('canManageWooConnection', 'Cashiers cannot trigger a full store resync.');
    }
  }

  /**
   * Central entrypoint for all synchronization across the entire Zameria application.
   */
  async sync(options: SyncOptions): Promise<SyncSummary> {
    const { scope, forceFull = false, onProgress } = options;
    const syncStore = useSyncStore.getState();
    const connectionStore = useConnectionStore.getState();

    // 1. Offline Detection
    const isBrowserOnline = typeof navigator !== 'undefined' && typeof navigator.onLine === 'boolean'
      ? navigator.onLine
      : true;
    const isOnline = isBrowserOnline || connectionStore.isOnline;
    if (!isOnline) {
      const offlineMsg = "You're offline. Sync requires an internet connection to reach your WooCommerce store.";
      syncStore.setSyncError(offlineMsg);
      throw new Error(offlineMsg);
    }

    // 2. Prevent concurrent runs
    if (this.isRunning) {
      throw new Error('A synchronization operation is already in progress.');
    }

    // 3. RBAC Authorization check
    this.checkScopeAuthorization(scope);

    this.isRunning = true;
    syncStore.startScopeSync(scope);
    const startTime = Date.now();
    const startedAt = new Date().toISOString();

    const entities: Partial<Record<SyncEntity, SyncEntityResult>> = {};
    let totalImported = 0;
    let totalUpdated = 0;
    let totalFailed = 0;
    const errors: string[] = [];

    const recordResult = (res: SyncEntityResult) => {
      entities[res.entity] = res;
      totalImported += res.importedCount;
      totalUpdated += res.updatedCount;
      totalFailed += res.failedCount;

      if (res.failedCount > 0) {
        errors.push(...res.errors);
        syncStore.addFailedItem({
          entity: res.entity,
          operation: 'fetch',
          error: res.errors.join('; ') || `Failed syncing ${res.entity}`,
        });
      } else {
        syncStore.recordEntitySyncSuccess(res.entity);
      }
    };

    try {
      const getModifiedAfter = (entity: SyncEntity): string | null => {
        if (forceFull) return null;
        return syncStore.lastSyncedByEntity[entity] || null;
      };

      // 4. Scope Execution Pipeline
      switch (scope) {
        case 'full': {
          // Full reconciliation across all domains. This is the path a merchant asks
          // for from the Sync button or Settings — never the per-minute till loop,
          // which stays on the cursor-based catalogue feed in posSync.ts so a large
          // store's order history cannot block selling.
          const deviceToken = sessionToken();
          if (deviceToken) {
            syncStore.updateEntityProgress('orders', 0, 5, 'Uploading pending sales...');
            await pushPendingOrders();
            syncStore.updateEntityProgress('products', 1, 5, 'Refreshing changed catalogue items...');
            const changed = forceFull ? await syncAllProducts({ incremental: false }) : await pullChanges(deviceToken);
            recordResult({
              entity: 'products',
              importedCount: 'importedCount' in changed ? Number(changed.importedCount) : 0,
              updatedCount: changed.updatedCount,
              failedCount: 0,
              errors: [],
            });

            syncStore.updateEntityProgress('categories', 2, 5, 'Syncing categories...');
            const catRes = await syncAllCategories();
            await syncAllBrands();
            recordResult({
              entity: 'categories',
              importedCount: catRes.importedCount,
              updatedCount: catRes.updatedCount,
              failedCount: 0,
              errors: [],
            });

            syncStore.updateEntityProgress('customers', 3, 5, 'Syncing customers...');
            const custRes = await syncAllCustomers({
              incremental: !forceFull,
              modifiedAfter: getModifiedAfter('customers'),
              onProgress: (cur, tot) => {
                syncStore.updateEntityProgress('customers', cur, tot);
                onProgress?.('customers', cur, tot);
              },
            });
            recordResult(custRes);

            syncStore.updateEntityProgress('orders', 4, 5, 'Syncing orders...');
            const ordRes = await syncAllOrders({
              incremental: !forceFull,
              modifiedAfter: getModifiedAfter('orders'),
              allPages: forceFull,
              onProgress: (cur, tot) => {
                syncStore.updateEntityProgress('orders', cur, tot);
                onProgress?.('orders', cur, tot);
              },
            });
            recordResult(ordRes);

            syncStore.updateEntityProgress('coupons', 5, 5, 'Syncing coupons...');
            const coupRes = await syncAllCoupons({
              onProgress: (cur, tot) => {
                syncStore.updateEntityProgress('coupons', cur, tot);
                onProgress?.('coupons', cur, tot);
              },
            });
            recordResult(coupRes);
            // Launch Layer 2 background progressive historical sync
            void historicalSyncService.startHistoricalSync({ force: forceFull });
            break;
          }

          // Sequential full synchronization across all domains
          syncStore.updateEntityProgress('categories', 0, 1, 'Syncing categories...');
          const catRes = await syncAllCategories();
          await syncAllBrands();
          recordResult({
            entity: 'categories',
            importedCount: catRes.importedCount,
            updatedCount: catRes.updatedCount,
            failedCount: 0,
            errors: [],
          });

          syncStore.updateEntityProgress('products', 0, 1, 'Syncing products...');
          const prodRes = await syncAllProducts({
            incremental: !forceFull,
            modifiedAfter: getModifiedAfter('products'),
            onProgress: (cur, tot) => {
              syncStore.updateEntityProgress('products', cur, tot, `Products page ${cur} of ${tot}`);
              onProgress?.('products', cur, tot);
            },
          });
          recordResult(prodRes);

          syncStore.updateEntityProgress('inventory', 0, 1, 'Syncing inventory stock...');
          const invRes = await syncInventoryStock({
            onProgress: (cur, tot) => {
              syncStore.updateEntityProgress('inventory', cur, tot);
              onProgress?.('inventory', cur, tot);
            },
          });
          recordResult(invRes);

          syncStore.updateEntityProgress('customers', 0, 1, 'Syncing customers...');
          const custRes = await syncAllCustomers({
            incremental: !forceFull,
            modifiedAfter: getModifiedAfter('customers'),
            onProgress: (cur, tot) => {
              syncStore.updateEntityProgress('customers', cur, tot);
              onProgress?.('customers', cur, tot);
            },
          });
          recordResult(custRes);

          syncStore.updateEntityProgress('orders', 0, 1, 'Syncing orders...');
          const ordRes = await syncAllOrders({
            incremental: !forceFull,
            modifiedAfter: getModifiedAfter('orders'),
            onProgress: (cur, tot) => {
              syncStore.updateEntityProgress('orders', cur, tot);
              onProgress?.('orders', cur, tot);
            },
          });
          recordResult(ordRes);

          syncStore.updateEntityProgress('coupons', 0, 1, 'Syncing coupons...');
          const coupRes = await syncAllCoupons({
            onProgress: (cur, tot) => {
              syncStore.updateEntityProgress('coupons', cur, tot);
              onProgress?.('coupons', cur, tot);
            },
          });
          recordResult(coupRes);
          // Launch Layer 2 background progressive historical sync
          void historicalSyncService.startHistoricalSync({ force: forceFull });
          break;
        }

        case 'products': {
          syncStore.updateEntityProgress('categories', 0, 1, 'Syncing categories...');
          await syncAllCategories();
          await syncAllBrands();

          syncStore.updateEntityProgress('products', 0, 1, 'Syncing products...');
          const prodRes = await syncAllProducts({
            incremental: !forceFull,
            modifiedAfter: getModifiedAfter('products'),
            onProgress: (cur, tot) => {
              syncStore.updateEntityProgress('products', cur, tot);
              onProgress?.('products', cur, tot);
            },
          });
          recordResult(prodRes);
          break;
        }

        case 'inventory': {
          syncStore.updateEntityProgress('orders', 0, 1, 'Uploading sales...');
          await pushPendingOrders();
          syncStore.updateEntityProgress('inventory', 0, 1, 'Syncing inventory...');
          const invRes = await syncInventoryStock({
            onProgress: (cur, tot) => {
              syncStore.updateEntityProgress('inventory', cur, tot);
              onProgress?.('inventory', cur, tot);
            },
          });
          recordResult(invRes);
          break;
        }

        case 'orders': {
          syncStore.updateEntityProgress('orders', 0, 1, 'Syncing orders...');
          const ordRes = await syncAllOrders({
            incremental: !forceFull,
            modifiedAfter: getModifiedAfter('orders'),
            onProgress: (cur, tot) => {
              syncStore.updateEntityProgress('orders', cur, tot);
              onProgress?.('orders', cur, tot);
            },
          });
          recordResult(ordRes);
          break;
        }

        case 'customers': {
          syncStore.updateEntityProgress('customers', 0, 1, 'Syncing customers...');
          const custRes = await syncAllCustomers({
            incremental: !forceFull,
            modifiedAfter: getModifiedAfter('customers'),
            onProgress: (cur, tot) => {
              syncStore.updateEntityProgress('customers', cur, tot);
              onProgress?.('customers', cur, tot);
            },
          });
          recordResult(custRes);
          const history = await historicalSyncService.startHistoricalSync({ force: forceFull });
          if (history.status === 'error') recordResult({ entity: 'orders', importedCount: 0, updatedCount: 0, failedCount: 1, errors: [history.error || 'History import interrupted'] });
          break;
        }

        case 'coupons': {
          syncStore.updateEntityProgress('coupons', 0, 1, 'Syncing coupons...');
          const coupRes = await syncAllCoupons({
            onProgress: (cur, tot) => {
              syncStore.updateEntityProgress('coupons', cur, tot);
              onProgress?.('coupons', cur, tot);
            },
          });
          recordResult(coupRes);
          break;
        }

        case 'pos': {
          // POS-specific scope: Refreshes catalogue, stock, categories, customers, and coupons
          // WITHOUT resetting active cart, customer, coupon, or split payments.
          // Upload waiting sales first so the stock pulled next already includes them.
          syncStore.updateEntityProgress('orders', 0, 1, 'Uploading sales...');
          await pushPendingOrders();

          const deviceToken = sessionToken();
          if (deviceToken) {
            syncStore.updateEntityProgress('products', 0, 1, 'Refreshing catalogue delta...');
            const changed = forceFull ? await syncAllProducts({ incremental: false }) : await pullChanges(deviceToken);
            recordResult({
              entity: 'products',
              importedCount: 'importedCount' in changed ? Number(changed.importedCount) : 0,
              updatedCount: changed.updatedCount,
              failedCount: 0,
              errors: [],
            });
          } else {
            syncStore.updateEntityProgress('products', 0, 1, 'Refreshing catalogue...');
            await syncAllCategories();
            const pRes = await syncAllProducts({
              incremental: !forceFull,
              modifiedAfter: getModifiedAfter('products'),
            });
            recordResult(pRes);
          }

          const iRes = await syncInventoryStock();
          recordResult(iRes);

          syncStore.updateEntityProgress('customers', 0, 1, 'Refreshing customers...');
          const custRes = await syncAllCustomers({
            incremental: !forceFull,
            modifiedAfter: getModifiedAfter('customers'),
          });
          recordResult(custRes);

          const cRes = await syncAllCoupons();
          recordResult(cRes);
          break;
        }

        case 'dashboard': {
          // Dashboard scope: Orders, sales, inventory, and customers for live metrics
          syncStore.updateEntityProgress('orders', 0, 1, 'Syncing orders for dashboard...');
          const oRes = await syncAllOrders({
            incremental: !forceFull,
            modifiedAfter: getModifiedAfter('orders'),
          });
          recordResult(oRes);

          const iRes = await syncInventoryStock();
          recordResult(iRes);

          const cRes = await syncAllCustomers({
            incremental: !forceFull,
            modifiedAfter: getModifiedAfter('customers'),
          });
          recordResult(cRes);
          break;
        }
      }

      const completedAt = new Date().toISOString();
      const durationMs = Date.now() - startTime;
      const status: SyncSummary['status'] =
        totalFailed === 0
          ? 'success'
          : totalImported + totalUpdated > 0
          ? 'partial'
          : 'failed';

      const summary: SyncSummary = {
        scope,
        status,
        startedAt,
        completedAt,
        durationMs,
        entities,
        totalImported,
        totalUpdated,
        totalFailed,
        error: errors.length > 0 ? errors[0] : undefined,
      };

      syncStore.finishScopeSync(summary);
      connectionStore.setLastSynced(completedAt);
      return summary;
    } catch (err: any) {
      const errorMsg = err?.message || 'Sync failed due to an unexpected error.';
      syncStore.setSyncError(errorMsg);
      throw err;
    } finally {
      this.isRunning = false;
    }
  }

  /**
   * Retries previously failed synchronization items.
   */
  async retryFailed(): Promise<SyncSummary> {
    return this.sync({ scope: 'full', forceFull: false });
  }
}

// Export singleton instance
export const syncEngine = new SyncEngine();

/**
 * Convenience helper function matching the central sync specification:
 * sync({ scope: 'products' })
 */
export function sync(options: SyncOptions): Promise<SyncSummary> {
  return syncEngine.sync(options);
}
