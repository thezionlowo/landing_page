/**
 * ZAMERIA Thermal Receipt Printing Service
 * 
 * Standard POS thermal printing engine:
 * - Emulates standard continuous thermal roll printing (80mm default, 58mm option).
 * - Eliminates multi-page / 22-page bloat by completely detaching POS application shell
 *   from the print layout tree.
 * - Uses valid W3C @page syntax without invalid !important declarations, ensuring
 *   Chromium, WebKit, and Gecko format the print preview at the intended thermal roll size.
 * - Sized specifically for 80mm thermal receipt printers (25–35mm logo, 4mm padding, compact footer).
 * - Enforces crisp pure black text (#000000) and sharp thermal borders.
 */

export type ThermalPaperWidth = '80mm' | '58mm';

export interface ReceiptPrintConfig {
  paperWidth: ThermalPaperWidth;
  logoWidthMm: number;
  logoMaxWidthMm: number;
  paddingLeftMm: number;
  paddingRightMm: number;
  paddingTopMm: number;
  paddingBottomMm: number;
  fontSize: string;
  lineHeight: string;
}

export const RECEIPT_CONFIGS: Record<ThermalPaperWidth, ReceiptPrintConfig> = {
  '80mm': {
    paperWidth: '80mm',
    logoWidthMm: 28,      // 25–35mm target range on 80mm roll
    logoMaxWidthMm: 32,
    paddingLeftMm: 4,      // 3–5mm horizontal padding
    paddingRightMm: 4,
    paddingTopMm: 2,
    paddingBottomMm: 2.5,  // Compact ending immediately after footer
    fontSize: '11px',
    lineHeight: '1.3',
  },
  '58mm': {
    paperWidth: '58mm',
    logoWidthMm: 22,
    logoMaxWidthMm: 24,
    paddingLeftMm: 3,
    paddingRightMm: 3,
    paddingTopMm: 2,
    paddingBottomMm: 2.5,
    fontSize: '9.5px',
    lineHeight: '1.25',
  },
};

const STORAGE_KEY_PAPER_WIDTH = 'zameria_receipt_paper_width';

export function getReceiptPaperWidth(): ThermalPaperWidth {
  try {
    if (typeof localStorage !== 'undefined') {
      const stored = localStorage.getItem(STORAGE_KEY_PAPER_WIDTH);
      if (stored === '58mm' || stored === '80mm') {
        return stored;
      }
    }
  } catch {}
  return '80mm';
}

export function setReceiptPaperWidth(width: ThermalPaperWidth): void {
  try {
    if (typeof localStorage !== 'undefined') {
      localStorage.setItem(STORAGE_KEY_PAPER_WIDTH, width);
    }
  } catch {}
}

/**
 * Builds the thermal print CSS for the given roll width.
 * Note: CSS Paged Media Module Level 3 strictly forbids '!important' inside @page rules.
 * Any declaration with '!important' in @page is discarded as invalid by browser engines,
 * which was the root cause of the previous A4 fallback!
 */
export function buildThermalPrintCss(config: ReceiptPrintConfig): string {
  const { paperWidth, logoWidthMm, logoMaxWidthMm, paddingLeftMm, paddingRightMm, paddingTopMm, paddingBottomMm, fontSize, lineHeight } = config;
  return `
    /* Top-level and media-scoped @page rules for cross-browser thermal roll support */
    @page {
      size: ${paperWidth} auto;
      margin: 0;
    }

    @media print {
      @page {
        size: ${paperWidth} auto;
        margin: 0;
      }

      html, body {
        width: ${paperWidth} !important;
        max-width: ${paperWidth} !important;
        height: auto !important;
        min-height: 0 !important;
        margin: 0 !important;
        padding: 0 !important;
        background: #ffffff !important;
        color: #000000 !important;
        overflow: visible !important;
        -webkit-print-color-adjust: exact !important;
        print-color-adjust: exact !important;
      }

      /* Isolate the receipt by hiding all application chrome */
      body > *:not(#zameria-print-container) {
        display: none !important;
      }

      #zameria-print-container {
        display: block !important;
        position: relative !important;
        width: ${paperWidth} !important;
        max-width: ${paperWidth} !important;
        box-sizing: border-box !important;
        padding: ${paddingTopMm}mm ${paddingRightMm}mm ${paddingBottomMm}mm ${paddingLeftMm}mm !important;
        margin: 0 auto !important;
        background: #ffffff !important;
        color: #000000 !important;
        font-family: monospace, ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, "Courier New", monospace !important;
        font-size: ${fontSize} !important;
        line-height: ${lineHeight} !important;
        overflow: visible !important;
      }

      #zameria-print-container * {
        box-sizing: border-box !important;
        color: #000000 !important;
        -webkit-text-fill-color: #000000 !important;
        text-shadow: none !important;
        background: transparent !important;
      }

      #zameria-print-container .border-dashed,
      #zameria-print-container .border-b,
      #zameria-print-container .border-t {
        border-color: #000000 !important;
      }

      /* Logo constraint: centered, aspect ratio preserved, 25-35mm width */
      #zameria-print-container img,
      #zameria-print-container .thermal-receipt-logo {
        width: ${logoWidthMm}mm !important;
        max-width: ${logoMaxWidthMm}mm !important;
        height: auto !important;
        object-fit: contain !important;
        margin: 0 auto 3px auto !important;
        display: block !important;
      }

      /* Text wrapping for long product names */
      #zameria-print-container .break-words {
        word-break: break-word !important;
        overflow-wrap: break-word !important;
      }

      /* Pagination controls */
      #zameria-print-container .thermal-avoid-break,
      #zameria-print-container [data-avoid-break="true"] {
        break-inside: avoid !important;
        page-break-inside: avoid !important;
      }
    }
  `;
}

/**
 * Triggers thermal printing by cloning the receipt element into an isolated
 * body-level print container, ensuring zero background POS DOM participates
 * in the print layout.
 */
export async function printThermalReceipt(
  receiptElement: HTMLElement | null,
  options?: { paperWidth?: ThermalPaperWidth }
): Promise<void> {
  if (!receiptElement || typeof window === 'undefined' || typeof document === 'undefined') {
    window?.print?.();
    return;
  }

  const paperWidth = options?.paperWidth || getReceiptPaperWidth();
  const config = RECEIPT_CONFIGS[paperWidth] || RECEIPT_CONFIGS['80mm'];

  // 1. Inject dynamic paper-width style rule matching active roll setting
  let dynamicStyle = document.getElementById('zameria-dynamic-print-style') as HTMLStyleElement | null;
  if (!dynamicStyle) {
    dynamicStyle = document.createElement('style');
    dynamicStyle.id = 'zameria-dynamic-print-style';
    document.head.appendChild(dynamicStyle);
  }
  dynamicStyle.textContent = buildThermalPrintCss(config);

  // 2. Locate or create dedicated print container on document.body
  let printContainer = document.getElementById('zameria-print-container');
  if (!printContainer) {
    printContainer = document.createElement('div');
    printContainer.id = 'zameria-print-container';
    document.body.appendChild(printContainer);
  }

  // 3. Clone receipt DOM into print container
  printContainer.innerHTML = '';
  const clone = receiptElement.cloneNode(true) as HTMLElement;
  clone.removeAttribute('id');
  clone.classList.remove('shadow-xs', 'border', 'rounded-xl', 'bg-surface');
  clone.classList.add('thermal-receipt-print-root');
  printContainer.appendChild(clone);
  printContainer.setAttribute('data-paper-width', paperWidth);

  // 4. Ensure all images/logos are decoded before opening print preview
  const images = Array.from(printContainer.querySelectorAll('img'));
  await Promise.all(
    images.map((img) => {
      if (img.complete && img.naturalWidth > 0) {
        return Promise.resolve();
      }
      return new Promise<void>((resolve) => {
        img.onload = () => resolve();
        img.onerror = () => resolve();
        setTimeout(resolve, 300);
      });
    })
  );

  // 5. Cooperative microtask yield to allow browser layout calculation
  await new Promise((resolve) => setTimeout(resolve, 50));

  // 6. Cleanup listener for afterprint
  const cleanup = () => {
    window.removeEventListener('afterprint', cleanup);
    if (printContainer && printContainer.parentNode) {
      printContainer.innerHTML = '';
    }
    if (dynamicStyle && dynamicStyle.parentNode) {
      dynamicStyle.remove();
    }
  };
  window.addEventListener('afterprint', cleanup);

  // 7. Invoke native browser print preview
  window.print();

  // Safety fallback cleanup
  setTimeout(cleanup, 3000);
}

// Global fallback listener: if user triggers print via shortcut (Cmd+P/Ctrl+P) while receipt is mounted
if (typeof window !== 'undefined') {
  window.addEventListener('beforeprint', () => {
    const printableReceipt = document.getElementById('printable-receipt');
    let printContainer = document.getElementById('zameria-print-container');
    if (printableReceipt && (!printContainer || printContainer.children.length === 0)) {
      if (!printContainer) {
        printContainer = document.createElement('div');
        printContainer.id = 'zameria-print-container';
        document.body.appendChild(printContainer);
      }
      const paperWidth = getReceiptPaperWidth();
      const config = RECEIPT_CONFIGS[paperWidth] || RECEIPT_CONFIGS['80mm'];
      let dynamicStyle = document.getElementById('zameria-dynamic-print-style') as HTMLStyleElement | null;
      if (!dynamicStyle) {
        dynamicStyle = document.createElement('style');
        dynamicStyle.id = 'zameria-dynamic-print-style';
        document.head.appendChild(dynamicStyle);
      }
      dynamicStyle.textContent = buildThermalPrintCss(config);
      printContainer.innerHTML = '';
      const clone = printableReceipt.cloneNode(true) as HTMLElement;
      clone.removeAttribute('id');
      clone.classList.remove('shadow-xs', 'border', 'rounded-xl', 'bg-surface');
      clone.classList.add('thermal-receipt-print-root');
      printContainer.appendChild(clone);
      printContainer.setAttribute('data-paper-width', paperWidth);
    }
  });
}
