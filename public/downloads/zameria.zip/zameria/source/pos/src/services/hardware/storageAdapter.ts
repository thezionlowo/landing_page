/**
 * ZAMERIA Hardware Storage Adapter
 * 
 * Provides safe storage access with quota handling and requests
 * browser persistent storage to safeguard IndexedDB against iOS WebKit
 * 7-day eviction.
 */

import type { IStorageService } from './types';

export class HardwareStorageAdapter implements IStorageService {
  constructor() {
    void this.ensurePersistentStorage();
  }

  public getItem(key: string): string | null {
    if (typeof localStorage === 'undefined') return null;
    try {
      return localStorage.getItem(key);
    } catch {
      return null;
    }
  }

  public setItem(key: string, value: string): void {
    if (typeof localStorage === 'undefined') return;
    try {
      localStorage.setItem(key, value);
    } catch (e) {
      console.warn(`[HardwareStorage] LocalStorage quota exceeded or restricted for key: ${key}`, e);
    }
  }

  public removeItem(key: string): void {
    if (typeof localStorage === 'undefined') return;
    try {
      localStorage.removeItem(key);
    } catch {}
  }

  public async ensurePersistentStorage(): Promise<boolean> {
    if (typeof navigator !== 'undefined' && navigator.storage && navigator.storage.persist) {
      try {
        const isPersisted = await navigator.storage.persisted();
        if (!isPersisted) {
          const granted = await navigator.storage.persist();
          return granted;
        }
        return true;
      } catch (err) {
        console.warn('[HardwareStorage] Storage persistence request notice:', err);
      }
    }
    return false;
  }
}

export const hardwareStorage = new HardwareStorageAdapter();
