import { sessionToken } from '@/services/zameria/session';
import { zameriaConfig } from '@/services/zameria/config';
import { useAuthStore } from '@/store/authStore';
const flights = new Map<string, Promise<unknown>>();
const full = new Set<string>();
let foreground = 0;
export function syncScope() {
 const user = useAuthStore.getState().user;
 return `${zameriaConfig.apiRoot}|${user?.id || 0}|${JSON.stringify(user?.permissions || {})}`;
}
export function singleFlight<T>(job: string, run: () => Promise<T>, requireFull = false): Promise<T> {
 const key = `${syncScope()}|${sessionToken() || ''}|${job}`;
 const current = flights.get(key);
 if(current && requireFull && !full.has(key)) return singleFlight(`${job}-full-upgrade`, async()=>{try{await current;}catch{}return singleFlight(job,run,true);});
 if (current) return current as Promise<T>;
 const next = Promise.resolve().then(run).finally(() => { if (flights.get(key) === next) { flights.delete(key);full.delete(key); } });
 if(requireFull)full.add(key);
 flights.set(key, next); return next;
}
export async function withForeground<T>(run:()=>Promise<T>):Promise<T>{foreground++;try{return await run();}finally{foreground--;}}
export async function yieldToUI(){
 do { await new Promise<void>(resolve=>setTimeout(resolve,foreground?50:16)); } while(foreground>0);
}
