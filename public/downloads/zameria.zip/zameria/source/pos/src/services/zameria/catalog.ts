import { db, getSetting, setSetting } from '@/db';
import { toKobo } from '@/lib';
import { syncAllCategories } from '@/services/woocommerce/categoryService';
import { syncAllBrands } from '@/services/woocommerce/brandService';
import { useSyncStore } from '@/store/syncStore';
import type { Product, ProductVariation, StockStatus, Brand } from '@/types';
import { zameriaApi, type PluginProduct, type PluginVariation } from './api';

/*
 * Product catalogue and stock, fed by the Zameria plugin:
 *   - First run: download every product (with variations) page by page.
 *   - After that: ask only for products changed since the last cursor, every sync.
 *
 * Stock shown at the till = stock on the server minus what this device has sold but not yet
 * uploaded. That keeps offline counts right, and a pull can never "undo" an offline sale.
 */

const CURSOR_KEY = 'zameria_changes_cursor';

export async function hasCatalogue(): Promise<boolean> {
  return (await getSetting(CURSOR_KEY)) !== undefined;
}

export async function resetCatalogueCursor(): Promise<void> {
  await db.settings.where('key').equals(CURSOR_KEY).delete();
}

/** Quantity sold on this device that the store hasn't counted yet, keyed by stock-owner id. */
export async function unsyncedQuantities(): Promise<Map<number, number>> {
  const orders = await db.orders
    .where('syncStatus')
    .anyOf('PENDING_SYNC', 'SYNC_ERROR')
    .filter((order) => order.status === 'completed' && !order.wooId)
    .toArray();
  const totals = new Map<number, number>();
  if (!orders.length) return totals;

  const items = await db.orderItems.where('orderId').anyOf(orders.map((o) => o.id)).toArray();
  for (const item of items) {
    const owner = item.stockOwnerWooId ?? item.wooVariationId ?? item.wooProductId;
    if (owner) totals.set(owner, (totals.get(owner) ?? 0) + item.quantity);
  }
  return totals;
}

function stockFor(
  source: PluginProduct | PluginVariation,
  unsynced: Map<number, number>
): { stockQuantity: number | null; stockStatus: StockStatus } {
  if (!source.manage_stock || source.stock_quantity === null) {
    return { stockQuantity: null, stockStatus: source.stock_status };
  }
  const quantity = source.stock_quantity - (unsynced.get(source.stock_owner_id) ?? 0);
  const stockStatus: StockStatus = quantity <= 0 && !source.backorders_allowed ? 'outofstock' : source.stock_status;
  return { stockQuantity: quantity, stockStatus };
}

function mapVariation(v: PluginVariation, unsynced: Map<number, number>): ProductVariation {
  return {
    id: v.id,
    wooId: v.id,
    sku: v.sku,
    barcode: v.barcode || undefined,
    price: toKobo(parseFloat(v.price) || 0),
    regularPrice: toKobo(parseFloat(v.regular_price || v.price) || 0),
    salePrice: v.sale_price ? toKobo(parseFloat(v.sale_price)) : null,
    manageStock: v.manage_stock,
    stockOwnerWooId: v.stock_owner_id,
    attributes: v.attributes,
    image: v.image ?? undefined,
    ...stockFor(v, unsynced),
  };
}

async function applyProducts(products: PluginProduct[]): Promise<void> {
  if (!products || !products.length) return;
  const unsynced = await unsyncedQuantities();
  const now = new Date().toISOString();

  // 1. Batch pre-fetch all referenced categories in one shot
  const allCatWooIds = Array.from(new Set(products.flatMap((p) => (Array.isArray(p.category_ids) ? p.category_ids : []))));
  const localCategories = allCatWooIds.length
    ? await db.categories.where('wooId').anyOf(allCatWooIds).toArray()
    : [];
  const catWooToLocalId = new Map<number, number>();
  for (const c of localCategories) {
    if (c.wooId) catWooToLocalId.set(c.wooId, c.id);
  }

  // 2. Batch pre-fetch all referenced brands in one shot
  const allBrandWooIds = Array.from(
    new Set(products.map((p) => p.brand?.id).filter(Boolean))
  ) as number[];
  const localBrands = allBrandWooIds.length
    ? await db.brands.where('wooId').anyOf(allBrandWooIds).toArray()
    : [];
  const brandWooMap = new Map<number, Brand>();
  for (const b of localBrands) {
    if (b.wooId) brandWooMap.set(b.wooId, b);
  }

  // 3. Batch pre-fetch all existing products in one shot
  const batchWooIds = products.map((p) => p?.id).filter(Boolean);
  const existingProducts = batchWooIds.length
    ? await db.products.where('wooId').anyOf(batchWooIds).toArray()
    : [];
  const existingProductMap = new Map<number, Product>();
  for (const ep of existingProducts) {
    if (ep.wooId) existingProductMap.set(ep.wooId, ep);
  }

  // 4. In-memory resolution and batch preparation
  const toAdd: Product[] = [];
  const toUpdate: { id: number; data: Partial<Product> }[] = [];

  await db.transaction('rw', [db.products, db.categories, db.brands], async () => {
    for (const pp of products) {
      if (!pp || !pp.id) continue;
      const stock = stockFor(pp, unsynced);
      const variations = Array.isArray(pp.variations) ? pp.variations.map((v) => mapVariation(v, unsynced)) : [];

      let brandId: number | null = null;
      let wooBrandId: number | null = null;
      let brandName: string | null = null;
      let brandObj: { id: number; name: string; slug: string; taxonomy?: string } | null = null;

      if (pp.brand) {
        wooBrandId = pp.brand.id;
        brandName = pp.brand.name;
        brandObj = {
          id: pp.brand.id,
          name: pp.brand.name,
          slug: pp.brand.slug || '',
          taxonomy: pp.brand.taxonomy || 'product_brand',
        };

        let localBrand = brandWooMap.get(pp.brand.id);
        if (localBrand) {
          brandId = localBrand.id;
          await db.brands.update(localBrand.id, {
            name: pp.brand.name,
            slug: pp.brand.slug,
            taxonomy: pp.brand.taxonomy || localBrand.taxonomy,
            syncStatus: 'SYNCED',
            lastSyncedAt: now,
          });
        } else {
          brandId = await db.brands.add({
            wooId: pp.brand.id,
            name: pp.brand.name,
            slug: pp.brand.slug || pp.brand.name.toLowerCase().replace(/\s+/g, '-'),
            taxonomy: pp.brand.taxonomy || 'product_brand',
            syncStatus: 'SYNCED',
            lastSyncedAt: now,
          } as any);
          brandWooMap.set(pp.brand.id, { id: brandId, wooId: pp.brand.id, name: pp.brand.name, slug: pp.brand.slug || '', taxonomy: pp.brand.taxonomy || 'product_brand', syncStatus: 'SYNCED', lastSyncedAt: now });
        }
      }

      const categoryIdsList = Array.isArray(pp.category_ids) ? pp.category_ids : [];
      const localCatIds = categoryIdsList
        .map((wooCatId) => catWooToLocalId.get(wooCatId))
        .filter((id): id is number => typeof id === 'number');

      const fields: Partial<Product> = {
        wooId: pp.id,
        name: pp.name || 'Untitled Product',
        slug: pp.slug || '',
        type: pp.type || 'simple',
        status: 'publish',
        description: pp.description || '',
        shortDescription: pp.short_description || '',
        sku: pp.sku || '',
        barcode: pp.barcode || undefined,
        gtin: pp.barcode || undefined,
        price: toKobo(parseFloat(pp.price) || 0),
        regularPrice: toKobo(parseFloat(pp.regular_price || pp.price) || 0),
        salePrice: pp.sale_price ? toKobo(parseFloat(pp.sale_price)) : null,
        onSale: Boolean(pp.on_sale),
        manageStock: Boolean(pp.manage_stock),
        stockOwnerWooId: pp.stock_owner_id ?? pp.id,
        ...stock,
        weight: pp.weight || '',
        dimensions: pp.dimensions || { length: '', width: '', height: '' },
        categoryIds: localCatIds,
        wooCategoryIds: categoryIdsList,
        brandId,
        wooBrandId,
        brandName,
        brand: brandObj,
        images: Array.isArray(pp.images) ? pp.images : [],
        attributes: Array.isArray(pp.attributes) ? pp.attributes : [],
        variations,
        syncStatus: 'SYNCED',
        lastSyncedAt: now,
        remoteVersion: pp.date_modified ?? now,
        updatedAt: now,
      };

      const existing = existingProductMap.get(pp.id);
      if (!existing) {
        toAdd.push({
          ...fields,
          costPrice: null,
          upc: '',
          ean: '',
          isbn: '',
          localVersion: 1,
          createdAt: pp.date_created ?? now,
        } as unknown as Product);
      } else if (existing.syncStatus === 'PENDING_SYNC') {
        // Unsaved cashier edit: preserve local modifications, update live server stock
        toUpdate.push({ id: existing.id, data: { ...stock, variations, lastSyncedAt: now } });
      } else {
        toUpdate.push({ id: existing.id, data: fields });
      }
    }

    if (toAdd.length > 0) {
      await db.products.bulkAdd(toAdd);
    }
    for (const item of toUpdate) {
      await db.products.update(item.id, item.data);
    }
  });
}

/** Products (or variations) that left the catalogue. History is kept: products become drafts. */
async function applyRemovals(ids: number[]): Promise<void> {
  if (!ids.length) return;
  const removed = new Set(ids);
  const now = new Date().toISOString();
  await db.transaction('rw', db.products, async () => {
    await db.products.where('wooId').anyOf(ids).modify({ status: 'draft', updatedAt: now });
    await db.products
      .filter((p) => Boolean(p.variations?.some((v) => removed.has(v.wooId))))
      .modify((p) => {
        p.variations = p.variations?.filter((v) => !removed.has(v.wooId));
      });
  });
}

/** Re-applies stock after sales are uploaded or cancelled, without a network call. */
export async function applyServerProducts(products: PluginProduct[]): Promise<void> {
  await applyProducts(products);
}

export async function downloadCatalogue(
  token: string,
  onProgress?: (current: number, total: number) => void
): Promise<{ importedCount: number }> {
  // Check if we already have published products in IndexedDB (e.g. from previous offline/online session)
  const existingCount = await db.products.where('status').equals('publish').count();
  if (existingCount > 0) {
    useSyncStore.getState().setSalesReady(true);
  }

  await syncAllCategories().catch((err) => console.warn('Categories sync skipped:', err));
  await syncAllBrands().catch((err) => console.warn('Brands sync skipped:', err));

  const seen = new Set<number>();
  let cursor = 0;
  let page = 1;
  let totalPages = 1;
  do {
    const result = await zameriaApi.products(token, page);
    if (page === 1) cursor = result.cursor ?? 0;
    totalPages = Math.max(result.total_pages, 1);
    const prodList = Array.isArray(result?.products) ? result.products : [];
    prodList.forEach((p) => {
      if (p?.id) seen.add(p.id);
    });
    await applyProducts(prodList);

    // PRIORITY 1: Make Sales ready as soon as critical products + stock are loaded!
    useSyncStore.getState().setSalesReady(true);

    onProgress?.(page, totalPages);
    page++;

    // Yield control to the browser microtask loop so cashier interactions and UI remain 60fps
    if (page <= totalPages) {
      await new Promise((resolve) => setTimeout(resolve, 30));
    }
  } while (page <= totalPages);

  // Anything we had that is no longer published online leaves the till (kept as draft for history).
  const stale = (await db.products.filter((p) => p.wooId !== null && p.status === 'publish').toArray())
    .map((p) => p.wooId as number)
    .filter((id) => !seen.has(id));
  await applyRemovals(stale);

  await setSetting(CURSOR_KEY, String(cursor));
  // Catch anything that changed while we were downloading.
  await pullChanges(token);
  return { importedCount: seen.size };
}

/** Applies product/stock changes since the last cursor. Downloads everything on first run. */
export async function pullChanges(token: string): Promise<{ updatedCount: number }> {
  // Fast check: if products exist in Dexie, Sales is immediately usable
  const localPublished = await db.products.where('status').equals('publish').count();
  if (localPublished > 0) {
    useSyncStore.getState().setSalesReady(true);
  }

  const stored = await getSetting(CURSOR_KEY);
  if (stored === undefined) {
    const { importedCount } = await downloadCatalogue(token);
    useSyncStore.getState().setSalesReady(true);
    return { updatedCount: importedCount };
  }

  let cursor = Number(stored) || 0;
  let updatedCount = 0;
  for (;;) {
    const result = await zameriaApi.changes(token, cursor);
    if (result.reset) {
      // The store pruned its change log past our cursor: start over.
      await resetCatalogueCursor();
      const { importedCount } = await downloadCatalogue(token);
      useSyncStore.getState().setSalesReady(true);
      return { updatedCount: importedCount };
    }

    await applyProducts(result.products);
    await applyRemovals(result.removed);
    await setSetting(CURSOR_KEY, String(result.cursor));
    updatedCount += result.products.length + result.removed.length;
    cursor = result.cursor;
    useSyncStore.getState().setSalesReady(true);
    if (!result.more) return { updatedCount };
  }
}
