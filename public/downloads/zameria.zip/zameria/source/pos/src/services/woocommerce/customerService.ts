import { db } from '@/db';
import { getWooClient } from './client';
import { useConnectionStore } from '@/store/connectionStore';
import type { Customer, BillingAddress, SyncEntityResult } from '@/types';
import { isDemoSession, sessionToken } from '@/services/zameria/session';
import { zameriaApi } from '@/services/zameria/api';
import { zameriaConfig } from '@/services/zameria/config';
import { decodeHtmlEntities } from '@/lib';
import { customerIndex, resolveOrderCustomer } from './customerIdentity';
import { prepareCustomerHistoryRepair } from './customerSyncMigration';
import { validateImportPage, checkImportSnapshot } from './pagination';

export interface CustomerSyncOptions {
  incremental?: boolean;
  modifiedAfter?: string | null;
  onProgress?: (current: number, total: number) => void;
  startPage?: number;
  onPage?: (page: number, pages: number | undefined, more: boolean) => void;
}

/**
 * Normalizes remote WooCommerce customer billing data.
 */
function normalizeBilling(raw: any, emailFallback: string, nameFallback: { first: string; last: string }): BillingAddress {
  const firstName = decodeHtmlEntities(raw?.first_name || nameFallback.first || '');
  const lastName = decodeHtmlEntities(raw?.last_name || nameFallback.last || '');
  return {
    firstName,
    lastName,
    company: decodeHtmlEntities(raw?.company || ''),
    address1: decodeHtmlEntities(raw?.address_1 || ''),
    address2: decodeHtmlEntities(raw?.address_2 || ''),
    city: decodeHtmlEntities(raw?.city || ''),
    state: decodeHtmlEntities(raw?.state || ''),
    postcode: (raw?.postcode || '').trim(),
    country: raw?.country || 'NG',
    email: (raw?.email || emailFallback || '').trim(),
    phone: (raw?.phone || '').trim(),
  };
}

/**
 * Pushes locally created or edited customers to WooCommerce.
 */
export async function pushPendingCustomers(): Promise<{ pushedCount: number; failedCount: number }> {
  const client = getWooClient();
  const isOnline = useConnectionStore.getState().isOnline;
  let pushedCount = 0;
  let failedCount = 0;

  if (!client || !isOnline) {
    return { pushedCount, failedCount };
  }

  const pendingCustomers = await db.customers
    .where('syncStatus')
    .anyOf('PENDING_SYNC', 'LOCAL_ONLY')
    .toArray()
    .catch(async (err) => {
      console.warn('Fallback querying pending customers:', err);
      return (await db.customers.toArray()).filter((c) => c.syncStatus === 'PENDING_SYNC');
    });

  for (const cust of pendingCustomers) {
    if (cust.profileType === 'guest') continue;
    try {
      if (cust.wooId) {
        // Remote update
        await client.put(`/customers/${cust.wooId}`, {
          first_name: cust.firstName,
          last_name: cust.lastName,
          email: cust.email,
          billing: {
            first_name: cust.billing.firstName,
            last_name: cust.billing.lastName,
            phone: cust.billing.phone,
            email: cust.billing.email,
            company: cust.billing.company,
            address_2: cust.billing.address2,
            postcode: cust.billing.postcode,
            address_1: cust.billing.address1,
            city: cust.billing.city,
            state: cust.billing.state,
            country: cust.billing.country,
          },
        });
        await db.customers.update(cust.id, {
          syncStatus: 'SYNCED',
          lastSyncedAt: new Date().toISOString(),
        });
        pushedCount++;
      } else {
        // Remote create
        const res = await client.post<{ id: number }>('/customers', {
          first_name: cust.firstName,
          last_name: cust.lastName,
          email: cust.email,
          username: cust.email.split('@')[0] || `user_${Date.now()}`,
          billing: {
            first_name: cust.billing.firstName,
            last_name: cust.billing.lastName,
            phone: cust.billing.phone,
            email: cust.billing.email,
            company: cust.billing.company,
            address_2: cust.billing.address2,
            postcode: cust.billing.postcode,
            address_1: cust.billing.address1,
            city: cust.billing.city,
            state: cust.billing.state,
            country: cust.billing.country,
          },
        });
        const remoteWooId = Number(res.data.id);
        await db.customers.update(cust.id, {
          wooId: remoteWooId,
          syncStatus: 'SYNCED',
          lastSyncedAt: new Date().toISOString(),
        });
        pushedCount++;
      }
    } catch {
      failedCount++;
    }
  }

  return { pushedCount, failedCount };
}

/**
 * Upserts a batch of WooCommerce customer records into local Dexie database.
 * Matches by WooCommerce ID, adopting an unlinked local record only on an unambiguous email.
 */
export async function upsertCustomerBatch(
  remoteCustomers: any[],
  now: string = new Date().toISOString()
): Promise<{ importedCount: number; updatedCount: number }> {
  let importedCount = 0;
  let updatedCount = 0;

  if (!remoteCustomers || remoteCustomers.length === 0) {
    return { importedCount, updatedCount };
  }

  await db.transaction('rw', db.customers, async () => {
    for (const rc of remoteCustomers) {
      const wooId = Number(rc.id);
      if (!Number.isSafeInteger(wooId) || wooId <= 0) continue;
      const email = (rc.email || '').trim().toLowerCase();
      let firstName = rc.first_name || rc.billing?.first_name || '';
      let lastName = rc.last_name || rc.billing?.last_name || '';
      if (!firstName && !lastName && rc.display_name && rc.display_name !== rc.username) {
        const parts = rc.display_name.trim().split(/\s+/);
        firstName = parts[0] || '';
        lastName = parts.slice(1).join(' ') || '';
      }
      firstName = decodeHtmlEntities(firstName);
      lastName = decodeHtmlEntities(lastName);

      const username = rc.username || (email ? email.split('@')[0] : `user_${wooId}`);
      const avatarUrl = rc.avatar_url || '';
      const billing = normalizeBilling(rc.billing, email, { first: firstName, last: lastName });

      // Capture authoritative WooCommerce store metrics (strip commas in total_spent string)
      const count = Number(rc.purchases_count);
      const purchasesCount = rc.purchases_count != null && Number.isSafeInteger(count) && count >= 0 ? count : undefined;
      const rawOrdersCount = rc.orders_count != null ? Number(rc.orders_count) : undefined;
      const cleanTotalSpent = rc.total_spent != null ? parseFloat(String(rc.total_spent).replace(/,/g, '')) : undefined;
      const rawTotalSpent = cleanTotalSpent != null && !isNaN(cleanTotalSpent) ? Math.round(cleanTotalSpent * 100) : undefined;

      // Read inside the write transaction to serialize concurrent sync batches.
      const byWoo = await db.customers.where('wooId').equals(wooId).first();
      const emailMatches = email ? await db.customers.where('email').equalsIgnoreCase(email).toArray() : [];
      const adoptable = emailMatches.filter(c => !c.wooId && c.profileType !== 'guest');
      const existing = byWoo || (adoptable.length === 1 ? adoptable[0] : undefined);

      if (existing) {
        if (existing.syncStatus === 'PENDING_SYNC') {
          continue;
        }

        await db.customers.update(existing.id, {
          wooId: wooId || existing.wooId,
          firstName,
          lastName,
          email: email || existing.email,
          username: username || existing.username,
          avatarUrl: avatarUrl || existing.avatarUrl,
          billing: {
            ...existing.billing,
            ...billing,
          },
          ordersCount: rawOrdersCount !== undefined ? rawOrdersCount : existing.ordersCount,
          purchasesCount: purchasesCount ?? existing.purchasesCount,
          totalSpent: rawTotalSpent !== undefined ? rawTotalSpent : existing.totalSpent,
          syncStatus: 'SYNCED',
          lastSyncedAt: now,
          updatedAt: rc.date_modified || now,
        });
        updatedCount++;
      } else {
        await db.customers.add({
          wooId: wooId || null,
          firstName,
          lastName,
          email,
          username,
          avatarUrl,
          billing,
          ordersCount: rawOrdersCount ?? 0,
          purchasesCount,
          totalSpent: rawTotalSpent ?? 0,
          syncStatus: 'SYNCED',
          lastSyncedAt: now,
          localVersion: 1,
          remoteVersion: rc.date_modified || now,
          createdAt: rc.date_created || now,
          updatedAt: rc.date_modified || now,
        } as Customer);
        importedCount++;
      }
    }
  });

  // 3. Immediately link any existing orders matching these synced customers
  await reconcileCustomerOrders();

  return { importedCount, updatedCount };
}

/**
 * Reconciles local Dexie orders with local customers.
 * Links orders to customer IDs so the Customers directory and customer
 * history reflect all qualifying purchases.
 * Idempotent & non-destructive: NEVER creates fake customer records from orders.
 */
export async function reconcileCustomerOrders(): Promise<{ reconciledCount: number; createdCustomersCount: number }> {
  const customers = await db.customers.toArray();
  const index = customerIndex(customers);

  let reconciledCount = 0;
  const orders = await db.orders.toArray();
  const ordersToUpdate: { id: number; customerId: number | null }[] = [];

  for (const ord of orders) {
    const matchedId = resolveOrderCustomer(ord, index);

    if (ord.customerId !== matchedId) {
      ordersToUpdate.push({ id: ord.id, customerId: matchedId });
    }
  }

  if (ordersToUpdate.length > 0) {
    await db.transaction('rw', db.orders, async () => {
      for (const item of ordersToUpdate) {
        await db.orders.update(item.id, { customerId: item.customerId });
        reconciledCount++;
      }
    });
  }

  return { reconciledCount, createdCustomersCount: 0 };
}

/**
 * Safe, deterministic data reconciliation process to merge duplicate customer records,
 * re-link order histories to authoritative customer records, and remove ghost records.
 */
export async function cleanAndReconcileCustomers(): Promise<{
  mergedCount: number;
  removedGhostsCount: number;
  ordersReconciledCount: number;
}> {
  return db.transaction('rw', db.customers, db.orders, async () => {
    const allCustomers = await db.customers.toArray();
    const allOrders = await db.orders.toArray();

    const toDeleteCustomerIds = new Set<number>();
    const idRemap = new Map<number, number | null>(); // oldId -> authoritativeId

    // 1. Group by wooId (authoritative external identity)
    const byWoo = new Map<number, Customer[]>();
    for (const c of allCustomers) {
      if (c.wooId && c.wooId > 0) {
        if (!byWoo.has(c.wooId)) byWoo.set(c.wooId, []);
        byWoo.get(c.wooId)!.push(c);
      }
    }

    for (const group of byWoo.values()) {
      if (group.length > 1) {
        // Preserve pending edits when consolidating duplicate remote identities.
        group.sort((a, b) => (b.syncStatus === 'PENDING_SYNC' ? 1 : 0) - (a.syncStatus === 'PENDING_SYNC' ? 1 : 0) || a.id - b.id);
        const primary = group[0];
        for (let i = 1; i < group.length; i++) {
          const dup = group[i];
          toDeleteCustomerIds.add(dup.id);
          idRemap.set(dup.id, primary.id);
          if (dup.purchaserKey && !primary.purchaserKey) {
            const summary = { purchaserKey: dup.purchaserKey, profileType: dup.profileType, purchaserActive: dup.purchaserActive,
              purchaserScope: dup.purchaserScope, purchasesCount: dup.purchasesCount, ordersCount: dup.ordersCount,
              totalSpent: dup.totalSpent, lastPurchaseAt: dup.lastPurchaseAt };
            await db.customers.update(primary.id, summary);
            Object.assign(primary, summary);
          }
          if (!primary.billing?.phone && dup.billing?.phone) {
            primary.billing = { ...primary.billing, phone: dup.billing.phone };
            await db.customers.update(primary.id, { billing: primary.billing });
          }
        }
      }
    }

    // 2. Group by normalized real email for records without conflicting wooIds
    const remainingCusts = allCustomers.filter((c) => !toDeleteCustomerIds.has(c.id));
    const byEmail = new Map<string, Customer[]>();
    for (const c of remainingCusts) {
      const em = (c.email || '').trim().toLowerCase();
      if (em && !em.endsWith('@store.local')) {
        if (!byEmail.has(em)) byEmail.set(em, []);
        byEmail.get(em)!.push(c);
      }
    }

    for (const group of byEmail.values()) {
      if (group.length > 1) {
        if (group.some(c => c.purchaserKey || c.profileType === 'guest')) continue;
        if (new Set(group.map(c => c.wooId).filter(Boolean)).size > 1) continue;
        if (group.some(c => c.syncStatus === 'PENDING_SYNC' || c.syncStatus === 'LOCAL_ONLY')) continue;
        group.sort((a, b) => (b.wooId ? 1 : 0) - (a.wooId ? 1 : 0) || a.id - b.id);
        const primary = group[0];
        for (let i = 1; i < group.length; i++) {
          const dup = group[i];
          if (!dup.wooId || dup.wooId === primary.wooId) {
            toDeleteCustomerIds.add(dup.id);
            idRemap.set(dup.id, primary.id);
            if (!primary.billing?.phone && dup.billing?.phone) {
              primary.billing = { ...primary.billing, phone: dup.billing.phone };
              await db.customers.update(primary.id, { billing: primary.billing });
            }
          }
        }
      }
    }

    // 3. Remove ghost @store.local and empty unlinked junk records
    let removedGhostsCount = 0;
    for (const c of allCustomers) {
      const em = (c.email || '').trim().toLowerCase();
      const isGhostEmail = em.endsWith('@store.local') && !c.wooId;
      const isBlankJunk = !c.wooId && !c.firstName?.trim() && !c.lastName?.trim() && !c.email?.trim() && !c.billing?.phone?.trim();
      if ((isGhostEmail || isBlankJunk) && c.syncStatus !== 'PENDING_SYNC' && c.syncStatus !== 'LOCAL_ONLY') {
        toDeleteCustomerIds.add(c.id);
        idRemap.set(c.id, null);
        removedGhostsCount++;
      }
    }

    const mergedCount = Math.max(0, toDeleteCustomerIds.size - removedGhostsCount);

    if (toDeleteCustomerIds.size > 0) {
      await db.customers.bulkDelete(Array.from(toDeleteCustomerIds));
    }

    // 4. Update orders to match authoritative customers
    const finalCustomers = await db.customers.toArray();
    const index = customerIndex(finalCustomers);

    let ordersReconciledCount = 0;
    await db.transaction('rw', db.orders, async () => {
      for (const o of allOrders) {
        const remappedId = o.customerId && idRemap.has(o.customerId) ? idRemap.get(o.customerId) ?? null : o.customerId;
        const targetId = resolveOrderCustomer({ ...o, customerId: remappedId }, index);

        if (targetId !== o.customerId) {
          await db.orders.update(o.id, { customerId: targetId });
          ordersReconciledCount++;
        }
      }
  });

  return { mergedCount, removedGhostsCount, ordersReconciledCount };
  });
}

/**
 * Synchronizes customers from WooCommerce into local Dexie database.
 * Idempotent: maps by wooId or email to avoid duplicate customer records.
 * Saves batch-by-batch for progressive availability and network resilience.
 */
export async function syncAllCustomers(options?: CustomerSyncOptions): Promise<SyncEntityResult> {
  await prepareCustomerHistoryRepair();
  const client = getWooClient(), token = sessionToken(), root = zameriaConfig.apiRoot;
  const now = new Date().toISOString();
  const result: SyncEntityResult = { entity: 'customers', importedCount: 0, updatedCount: 0, failedCount: 0, errors: [] };
  if (!useConnectionStore.getState().isOnline) return result;
  await pushPendingCustomers();
  try {
    let source: 'plugin' | 'woo' = token ? 'plugin' : 'woo';
    if (!token && !client) return result;
    const startPage = Math.max(1, options?.startPage || 1);
    let page = startPage, pages: number | undefined, total: number | undefined;
    const seen = new Set<number>();
    for (;;) {
      let data: any[], pageCount: number | undefined, itemCount: number | undefined;
      if (source === 'plugin') {
        try {
          const res = await zameriaApi.customers(token!, page, 100);
          data = res.customers; pageCount = res.total_pages; itemCount = res.total_items;
        } catch (error: any) {
          // Only an unavailable route on the FIRST page may select another source.
          // A timeout/permission failure or a later-page failure must be retried.
          if (page !== 1 || error?.status !== 404 || !client) throw error;
          source = 'woo';
          continue;
        }
      } else {
        if (!client) throw new Error('Store client is not connected');
        const res = await client.get<any[]>('/customers', { per_page: 100, page, role: 'customer' });
        data = res.data; pageCount = res.totalPages; itemCount = res.totalItems;
      }
      if (sessionToken() !== token || zameriaConfig.apiRoot !== root) throw new Error('Store session changed during customer sync');
      const batch = validateImportPage(data, page, 100, pageCount, itemCount);
      pages = checkImportSnapshot(pages, batch.totalPages);
      total = checkImportSnapshot(total, batch.totalItems);
      for (const row of batch.rows) {
        if (seen.has(Number(row.id))) throw new Error('Duplicate customer page; retry required');
        seen.add(Number(row.id));
      }
      const counts = await upsertCustomerBatch(batch.rows, now);
      result.importedCount += counts.importedCount; result.updatedCount += counts.updatedCount;
      options?.onPage?.(page, pages, batch.more);
      options?.onProgress?.(page, pages ?? page + Number(batch.more));
      if (!batch.more) break;
      page++;
    }
    if (total !== undefined && (startPage - 1) * 100 + seen.size !== total) throw new Error('Customer import count does not match the store');
  } catch (err: any) {
    result.failedCount++;
    result.errors.push(err?.message || 'Customer sync interrupted. Retry to finish importing.');
  }
  await cleanAndReconcileCustomers();
  return result;
}

export interface CreateCustomerInput {
  name?: string;
  firstName?: string;
  lastName?: string;
  email?: string;
  phone?: string;
  billing?: Partial<BillingAddress>;
}

export interface CreateCustomerResult {
  success: boolean;
  customer?: Customer;
  isDuplicate?: boolean;
  error?: string;
}

/**
 * Creates a customer locally in Dexie and synchronizes with WooCommerce when online.
 * Checks for duplicate email or phone before creation.
 */
export async function createCustomer(input: CreateCustomerInput): Promise<CreateCustomerResult> {
  // Normalize names: support either full 'name' or separate 'firstName'/'lastName'
  let firstName = (input.firstName || '').trim();
  let lastName = (input.lastName || '').trim();
  if (!firstName && input.name?.trim()) {
    const parts = input.name.trim().split(/\s+/);
    firstName = parts[0] || '';
    lastName = parts.slice(1).join(' ') || '';
  }

  const email = (input.email || '').trim().toLowerCase();
  const phone = (input.phone || '').trim();

  if (!firstName) {
    return { success: false, error: 'Customer name is required' };
  }
  if (email && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
    return { success: false, error: 'Invalid email address format' };
  }

  // 1. Duplicate check in local IndexedDB
  if (email) {
    const existingByEmail = await db.customers.where('email').equalsIgnoreCase(email).first();
    if (existingByEmail) {
      return {
        success: false,
        isDuplicate: true,
        customer: existingByEmail,
        error: `A customer with email "${email}" already exists (${existingByEmail.firstName} ${existingByEmail.lastName}).`,
      };
    }
  }

  if (phone) {
    const normalizePhone = (raw: string) => {
      const digits = raw.replace(/\D/g, '');
      if (digits.startsWith('234') && digits.length > 10) return digits.slice(3);
      if (digits.startsWith('0') && digits.length > 10) return digits.slice(1);
      return digits;
    };

    const normPhone = normalizePhone(phone);
    if (normPhone.length >= 7) {
      const allCust = await db.customers.toArray();
      const existingByPhone = allCust.find((c) => {
        const p = normalizePhone(c.billing?.phone || '');
        return p && (p === normPhone || p.endsWith(normPhone) || normPhone.endsWith(p));
      });
      if (existingByPhone) {
        return {
          success: false,
          isDuplicate: true,
          customer: existingByPhone,
          error: `A customer with phone "${phone}" already exists (${existingByPhone.firstName} ${existingByPhone.lastName}).`,
        };
      }
    }
  }

  const client = getWooClient();
  const isOnline = useConnectionStore.getState().isOnline;
  const now = new Date().toISOString();

  let wooId: number | null = null;
  let syncStatus: Customer['syncStatus'] = 'PENDING_SYNC';
  let lastSyncedAt: string | null = null;

  const billingData: BillingAddress = {
    firstName: firstName || '',
    lastName: lastName || '',
    company: input.billing?.company || '',
    address1: input.billing?.address1 || '',
    address2: input.billing?.address2 || '',
    city: input.billing?.city || '',
    state: input.billing?.state || '',
    postcode: input.billing?.postcode || '',
    country: input.billing?.country || 'NG',
    email: email || '',
    phone: phone || '',
  };

  // 2. If online and not demo, create remotely in WooCommerce
  if (client && isOnline && !isDemoSession()) {
    try {
      const res = await client.post<{ id: number }>('/customers', {
        first_name: firstName,
        last_name: lastName,
        email: email || undefined,
        username: email ? email.split('@')[0] : `user_${Date.now()}`,
        billing: {
          first_name: firstName,
          last_name: lastName,
          phone: phone,
          email: email || undefined,
          company: billingData.company,
          address_2: billingData.address2,
          postcode: billingData.postcode,
          address_1: billingData.address1,
          city: billingData.city,
          state: billingData.state,
          country: billingData.country,
        },
      });

      if (res.data?.id) {
        wooId = Number(res.data.id);
        syncStatus = 'SYNCED';
        lastSyncedAt = now;
      }
    } catch (err: any) {
      if (err?.code === 'registration-error-email-exists' || err?.message?.toLowerCase().includes('already registered')) {
        try {
          const found = await client.get<any[]>('/customers', { email });
          if (found.data && found.data.length > 0) {
            const rc = found.data[0];
            const existingWooId = Number(rc.id);
            const existingCust = await db.customers.where('wooId').equals(existingWooId).first();
            if (existingCust) {
              return {
                success: false,
                isDuplicate: true,
                customer: existingCust,
                error: `Customer with email "${email}" already exists in store.`,
              };
            }
            // Customer exists remotely in WooCommerce: adopt their remote ID and stats
            wooId = existingWooId;
            syncStatus = 'SYNCED';
            lastSyncedAt = now;
          }
        } catch {}
      }
      if (!wooId) {
        syncStatus = 'PENDING_SYNC';
      }
    }
  }

  // 3. Store locally in Dexie
  const newCustomerRecord: Omit<Customer, 'id'> = {
    wooId,
    email: email || '',
    firstName: firstName || '',
    lastName: lastName || '',
    username: email ? email.split('@')[0] : `${firstName.toLowerCase()}.${Date.now().toString().slice(-4)}`,
    billing: billingData,
    avatarUrl: '',
    syncStatus,
    lastSyncedAt,
    localVersion: 1,
    remoteVersion: null,
    createdAt: now,
    updatedAt: now,
  };

  const newId = (await db.customers.add(newCustomerRecord as Customer)) as number;
  const createdCustomer = (await db.customers.get(newId)) as Customer;

  // 4. Reconcile any existing orders
  await reconcileCustomerOrders();

  return {
    success: true,
    customer: createdCustomer,
  };
}

export interface UpdateCustomerInput {
  firstName: string;
  lastName: string;
  email: string;
  phone?: string;
  billing: {
    company?: string;
    address1: string;
    address2?: string;
    city: string;
    state: string;
    country: string;
    postcode?: string;
  };
}

/**
 * Updates an existing customer's contact and billing details in Dexie and synchronizes with WooCommerce.
 */
export async function updateCustomer(
  id: number,
  data: UpdateCustomerInput
): Promise<{ success: boolean; customer?: Customer; error?: string }> {
  const existing = await db.customers.get(id);
  if (!existing) {
    return { success: false, error: 'Customer not found' };
  }
  if (existing.profileType === 'guest') {
    return { success: false, error: 'Guest purchaser details come from their WooCommerce orders.' };
  }

  const now = new Date().toISOString();
  const updatedBilling: BillingAddress = {
    ...existing.billing,
    firstName: data.firstName.trim() || existing.firstName,
    lastName: data.lastName.trim() || existing.lastName,
    phone: data.phone !== undefined ? data.phone.trim() : (existing.billing?.phone || ''),
    email: data.email.trim() || existing.email,
    company: data.billing.company !== undefined ? data.billing.company.trim() : (existing.billing?.company || ''),
    address1: data.billing.address1.trim(),
    address2: data.billing.address2 !== undefined ? data.billing.address2.trim() : (existing.billing?.address2 || ''),
    city: data.billing.city.trim(),
    state: data.billing.state.trim(),
    country: data.billing.country.trim() || 'NG',
    postcode: data.billing.postcode !== undefined ? data.billing.postcode.trim() : (existing.billing?.postcode || ''),
  };

  const client = getWooClient();
  const isOnline = useConnectionStore.getState().isOnline;
  let syncStatus: 'SYNCED' | 'PENDING_SYNC' = 'PENDING_SYNC';

  if (client && isOnline && existing.wooId) {
    try {
      await client.put(`/customers/${existing.wooId}`, {
        first_name: data.firstName.trim(),
        last_name: data.lastName.trim(),
        email: data.email.trim(),
        billing: {
          first_name: data.firstName.trim(),
          last_name: data.lastName.trim(),
          email: updatedBilling.email,
          company: updatedBilling.company,
          phone: updatedBilling.phone,
          address_1: updatedBilling.address1,
          address_2: updatedBilling.address2,
          city: updatedBilling.city,
          state: updatedBilling.state,
          country: updatedBilling.country,
          postcode: updatedBilling.postcode,
        },
      });
      syncStatus = 'SYNCED';
    } catch {
      syncStatus = 'PENDING_SYNC';
    }
  }

  await db.customers.update(id, {
    firstName: data.firstName.trim(),
    lastName: data.lastName.trim(),
    email: data.email.trim(),
    billing: updatedBilling,
    syncStatus,
    lastSyncedAt: syncStatus === 'SYNCED' ? now : existing.lastSyncedAt,
    updatedAt: now,
  });

  const updated = await db.customers.get(id);
  return { success: true, customer: updated };
}
