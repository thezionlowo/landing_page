import type { SupportConversation } from '../supportChatClient';
import { restUrl, zameriaConfig } from './config';
import type { AuthEntitlement } from '@/types';

/**
 * Client for the Zameria plugin's own endpoints (/wp-json/zameria/v1). Handles sign-in,
 * the product/stock feed and idempotent sale upload. Everything else goes through the
 * WooCommerce client using the same device token.
 */

/** The request never reached the server (no internet, DNS failure, server down). */
export class OfflineError extends Error {
  constructor(message = "You're offline.") {
    super(message);
    this.name = 'OfflineError';
  }
}

/** Network, CORS, or reachability issue while the device has internet connection */
export class ApiConnectionError extends Error {
  constructor(message = 'Unable to reach WooCommerce store. Please check your connection or CORS settings.') {
    super(message);
    this.name = 'ApiConnectionError';
  }
}

/** The server answered with an error. */
export class ZameriaApiError extends Error {
  constructor(
    message: string,
    public status: number,
    public code: string
  ) {
    super(message);
    this.name = 'ZameriaApiError';
  }
}

export const TOKEN_HEADER = 'X-Zameria-Token';
const TIMEOUT_MS = 30_000;

export interface PluginUser {
  id: number;
  name: string;
  username: string;
  email: string;
  roles: string[];
  capabilities: Record<string, boolean>;
}

export interface StoreInfo {
  name: string;
  address: string;
  receipt_footer: string;
  logo?: string;
}

export interface PluginCategory {
  id: number;
  name: string;
  parent: number;
}

export interface PluginCurrency {
  code: string;
  symbol: string;
  position?: 'left' | 'right' | 'left_space' | 'right_space' | string;
  decimals?: number;
  decimal_separator?: string;
  thousand_separator?: string;
}

export interface LoginResponse {
  token: string;
  device: { id: number; name: string };
  user: PluginUser;
  store?: StoreInfo;
  plan?: string;
  entitlement?: AuthEntitlement;
  currency?: PluginCurrency;
}

export interface PluginBrand {
  id: number;
  name: string;
  slug: string;
  taxonomy?: string;
  count?: number;
  description?: string;
}

export interface BootstrapResponse {
  store: StoreInfo;
  currency: PluginCurrency;
  payment_methods: { id: string; label: string }[];
  categories?: PluginCategory[];
  brands?: PluginBrand[];
  cursor: number;
  user: PluginUser;
  device: { id: number; name: string };
  plan?: string;
  entitlement?: AuthEntitlement;
}

export interface PluginImage {
  id: number;
  src: string;
  name: string;
  alt: string;
}

interface PluginSellable {
  id: number;
  sku: string;
  barcode: string;
  price: string;
  regular_price: string;
  sale_price: string | null;
  on_sale: boolean;
  manage_stock: boolean;
  stock_quantity: number | null;
  stock_owner_id: number;
  stock_status: 'instock' | 'outofstock' | 'onbackorder';
  backorders_allowed: boolean;
}

export interface PluginVariation extends PluginSellable {
  attributes: { name: string; option: string }[];
  image: PluginImage | null;
}

export interface PluginProduct extends PluginSellable {
  type: 'simple' | 'variable';
  status: 'publish';
  name: string;
  slug: string;
  description: string;
  short_description: string;
  weight: string;
  dimensions: { length: string; width: string; height: string };
  images: PluginImage[];
  category_ids: number[];
  brand?: PluginBrand | null;
  date_created: string | null;
  date_modified: string | null;
  attributes: {
    id: number;
    name: string;
    position: number;
    visible: boolean;
    variation: boolean;
    options: string[];
  }[];
  variations: PluginVariation[];
}

export interface ProductsPage {
  products: PluginProduct[];
  page: number;
  total_pages: number;
  cursor: number | null;
}

export type ChangesResponse =
  | { reset: true }
  | { reset: false; products: PluginProduct[]; removed: number[]; cursor: number; more: boolean };

export interface SalePayload {
  uuid: string;
  receipt_number: string;
  created_at: string;
  total: string;
  lines: {
    item_id: number;
    name: string;
    quantity: number;
    unit_price: string;
    subtotal: string;
    total: string;
  }[];
  coupons: { code: string; discount: string }[];
  fees: { name: string; total: string }[];
  payment: {
    method: string;
    title: string;
    amount_tendered?: string;
    splits: { method: string; title: string; amount: string }[];
  };
  customer: { id: number | null; name: string; email: string; phone: string };
  note: string;
  attended_by: string;
}

export interface SaleResult {
  uuid: string;
  status: 'created' | 'duplicate' | 'pending' | 'error';
  order_id?: number;
  order_number?: string;
  message?: string;
}

async function request<T>(
  method: 'GET' | 'POST',
  route: string,
  options: { token?: string; body?: unknown; params?: Record<string, string | number> } = {}
): Promise<T> {
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), TIMEOUT_MS);

  // Credentials must never be placed in URLs: URLs are commonly retained by browser history,
  // reverse proxies and access logs. The plugin accepts the dedicated device-token header.
  const requestParams: Record<string, string | number> = options.params ?? {};

  const requestHeaders: Record<string, string> = {
    'Content-Type': 'application/json',
    ...(options.token
      ? {
          [TOKEN_HEADER]: options.token,
        }
      : {}),
  };

  let response: Response;
  let data: any;
  try {
    response = await fetch(restUrl(zameriaConfig.apiRoot, route, requestParams), {
      method,
      headers: requestHeaders,
      ...(options.body === undefined ? {} : { body: JSON.stringify(options.body) }),
      cache: 'no-store',
      // Token auth only; a WordPress login cookie without a nonce would confuse the REST API.
      credentials: 'omit',
      signal: controller.signal,
    });
    data = await response.json().catch((err: unknown) => {
      if (controller.signal.aborted) throw err;
      return null;
    });
  } catch (err: any) {
    if (err?.name === 'AbortError') {
      throw new ApiConnectionError('Store connection timed out. Please verify your store server is responsive.');
    }
    const isDeviceOffline = typeof navigator !== 'undefined' && !navigator.onLine;
    if (isDeviceOffline) {
      throw new OfflineError();
    }
    throw new ApiConnectionError(
      err?.message || 'Unable to connect to WooCommerce store. Please ensure your store allows API access.'
    );
  } finally {
    clearTimeout(timer);
  }

  if (!response.ok) {
    throw new ZameriaApiError(data?.message ?? `Server error (${response.status})`, response.status, data?.code ?? 'unknown');
  }
  return data as T;
}

export const zameriaApi = {
  purchasers: (token: string, after = '', snapshot?: number) =>
    request<any>('GET', 'purchasers', { token, params: { after, ...(snapshot === undefined ? {} : { snapshot }) } }),
  purchaserChanges: (token: string, since: number, scope: string) =>
    request<any>('GET', 'purchaser-changes', { token, params: { since, scope } }),
  purchaserOrders: (token: string, key: string, before = 0, snapshot?: number) =>
    request<any>('GET', `purchasers/${encodeURIComponent(key)}/orders`, { token, params: { before, ...(snapshot === undefined ? {} : { snapshot }) } }),
  supportStart: (token: string, message: string) => request<{conversation:SupportConversation}>('POST','support/start',{token,body:{message}}),
  supportConversation: (token: string, body?: {message?:string;action?:string}) => request<{conversation:SupportConversation|null}>(body?'POST':'GET','support/conversation',{token,...(body?{body}:{})}),
  login: (username: string, password: string, deviceName: string, deviceId?: number) =>
    request<LoginResponse>('POST', 'auth/login', {
      body: {
        username,
        password,
        device_name: deviceName,
        ...(deviceId ? { device_id: deviceId } : {}),
      },
    }),

  logout: (token: string) => request<{ ok: true }>('POST', 'auth/logout', { token }),

  session: (token: string) => request<{ ok: true }>('GET', 'auth/session', { token }),

  bootstrap: (token: string) => request<BootstrapResponse>('GET', 'bootstrap', { token }),

  brands: (token: string) => request<{ brands: PluginBrand[] }>('GET', 'brands', { token }),

  products: (token: string, page: number) =>
    request<ProductsPage>('GET', 'products', { token, params: { page, per_page: 100 } }),

  changes: (token: string, since: number) =>
    request<ChangesResponse>('GET', 'changes', { token, params: { since, limit: 300 } }),

  pushSales: (token: string, sales: SalePayload[]) =>
    request<{ results: SaleResult[]; products: PluginProduct[] }>('POST', 'sales', { token, body: { sales } }),

  dashboardSummary: (token: string, params: Record<string,string>) => request<import('./dashboardSummary').DashboardSummaryResponse>('GET', 'dashboard-summary', { token, params }),

  customerChanges: (token: string, since: number) => request<{customers: any[]; removed: number[]; cursor: number; more: boolean}>('GET', 'customer-changes', { token, params: { since } }),

  customers: (token: string, page = 1, perPage = 100, search = '') =>
    request<{ customers: any[]; page: number; total_pages: number; total_items: number; feed_cursor?: number }>('GET', 'customers', {
      token,
      params: { page, per_page: perPage, ...(search ? { search } : {}) },
    }),

  setProductBrand: (token: string, productId: number, brandId: number) =>
    request<{ ok: boolean; product_id: number; brand: any }>('POST', `products/${productId}/brand`, {
      token,
      body: { brand_id: brandId },
    }),
};
