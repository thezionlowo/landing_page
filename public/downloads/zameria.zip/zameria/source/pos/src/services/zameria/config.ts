declare global {
  interface Window {
    /** Injected by the Zameria WordPress plugin when it serves the app at /pos/. */
    ZAMERIA_CONFIG?: StoreConnection;
  }
}

/** Where a store's REST API lives. */
export interface StoreConnection {
  /** e.g. https://shop.com/wp-json/ */
  restRoot: string;
  /** e.g. https://shop.com/wp-json/zameria/v1/ */
  apiRoot: string;
  /** e.g. https://shop.com/ */
  storeUrl: string;
  storeName: string;
}

const SAVED_STORE_KEY = 'zameria_store_connection';

const injected = typeof window !== 'undefined' ? window.ZAMERIA_CONFIG : undefined;

function savedStore(): StoreConnection | null {
  try {
    const raw = localStorage.getItem(SAVED_STORE_KEY);
    return raw ? (JSON.parse(raw) as StoreConnection) : null;
  } catch {
    return null;
  }
}

// `npm run dev`: Vite proxies /wp-json to the local WordPress site.
const metaEnv = typeof import.meta !== 'undefined' && (import.meta as any).env ? (import.meta as any).env : {};
const devStore: StoreConnection = {
  restRoot: metaEnv.VITE_REST_ROOT ?? '/wp-json/',
  apiRoot: metaEnv.VITE_ZAMERIA_API_ROOT ?? '/wp-json/zameria/v1/',
  storeUrl: typeof window !== 'undefined' ? window.location.origin : '',
  storeName: 'ZAMERIA POS',
};

// Vite sets DEV in the browser; the process check only applies when scripts run outside Vite (tsx).
const isDev =
  metaEnv.DEV !== undefined ? Boolean(metaEnv.DEV) : (globalThis as any).process?.env?.NODE_ENV !== 'production';
const productPreview = metaEnv.MODE === 'product-preview';
const initialStore = productPreview ? null : injected ?? savedStore() ?? (isDev ? devStore : null);

/**
 * The store this app talks to. Three ways the app can run:
 *   - Served by the plugin at shop.com/pos/: the plugin injects the store (fixed).
 *   - Hosted (e.g. on Vercel): staff type their store's address once; it is remembered.
 *   - `npm run dev`: the local WordPress site through the Vite proxy.
 * Read fields at call time; they change when a hosted app connects to a store.
 */
export const zameriaConfig = {
  restRoot: initialStore?.restRoot ?? '',
  apiRoot: initialStore?.apiRoot ?? '',
  storeUrl: initialStore?.storeUrl ?? '',
  storeName: initialStore?.storeName ?? 'ZAMERIA POS',
  /** True when served by the plugin from a real store. */
  servedByPlugin: Boolean(injected),
};

/** True when the app knows which store to use. */
export function hasStoreConnection(): boolean {
  return zameriaConfig.apiRoot !== '';
}

/** The remembered store of a hosted app (null when served by the plugin or not connected). */
export function connectedStore(): StoreConnection | null {
  return productPreview || injected ? null : savedStore();
}

export function setStoreConnection(store: StoreConnection): void {
  if (productPreview) return;
  Object.assign(zameriaConfig, store);
  try {
    localStorage.setItem(SAVED_STORE_KEY, JSON.stringify(store));
  } catch {}
}

export function clearStoreConnection(): void {
  if (productPreview) return;
  try {
    localStorage.removeItem(SAVED_STORE_KEY);
  } catch {}
  Object.assign(zameriaConfig, { restRoot: '', apiRoot: '', storeUrl: '', storeName: 'ZAMERIA POS' });
}

/** Demo data is restricted to development and the isolated website product preview. */
export function demoLoginEnabled(): boolean {
  return productPreview || isDev && !injected && savedStore() === null;
}

/** Joins a REST root and a route, supporting both /wp-json/ and ?rest_route= style roots. */
export function restUrl(root: string, route: string, params?: Record<string, string | number>): string {
  const baseHref = typeof window !== 'undefined' && window.location?.href ? window.location.href : 'http://localhost';
  const url = new URL(root, baseHref);
  const restRoute = url.searchParams.get('rest_route');
  const cleanRoute = route.replace(/^\//, '');
  if (restRoute !== null) {
    url.searchParams.set('rest_route', restRoute.replace(/\/?$/, '/') + cleanRoute);
  } else {
    url.pathname = url.pathname.replace(/\/?$/, '/') + cleanRoute;
  }
  for (const [key, value] of Object.entries(params ?? {})) {
    url.searchParams.set(key, String(value));
  }
  return url.toString();
}

const REQUESTED_STORE_KEY = 'zameria_requested_store';

// The plugin's "Open ZAMERIA POS" button links to pos.zameria.co/login?store=<store address>
// (the standalone dashboard uses ?store_url=). Keep the address for this tab (it survives
// redirects inside the app) and tidy the address bar.
const STORE_PARAMS = ['store', 'store_url', 'storeUrl'];

if (typeof window !== 'undefined' && !injected && !productPreview) {
  try {
    const url = new URL(window.location.href);
    const param = STORE_PARAMS.find((name) => url.searchParams.get(name)?.trim());
    if (param) {
      let store = url.searchParams.get(param)!.trim();
      if (!/^https?:\/\//i.test(store)) store = `https://${store}`;
      sessionStorage.setItem(REQUESTED_STORE_KEY, store);
    }
    if (STORE_PARAMS.some((name) => url.searchParams.has(name))) {
      STORE_PARAMS.forEach((name) => url.searchParams.delete(name));
      window.history.replaceState(window.history.state, '', url.toString());
    }
  } catch {}
}

/** Store address handed over by the WordPress plugin, if this visit came from there. */
export function requestedStore(): string | null {
  if (productPreview) return null;
  try {
    return sessionStorage.getItem(REQUESTED_STORE_KEY);
  } catch {
    return null;
  }
}

export function clearRequestedStore(): void {
  try {
    sessionStorage.removeItem(REQUESTED_STORE_KEY);
  } catch {}
}
