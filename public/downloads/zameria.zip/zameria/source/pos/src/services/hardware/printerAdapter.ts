/**
 * ZAMERIA Hardware Printer Adapter
 * 
 * Bridges standard browser iframe thermal roll printing with
 * native Bluetooth/Network ESC/POS printers on mobile and desktop runtimes.
 */

import {
  type ThermalPaperWidth,
  getReceiptPaperWidth,
  setReceiptPaperWidth,
  printThermalReceipt,
  buildThermalPrintCss,
  RECEIPT_CONFIGS,
} from '../printService';
import type { IPrinterService, PrinterDevice, CashDrawerKickOptions } from './types';

const STORAGE_ACTIVE_PRINTER = 'zameria_active_printer';

export class HardwarePrinterAdapter implements IPrinterService {
  private activePrinter: PrinterDevice;

  constructor() {
    this.activePrinter = this.loadActivePrinter();
  }

  private loadActivePrinter(): PrinterDevice {
    try {
      if (typeof localStorage !== 'undefined') {
        const raw = localStorage.getItem(STORAGE_ACTIVE_PRINTER);
        if (raw) {
          const parsed = JSON.parse(raw);
          if (parsed && parsed.id) return parsed;
        }
      }
    } catch {}

    return {
      id: 'default-browser-printer',
      name: 'System Thermal Roll (Iframe/Browser)',
      type: 'browser',
      isConnected: true,
      paperWidth: getReceiptPaperWidth(),
    };
  }

  public async getPrinters(): Promise<PrinterDevice[]> {
    const devices: PrinterDevice[] = [
      {
        id: 'default-browser-printer',
        name: 'System Thermal Roll (Iframe/Browser)',
        type: 'browser',
        isConnected: true,
        paperWidth: this.getPaperWidth(),
      },
    ];

    // Check for native Capacitor Bluetooth printer plugin if installed
    const cap = (typeof window !== 'undefined' ? (window as any).Capacitor : null);
    if (cap?.Plugins?.BluetoothPrinter) {
      try {
        const nativeList = await cap.Plugins.BluetoothPrinter.listDevices();
        if (Array.isArray(nativeList?.devices)) {
          for (const d of nativeList.devices) {
            devices.push({
              id: d.address || d.id,
              name: d.name || 'Bluetooth ESC/POS Printer',
              type: 'bluetooth',
              address: d.address,
              isConnected: false,
              paperWidth: this.getPaperWidth(),
            });
          }
        }
      } catch (err) {
        console.warn('Native Bluetooth printer scan notice:', err);
      }
    }

    return devices;
  }

  public getActivePrinter(): PrinterDevice {
    return this.activePrinter;
  }

  public async setActivePrinter(printer: PrinterDevice): Promise<boolean> {
    this.activePrinter = printer;
    try {
      if (typeof localStorage !== 'undefined') {
        localStorage.setItem(STORAGE_ACTIVE_PRINTER, JSON.stringify(printer));
      }
    } catch {}
    return true;
  }

  public getPaperWidth(): ThermalPaperWidth {
    return getReceiptPaperWidth();
  }

  public setPaperWidth(width: ThermalPaperWidth): void {
    setReceiptPaperWidth(width);
    this.activePrinter.paperWidth = width;
    void this.setActivePrinter(this.activePrinter);
  }

  public async printHtml(html: string): Promise<boolean> {
    // If native Bluetooth printer is active and connected, forward to native ESC/POS bridge
    const cap = (typeof window !== 'undefined' ? (window as any).Capacitor : null);
    if (this.activePrinter.type === 'bluetooth' && cap?.Plugins?.BluetoothPrinter) {
      try {
        await cap.Plugins.BluetoothPrinter.printHtml({
          html,
          paperWidth: this.activePrinter.paperWidth,
        });
        return true;
      } catch (err) {
        console.warn('Bluetooth print fallback to standard thermal print:', err);
      }
    }

    // Default universal thermal printing: uses cleanly isolated print container
    if (typeof document !== 'undefined') {
      const tempWrapper = document.createElement('div');
      tempWrapper.innerHTML = html;
      await printThermalReceipt(tempWrapper, { paperWidth: this.activePrinter.paperWidth });
      return true;
    }
    return false;
  }

  public async printRawEscPos(bytes: Uint8Array): Promise<boolean> {
    const cap = (typeof window !== 'undefined' ? (window as any).Capacitor : null);
    if (cap?.Plugins?.BluetoothPrinter) {
      try {
        await cap.Plugins.BluetoothPrinter.printRaw({
          data: Array.from(bytes),
        });
        return true;
      } catch (err) {
        console.error('Failed to send raw ESC/POS command:', err);
      }
    }
    return false;
  }

  public async openCashDrawer(options?: CashDrawerKickOptions): Promise<boolean> {
    // Standard ESC/POS kick pulse: ESC p m t1 t2 (ASCII: 27, 112, 0, 25, 250)
    const pin = options?.pin === 5 ? 1 : 0;
    const pulseMs = options?.pulseMs || 50;
    const t1 = Math.min(255, Math.max(1, Math.floor(pulseMs / 2)));
    const kickCommand = new Uint8Array([27, 112, pin, t1, t1]);

    const cap = (typeof window !== 'undefined' ? (window as any).Capacitor : null);
    if (cap?.Plugins?.BluetoothPrinter) {
      return this.printRawEscPos(kickCommand);
    }

    // On standard browser/desktop printers, cash drawer pulse is usually handled
    // automatically by printer driver settings upon print completion.
    return true;
  }

  public isHardwarePrintingSupported(): boolean {
    return true;
  }
}

export const hardwarePrinter = new HardwarePrinterAdapter();
