export { WooCommerceClient, WooCommerceApiError, setWooClient, getWooClient, clearWooClient } from './client';
export type { WooCommerceConfig } from './client';
export { syncWooCommerce } from './syncService';
export type { SyncResult } from './syncService';
export { syncEngine, sync, SyncEngine } from './syncEngine';
export type { SyncOptions } from './syncEngine';
export {
  createProduct,
  updateProduct,
  deleteProduct,
  syncProductStock,
  syncAllProducts,
  syncInventoryStock,
  processPendingProductQueue,
} from './productService';
export type { CreateProductInput, UpdateProductInput, ProductSyncResult, ProductSyncOptions } from './productService';
export {
  syncAllCategories,
  buildCategoryTree,
  flattenCategoryTree,
} from './categoryService';
export type { CategoryTreeNode } from './categoryService';
export {
  syncAllBrands,
  getBrandById,
  getBrandByWooId,
  getAllBrands,
} from './brandService';
export {
  validateWooCoupon,
  evaluateCouponAgainstCart,
  calculateCouponDiscount,
  syncAllCoupons,
  getCachedWooCoupons,
  DEMO_WOO_COUPONS,
} from './couponService';
export type { WooCoupon, CouponValidationResult } from './couponService';
export {
  syncRecentOrders,
  syncAllOrders,
  pushPendingOrders,
  cancelOrder,
  syncOrdersForCustomer,
} from './orderSyncService';
export type { OrderSyncOptions } from './orderSyncService';
export {
  syncAllCustomers,
  pushPendingCustomers,
  createCustomer,
  updateCustomer,
  reconcileCustomerOrders,
  upsertCustomerBatch,
  cleanAndReconcileCustomers,
} from './customerService';
export type { CustomerSyncOptions, CreateCustomerInput, CreateCustomerResult, UpdateCustomerInput } from './customerService';
export { historicalSyncService, HistoricalSyncService } from './historicalSyncService';
export type { HistoricalSyncCheckpoint } from './historicalSyncService';
