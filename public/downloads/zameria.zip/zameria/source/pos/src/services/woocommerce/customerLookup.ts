import { db } from '@/db';
import type { Customer } from '@/types';
import { customerEmail } from './customerIdentity';
/** Resolve only identities referenced by this batch, retaining all ambiguous email matches. */
export async function customersForOrders(orders: any[]): Promise<Customer[]> {
 const woo = [...new Set(orders.map(o => Number(o.customer_id ?? o.wooCustomerId)).filter(id => id > 0))];
 const ids = [...new Set(orders.map(o => Number(o.customerId)).filter(id => id > 0))];
 const emails = [...new Set(orders.map(o => customerEmail(o.billing?.email ?? o.customerEmail)).filter(Boolean))];
 const guestOrders = [...new Set(orders.map(o => Number(o.wooId ?? o.id)).filter(id => id > 0))];
 const groups = await Promise.all([
  woo.length ? db.customers.where('wooId').anyOf(woo).toArray() : [],
  ids.length ? db.customers.bulkGet(ids).then(rows => rows.filter((c): c is Customer => Boolean(c))) : [],
  ...emails.map(email => db.customers.where('email').equalsIgnoreCase(email).toArray()),
  guestOrders.length ? db.customers.where('guestOrderId').anyOf(guestOrders).toArray() : [],
 ]);
 return [...new Map(groups.flat().map(c => [c.id, c])).values()];
}
