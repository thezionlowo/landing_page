import { toast } from 'sonner';
import { db } from '@/db';
import { useAuthStore } from '@/store/authStore';
import { useConnectionStore } from '@/store/connectionStore';
import { useSyncStore } from '@/store/syncStore';
import { OfflineError, ZameriaApiError, ApiConnectionError } from './api';
import { pullChanges } from './catalog';
import { pushPendingSales } from './sales';
import { sessionToken } from './session';
import { cleanAndReconcileCustomers } from '@/services/woocommerce/customerService';
import { syncAllOrders, syncRecentOrders } from '@/services/woocommerce/orderSyncService';
import { historicalSyncService } from '@/services/woocommerce/historicalSyncService';
import { processPendingProductQueue } from '@/services/woocommerce/productService';
import { syncAllBrands } from '@/services/woocommerce/brandService';
import { syncAllCustomers } from '@/services/woocommerce/customerService';
import { syncAllCategories } from '@/services/woocommerce/categoryService';
import { syncAllCoupons } from '@/services/woocommerce/couponService';

/*
 * Background sync for the till. Order matters:
 *   1. Upload sales first, so the store's stock already includes them.
 *   2. Then pull product/stock changes since the last cursor -> SALES READY immediately.
 *   3. Fetch the most recent 7 days of orders -> ORDERS READY.
 *   4. Progressively synchronize older historical data in the background.
 * Runs on sign-in, every minute, when the connection returns and when the app is reopened.
 */

export const SYNC_INTERVAL_MS = 60_000;

let running: Promise<void> | null = null;

export async function refreshPendingCount(): Promise<void> {
  const count = await db.orders.where('syncStatus').anyOf('PENDING_SYNC', 'SYNC_ERROR').count();
  useSyncStore.getState().setPendingCount(count);
}

let lastDataSync = 0;
const DATA_INTERVAL_KEY = 'zameria_data_sync_interval_minutes';
export function getDataSyncIntervalMinutes(): number {
  try {
    const value = Number(localStorage.getItem(DATA_INTERVAL_KEY));
    return Number.isFinite(value) && value >= 1 && value <= 60 ? value : 3;
  } catch { return 3; }
}
export function setDataSyncIntervalMinutes(value: number): void {
  if (Number.isFinite(value) && value >= 1 && value <= 60) localStorage.setItem(DATA_INTERVAL_KEY, String(value));
}

/**
 * Phase 3: Non-blocking background progressive data sync for older orders and customers.
 * Runs asynchronously without blocking operational POS flows.
 */
export async function runBackgroundDataSync(force = false): Promise<void> {
  const token = sessionToken();
  if (!token) return;

  const now = Date.now();
  if (!force && now - lastDataSync < getDataSyncIntervalMinutes() * 60_000) {
    return;
  }
  lastDataSync = now;

  try {
    const customers = await syncAllCustomers({ incremental: true });
    if (customers.failedCount) console.warn('Customer refresh incomplete:', customers.errors.join('; '));
    await Promise.allSettled([syncAllCategories(), syncAllCoupons()]);
    // Progressive background historical sync for older orders & customers
    void historicalSyncService.startHistoricalSync();
  } catch (e) {
    // Non-fatal background refresh warning
    console.warn('Background data sync notice:', e);
  }
}

async function doSync(): Promise<void> {
  const token = sessionToken();
  if (!token) return;

  // Optimistic readiness check: if cached data exists, enable POS immediately
  try {
    const cachedProducts = await db.products.where('status').equals('publish').count();
    if (cachedProducts > 0) {
      useSyncStore.getState().setSalesReady(true);
    }
    const cachedOrders = await db.orders.count();
    if (cachedOrders > 0) {
      useSyncStore.getState().setOrdersReady(true);
    }
  } catch {}

  try {
    // Step 1: Upload pending local sales and pending product updates first so store state is accurate
    useConnectionStore.getState().setSyncProgress({ entity: 'Synchronizing POS data', current: 0, total: 3 });
    try {
      await pushPendingSales(token);
    } catch (pushErr) {
      console.warn('Pending sales push warning:', pushErr);
    }
    await processPendingProductQueue().catch((err) => console.warn('Product queue flush notice:', err));

    // Step 2: Pull catalogue delta & refresh brands / stock -> SALES READY
    useConnectionStore.getState().setSyncProgress({ entity: 'Refreshing catalogue & stock', current: 1, total: 3 });
    await syncAllBrands().catch(() => {});
    await pullChanges(token);
    useSyncStore.getState().setSalesReady(true);

    const now = new Date().toISOString();
    useConnectionStore.getState().setLastSynced(now);
    useSyncStore.getState().recordEntitySyncSuccess('inventory', now);
    useSyncStore.getState().recordEntitySyncSuccess('products', now);
    useConnectionStore.getState().setOnline(true);
    useConnectionStore.getState().setError(null);

    // Step 3: Prioritize the most recent 7 days of orders -> ORDERS READY
    useConnectionStore.getState().setSyncProgress({ entity: 'Syncing recent 7-day orders', current: 2, total: 3 });
    try {
      await syncRecentOrders(7);
      await syncAllOrders({ incremental: true });
      useSyncStore.getState().setOrdersReady(true);
    } catch (orderErr) {
      console.warn('Recent orders sync warning:', orderErr);
    }

    // Ensure customers from recent orders and local store are reconciled and deduplicated
    try {
      await cleanAndReconcileCustomers();
    } catch (custErr) {
      console.warn('Customer reconciliation notice:', custErr);
    }

    // Step 4: Progressively backfill older historical orders & customers in background
    void runBackgroundDataSync();
  } catch (err) {
    const isDeviceOffline = typeof navigator !== 'undefined' && !navigator.onLine;

    if (err instanceof OfflineError) {
      // Genuine device network disconnection
      useConnectionStore.getState().setOnline(false);
      useConnectionStore.getState().setError("You're offline. Sales will sync when connection returns.");
    } else if (err instanceof ApiConnectionError) {
      // Device has active internet, but store API is temporarily unreachable or returning CORS error
      useConnectionStore.getState().setOnline(true);
      useConnectionStore.getState().setError(err.message);
    } else if (err instanceof ZameriaApiError && (err.status === 401 || err.status === 403)) {
      if (sessionToken() === token) {
        toast.error('This register was signed out of the store.', { description: err.message });
        useAuthStore.getState().logout();
      }
    } else {
      console.warn('Zameria sync failed:', err);
      if (!isDeviceOffline) {
        useConnectionStore.getState().setOnline(true);
      }
      useConnectionStore.getState().setError(err instanceof Error ? err.message : 'Sync failed. It will retry automatically.');
    }
  } finally {
    useConnectionStore.getState().setSyncProgress(null);
    await refreshPendingCount();
  }
}

/** Syncs now, or joins the sync already in progress. */
export function runPosSync(): Promise<void> {
  running ??= doSync().finally(() => {
    running = null;
  });
  return running;
}

export function startPosSyncLoop(): () => void {
  const sync = () => void runPosSync();
  const onVisible = () => document.visibilityState === 'visible' && sync();

  sync();
  const timer = setInterval(sync, SYNC_INTERVAL_MS);
  window.addEventListener('online', sync);
  document.addEventListener('visibilitychange', onVisible);

  return () => {
    clearInterval(timer);
    window.removeEventListener('online', sync);
    document.removeEventListener('visibilitychange', onVisible);
  };
}
