import { useEffect, useState } from 'react';
import { getSetting, setSetting } from '@/db';
import { zameriaApi } from './api';
import { sessionToken } from './session';
import { syncScope } from '@/services/woocommerce/syncCoordinator';
export interface DashboardSummary {
 metrics: {totalSales:number;websiteSales:number;posSales:number;websiteSalesPct:number;posSalesPct:number;websiteOrdersCount:number;posOrdersCount:number;completedOrdersCount:number;totalOrdersCount:number;pendingOrdersCount:number;itemsSold:number;aov:number;uniqueCustomersCount:number;salesChangePct:number;salesChangeSign:'pos'|'neg'|'neutral';prevTotalSales:number};
 series:Record<string,{total:number;website:number;pos:number}>;
 payments:Record<string,{amount:number;count:number}>;
 topProducts:{name:string;sku:string;unitsSold:number;revenue:number;hasWebsite:boolean;hasPOS:boolean}[];
 verifiedAt:string;
}
export interface DashboardSummaryResponse { status:'ready'|'building'; summary:DashboardSummary|null; fresh:boolean; pages_processed:number }
export function useDashboardSummary(bounds:{start:Date;end:Date;prevStart:Date;prevEnd:Date;grouping:string},online:boolean) {
 const scope=syncScope(),token=sessionToken();
 const params={start:bounds.start.toISOString(),end:bounds.end.toISOString(),previous_start:bounds.prevStart.toISOString(),previous_end:bounds.prevEnd.toISOString(),grouping:bounds.grouping,timezone:Intl.DateTimeFormat().resolvedOptions().timeZone};
 const identity=`${scope}|${JSON.stringify(params)}`;
 const [state,setState]=useState<{identity:string;summary?:DashboardSummary;fresh:boolean;error?:string}>({identity,fresh:false});
 useEffect(()=>{
  let active=true,timer:ReturnType<typeof setTimeout>|undefined;
  const key=`dashboard_summary_v1:${identity}`;
  let receivedRemote=false;
  void getSetting(key).then(raw=>{if(active&&!receivedRemote&&raw){try{setState({identity,summary:JSON.parse(raw),fresh:false});}catch{}}}).catch(()=>{});
  const refresh=async()=>{
   if(!active||!online||!token)return;
   try{
    const result=await zameriaApi.dashboardSummary(token,params);
    if(!active||token!==sessionToken()||scope!==syncScope())return;
    receivedRemote=true;
    if(result.summary){await setSetting(key,JSON.stringify(result.summary));if(active)setState({identity,summary:result.summary,fresh:result.fresh});}
    else setState({identity,fresh:false});
    timer=setTimeout(()=>void refresh(),result.status==='building'?2000:60000);
   }catch(error){if(active&&token===sessionToken()&&scope===syncScope()){setState(previous=>({...(previous.identity===identity?previous:{}),identity,fresh:false,error:error instanceof Error?error.message:'Store summary unavailable'}));timer=setTimeout(()=>void refresh(),30000);}}
  };
  void refresh();
  return()=>{active=false;if(timer)clearTimeout(timer);};
 },[identity,online,token]);
 return state.identity===identity?state:{identity,fresh:false};
}
