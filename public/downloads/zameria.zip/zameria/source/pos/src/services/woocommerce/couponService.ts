import { db, getSetting, setSetting } from '@/db';
import { getWooClient } from './client';
import { useConnectionStore } from '@/store/connectionStore';
import { toKobo, formatMoney } from '@/lib';
import type { CartItem, AppliedCoupon, MoneyKobo, SyncEntityResult } from '@/types';
import { isDemoSession } from '@/services/zameria/session';

export interface WooCoupon {
  id: number;
  code: string;
  amount: string;
  discount_type: 'percent' | 'fixed_cart' | 'fixed_product';
  description: string;
  date_expires: string | null;
  date_expires_gmt: string | null;
  usage_count: number;
  individual_use: boolean;
  product_ids: number[];
  excluded_product_ids: number[];
  usage_limit: number | null;
  usage_limit_per_user: number | null;
  limit_usage_to_x_items: number | null;
  free_shipping: boolean;
  product_categories: number[];
  excluded_product_categories: number[];
  exclude_sale_items: boolean;
  minimum_amount: string;
  maximum_amount: string;
  email_restrictions: string[];
  used_by: (string | number)[];
}

export interface CouponValidationResult {
  valid: boolean;
  coupon?: AppliedCoupon;
  error?: string;
}

// Built-in standard mock coupons for demo/showcase environments when not connected to a live WooCommerce instance
export const DEMO_WOO_COUPONS: WooCoupon[] = [
  {
    id: 101,
    code: 'welcome10',
    amount: '10',
    discount_type: 'percent',
    description: '10% discount on entire cart',
    date_expires: null,
    date_expires_gmt: null,
    usage_count: 14,
    individual_use: false,
    product_ids: [],
    excluded_product_ids: [],
    usage_limit: 100,
    usage_limit_per_user: 1,
    limit_usage_to_x_items: null,
    free_shipping: false,
    product_categories: [],
    excluded_product_categories: [],
    exclude_sale_items: false,
    minimum_amount: '0',
    maximum_amount: '0',
    email_restrictions: [],
    used_by: [],
  },
  {
    id: 102,
    code: 'zameria5000',
    amount: '5000',
    discount_type: 'fixed_cart',
    description: '₦5,000 fixed discount on orders over ₦20,000',
    date_expires: null,
    date_expires_gmt: null,
    usage_count: 5,
    individual_use: false,
    product_ids: [],
    excluded_product_ids: [],
    usage_limit: 50,
    usage_limit_per_user: 1,
    limit_usage_to_x_items: null,
    free_shipping: false,
    product_categories: [],
    excluded_product_categories: [],
    exclude_sale_items: false,
    minimum_amount: '20000',
    maximum_amount: '0',
    email_restrictions: [],
    used_by: [],
  },
  {
    id: 103,
    code: 'beauty15',
    amount: '15',
    discount_type: 'percent',
    description: '15% off Category 1 products',
    date_expires: null,
    date_expires_gmt: null,
    usage_count: 8,
    individual_use: false,
    product_ids: [],
    excluded_product_ids: [],
    usage_limit: 200,
    usage_limit_per_user: 1,
    limit_usage_to_x_items: null,
    free_shipping: false,
    product_categories: [1],
    excluded_product_categories: [],
    exclude_sale_items: false,
    minimum_amount: '0',
    maximum_amount: '0',
    email_restrictions: [],
    used_by: [],
  },
  {
    id: 104,
    code: 'vip20',
    amount: '20',
    discount_type: 'percent',
    description: '20% off for registered VIP customer',
    date_expires: null,
    date_expires_gmt: null,
    usage_count: 2,
    individual_use: true,
    product_ids: [],
    excluded_product_ids: [],
    usage_limit: 10,
    usage_limit_per_user: 1,
    limit_usage_to_x_items: null,
    free_shipping: false,
    product_categories: [],
    excluded_product_categories: [],
    exclude_sale_items: false,
    minimum_amount: '0',
    maximum_amount: '0',
    email_restrictions: ['vip@example.com', 'john@example.com', 'ada@example.com'],
    used_by: [],
  },
  {
    id: 105,
    code: 'expired10',
    amount: '10',
    discount_type: 'percent',
    description: 'Expired promotional coupon',
    date_expires: '2024-01-01T00:00:00',
    date_expires_gmt: '2024-01-01T00:00:00',
    usage_count: 10,
    individual_use: false,
    product_ids: [],
    excluded_product_ids: [],
    usage_limit: 100,
    usage_limit_per_user: 1,
    limit_usage_to_x_items: null,
    free_shipping: false,
    product_categories: [],
    excluded_product_categories: [],
    exclude_sale_items: false,
    minimum_amount: '0',
    maximum_amount: '0',
    email_restrictions: [],
    used_by: [],
  },
  {
    id: 106,
    code: 'limitreached',
    amount: '10',
    discount_type: 'percent',
    description: 'Coupon with limit exhausted',
    date_expires: null,
    date_expires_gmt: null,
    usage_count: 10,
    individual_use: false,
    product_ids: [],
    excluded_product_ids: [],
    usage_limit: 10,
    usage_limit_per_user: 1,
    limit_usage_to_x_items: null,
    free_shipping: false,
    product_categories: [],
    excluded_product_categories: [],
    exclude_sale_items: false,
    minimum_amount: '0',
    maximum_amount: '0',
    email_restrictions: [],
    used_by: [],
  },
];

/**
 * Validates a coupon code against WooCommerce and calculates the resulting discount.
 * 
 * Rules:
 * 1. WooCommerce is the single source of truth.
 * 2. If completely offline, coupon validation cannot proceed without an internet connection.
 * 3. Evaluates all WooCommerce constraints: expiry, limits, email restrictions, min/max spend, products, categories.
 */
export async function validateWooCoupon(
  code: string,
  items: CartItem[],
  customerEmail?: string | null
): Promise<CouponValidationResult> {
  const trimmed = code.trim();
  if (!trimmed) {
    return { valid: false, error: 'Please enter a coupon code.' };
  }

  if (items.length === 0) {
    return { valid: false, error: 'Cart is empty. Add products before applying a coupon.' };
  }

  const isOnline = useConnectionStore.getState().isOnline;
  const client = getWooClient();

  let wcCoupon: WooCoupon | null = null;

  if (client && isOnline) {
    try {
      // Query WooCommerce REST API: /wp-json/wc/v3/coupons?code=...
      const res = await client.get<WooCoupon[]>('/coupons', { code: trimmed });
      if (res.data && res.data.length > 0) {
        wcCoupon = res.data.find(
          (c) => c.code.toLowerCase() === trimmed.toLowerCase()
        ) || null;
      }

      if (!wcCoupon) {
        // Fallback to search if exact code lookup did not return a match
        const searchRes = await client.get<WooCoupon[]>('/coupons', { search: trimmed });
        if (searchRes.data && searchRes.data.length > 0) {
          wcCoupon = searchRes.data.find(
            (c) => c.code.toLowerCase() === trimmed.toLowerCase()
          ) || null;
        }
      }
    } catch (err: any) {
      return {
        valid: false,
        error: err?.message || 'Unable to connect to WooCommerce store to validate coupon.',
      };
    }
  } else if (!isOnline) {
    // Offline: validate against coupons cached at the last sync. Usage limits may be slightly
    // stale; WooCommerce records the usage when the sale uploads.
    const cached = await getCachedWooCoupons();
    wcCoupon = cached.find((c) => c.code.toLowerCase() === trimmed.toLowerCase()) || null;
    if (!wcCoupon) {
      return { valid: false, error: 'Coupon not found in the offline cache. Connect to the internet to check it.' };
    }
  } else if (isDemoSession()) {
    // Demo Mode fallback (when not connected to live WooCommerce store credentials)
    wcCoupon = DEMO_WOO_COUPONS.find(
      (c) => c.code.toLowerCase() === trimmed.toLowerCase()
    ) || null;
  }

  if (!wcCoupon) {
    return { valid: false, error: 'Coupon not found.' };
  }

  return evaluateCouponAgainstCart(wcCoupon, items, customerEmail);
}

/**
 * Evaluates a WooCommerce coupon object against a set of cart items and customer email.
 */
export async function evaluateCouponAgainstCart(
  coupon: WooCoupon,
  items: CartItem[],
  customerEmail?: string | null
): Promise<CouponValidationResult> {
  const now = new Date();

  // 1. Expiration check
  if (coupon.date_expires || coupon.date_expires_gmt) {
    const expireDateStr = coupon.date_expires_gmt || coupon.date_expires;
    if (expireDateStr) {
      const exp = new Date(expireDateStr);
      if (!isNaN(exp.getTime()) && exp.getTime() < now.getTime()) {
        return { valid: false, error: 'This coupon has expired.' };
      }
    }
  }

  // 2. Global Usage Limit check
  if (
    coupon.usage_limit !== null &&
    coupon.usage_limit !== undefined &&
    coupon.usage_limit > 0 &&
    coupon.usage_count >= coupon.usage_limit
  ) {
    return { valid: false, error: 'This coupon has reached its usage limit.' };
  }

  // 3. Customer Email Restrictions check
  const emailRestrictions = coupon.email_restrictions || [];
  if (emailRestrictions.length > 0) {
    const trimmedEmail = (customerEmail || '').trim().toLowerCase();
    if (!trimmedEmail) {
      return {
        valid: false,
        error: 'This coupon is restricted to specific customers. Please select a customer first.',
      };
    }

    const matches = emailRestrictions.some(
      (e) => e.trim().toLowerCase() === trimmedEmail
    );
    if (!matches) {
      return {
        valid: false,
        error: `This coupon cannot be used for this customer (${customerEmail}).`,
      };
    }
  }

  // 4. Cart Items Eligibility Filtering (Product & Category rules)
  const eligibleItems: CartItem[] = [];

  for (const item of items) {
    // Exclude sale items check
    if (coupon.exclude_sale_items) {
      if (item.salePrice || item.discount) {
        continue;
      }
    }

    // Excluded product IDs check
    const wooPid = item.wooProductId;
    const localPid = item.productId;
    if (coupon.excluded_product_ids && coupon.excluded_product_ids.length > 0) {
      if (
        (wooPid && coupon.excluded_product_ids.includes(wooPid)) ||
        coupon.excluded_product_ids.includes(localPid)
      ) {
        continue;
      }
    }

    // Included product IDs check
    if (coupon.product_ids && coupon.product_ids.length > 0) {
      const isIncluded =
        (wooPid && coupon.product_ids.includes(wooPid)) ||
        coupon.product_ids.includes(localPid);
      if (!isIncluded) {
        continue;
      }
    }

    // Category restrictions check
    if (
      (coupon.product_categories && coupon.product_categories.length > 0) ||
      (coupon.excluded_product_categories && coupon.excluded_product_categories.length > 0)
    ) {
      // Look up product categories from local database
      const prod = await db.products.get(item.productId);
      const prodCategoryIds = prod?.categoryIds || [];
      const prodWooCategoryIds = prod?.wooCategoryIds || [];
      const allCatIds = [...new Set([...prodCategoryIds, ...prodWooCategoryIds])];

      if (coupon.excluded_product_categories && coupon.excluded_product_categories.length > 0) {
        const isExcludedCategory = allCatIds.some((cid) =>
          coupon.excluded_product_categories.includes(cid)
        );
        if (isExcludedCategory) {
          continue;
        }
      }

      if (coupon.product_categories && coupon.product_categories.length > 0) {
        const hasIncludedCategory = allCatIds.some((cid) =>
          coupon.product_categories.includes(cid)
        );
        if (!hasIncludedCategory) {
          continue;
        }
      }
    }

    eligibleItems.push(item);
  }

  // If specific product or category filters were configured and no cart item matched
  const hasProductFilters =
    (coupon.product_ids && coupon.product_ids.length > 0) ||
    (coupon.product_categories && coupon.product_categories.length > 0);

  if (hasProductFilters && eligibleItems.length === 0) {
    return {
      valid: false,
      error: 'This coupon is not valid for the products or categories in this order.',
    };
  }

  // Calculate cart subtotal and eligible subtotal
  const cartSubtotal = items.reduce((sum, item) => sum + item.lineTotal, 0);
  const eligibleSubtotal = eligibleItems.reduce((sum, item) => sum + item.lineTotal, 0);

  // 5. Minimum Spend check
  if (coupon.minimum_amount) {
    const minVal = parseFloat(coupon.minimum_amount);
    if (!isNaN(minVal) && minVal > 0) {
      const minKobo = toKobo(minVal);
      if (cartSubtotal < minKobo) {
        return {
          valid: false,
          error: `This coupon requires a minimum spend of ${formatMoney(minKobo)}.`,
        };
      }
    }
  }

  // 6. Maximum Spend check
  if (coupon.maximum_amount) {
    const maxVal = parseFloat(coupon.maximum_amount);
    if (!isNaN(maxVal) && maxVal > 0) {
      const maxKobo = toKobo(maxVal);
      if (cartSubtotal > maxKobo) {
        return {
          valid: false,
          error: `This coupon is only valid for orders up to ${formatMoney(maxKobo)}.`,
        };
      }
    }
  }

  if (eligibleSubtotal <= 0) {
    return {
      valid: false,
      error: 'This coupon does not apply to any items in the cart.',
    };
  }

  // 7. Calculate Discount Amount
  let discountKobo: MoneyKobo = 0;
  const rawAmount = parseFloat(coupon.amount) || 0;

  switch (coupon.discount_type) {
    case 'percent': {
      discountKobo = Math.round(eligibleSubtotal * (rawAmount / 100));
      break;
    }
    case 'fixed_cart': {
      const fixedKobo = toKobo(rawAmount);
      discountKobo = Math.min(fixedKobo, eligibleSubtotal);
      break;
    }
    case 'fixed_product': {
      const unitDiscountKobo = toKobo(rawAmount);
      let eligibleItemsCount = 0;
      for (const item of eligibleItems) {
        const maxQty = coupon.limit_usage_to_x_items
          ? Math.min(item.quantity, Math.max(0, coupon.limit_usage_to_x_items - eligibleItemsCount))
          : item.quantity;
        discountKobo += Math.min(item.lineTotal, unitDiscountKobo * maxQty);
        eligibleItemsCount += maxQty;
      }
      break;
    }
    default: {
      discountKobo = 0;
    }
  }

  // Ensure discount does not exceed the eligible subtotal
  discountKobo = Math.max(0, Math.min(discountKobo, eligibleSubtotal));

  if (discountKobo <= 0) {
    return {
      valid: false,
      error: 'This coupon does not provide a discount for the items in your cart.',
    };
  }

  const applied: AppliedCoupon = {
    code: coupon.code.toUpperCase(),
    amount: coupon.amount,
    discountType: coupon.discount_type,
    discountKobo,
    description: coupon.description,
    wooCouponId: coupon.id,
    minimumAmount: coupon.minimum_amount ? toKobo(parseFloat(coupon.minimum_amount)) : undefined,
    maximumAmount: coupon.maximum_amount ? toKobo(parseFloat(coupon.maximum_amount)) : undefined,
    productIds: coupon.product_ids,
    excludedProductIds: coupon.excluded_product_ids,
    categoryIds: coupon.product_categories,
    excludedCategoryIds: coupon.excluded_product_categories,
    emailRestrictions: coupon.email_restrictions,
    excludeSaleItems: coupon.exclude_sale_items,
    usageLimit: coupon.usage_limit,
    usageCount: coupon.usage_count,
    individualUse: coupon.individual_use,
  };

  return { valid: true, coupon: applied };
}

/**
 * Dynamically recalculates the discount of an already applied coupon against the active cart items.
 * Returns null if the cart is no longer eligible (e.g. min spend no longer met or items removed).
 */
export async function calculateCouponDiscount(
  appliedCoupon: AppliedCoupon,
  items: CartItem[],
  customerEmail?: string | null
): Promise<{ discountKobo: MoneyKobo } | { error: string }> {
  // Reconstruct WooCoupon-like object from AppliedCoupon metadata
  const mockWc: WooCoupon = {
    id: appliedCoupon.wooCouponId || 0,
    code: appliedCoupon.code,
    amount: appliedCoupon.amount,
    discount_type: appliedCoupon.discountType,
    description: appliedCoupon.description || '',
    date_expires: null,
    date_expires_gmt: null,
    usage_count: appliedCoupon.usageCount || 0,
    individual_use: appliedCoupon.individualUse || false,
    product_ids: appliedCoupon.productIds || [],
    excluded_product_ids: appliedCoupon.excludedProductIds || [],
    usage_limit: appliedCoupon.usageLimit || null,
    usage_limit_per_user: null,
    limit_usage_to_x_items: null,
    free_shipping: false,
    product_categories: appliedCoupon.categoryIds || [],
    excluded_product_categories: appliedCoupon.excludedCategoryIds || [],
    exclude_sale_items: appliedCoupon.excludeSaleItems || false,
    minimum_amount: appliedCoupon.minimumAmount ? (appliedCoupon.minimumAmount / 100).toString() : '0',
    maximum_amount: appliedCoupon.maximumAmount ? (appliedCoupon.maximumAmount / 100).toString() : '0',
    email_restrictions: appliedCoupon.emailRestrictions || [],
    used_by: [],
  };

  const res = await evaluateCouponAgainstCart(mockWc, items, customerEmail);
  if (!res.valid || !res.coupon) {
    return { error: res.error || 'Cart is no longer eligible for this coupon.' };
  }

  return { discountKobo: res.coupon.discountKobo };
}

/**
 * Retrieves cached WooCommerce coupons from local database settings.
 */
export async function getCachedWooCoupons(): Promise<WooCoupon[]> {
  try {
    const raw = await getSetting('woo_coupons');
    if (raw) {
      return JSON.parse(raw);
    }
  } catch {}
  return DEMO_WOO_COUPONS;
}

/**
 * Synchronizes coupons from WooCommerce into local cached settings.
 */
export async function syncAllCoupons(options?: {
  onProgress?: (current: number, total: number) => void;
}): Promise<SyncEntityResult> {
  const client = getWooClient();
  const isOnline = useConnectionStore.getState().isOnline;

  const result: SyncEntityResult = {
    entity: 'coupons',
    importedCount: 0,
    updatedCount: 0,
    failedCount: 0,
    errors: [],
  };

  if (client && isOnline) {
    try {
      const firstPage = await client.get<WooCoupon[]>('/coupons', { per_page: 100, page: 1 });
      const totalPages = firstPage.totalPages || 1;
      const remoteCoupons: WooCoupon[] = [...(firstPage.data || [])];
      options?.onProgress?.(1, totalPages);

      for (let page = 2; page <= totalPages; page++) {
        try {
          const pageRes = await client.get<WooCoupon[]>('/coupons', { per_page: 100, page });
          if (pageRes.data) {
            remoteCoupons.push(...pageRes.data);
          }
          options?.onProgress?.(page, totalPages);
        } catch (pErr: any) {
          result.failedCount++;
          result.errors.push(`Coupon page ${page} error: ${pErr.message}`);
        }
      }

      await setSetting('woo_coupons', JSON.stringify(remoteCoupons));
      result.importedCount = remoteCoupons.length;
    } catch (err: any) {
      result.failedCount++;
      result.errors.push(err.message || 'Failed to sync coupons from WooCommerce');
    }
  } else if (isDemoSession()) {
    // Demo Mode: cache demo coupons
    await setSetting('woo_coupons', JSON.stringify(DEMO_WOO_COUPONS));
    result.updatedCount = DEMO_WOO_COUPONS.length;
  }

  return result;
}
