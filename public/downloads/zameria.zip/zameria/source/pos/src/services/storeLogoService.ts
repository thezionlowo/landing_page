import { db } from '@/db';

/**
 * Normalizes a store key from storeUrl or storeName to ensure isolation across stores.
 */
export function getStoreKey(storeUrlOrName?: string | null): string {
  if (!storeUrlOrName || !storeUrlOrName.trim()) {
    return 'default';
  }
  return storeUrlOrName
    .trim()
    .toLowerCase()
    .replace(/^https?:\/\//, '')
    .replace(/[^a-z0-9.-]+/g, '_');
}

/**
 * Retrieve the current logo for a specific store.
 * Checks localStorage first for synchronous rendering (receipts/previews),
 * with fallback to IndexedDB.
 */
export function getStoreLogo(storeUrlOrName?: string | null): string | null {
  const key = getStoreKey(storeUrlOrName);
  const storageKey = `zameria_store_logo_${key}`;
  if (typeof localStorage !== 'undefined') {
    try {
      const cached = localStorage.getItem(storageKey);
      if (cached) return cached;
      // Fallback: check any cached store logo in localStorage
      for (let i = 0; i < localStorage.length; i++) {
        const k = localStorage.key(i);
        if (k && k.startsWith('zameria_store_logo_')) {
          const val = localStorage.getItem(k);
          if (val) return val;
        }
      }
    } catch {}
  }
  return null;
}

/**
 * Save store logo for a specific store.
 */
export async function saveStoreLogo(storeUrlOrName: string | null | undefined, dataUrl: string): Promise<void> {
  const key = getStoreKey(storeUrlOrName);
  const storageKey = `zameria_store_logo_${key}`;

  // 1. Cache in localStorage for immediate sync retrieval in UI and print
  if (typeof localStorage !== 'undefined') {
    try {
      localStorage.setItem(storageKey, dataUrl);
    } catch (e) {
      console.warn('localStorage storage limit reached, relying on IndexedDB:', e);
    }
  }

  // 2. Persist in Dexie settings table
  try {
    const existing = await db.settings.where('key').equals(storageKey).first();
    if (existing && existing.id) {
      await db.settings.update(existing.id, { value: dataUrl });
    } else {
      await db.settings.add({ key: storageKey, value: dataUrl } as any);
    }
  } catch (err) {
    console.warn('Failed to persist store logo in Dexie:', err);
  }
}

/**
 * Remove store logo for a specific store.
 */
export async function removeStoreLogo(storeUrlOrName: string | null | undefined): Promise<void> {
  const key = getStoreKey(storeUrlOrName);
  const storageKey = `zameria_store_logo_${key}`;

  if (typeof localStorage !== 'undefined') {
    try {
      localStorage.removeItem(storageKey);
    } catch {}
  }

  try {
    await db.settings.where('key').equals(storageKey).delete();
  } catch (err) {
    console.warn('Failed to delete store logo in Dexie:', err);
  }
}

/**
 * Hydrate logo from Dexie into localStorage on store load/switch.
 */
export async function hydrateStoreLogo(storeUrlOrName: string | null | undefined): Promise<string | null> {
  const key = getStoreKey(storeUrlOrName);
  const storageKey = `zameria_store_logo_${key}`;

  try {
    const item = await db.settings.where('key').equals(storageKey).first();
    if (item && item.value) {
      if (typeof localStorage !== 'undefined') {
        try {
          localStorage.setItem(storageKey, item.value);
        } catch {}
      }
      return item.value;
    }
  } catch {}

  return getStoreLogo(storeUrlOrName);
}
