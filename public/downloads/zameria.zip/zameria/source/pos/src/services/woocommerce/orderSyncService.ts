import { db, getSetting, setSetting } from '@/db';
import { ensureOrderCustomers, isPurchasedOrder } from './orderCustomers';
import { prepareCustomerHistoryRepair } from './customerSyncMigration';
import { validateImportPage, checkImportSnapshot } from './pagination';
import { getWooClient } from './client';
import { useConnectionStore } from '@/store/connectionStore';
import { useSyncStore } from '@/store/syncStore';
import { toKobo, decodeHtmlEntities } from '@/lib';
import type { Order, OrderItem, Customer, SyncEntityResult } from '@/types';
import { PermissionDeniedError } from '@/types';
import { assertAuthorized, isOrderAccessibleToUser } from '@/services/auth';
import { useAuthStore } from '@/store/authStore';
import { isDemoSession, sessionToken } from '@/services/zameria/session';
import { pushPendingSales } from '@/services/zameria/sales';
import { pullChanges } from '@/services/zameria/catalog';
import { customerIndex, resolveOrderCustomer, customerEmail as normalizeEmail } from './customerIdentity';
import { canonicalWooOrderId, ORDER_IDENTITY_TABLES, reconcileOrderCopies, remoteOrderIdentity } from '@/db/orderIdentity';

export interface OrderSyncOptions {
  incremental?: boolean;
  modifiedAfter?: string | null;
  maxPages?: number;
  allPages?: boolean;
  onProgress?: (current: number, total: number) => void;
}

let runningOrderSync: Promise<SyncEntityResult> | null = null;

/**
 * Pushes offline or pending physical POS orders to WooCommerce.
 * Sets set_paid: true, status: 'completed', transmits coupon_lines and localTransactionId.
 */
export async function pushPendingOrders(): Promise<{ pushedCount: number; failedCount: number }> {
  // Real store: upload through the plugin, which is idempotent and reduces stock by quantity sold.
  const token = sessionToken();
  if (token) {
    try {
      return await pushPendingSales(token);
    } catch {
      return { pushedCount: 0, failedCount: 0 };
    }
  }

  const client = getWooClient();
  const isOnline = useConnectionStore.getState().isOnline;
  let pushedCount = 0;
  let failedCount = 0;

  if (!client || !isOnline) {
    return { pushedCount, failedCount };
  }

  const pendingOrders = await db.orders
    .where('syncStatus')
    .equals('PENDING_SYNC')
    .toArray();

  for (const ord of pendingOrders) {
    // Only push if it has a local transaction ID and no wooId yet
    if (ord.wooId) continue;

    try {
      // Load order line items
      const items = await db.orderItems.where('orderId').equals(ord.id).toArray();

      const lineItemsPayload = items.map((item) => {
        const payload: Record<string, any> = {
          name: item.name,
          quantity: item.quantity,
          total: (item.total / 100).toFixed(2),
        };
        if (item.wooProductId) {
          payload.product_id = item.wooProductId;
        }
        return payload;
      });

      const couponLinesPayload = Array.isArray(ord.couponLines)
        ? ord.couponLines.map((cl) => ({
          code: cl.code,
          discount: (cl.discount / 100).toFixed(2),
        }))
        : ord.couponCode
          ? [{ code: ord.couponCode, discount: ((ord.couponDiscount || 0) / 100).toFixed(2) }]
          : [];

      const wooPayload: Record<string, any> = {
        status: ord.status || 'completed',
        set_paid: ord.status === 'completed',
        payment_method: ord.paymentMethod || 'pos',
        payment_method_title: ord.paymentMethodTitle || 'Physical POS',
        customer_id: ord.wooCustomerId || undefined,
        customer_note: ord.customerNote || '',
        line_items: lineItemsPayload,
        coupon_lines: couponLinesPayload,
        meta_data: [
          { key: '_zameria_pos_order', value: 'yes' },
          { key: '_zameria_transaction_id', value: ord.localTransactionId },
          { key: '_zameria_source', value: 'pos' },
        ],
      };

      if (ord.customerEmail || ord.customerName || ord.customerPhone) {
        const [firstName, ...lastParts] = (ord.customerName && ord.customerName !== 'Walk-in Customer' ? ord.customerName : '').split(' ');
        wooPayload.billing = {
          first_name: firstName || '',
          last_name: lastParts.join(' ') || '',
          email: (ord.customerEmail || '').trim(),
          phone: (ord.customerPhone || '').trim(),
        };
      }

      if (ord.attendedBy) {
        wooPayload.meta_data.push({ key: '_zameria_attended_by', value: ord.attendedBy });
      }
      if (ord.attendedByUserId) {
        wooPayload.meta_data.push({ key: '_zameria_attended_by_user_id', value: String(ord.attendedByUserId) });
      }
      const creatorUserId = ord.createdByUserId ?? ord.attendedByUserId;
      if (creatorUserId) {
        wooPayload.meta_data.push({ key: '_zameria_created_by_user_id', value: String(creatorUserId) });
      }

      const res = await client.post<{ id: number; number?: string; date_modified?: string }>(
        '/orders',
        wooPayload
      );

      if (res.data?.id) {
        const remoteId = canonicalWooOrderId(res.data.id);
        if (!remoteId) throw new Error('Invalid order acknowledgement');
        await db.transaction('rw', ORDER_IDENTITY_TABLES, async (tx) => {
          await reconcileOrderCopies(tx, remoteId, ord.id);
          await db.orders.update(ord.id, {
            wooId: remoteId,
            orderNumber: res.data.number ? `#${res.data.number}` : ord.orderNumber,
            syncStatus: 'SYNCED',
            lastSyncedAt: new Date().toISOString(),
            remoteVersion: res.data.date_modified || new Date().toISOString(),
          });
        });
        pushedCount++;
      }
    } catch {
      failedCount++;
    }
  }

  return { pushedCount, failedCount };
}

/**
 * Priority 2: Synchronizes the most recent 7 days of orders first to make the Orders section usable immediately.
 * Older orders are not loaded here; they are synchronized progressively in the background.
 */
export async function syncRecentOrders(days = 7): Promise<SyncEntityResult> {
  const existingOrderCount = await db.orders.count();
  if (existingOrderCount > 0) {
    useSyncStore.getState().setOrdersReady(true);
  }

  const client = getWooClient();
  const isOnline = useConnectionStore.getState().isOnline;
  const now = new Date().toISOString();
  const cutoffDate = new Date(Date.now() - days * 24 * 60 * 60 * 1000).toISOString();

  const result: SyncEntityResult = {
    entity: 'orders',
    importedCount: 0,
    updatedCount: 0,
    failedCount: 0,
    errors: [],
  };

  // Upload pending orders first so nothing is lost
  await pushPendingOrders();

  if (client && isOnline) {
    try {
      let page = 1;
      let totalPages = 1;

      do {
        const res = await client.get<any[]>('/orders', {
          per_page: 50,
          page,
          after: cutoffDate,
          orderby: 'date',
          order: 'desc',
        });

        totalPages = Math.max(res.totalPages || 1, 1);
        if (Array.isArray(res.data) && res.data.length > 0) {
          const batchRes = await upsertOrderBatch(res.data, now);
          result.importedCount += batchRes.importedCount;
          result.updatedCount += batchRes.updatedCount;
        }

        useSyncStore.getState().setOrdersReady(true);
        page++;
      } while (page <= totalPages);

      useSyncStore.getState().recordEntitySyncSuccess('orders', now);
    } catch (err: any) {
      console.warn('Recent 7-day orders sync notice:', err);
      result.failedCount++;
      result.errors.push(err?.message || 'Failed fetching recent orders');
    }
  } else if (isDemoSession()) {
    useSyncStore.getState().setOrdersReady(true);
  }

  useSyncStore.getState().setOrdersReady(true);
  return result;
}

/**
 * Synchronizes WooCommerce orders into local Dexie database.
 * Coalesces concurrent in-flight calls to prevent multi-client WordPress overload.
 */
export async function syncAllOrders(options?: OrderSyncOptions): Promise<SyncEntityResult> {
  if (runningOrderSync) {
    return runningOrderSync;
  }
  runningOrderSync = doSyncAllOrders(options).finally(() => {
    runningOrderSync = null;
  });
  return runningOrderSync;
}

/**
 * Internal order sync implementation: maps by wooId or localTransactionId.
 */
async function doSyncAllOrders(options?: OrderSyncOptions): Promise<SyncEntityResult> {
  const client = getWooClient();
  const isOnline = useConnectionStore.getState().isOnline;
  const now = new Date().toISOString();

  const result: SyncEntityResult = {
    entity: 'orders',
    importedCount: 0,
    updatedCount: 0,
    failedCount: 0,
    errors: [],
  };

  // 1. Push any pending POS orders to WooCommerce
  await pushPendingOrders();

  if (client && isOnline) {
    try {
      // Use a checkpoint taken before a successful complete delta fetch. Creation
      // dates cannot detect later cancellations/refunds on older orders.
      const cursorKey = 'orders_modified_cursor';
      const savedCursor = options?.incremental ? await getSetting(cursorKey) : undefined;
      const afterFilter = options?.modifiedAfter || savedCursor;
      const params: Record<string, string | number> = {
        per_page: 50, orderby: options?.incremental || options?.modifiedAfter ? 'modified' : 'date',
        order: options?.incremental || options?.modifiedAfter ? 'asc' : 'desc', dates_are_gmt: 'true',
      };
      if (afterFilter) {
        // Small overlap makes inclusive boundaries and second-level timestamps safe.
        const parsed = Date.parse(afterFilter);
        if (!Number.isFinite(parsed)) throw new Error('Invalid order modification cursor');
        params.modified_after = new Date(parsed - 1000).toISOString();
        params.modified_before = now;
      }
      if (options?.incremental || options?.modifiedAfter) params.modified_before = now;

      let page = 1, pages: number | undefined, total: number | undefined;
      const seen = new Set<number>();
      const complete = options?.allPages || options?.incremental || Boolean(options?.modifiedAfter);
      let reachedEnd = false;
      const token = sessionToken();
      const root = (await import('@/services/zameria/config')).zameriaConfig.apiRoot;
      for (;;) {
        const response = await client.get<any[]>('/orders', { ...params, page });
        if (sessionToken() !== token || (await import('@/services/zameria/config')).zameriaConfig.apiRoot !== root) throw new Error('Store session changed');
        const batch = validateImportPage(response.data, page, 50, response.totalPages, response.totalItems);
        pages = checkImportSnapshot(pages, batch.totalPages); total = checkImportSnapshot(total, batch.totalItems);
        for (const order of batch.rows) {
          if (seen.has(Number(order.id))) throw new Error('Duplicate order page');
          seen.add(Number(order.id));
        }
        const counts = await upsertOrderBatch(batch.rows, now);
        result.importedCount += counts.importedCount; result.updatedCount += counts.updatedCount;
        options?.onProgress?.(page, pages ?? page + Number(batch.more));
        if (!batch.more) { reachedEnd = true; break; }
        if (!complete && page >= (options?.maxPages ?? 3)) break;
        page++;
      }
      if (reachedEnd && total !== undefined && seen.size !== total) throw new Error('Order import count does not match the store');
      if (reachedEnd) await setSetting(cursorKey, now);

    } catch (err: any) {
      result.failedCount++;
      result.errors.push(err.message || 'Failed to sync orders from WooCommerce');
    }
  } else if (isDemoSession()) {
    // Demo Mode: mark existing local orders as synced
    const allOrders = await db.orders.toArray();
    for (const ord of allOrders) {
      await db.orders.update(ord.id, {
        syncStatus: 'SYNCED',
        lastSyncedAt: now,
      });
      result.updatedCount++;
    }
  }

  // Clear pending count in sync store
  useSyncStore.getState().setPendingCount(await db.orders.where('syncStatus').anyOf('PENDING_SYNC', 'SYNC_ERROR').count());

  return result;
}

/**
 * Upserts a batch of remote WooCommerce orders into Dexie atomically.
 * Resolves customerId, line items, coupon discounts, attendedBy, and delivery fields.
 * Idempotent: uses wooId and localTransactionId to prevent any duplicate records.
 */
export async function upsertOrderBatch(
  remoteOrders: any[],
  now: string = new Date().toISOString()
): Promise<{ importedCount: number; updatedCount: number }> {
  let importedCount = 0;
  let updatedCount = 0;

  if (!remoteOrders || remoteOrders.length === 0) {
    return { importedCount, updatedCount };
  }

  await prepareCustomerHistoryRepair();

  // 3. Scoped pre-fetch for product IDs referenced in line items of this batch
  const batchLineProductWooIds = Array.from(
    new Set(remoteOrders.flatMap((ro) => (ro.line_items || []).map((li: any) => Number(li.product_id)).filter(Boolean)))
  ) as number[];
  const localProducts = batchLineProductWooIds.length
    ? await db.products.where('wooId').anyOf(batchLineProductWooIds).toArray()
    : [];
  const productWooMap = new Map<number, number>();
  for (const p of localProducts) {
    if (p.wooId) productWooMap.set(p.wooId, p.id);
  }

  // 4. Atomic batch writes inside a single Dexie transaction
  await db.transaction('rw', [...ORDER_IDENTITY_TABLES, 'customers'], async (tx) => {
    await ensureOrderCustomers(remoteOrders, now);
    const index = customerIndex(await db.customers.toArray());
    for (const ro of remoteOrders) {
      const wooId = Number(ro.id);
      if (!Number.isSafeInteger(wooId) || wooId <= 0) continue;

      let existingOrder = await reconcileOrderCopies(tx, wooId);

      // Fast in-memory check by transaction ID from metadata if created from POS
      if (!existingOrder && Array.isArray(ro.meta_data)) {
        const txMeta = ro.meta_data.find((m: any) => m.key === '_zameria_transaction_id');
        if (txMeta?.value) {
          existingOrder = await db.orders.where('localTransactionId').equals(String(txMeta.value)).first();
        }
      }

      // A cached server refresh must not overwrite unuploaded edits or a local held sale.
      if (existingOrder?.wooId && !remoteOrderIdentity(existingOrder)) continue;

      const orderTotal = toKobo(parseFloat(String(ro.total || 0).replace(/,/g, '')) || 0);
      const refunds = Array.isArray(ro.refunds) ? ro.refunds.reduce((sum: number, refund: any) => sum + Math.abs(Number(refund.total) || 0), 0) : 0;
      const netTotal = ro.zameria_net_total != null ? toKobo(Math.max(0, Number(ro.zameria_net_total) || 0))
        : ro.status === 'refunded' ? 0 : Math.max(0, orderTotal - toKobo(refunds));
      const lineSubtotal = Array.isArray(ro.line_items)
        ? ro.line_items.reduce((sum: number, item: any) => sum + (parseFloat(String(item.subtotal || 0).replace(/,/g, '')) || 0), 0)
        : Number(ro.total) || 0;
      const orderSubtotal = toKobo(ro.subtotal != null ? Number(ro.subtotal) || 0 : lineSubtotal);
      const rawCustomerName =
        [ro.billing?.first_name, ro.billing?.last_name].filter(Boolean).join(' ') || 'Website Customer';
      const customerName = decodeHtmlEntities(rawCustomerName);
      const customerEmail = normalizeEmail(ro.billing?.email);
      const purchaseConfirmed = isPurchasedOrder(ro);
      const orderStatus = (['completed','processing','on-hold','cancelled','refunded','failed','trash','pending'].includes(ro.status)
        ? ro.status : purchaseConfirmed ? 'completed' : 'pending') as Order['status'];

      const attendedByMeta = ro.meta_data?.find((m: any) => m.key === '_zameria_attended_by')?.value;
      const attendedByUserIdMeta = ro.meta_data?.find((m: any) => m.key === '_zameria_attended_by_user_id')?.value;
      const createdByUserIdMeta = ro.meta_data?.find((m: any) => m.key === '_zameria_created_by_user_id')?.value;
      const isPosOrder = ro.meta_data?.some((m: any) => m.key === '_zameria_pos_order' && m.value === 'yes');
      const source: 'pos' | 'website' = isPosOrder ? 'pos' : 'website';

      const attendedBy = isPosOrder
        ? (attendedByMeta || (existingOrder?.attendedBy ?? null))
        : 'Website Order';
      const attendedByUserId = attendedByUserIdMeta
        ? Number(attendedByUserIdMeta)
        : (existingOrder?.attendedByUserId ?? null);
      const createdByUserId = isPosOrder
        ? (createdByUserIdMeta ? Number(createdByUserIdMeta) : (existingOrder?.createdByUserId ?? attendedByUserId))
        : null;

      const shippingMethod = ro.shipping_lines?.[0]?.method_title || (source === 'pos' ? 'in-store' : 'Online Delivery');
      const itemCount = ro.line_items?.reduce((acc: number, item: any) => acc + (item.quantity || 1), 0) || 1;
      const couponDiscount = toKobo(parseFloat(String(ro.discount_total || 0).replace(/,/g, '')) || 0);
      const couponCode = ro.coupon_lines?.[0]?.code || null;
      const couponLines = Array.isArray(ro.coupon_lines)
        ? ro.coupon_lines.map((cl: any) => ({
          code: cl.code,
          discount: toKobo(parseFloat(String(cl.discount || 0).replace(/,/g, '')) || 0),
        }))
        : [];

      // Link customerId by wooCustomerId or customerEmail
      const rawWooCustId = ro.customer_id ? Number(ro.customer_id) : null;
      const wooCustomerId = rawWooCustId && rawWooCustId > 0 ? rawWooCustId : null;
      const purchaserKey = typeof ro.zameria_purchaser_key === 'string' ? ro.zameria_purchaser_key : undefined;
      const customerId = resolveOrderCustomer({ wooCustomerId, customerEmail, customerName, customerId: null, purchaserKey }, index)
        ?? (!wooCustomerId && !customerEmail ? (await db.customers.filter(c => c.guestOrderId === wooId).first())?.id ?? null : null);

      // Extract Customer Phone & Delivery Details for Website Orders
      const customerPhone = ro.billing?.phone || ro.shipping?.phone || '';
      const rawShip = (ro.shipping?.address_1 || ro.shipping?.city) ? ro.shipping : ro.billing;
      const deliveryAddress = isPosOrder || !rawShip ? undefined : {
        first_name: rawShip.first_name || '',
        last_name: rawShip.last_name || '',
        company: rawShip.company || '',
        address_1: rawShip.address_1 || '',
        address_2: rawShip.address_2 || '',
        city: rawShip.city || '',
        state: rawShip.state || '',
        postcode: rawShip.postcode || '',
        country: rawShip.country || '',
        phone: rawShip.phone || customerPhone || '',
      };
      const formattedDeliveryAddress = isPosOrder || !deliveryAddress
        ? undefined
        : [
          deliveryAddress.address_1,
          deliveryAddress.address_2,
          deliveryAddress.city,
          deliveryAddress.state,
          deliveryAddress.country,
        ]
          .filter(Boolean)
          .join(', ');

      if (existingOrder) {
        // Reconcile and update without creating duplicates
        await db.orders.update(existingOrder.id, {
          wooId,
          orderNumber: `#${ro.number || wooId}`,
          createdAt: ro.date_created || existingOrder.createdAt,
          paymentMethod: ro.payment_method || existingOrder.paymentMethod,
          paymentMethodTitle: ro.payment_method_title || existingOrder.paymentMethodTitle,
          customerNote: ro.customer_note || '',
          syncStatus: 'SYNCED',
          remoteVersion: ro.date_modified || now,
          status: orderStatus,
          remoteStatus: ro.status,
          purchaseConfirmed,
          netTotal,
          purchaserKey,
          total: orderTotal,
          subtotal: orderSubtotal,
          couponDiscount,
          couponCode,
          couponLines,
          customerId,
          wooCustomerId,
          customerName,
          customerEmail,
          customerPhone,
          deliveryAddress,
          formattedDeliveryAddress,
          source,
          createdByUserId,
          attendedBy,
          attendedByUserId,
          shippingMethod,
          itemCount,
          lastSyncedAt: now,
          updatedAt: ro.date_modified || now,
          completedAt: orderStatus === 'completed' ? ro.date_completed || ro.date_modified || now : null,
        });

        // Refresh the remote snapshot so edited orders do not retain stale items.
        if (Array.isArray(ro.line_items)) {
          await db.orderItems.where('orderId').equals(existingOrder.id).delete();
          for (const item of ro.line_items) {
            const itemWooProdId = item.product_id ? Number(item.product_id) : null;
            const matchedLocalProductId = itemWooProdId ? (productWooMap.get(itemWooProdId) ?? 0) : 0;
            await db.orderItems.add({
              orderId: existingOrder.id,
              productId: matchedLocalProductId,
              wooProductId: itemWooProdId,
              wooVariationId: Number(item.variation_id) || null,
              name: decodeHtmlEntities(item.name || 'Product'),
              sku: item.sku || '',
              price: toKobo(parseFloat(String(item.price || 0).replace(/,/g, '')) || 0),
              quantity: item.quantity || 1,
              subtotal: toKobo(parseFloat(String(item.subtotal || 0).replace(/,/g, '')) || 0),
              total: toKobo(parseFloat(String(item.total || 0).replace(/,/g, '')) || 0),
              discount: null,
              image: item.image?.src || '',
            } as OrderItem);
          }
        }
        updatedCount++;
      } else {
        // Insert new order
        const newOrderId = await db.orders.add({
          wooId,
          localTransactionId: `woo-order-${wooId}`,
          orderNumber: ro.number ? `#${ro.number}` : `#${wooId}`,
          status: orderStatus,
          remoteStatus: ro.status,
          purchaseConfirmed,
          netTotal,
          purchaserKey,
          customerId,
          wooCustomerId,
          customerName,
          customerEmail,
          customerPhone,
          deliveryAddress,
          formattedDeliveryAddress,
          source,
          createdByUserId,
          attendedBy,
          attendedByUserId,
          subtotal: orderSubtotal,
          couponDiscount,
          couponCode,
          couponLines,
          transactionFee: 0,
          total: orderTotal,
          paymentMethod: ro.payment_method || 'online',
          paymentMethodTitle: ro.payment_method_title || 'Online Payment',
          shippingMethod,
          itemCount,
          customerNote: ro.customer_note || '',
          syncStatus: 'SYNCED',
          lastSyncedAt: now,
          localVersion: 1,
          remoteVersion: ro.date_modified || now,
          createdAt: ro.date_created || now,
          updatedAt: ro.date_modified || now,
          completedAt: orderStatus === 'completed' ? ro.date_completed || ro.date_created || now : null,
        } as Order);

        // Insert order line items
        if (Array.isArray(ro.line_items)) {
          for (const item of ro.line_items) {
            const itemWooProdId = item.product_id ? Number(item.product_id) : null;
            const matchedLocalProductId = itemWooProdId ? (productWooMap.get(itemWooProdId) ?? 0) : 0;

            await db.orderItems.add({
              orderId: newOrderId as number,
              productId: matchedLocalProductId,
              wooProductId: itemWooProdId,
              wooVariationId: Number(item.variation_id) || null,
              name: decodeHtmlEntities(item.name || 'Product'),
              sku: item.sku || '',
              price: toKobo(parseFloat(String(item.price || 0).replace(/,/g, '')) || 0),
              quantity: item.quantity || 1,
              subtotal: toKobo(parseFloat(String(item.subtotal || 0).replace(/,/g, '')) || 0),
              total: toKobo(parseFloat(String(item.total || 0).replace(/,/g, '')) || 0),
              discount: null,
              image: item.image?.src || '',
            } as OrderItem);
          }
        }
        importedCount++;
      }
    }
  });

  return { importedCount, updatedCount };
}

/**
 * Cancels an order with role-based security and inventory restoration.
 * Requires 'canCancelOrder' permission (Admin or Shop Manager).
 * Cashiers are rejected with PermissionDeniedError.
 * If the order was completed, restores the stock back to products in Dexie & WooCommerce.
 */
async function restoreLocalStock(productId: number, wooVariationId: number | null, quantity: number): Promise<void> {
  const product = await db.products.get(productId);
  if (!product) return;
  if (wooVariationId && product.variations) {
    await db.products.update(productId, {
      variations: product.variations.map((v) =>
        v.wooId === wooVariationId && v.manageStock && v.stockQuantity !== null
          ? { ...v, stockQuantity: v.stockQuantity + quantity, stockStatus: 'instock' as const }
          : v
      ),
    });
  } else if (product.manageStock && product.stockQuantity !== null) {
    await db.products.update(productId, { stockQuantity: product.stockQuantity + quantity, stockStatus: 'instock' });
  }
}

export async function cancelOrder(orderId: number): Promise<{ success: boolean; error?: string }> {
  // 1. Enforce backend/service-layer role permission
  assertAuthorized('canCancelOrder', 'Cashiers and unauthorized users cannot cancel orders.');

  const order = await db.orders.get(orderId);
  if (!order) {
    throw new Error(`Order #${orderId} not found.`);
  }

  // 1b. Enforce order visibility/ownership boundary
  const currentUser = useAuthStore.getState().user;
  if (!isOrderAccessibleToUser(order, currentUser)) {
    throw new PermissionDeniedError(
      'canCancelOrder',
      currentUser?.role || 'restricted',
      'You are not authorized to access or cancel this order.'
    );
  }

  if (order.status === 'cancelled') {
    return { success: true };
  }

  const previousStatus = order.status;
  const now = new Date().toISOString();

  if (order.wooId && !isDemoSession()) {
    // The store has this order: cancel it there. WooCommerce puts the stock back itself, and the
    // next sync brings the corrected stock to this till.
    const client = getWooClient();
    if (!client || !useConnectionStore.getState().isOnline) {
      throw new Error('Cancelling an uploaded order needs an internet connection.');
    }
    await client.put(`/orders/${order.wooId}`, { status: 'cancelled' });
    await db.orders.update(orderId, { status: 'cancelled', updatedAt: now });
    const token = sessionToken();
    if (token) await pullChanges(token).catch(() => { });
    return { success: true };
  }

  // Not uploaded yet: cancel locally. It will never be sent, so give the stock back on this till.
  if (previousStatus === 'completed') {
    const items = await db.orderItems.where('orderId').equals(orderId).toArray();
    for (const item of items) {
      await restoreLocalStock(item.productId, item.wooVariationId ?? null, item.quantity);
    }
  }
  await db.orders.update(orderId, { status: 'cancelled', updatedAt: now });

  return { success: true };
}

/**
 * Fetches and synchronizes orders specifically for a given customer profile on demand.
 * Queries WooCommerce by customer ID and customer email to retrieve all past transactions.
 */
export async function syncOrdersForCustomer(
  customer: Customer
): Promise<{ importedCount: number; updatedCount: number; error?: string }> {
  const client = getWooClient();
  const isOnline = useConnectionStore.getState().isOnline;

  if (!client || !isOnline) {
    return { importedCount: 0, updatedCount: 0, error: 'Device is offline or store client is not connected' };
  }

  await prepareCustomerHistoryRepair();
  customer = await db.customers.get(customer.id) || customer;
  const now = new Date().toISOString(), token = sessionToken();
  const errors: string[] = [], seen = new Set<number>();
  let totalImported = 0, totalUpdated = 0;
  const index = customerIndex(await db.customers.toArray());
  async function fetchPages(params: Record<string, string | number>) {
    let page = 1, pages: number | undefined, total: number | undefined;
    const queryIds = new Set<number>();
    try {
      for (;;) {
        const res = await client!.get<any[]>('/orders', {
          ...params, page, per_page: 50, orderby: 'id', order: 'desc', before: now, dates_are_gmt: 'true',
        });
        if (sessionToken() !== token) throw new Error('Store session changed');
        const batch = validateImportPage(res.data, page, 50, res.totalPages, res.totalItems);
        pages = checkImportSnapshot(pages, batch.totalPages);
        total = checkImportSnapshot(total, batch.totalItems);
        for (const row of batch.rows) {
          if (queryIds.has(Number(row.id))) throw new Error('Duplicate history page');
          queryIds.add(Number(row.id));
        }
        const matching = batch.rows.filter(ord => {
          const id = Number(ord.customer_id) || null;
          const email = normalizeEmail(ord.billing?.email);
          const matches = customer.guestOrderId ? Number(ord.id) === customer.guestOrderId
            : resolveOrderCustomer({ wooCustomerId: id, customerEmail: email, customerId: null, customerName: '' }, index) === customer.id;
          return matches;
        });
        const counts = await upsertOrderBatch(matching, now);
        totalImported += counts.importedCount; totalUpdated += counts.updatedCount;
        matching.forEach(order => seen.add(Number(order.id)));
        if (!batch.more) break;
        page++;
      }
      if (total !== undefined && queryIds.size !== total) throw new Error('History count does not match the store');
    } catch (err) { errors.push(err instanceof Error ? err.message : 'Failed fetching customer history'); }
  }
  if (customer.wooId && customer.wooId > 0) await fetchPages({ customer: customer.wooId });
  const email = normalizeEmail(customer.email);
  // Older plugins may ignore this optimization. We still paginate and filter the
  // complete guest result locally, so generic text search cannot miss a buyer.
  if (email) await fetchPages({ customer: 0, zameria_billing_email: email });
  if (customer.guestOrderId) await fetchPages({ include: customer.guestOrderId });
  if (!errors.length && (customer.wooId || email || customer.guestOrderId)) {
    await db.customers.update(customer.id, { orderHistorySyncedAt: now, historyOrderIds: [...seen] });
  }
  return { importedCount: totalImported, updatedCount: totalUpdated,
    ...(errors.length ? { error: `Order history is incomplete: ${errors.join('; ')}` } : {}),
  };
}
