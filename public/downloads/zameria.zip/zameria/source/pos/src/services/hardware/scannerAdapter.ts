/**
 * ZAMERIA Hardware Barcode Scanner Adapter
 * 
 * Provides unified barcode scanning:
 * 1. High-speed USB and Bluetooth HID barcode scanner wedge listener.
 * 2. Native Camera / ML Kit scanner status bridge.
 */

import type { IScannerService } from './types';

export class HardwareScannerAdapter implements IScannerService {
  private buffer = '';
  private lastKeyTime = 0;
  private readonly MAX_INTER_KEY_DELAY_MS = 60; // Barcode scanners type at 10-30ms per char
  private readonly MIN_BARCODE_LENGTH = 3;

  public startKeyboardListener(onScan: (barcode: string) => void): () => void {
    if (typeof window === 'undefined') return () => {};

    const handleKeyDown = (e: KeyboardEvent) => {
      // Ignore modifier keys
      if (e.ctrlKey || e.altKey || e.metaKey) return;

      const now = Date.now();
      const timeSinceLastKey = now - this.lastKeyTime;
      this.lastKeyTime = now;

      // Reset buffer if delay exceeds threshold (means human is typing, or scanner finished previous stream)
      if (timeSinceLastKey > this.MAX_INTER_KEY_DELAY_MS && this.buffer.length > 0) {
        this.buffer = '';
      }

      if (e.key === 'Enter' || e.key === 'Tab') {
        const trimmed = this.buffer.trim();
        if (trimmed.length >= this.MIN_BARCODE_LENGTH) {
          // If the active element is an input, prevent Enter from submitting the parent form
          const active = document.activeElement as HTMLElement | null;
          const isTargetInput = active && (active.tagName === 'INPUT' || active.tagName === 'TEXTAREA');

          // If the scanner typed into an input or into nowhere, dispatch barcode
          onScan(trimmed);
          this.buffer = '';
          if (!isTargetInput) {
            e.preventDefault();
          }
        } else {
          this.buffer = '';
        }
        return;
      }

      // Collect single printable characters
      if (e.key.length === 1) {
        this.buffer += e.key;
      }
    };

    window.addEventListener('keydown', handleKeyDown, { capture: true });

    return () => {
      window.removeEventListener('keydown', handleKeyDown, { capture: true });
    };
  }

  public isNativeScannerAvailable(): boolean {
    const cap = typeof window !== 'undefined' ? (window as any).Capacitor : null;
    return Boolean(cap?.Plugins?.BarcodeScanner || cap?.Plugins?.MLKitBarcodeScanner);
  }
}

export const hardwareScanner = new HardwareScannerAdapter();
