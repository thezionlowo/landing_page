import { db, setSetting } from '@/db';
import type { Customer, Order, AuthUser } from '@/types';
import { customerIndex, customerOrderStats, resolveOrderCustomer } from './customerIdentity';
import { customersForOrders } from './customerLookup';
import { isOrderAccessibleToUser } from '@/services/auth/orderAccess';
import { syncScope, singleFlight, yieldToUI } from './syncCoordinator';
import { useAuthStore } from '@/store/authStore';

export type CustomerStats = Omit<ReturnType<typeof customerOrderStats>, 'lastOrderDate'> & { lastOrderDate: string | null };
export interface CustomerSummaryRow {
 scope: string; customerId: number; customer: Customer; stats: CustomerStats;
 name: string; totalSpent: number; purchaseCount: number; orderCount: number; lastOrderDate: number; createdAt: number;
}
let generation = 0;
let installed = false, activeScope = '', timer: ReturnType<typeof setTimeout> | undefined;
const dirty = new Set<number>();
function row(customer: Customer, stats: CustomerStats, scope: string): CustomerSummaryRow {
 return { scope, customerId:customer.id, customer, stats,
  name:`${customer.firstName || ''} ${customer.lastName || ''}`.trim().toLowerCase(),
  totalSpent:stats.totalSpent, purchaseCount:stats.purchaseCount, orderCount:stats.orderCount,
  lastOrderDate:Date.parse(stats.lastOrderDate || '') || 0, createdAt:Date.parse(customer.createdAt) || 0 };
}
function safeProfile(c: Customer, user: AuthUser): Customer {
 return user.permissions.canViewAllOrders && !c.remoteDeleted ? c : {...c,purchasesCount:undefined,ordersCount:undefined,totalSpent:undefined};
}
/** Indexed detail query, never a directory-wide scan. */
export async function ordersForCustomer(customer: Customer, user: AuthUser): Promise<Order[]> {
 const matches = (await Promise.all([
  db.orders.where('customerId').equals(customer.id).toArray(),
  customer.wooId ? db.orders.where('wooCustomerId').equals(customer.wooId).toArray() : [],
  customer.email ? db.orders.where('customerEmail').equalsIgnoreCase(customer.email).toArray() : [],
  customer.guestOrderId ? db.orders.where('wooId').equals(customer.guestOrderId).toArray() : [],
 ])).flat();
 const orders = [...new Map(matches.map(o => [o.id,o])).values()];
 const index = customerIndex(await customersForOrders(orders));
 const ids = customer.orderHistorySyncedAt && customer.historyOrderIds ? new Set(customer.historyOrderIds) : null;
 return orders.filter(o => isOrderAccessibleToUser(o,user) && resolveOrderCustomer(o,index) === customer.id &&
  (!ids || !o.wooId || ids.has(o.wooId) || Date.parse(o.updatedAt)>Date.parse(customer.orderHistorySyncedAt!)))
  .sort((a,b)=>Date.parse(b.createdAt)-Date.parse(a.createdAt) || b.id-a.id);
}
async function project(id: number, scope: string, user: AuthUser) {
 const customer = await db.customers.get(id);
 if (!customer) { await db.customerSummaries.delete([scope,id]); return; }
 const orders = await ordersForCustomer(customer,user);
 if (activeScope !== scope || syncScope() !== scope) return;
 await db.customerSummaries.put(row(customer,customerOrderStats(safeProfile(customer,user),orders),scope));
}
function enqueue(id: number) {
 if (!activeScope || !Number.isSafeInteger(id) || id < 1) return;
 dirty.add(id);
 if (timer) return;
 timer=setTimeout(()=>{timer=undefined;void drain().catch(error=>console.warn('Customer summary refresh will retry:',error));},100);
}
async function drain() {
 const scope=activeScope,user=useAuthStore.getState().user;if (!scope || !user) return;
 return singleFlight('customer-projection',async()=>{
  while(dirty.size && activeScope===scope && syncScope()===scope) {
   const ids=[...dirty].slice(0,25);ids.forEach(id=>dirty.delete(id));
   for(const id of ids) { try { await project(id,scope,user); } catch(error) { dirty.add(id); throw error; } }
   await yieldToUI();
  }
 });
}
async function changedOrder(order: Order) {
 if (!activeScope) return;
 const customers=await customersForOrders([order]);
 customers.forEach(c=>enqueue(c.id));
 if(order.customerId) enqueue(order.customerId);
}
function installHooks() {
 if(installed)return;installed=true;
 db.customers.hook('creating',function(_key,_value,tx){ this.onsuccess=(key)=>tx.on('complete',()=>enqueue(Number(key))); });
 db.customers.hook('updating',(_changes,key,_customer,tx)=>{tx.on('complete',()=>enqueue(Number(key)));});
 db.customers.hook('deleting',(key,_customer,tx)=>{tx.on('complete',()=>enqueue(Number(key)));});
 db.orders.hook('creating',(_key,order,tx)=>{tx.on('complete',()=>{void changedOrder(order).catch(()=>{});});});
 db.orders.hook('updating',(changes,_key,order,tx)=>{tx.on('complete',()=>{void changedOrder(order).catch(()=>{});void changedOrder({...order,...changes}).catch(()=>{});});});
 db.orders.hook('deleting',(_key,order,tx)=>{tx.on('complete',()=>{void changedOrder(order).catch(()=>{});});});
}
/** One streaming cache projection per authenticated scope. Later commits touch affected buyers only. */
export function startCustomerProjection(user: AuthUser): () => void {
 installHooks();const scope=syncScope(), epoch=++generation;activeScope=scope;
 let retry:ReturnType<typeof setTimeout>|undefined;
 const initialize=()=>{
  if(generation!==epoch||activeScope!==scope)return;
  void bootstrap(scope,user,epoch).catch(error=>{
   if(generation!==epoch||activeScope!==scope)return;
   console.warn('Customer summary initialization will retry:',error);
   retry=setTimeout(initialize,30000);
  });
 };
 initialize();
 return ()=>{if(retry)clearTimeout(retry);if(activeScope===scope&&generation===epoch){generation++;activeScope='';dirty.clear();if(timer)clearTimeout(timer);timer=undefined;}};
}
async function bootstrap(scope: string,user:AuthUser,epoch:number) {
 if(generation!==epoch||activeScope!==scope)return;
 // Identity maps are linear in customer count; order rows are streamed in bounded pages.
 await setSetting(`customer_projection_ready:${scope}`,'0');
 const customers:Customer[]=[];let key=0;
 for(;;){const page=await db.customers.where('id').above(key).limit(500).toArray();if(!page.length)break;customers.push(...page);key=page.at(-1)!.id;await yieldToUI();if(activeScope!==scope||generation!==epoch)return;}
 const index=customerIndex(customers);
 type Acc={count:number;purchased:number;paid:number;spent:number;last:string|null};
 const aggregate=new Map<number,Acc>(), historyIds=new Map<number,Set<number>>();
 for(const c of customers)if(c.orderHistorySyncedAt&&c.historyOrderIds)historyIds.set(c.id,new Set(c.historyOrderIds));
 key=0;
 for(;;){
  const page=await db.orders.where('id').above(key).limit(500).toArray();if(!page.length)break;
  for(const order of page){
   if(!isOrderAccessibleToUser(order,user))continue;
   const id=resolveOrderCustomer(order,index);if(id===null)continue;
   const c=index.byId.get(id)!;const verified=historyIds.get(id);
   if(verified&&order.wooId&&!verified.has(order.wooId)&&Date.parse(order.updatedAt)<=Date.parse(c.orderHistorySyncedAt!))continue;
   const a=aggregate.get(id)||{count:0,purchased:0,paid:0,spent:0,last:null};a.count++;
   const purchase=order.purchaseConfirmed||['completed','processing','refunded'].includes(order.status);
   if(purchase)a.purchased++;
   if(order.status!=='refunded'&&(order.purchaseConfirmed||['completed','processing'].includes(order.status))){a.paid++;a.spent+=Number.isFinite(order.netTotal)?order.netTotal!:order.total||0;}
   if(Number.isFinite(Date.parse(order.createdAt))&&(!a.last||Date.parse(order.createdAt)>Date.parse(a.last)))a.last=order.createdAt;
   aggregate.set(id,a);
  }
  key=page.at(-1)!.id;await yieldToUI();if(activeScope!==scope||syncScope()!==scope||generation!==epoch)return;
 }
 for(let n=0;n<customers.length;n+=250){
  if(activeScope!==scope||syncScope()!==scope||generation!==epoch)return;
  const rows=customers.slice(n,n+250).map(c=>{
   const profile=safeProfile(c,user),a=aggregate.get(c.id)||{count:0,purchased:0,paid:0,spent:0,last:null};
   const remote=profile.purchasesCount||0,complete=Boolean(historyIds.get(c.id))||(Boolean(profile.orderHistorySyncedAt)&&a.purchased>=remote);
   const purchaseCount=complete?a.purchased:Math.max(remote,a.purchased),totalSpent=complete?a.spent:Math.max(profile.totalSpent||0,a.spent),paid=complete?a.paid:Math.max(profile.ordersCount||0,a.paid);
   return row(c,{purchaseCount,totalSpent,orderCount:complete?a.count:Math.max(profile.ordersCount||0,a.count,purchaseCount),averageOrderValue:paid?Math.round(totalSpent/paid):0,lastOrderDate:a.last},scope);
  });
  await db.customerSummaries.bulkPut(rows);await yieldToUI();
 }
 const keys=await db.customerSummaries.where('[scope+customerId]').between([scope,0],[scope,Infinity],true,true).primaryKeys();
 if(generation!==epoch||activeScope!==scope)return;
 await db.customerSummaries.bulkDelete(keys.filter(([,id])=>!index.byId.has(id)));
 await drain();
 if(activeScope===scope&&generation===epoch)await setSetting(`customer_projection_ready:${scope}`,'1');
}
export async function flushCustomerProjection() { if(timer){clearTimeout(timer);timer=undefined;}await drain(); }

export async function queryCustomerDirectory(scope: string, options: { sort: string; segment: string; search: string; limit: number }) {
 const { default: Dexie } = await import('dexie');
 const column = options.sort.startsWith('spent') ? 'totalSpent' : options.sort.startsWith('orders') ? 'orderCount' : options.sort === 'recent_purchase' ? 'lastOrderDate' : options.sort === 'newest' ? 'createdAt' : 'name';
 let query = db.customerSummaries.where(`[scope+${column}]`).between([scope,Dexie.minKey],[scope,Dexie.maxKey]);
 if(options.sort.endsWith('desc') || ['recent_purchase','newest'].includes(options.sort)) query=query.reverse();
 const q=options.search.trim().toLowerCase(), digits=q.replace(/\D/g,''),now=Date.now();
 return query.filter(r=>{
  const c=r.customer,s=r.stats;if(s.purchaseCount<1)return false;
  if(c.email?.endsWith('@store.local')&&!c.wooId)return false;
  if(!c.wooId&&!c.firstName?.trim()&&!c.lastName?.trim()&&!c.email?.trim()&&!c.billing?.phone?.trim())return false;
  if(q && ![c.firstName,c.lastName,`${c.firstName} ${c.lastName}`,c.email,c.billing?.city,c.billing?.phone].some(v=>String(v||'').toLowerCase().includes(q)) && !(digits.length>=3&&String(c.billing?.phone||'').replace(/\D/g,'').includes(digits)))return false;
  if(options.segment==='high_value'&&s.totalSpent<5000000)return false;
  if(options.segment==='regular'&&s.orderCount<2)return false;
  if(options.segment==='one_time'&&s.orderCount!==1)return false;
  if(options.segment==='recent'&&r.lastOrderDate<now-30*86400000)return false;
  if(options.segment==='inactive'&&r.lastOrderDate>=now-60*86400000)return false;
  return true;
 }).limit(options.limit).toArray();
}
