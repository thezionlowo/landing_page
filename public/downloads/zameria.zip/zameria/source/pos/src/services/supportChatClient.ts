/**
 * ZAMERIA Unified Support Chat Client Service
 * Connects POS and Customer Dashboard directly to Central Admin Support Inbox
 */

export interface SupportMessage {
  id: string;
  conversationId: string;
  senderType: 'customer' | 'support' | 'system';
  senderId?: string;
  senderName: string;
  message: string;
  createdAt: string;
  isInternalNote?: boolean;
}

export type SupportSource = 'POS' | 'WooCommerce Plugin' | 'Customer Dashboard' | 'Website';
export type SupportConversationStatus = 'Open' | 'In Progress' | 'Waiting for Customer' | 'Resolved';

export interface SupportConversation {
  id: string;
  customerId: string | null;
  businessName: string;
  customerName: string;
  email: string;
  phone?: string;
  plan?: string;
  storeUrl?: string;
  pluginVersion?: string;
  source: SupportSource;
  status: SupportConversationStatus;
  assignedStaffId: string | null;
  assignedStaffName: string | null;
  createdAt: string;
  updatedAt: string;
  lastMessageAt: string;
  lastMessage: string;
  lastMessageSender: 'customer' | 'support' | 'system';
  unreadBySupport: number;
  unreadByCustomer: number;
  messages: SupportMessage[];
}


import { zameriaApi } from './zameria/api';
import { sessionToken } from './zameria/session';
function token(): string { const value=sessionToken(); if(!value)throw new Error('Connect to your store to contact support.');return value; }
let unread=0;let unreadToken='';
function clean(conv: SupportConversation | null): SupportConversation | null { const current=sessionToken() || '';const count=conv?.unreadByCustomer || 0;if(unread!==count || unreadToken!==current){unread=count;unreadToken=current;if(typeof window!=='undefined')window.dispatchEvent(new CustomEvent('zameria_support_update'));}return conv ? {...conv,messages:(conv.messages || []).filter(m=>!m.isInternalNote)}:null; }
async function request(operation: (auth:string)=>Promise<{conversation:SupportConversation|null}>):Promise<SupportConversation|null> {
  const auth=token();const response=await operation(auth);
  if(sessionToken()!==auth) throw new Error('Your staff session changed. Please reopen support.');
  return clean(response.conversation);
}
export const supportChatClient = {
  getUnreadCount():number { return unreadToken===sessionToken()?unread:0; },
  async getConversation(_id?: string): Promise<SupportConversation | null> { return request(auth=>zameriaApi.supportConversation(auth)); },
  async getOrCreateConversation(params: {initialMessage: string}): Promise<SupportConversation | null> { return request(auth=>zameriaApi.supportStart(auth,params.initialMessage)); },
  async sendMessage(_id: string,message: string,_name?:string,_customer?:string): Promise<SupportConversation | null> { return request(auth=>zameriaApi.supportConversation(auth,{message})); },
  async markAsReadByCustomer(_id: string): Promise<void> { await request(auth=>zameriaApi.supportConversation(auth,{action:'read'})); },
  async resolveConversation(_id: string): Promise<void> { await request(auth=>zameriaApi.supportConversation(auth,{action:'resolve'})); },
  sanitizeForCustomer(conv: SupportConversation): SupportConversation { return clean(conv)!; },
};
