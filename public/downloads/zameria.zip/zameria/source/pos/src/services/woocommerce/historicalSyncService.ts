/** Resumable import through the existing customer and WooCommerce order APIs. */
import { getWooClient } from './client';
import { useConnectionStore } from '@/store/connectionStore';
import { useSyncStore } from '@/store/syncStore';
import { useAuthStore } from '@/store/authStore';
import { zameriaConfig } from '@/services/zameria/config';
import { sessionToken } from '@/services/zameria/session';
import { syncAllCustomers } from './customerService';
import { upsertOrderBatch } from './orderSyncService';
import { prepareCustomerHistoryRepair } from './customerSyncMigration';
import { validateImportPage, checkImportSnapshot } from './pagination';

export interface HistoricalSyncCheckpoint {
  version?: number;
  scope?: string;
  status: 'idle' | 'in_progress' | 'completed' | 'error';
  phase: 'idle' | 'operational_ready' | 'syncing_customers' | 'syncing_orders' | 'completed';
  lastCustomerPage: number;
  totalCustomerPages: number;
  totalCustomersImported: number;
  customersComplete?: boolean;
  ordersComplete?: boolean;
  cutoffDate: string | null;
  lastOrderPage: number;
  totalOrderPages: number;
  totalOrderItems?: number;
  lastOrderId?: number;
  totalOrdersReceived?: number;
  totalOrdersImported: number;
  oldestOrderDate: string | null;
  newestOrderDate: string | null;
  lastRunAt: string | null;
  completedAt: string | null;
  error?: string | null;
}
const STORAGE_KEY = 'zameria_historical_sync_checkpoint';
const VERSION = 2;
const defaults = (): HistoricalSyncCheckpoint => ({
  version: VERSION, scope: scope(), status: 'idle', phase: 'idle',
  lastCustomerPage: 0, totalCustomerPages: 1, totalCustomersImported: 0,
  cutoffDate: null, lastOrderPage: 0, totalOrderPages: 1, totalOrdersImported: 0,
  oldestOrderDate: null, newestOrderDate: null, lastRunAt: null, completedAt: null,
});
function scope(): string {
  const user = useAuthStore.getState().user;
  return `${zameriaConfig.apiRoot}|${user?.id || 0}|${Number(Boolean(user?.permissions?.canViewAllOrders))}`;
}
export class HistoricalSyncService {
  private running: Promise<HistoricalSyncCheckpoint> | null = null;
  private shouldPause = false;
  getCheckpoint(): HistoricalSyncCheckpoint {
    try {
      const saved = JSON.parse(localStorage.getItem(STORAGE_KEY) || 'null');
      if (saved?.version === VERSION && saved.scope === scope()) return { ...defaults(), ...saved };
    } catch { /* First run or old/corrupt checkpoint: recheck without deleting data. */ }
    return defaults();
  }
  saveCheckpoint(patch: Partial<HistoricalSyncCheckpoint>): HistoricalSyncCheckpoint {
    const value = { ...this.getCheckpoint(), ...patch, lastRunAt: new Date().toISOString() };
    // A failed checkpoint write must not be reported as a successful durable import.
    localStorage.setItem(STORAGE_KEY, JSON.stringify(value));
    return value;
  }
  resetCheckpoint(): void { localStorage.removeItem(STORAGE_KEY); }
  pause(): void { this.shouldPause = true; }
  isCompleted(): boolean { return this.getCheckpoint().status === 'completed'; }
  startHistoricalSync(options?: { force?: boolean }): Promise<HistoricalSyncCheckpoint> {
    this.running ??= this.run(options).finally(() => { this.running = null; });
    return this.running;
  }
  private async run(options?: { force?: boolean }): Promise<HistoricalSyncCheckpoint> {
    const client = getWooClient();
    if (!useConnectionStore.getState().isOnline) return this.getCheckpoint();
    if (!client) return { ...this.getCheckpoint(), status: 'error', error: 'Store client is not connected; history will retry after connection' };
    const identity = scope(), token = sessionToken();
    const guard = () => {
      if (scope() !== identity || sessionToken() !== token) throw new Error('Store session changed during history import');
    };
    await prepareCustomerHistoryRepair();
    guard();
    if (options?.force) this.resetCheckpoint();
    let checkpoint = this.getCheckpoint();
    if (checkpoint.status === 'completed') return checkpoint;
    this.shouldPause = false;
    checkpoint = this.saveCheckpoint({ status: 'in_progress', error: null });
    const sync = useSyncStore.getState();
    let profileError: string | undefined;
    try {
      if (this.shouldPause) return this.saveCheckpoint({ status: 'idle' });
      // A fixed upper bound covers ALL history, including the most recent week.
      // The live order delta continues to pick up newer orders independently.
      const cutoff = checkpoint.cutoffDate || new Date().toISOString();
      checkpoint = this.saveCheckpoint({ phase: 'syncing_orders', cutoffDate: cutoff });
      let page = checkpoint.lastOrderPage + 1;
      let pages = checkpoint.lastOrderPage ? checkpoint.totalOrderPages : undefined;
      let total = checkpoint.totalOrderItems;
      while (!checkpoint.ordersComplete) {
        guard();
        const response = await client.get<any[]>('/orders', {
          per_page: 50, page, before: cutoff, dates_are_gmt: 'true', orderby: 'id', order: 'asc',
        });
        guard();
        const batch = validateImportPage(response.data, page, 50, response.totalPages, response.totalItems);
        // Unknown totals are represented by an estimate for UI progress, never EOF.
        if (response.totalPages && checkpoint.lastOrderPage) pages = checkImportSnapshot(pages, batch.totalPages);
        else pages = batch.totalPages;
        total = checkImportSnapshot(total, batch.totalItems);
        let previous = checkpoint.lastOrderId || 0;
        for (const order of batch.rows) {
          if (Number(order.id) <= previous) throw new Error('Order pages did not advance; restart required');
          previous = Number(order.id);
        }
        const counts = await upsertOrderBatch(batch.rows);
        guard();
        const dates = batch.rows.map(order => order.date_created_gmt || order.date_created).filter(Boolean);
        const allDates = [...dates, checkpoint.oldestOrderDate, checkpoint.newestOrderDate].filter(Boolean).sort();
        checkpoint = this.saveCheckpoint({
          lastOrderPage: page, totalOrderPages: pages ?? page + Number(batch.more), totalOrderItems: total,
          totalOrdersReceived: (checkpoint.totalOrdersReceived || 0) + batch.rows.length, lastOrderId: previous,
          totalOrdersImported: checkpoint.totalOrdersImported + counts.importedCount,
          oldestOrderDate: allDates[0] || null, newestOrderDate: allDates.at(-1) || null,
        });
        sync.updateEntityProgress('orders', page, checkpoint.totalOrderPages, `Importing order history: page ${page}`);
        if (this.shouldPause) return this.saveCheckpoint({ status: 'idle' });
        if (!batch.more) { checkpoint = this.saveCheckpoint({ ordersComplete: true }); break; }
        page++;
        await new Promise(resolve => setTimeout(resolve, 40));
      }
      if (total !== undefined && checkpoint.totalOrdersReceived !== total) throw new Error('Order count does not match the store; restart required');
      if (!checkpoint.customersComplete) {
        checkpoint = this.saveCheckpoint({ phase: 'syncing_customers' });
        const profiles = await syncAllCustomers({ startPage: checkpoint.lastCustomerPage + 1,
          onPage: (page, pages, more) => {
            guard();
            checkpoint = this.saveCheckpoint({ lastCustomerPage: page, totalCustomerPages: pages ?? page + Number(more) });
          },
          onProgress: (page, pages) => sync.updateEntityProgress('customers', page, pages),
        });
        guard();
        checkpoint = this.saveCheckpoint({ totalCustomersImported: checkpoint.totalCustomersImported + profiles.importedCount });
        if (profiles.failedCount) profileError = profiles.errors.join('; ');
        else checkpoint = this.saveCheckpoint({ customersComplete: true });
      }
      if (profileError) throw new Error(`Order history imported; customer profiles need retry: ${profileError}`);
      const completedAt = new Date().toISOString();
      checkpoint = this.saveCheckpoint({ status: 'completed', phase: 'completed', completedAt, error: null });
      sync.recordEntitySyncSuccess('orders', completedAt);
      sync.recordEntitySyncSuccess('customers', completedAt);
      return checkpoint;
    } catch (error: any) {
      if (scope() !== identity || sessionToken() !== token) return { ...checkpoint, status: 'error', error: 'Store session changed' };
      const message = error?.message || 'History import interrupted';
      // Deleted/reordered source pages must be re-read, rather than skipping records.
      const restart = /restart required|total changed/.test(message);
      return this.saveCheckpoint({ status: 'error', error: message,
        ...(restart ? { lastOrderPage: 0, lastOrderId: 0, totalOrdersReceived: 0, totalOrderItems: undefined, ordersComplete: false } : {}),
      });
    }
  }
}
export const historicalSyncService = new HistoricalSyncService();
