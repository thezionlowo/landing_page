import { setWooClient, clearWooClient } from '@/services/woocommerce/client';
import { OfflineError, ZameriaApiError, zameriaApi, type PluginUser } from '@/services/zameria/api';
import { demoLoginEnabled, zameriaConfig, setStoreConnection } from '@/services/zameria/config';
import { connectStore, discoverStore } from '@/services/zameria/storeConnect';
import type { AuthUser, RolePermissions } from '@/types';
import { PermissionDeniedError } from '@/types';
import { useAuthStore } from '@/store/authStore';

export * from './permissions';
export * from './orderAccess';
import { DEMO_USERS, resolveRoleAndPermissions } from './permissions';
import { saveStoreLogo } from '@/services/storeLogoService';
import { setStoreCurrency } from '@/lib';

// ============================================================================
// SERVICE-LEVEL AUTHORIZATION CHECK
// ============================================================================

/**
 * Enforces authorization at the service level so the UI can explain a refusal early.
 * The store enforces the same rules again server-side for every request.
 */
export function assertAuthorized(permission: keyof RolePermissions, customMessage?: string): void {
  const { user, isAuthenticated } = useAuthStore.getState();

  if (!isAuthenticated || !user) {
    throw new PermissionDeniedError(
      permission,
      'restricted',
      customMessage || 'Authentication required: User is not logged into Zameria.'
    );
  }

  if (!user.permissions[permission]) {
    throw new PermissionDeniedError(
      permission,
      user.role,
      customMessage || `Access denied: Role '${user.roleLabel}' is not authorized to perform '${String(permission)}'.`
    );
  }
  if (permission === 'canCompleteSale' && user.token && !activeStoreAccess(user.entitlement)) {
    throw new Error('Active store access is required to start a sale. Your queued sales are preserved.');
  }
}

export function activeStoreAccess(entitlement?: AuthUser['entitlement']): boolean {
  if (!entitlement?.is_licensed || !['trial_active','paid_active','gifted_active'].includes(entitlement.status)) return false;
  const end = entitlement.status === 'trial_active' ? entitlement.trial_end : entitlement.license_expires_at;
  if (entitlement.offline_until && !(Date.parse(entitlement.offline_until) > Date.now())) return false;
  return Boolean(end && Number.isFinite(Date.parse(end)) && Date.parse(end) > Date.now());
}

// ============================================================================
// AUTHENTICATION & REVALIDATION SERVICES
// ============================================================================

export interface LoginCredentials {
  username: string;
  password?: string;
  /** The WooCommerce store address (e.g. https://mystore.com) */
  storeUrl?: string;
  /** Name for this register, shown in WooCommerce > Zameria POS > Signed-in devices. */
  deviceName?: string;
  deviceId?: number;
  demoProfile?: 'admin' | 'manager' | 'cashier' | 'custom';
}

export { demoLoginEnabled };

function toAuthUser(pluginUser: PluginUser, extra: Partial<AuthUser>): AuthUser {
  const resolved = resolveRoleAndPermissions(pluginUser.roles, pluginUser.capabilities);
  return {
    id: pluginUser.id,
    username: pluginUser.username,
    displayName: pluginUser.name || pluginUser.username,
    email: pluginUser.email,
    wooRoles: pluginUser.roles,
    wooCapabilities: pluginUser.capabilities,
    role: resolved.role,
    roleLabel: resolved.roleLabel,
    permissions: resolved.permissions,
    lastValidatedAt: new Date().toISOString(),
    storeUrl: zameriaConfig.storeUrl,
    storeName: zameriaConfig.storeName,
    ...extra,
  };
}

/** Points the WooCommerce client at the store using this session's device token. */
export function connectWooClient(user: AuthUser | null): void {
  if (user?.token) {
    setWooClient({ url: user.storeUrl || zameriaConfig.storeUrl, restRoot: zameriaConfig.restRoot, token: user.token });
  } else {
    clearWooClient();
  }
}

/**
 * Signs a staff member in with their WordPress username and password. The plugin checks the
 * password and returns a device token plus the user's real roles.
 */
export async function authenticateUser(credentials: LoginCredentials): Promise<AuthUser> {
  if (credentials.demoProfile && demoLoginEnabled() && DEMO_USERS[credentials.demoProfile]) {
    return { ...DEMO_USERS[credentials.demoProfile], lastValidatedAt: new Date().toISOString() };
  }

  const username = credentials.username.trim();
  if (!username || !credentials.password) {
    throw new Error('Username and password are required.');
  }

  // If a store URL is provided, ensure store connection targets this WordPress store
  if (credentials.storeUrl?.trim()) {
    let rawStore = credentials.storeUrl.trim();
    if (!/^https?:\/\//i.test(rawStore)) {
      rawStore = `https://${rawStore}`;
    }
    const cleanStoreUrl = rawStore.replace(/\/+$/, '') + '/';

    let discovered;
    try {
      discovered = await discoverStore(cleanStoreUrl);
    } catch {
      let hostName = 'Store';
      try {
        hostName = new URL(cleanStoreUrl).hostname;
      } catch {}
      discovered = {
        restRoot: `${cleanStoreUrl}wp-json/`,
        apiRoot: `${cleanStoreUrl}wp-json/zameria/v1/`,
        storeUrl: cleanStoreUrl,
        storeName: hostName,
      };
    }
    if (zameriaConfig.servedByPlugin) setStoreConnection(discovered);
    else await connectStore(discovered);
  }

  const SAVED_DEVICE_ID_KEY = 'zameria_saved_device_id';
  const SAVED_DEVICE_NAME_KEY = 'zameria_saved_device_name';
  const savedDeviceId = typeof localStorage !== 'undefined'
    ? Number(localStorage.getItem(SAVED_DEVICE_ID_KEY)) || undefined
    : undefined;
  const targetDeviceId = credentials.deviceId || savedDeviceId;
  const targetDeviceName = credentials.deviceName?.trim() || (typeof localStorage !== 'undefined' ? localStorage.getItem(SAVED_DEVICE_NAME_KEY) : null) || 'Register';

  try {
    const res = await zameriaApi.login(username, credentials.password, targetDeviceName, targetDeviceId);
    if (typeof localStorage !== 'undefined' && res.device?.id) {
      try {
        localStorage.setItem(SAVED_DEVICE_ID_KEY, String(res.device.id));
        if (res.device.name) {
          localStorage.setItem(SAVED_DEVICE_NAME_KEY, res.device.name);
        }
      } catch {}
    }
    if (res.currency) {
      setStoreCurrency(res.currency);
    }
    if (res.store?.logo) {
      void saveStoreLogo(res.store.name || zameriaConfig.storeName, res.store.logo);
    }
    return toAuthUser(res.user, {
      token: res.token,
      deviceId: res.device.id,
      deviceName: res.device.name,
      registerId: res.device.id,
      registerName: res.device.name,
      storeName: res.store?.name || zameriaConfig.storeName,
      storeAddress: res.store?.address,
      storeFooter: res.store?.receipt_footer,
      entitlement: res.entitlement,
    });
  } catch (err) {
    if (err instanceof OfflineError) {
      throw new Error('You need an internet connection to sign in. After that the till works offline.');
    }
    if (err instanceof ZameriaApiError && err.status === 404) {
      throw new Error('The Zameria POS plugin was not found on this store. Is it installed and activated?');
    }
    throw err;
  }
}

/** Tells the store to forget this device's token. Best effort: works offline too. */
export async function signOutDevice(user: AuthUser | null): Promise<void> {
  if (!user?.token) return;
  try {
    await zameriaApi.logout(user.token);
  } catch {
    // Offline: the token is dropped locally; an admin can revoke it in WooCommerce > Zameria POS.
  }
}

/**
 * Re-reads the user's roles from the store. A revoked device or user is signed out; being
 * offline keeps the current session so the till keeps working.
 */
export async function revalidateUserSession(
  currentUser: AuthUser
): Promise<{ valid: boolean; updatedUser?: AuthUser; revokedReason?: string }> {
  if (!currentUser.token) {
    // Demo session (development only).
    return { valid: demoLoginEnabled(), updatedUser: { ...currentUser, lastValidatedAt: new Date().toISOString() } };
  }

  try {
    const info = await zameriaApi.bootstrap(currentUser.token);
    if (info.currency) {
      setStoreCurrency(info.currency);
    }
    if (info.store?.logo) {
      void saveStoreLogo(info.store.name || currentUser.storeName, info.store.logo);
    }
    return {
      valid: true,
      updatedUser: toAuthUser(info.user, {
        token: currentUser.token,
        deviceId: info.device.id,
        deviceName: info.device.name,
        registerId: info.device.id,
        registerName: info.device.name,
        storeName: info.store?.name || currentUser.storeName,
        storeAddress: info.store?.address || currentUser.storeAddress,
        storeFooter: info.store?.receipt_footer || currentUser.storeFooter,
        entitlement: info.entitlement || currentUser.entitlement,
      }),
    };
  } catch (err) {
    if (err instanceof ZameriaApiError && (err.status === 401 || (err.status === 403 && err.code === 'zameria_forbidden'))) {
      return { valid: false, revokedReason: err.message };
    }
    return { valid: true, updatedUser: currentUser };
  }
}
