import type { AuthUser, RolePermissions, ZameriaRole } from '@/types';

// ============================================================================
// PERMISSION MATRICES (WooCommerce Role Mappings)
// ============================================================================

export const ADMINISTRATOR_PERMISSIONS: RolePermissions = {
  canAccessPOS: true,
  canAccessDashboard: true,
  canAccessSale: true,
  canAccessOrders: true,
  canAccessCustomers: true,
  canAccessProducts: true,
  canAccessSettings: true,

  canCreateProduct: true,
  canEditProduct: true,
  canDeleteProduct: true,
  canEditProductPrice: true,
  canEditStockManually: true,
  canUploadProductMedia: true,

  canCompleteSale: true,
  canApplyDiscount: true,
  canHoldOrder: true,
  canResumeOrder: true,
  canCancelOrder: true,
  canViewAllOrders: true,
  canRefundOrder: true,

  canManageSettings: true,
  canManageStoreLogo: true,
  canManageWooConnection: true,
  canManageStaff: true,
  canExportData: true,
};

export const SHOP_MANAGER_PERMISSIONS: RolePermissions = {
  canAccessPOS: true,
  canAccessDashboard: true,
  canAccessSale: true,
  canAccessOrders: true,
  canAccessCustomers: true,
  canAccessProducts: true,
  canAccessSettings: true, // Operational settings only

  canCreateProduct: true,
  canEditProduct: true,
  canDeleteProduct: true,
  canEditProductPrice: true,
  canEditStockManually: true,
  canUploadProductMedia: true,

  canCompleteSale: true,
  canApplyDiscount: true,
  canHoldOrder: true,
  canResumeOrder: true,
  canCancelOrder: true,
  canViewAllOrders: true,
  canRefundOrder: true,

  canManageSettings: false, // Cannot access system integration settings
  canManageStoreLogo: true, // Shop Managers can configure store branding and receipt logo
  canManageWooConnection: false, // Cannot change API credentials or store URL
  canManageStaff: false, // Cannot manage staff user roles
  canExportData: true,
};

export const CASHIER_PERMISSIONS: RolePermissions = {
  canAccessPOS: true,
  canAccessDashboard: false,
  canAccessSale: true,
  canAccessOrders: true,
  canAccessCustomers: true,
  canAccessProducts: false, // Products page editing restricted
  canAccessSettings: false, // Settings restricted

  canCreateProduct: false, // Cannot create products
  canEditProduct: false, // Cannot edit products
  canDeleteProduct: false, // Cannot delete products
  canEditProductPrice: false, // Cannot modify selling prices
  canEditStockManually: false, // Cannot manually manipulate inventory levels
  canUploadProductMedia: false,

  canCompleteSale: true,
  canApplyDiscount: true,
  canHoldOrder: true,
  canResumeOrder: true,
  canCancelOrder: false,
  canViewAllOrders: false, // Cashiers can only view their own completed POS sales and shared website orders
  canRefundOrder: false,

  canManageSettings: false,
  canManageStoreLogo: false,
  canManageWooConnection: false,
  canManageStaff: false,
  canExportData: false,
};

export const RESTRICTED_PERMISSIONS: RolePermissions = {
  canAccessPOS: false, // Zero POS access for unauthorized roles
  canAccessDashboard: false,
  canAccessSale: false,
  canAccessOrders: false,
  canAccessCustomers: false,
  canAccessProducts: false,
  canAccessSettings: false,

  canCreateProduct: false,
  canEditProduct: false,
  canDeleteProduct: false,
  canEditProductPrice: false,
  canEditStockManually: false,
  canUploadProductMedia: false,

  canCompleteSale: false,
  canApplyDiscount: false,
  canHoldOrder: false,
  canResumeOrder: false,
  canCancelOrder: false,
  canViewAllOrders: false,
  canRefundOrder: false,

  canManageSettings: false,
  canManageStoreLogo: false,
  canManageWooConnection: false,
  canManageStaff: false,
  canExportData: false,
};

// ============================================================================
// ROLE & PERMISSION RESOLVER
// ============================================================================

export interface ResolvedRole {
  role: ZameriaRole;
  roleLabel: string;
  permissions: RolePermissions;
}

export function resolveRoleAndPermissions(
  wooRoles: string[] = [],
  capabilities: Record<string, boolean> = {}
): ResolvedRole {
  const normalizedRoles = wooRoles.map((r) => r.toLowerCase().trim());

  // 1. Administrator Check
  if (
    normalizedRoles.includes('administrator') ||
    normalizedRoles.includes('admin') ||
    capabilities.manage_options ||
    capabilities.manage_woocommerce
  ) {
    return {
      role: 'administrator',
      roleLabel: 'Administrator',
      permissions: { ...ADMINISTRATOR_PERMISSIONS },
    };
  }

  // 2. Shop Manager Check
  if (
    normalizedRoles.includes('shop_manager') ||
    normalizedRoles.includes('shop-manager') ||
    normalizedRoles.includes('manager') ||
    (capabilities.edit_products && capabilities.publish_products)
  ) {
    return {
      role: 'shop_manager',
      roleLabel: 'Shop Manager',
      permissions: { ...SHOP_MANAGER_PERMISSIONS },
    };
  }

  // 3. Cashier / POS Staff Check
  if (
    normalizedRoles.includes('cashier') ||
    normalizedRoles.includes('pos_staff') ||
    normalizedRoles.includes('pos_cashier') ||
    normalizedRoles.includes('teller') ||
    normalizedRoles.includes('sales_person') ||
    normalizedRoles.includes('clerk')
  ) {
    return {
      role: 'cashier',
      roleLabel: 'Cashier / POS Staff',
      permissions: { ...CASHIER_PERMISSIONS },
    };
  }

  // 4. Custom / Unknown Roles — inspect capabilities or fail safely
  if (capabilities.edit_shop_orders && !capabilities.edit_products) {
    return {
      role: 'cashier',
      roleLabel: `Custom POS Staff (${wooRoles[0] || 'Unknown'})`,
      permissions: { ...CASHIER_PERMISSIONS },
    };
  }

  // Fail safely to Restricted
  return {
    role: 'restricted',
    roleLabel: `Restricted (${wooRoles[0] || 'Unrecognized Role'})`,
    permissions: { ...RESTRICTED_PERMISSIONS },
  };
}

// ============================================================================
// DEMO PERSONAS FOR QUICK TESTING & OFFLINE LOGIN
// ============================================================================

const DEMO_ADMIN: AuthUser = {
  id: 101,
  username: 'admin.sarah',
  displayName: 'Sarah Jenkins (Owner)',
  email: 'admin@zameria.co',
  avatarUrl: '',
  wooRoles: ['administrator'],
  wooCapabilities: { manage_options: true, manage_woocommerce: true },
  role: 'administrator',
  roleLabel: 'Administrator',
  permissions: ADMINISTRATOR_PERMISSIONS,
  lastValidatedAt: new Date().toISOString(),
  storeName: 'ZAMERIA Lagos Flagship',
  storeUrl: 'https://demo.zameria.co',
};

const DEMO_MANAGER: AuthUser = {
  id: 102,
  username: 'manager.david',
  displayName: 'David Okafor (Store Manager)',
  email: 'manager@zameria.co',
  avatarUrl: '',
  wooRoles: ['shop_manager'],
  wooCapabilities: { edit_products: true, publish_products: true },
  role: 'shop_manager',
  roleLabel: 'Shop Manager',
  permissions: SHOP_MANAGER_PERMISSIONS,
  lastValidatedAt: new Date().toISOString(),
  storeName: 'ZAMERIA Lagos Flagship',
  storeUrl: 'https://demo.zameria.co',
};

const DEMO_CASHIER: AuthUser = {
  id: 103,
  username: 'cashier.amara',
  displayName: 'Amara Nwosu (Head Cashier)',
  email: 'cashier@zameria.co',
  avatarUrl: '',
  wooRoles: ['cashier'],
  wooCapabilities: { read: true },
  role: 'cashier',
  roleLabel: 'Cashier / POS Staff',
  permissions: CASHIER_PERMISSIONS,
  lastValidatedAt: new Date().toISOString(),
  storeName: 'ZAMERIA Lagos Flagship',
  storeUrl: 'https://demo.zameria.co',
};

const DEMO_CASHIER_B: AuthUser = {
  id: 105,
  username: 'cashier.tunde',
  displayName: 'Tunde Adebayo (Cashier B)',
  email: 'cashier.b@zameria.co',
  avatarUrl: '',
  wooRoles: ['cashier'],
  wooCapabilities: { read: true },
  role: 'cashier',
  roleLabel: 'Cashier / POS Staff (B)',
  permissions: CASHIER_PERMISSIONS,
  lastValidatedAt: new Date().toISOString(),
  storeName: 'ZAMERIA Lagos Flagship',
  storeUrl: 'https://demo.zameria.co',
};

const DEMO_RESTRICTED: AuthUser = {
  id: 104,
  username: 'custom.alex',
  displayName: 'Alex Taylor (Guest Staff)',
  email: 'alex@zameria.co',
  avatarUrl: '',
  wooRoles: ['subscriber'],
  wooCapabilities: { read: true },
  role: 'restricted',
  roleLabel: 'Restricted (Subscriber)',
  permissions: RESTRICTED_PERMISSIONS,
  lastValidatedAt: new Date().toISOString(),
  storeName: 'ZAMERIA Lagos Flagship',
  storeUrl: 'https://demo.zameria.co',
};

export const DEMO_USERS: Record<string, AuthUser> = (import.meta.env?.DEV || import.meta.env?.MODE === 'product-preview') ? {
  admin: DEMO_ADMIN,
  administrator: DEMO_ADMIN,
  manager: DEMO_MANAGER,
  shop_manager: DEMO_MANAGER,
  cashier: DEMO_CASHIER,
  cashier_a: DEMO_CASHIER,
  cashier_b: DEMO_CASHIER_B,
  custom: DEMO_RESTRICTED,
  restricted: DEMO_RESTRICTED,
} : {};
