import { db, getSetting, setSetting } from '@/db';

const REPAIR_KEY = 'customer_history_repair_0.2.12';

/** Keep IDs, authentication, queued work and schema 7. Only retire index metadata. */
export async function prepareCustomerHistoryRepair(): Promise<void> {
  if (await getSetting(REPAIR_KEY)) return;
  await db.transaction('rw', db.customers, db.settings, async () => {
    if (await getSetting(REPAIR_KEY)) return;
    await db.customers.toCollection().modify(customer => {
      if (customer.profileType === 'guest' && /^o-\d+$/.test(customer.purchaserKey || '')) {
        customer.guestOrderId = Number(customer.purchaserKey!.slice(2));
      }
      delete customer.purchaserKey;
      delete customer.purchaserActive;
      delete customer.purchaserScope;
      delete customer.orderHistorySyncedAt;
      delete customer.historyOrderIds;
      if (customer.profileType === 'guest') {
        delete customer.purchasesCount;
        delete customer.ordersCount;
        delete customer.totalSpent;
      }
    });
    // The new importer ignores old checkpoints by version, including false completions.
    await setSetting(REPAIR_KEY, '1');
  });
}
