import { db } from '@/db';
import { getWooClient } from './client';
import type { Brand } from '@/types';
import { sessionToken, isDemoSession } from '@/services/zameria/session';
import { zameriaApi } from '@/services/zameria/api';

/**
 * Synchronizes WooCommerce product brands into local Dexie database.
 * Dual-source strategy:
 *   1. Tries Zameria Plugin's /wp-json/zameria/v1/brands endpoint (auto-detects active taxonomy:
 *      product_brand, pwb-brand, yith_product_brand, brand, pa_brand).
 *   2. Fallbacks to WooCommerce REST /wp-json/wc/v3/products/brands.
 * 
 * Idempotent: repeated runs update existing brands without creating duplicates.
 */
export async function syncAllBrands(): Promise<{
  importedCount: number;
  updatedCount: number;
  brands: Brand[];
}> {
  const token = sessionToken();
  const client = getWooClient();
  const now = new Date().toISOString();
  let importedCount = 0;
  let updatedCount = 0;

  let remoteBrands: Array<{
    id: number;
    name: string;
    slug?: string;
    taxonomy?: string;
    count?: number;
    description?: string;
  }> = [];

  // Strategy 1: Plugin REST endpoint /brands
  if (token) {
    try {
      const res = await zameriaApi.brands(token);
      if (Array.isArray(res?.brands) && res.brands.length > 0) {
        remoteBrands = res.brands;
      }
    } catch (err: any) {
      // Fall through to Strategy 2
    }
  }

  // Strategy 2: WooCommerce REST API /products/brands
  if (remoteBrands.length === 0 && client) {
    try {
      const res = await client.get<any[]>('/products/brands', { per_page: 100 });
      if (Array.isArray(res.data) && res.data.length > 0) {
        remoteBrands = res.data.map((b: any) => ({
          id: Number(b.id),
          name: b.name || 'Unnamed Brand',
          slug: b.slug || '',
          taxonomy: 'product_brand',
          count: Number(b.count || 0),
          description: b.description || '',
        }));
      }
    } catch {
      // Fallback failed or brands endpoint not registered
    }
  }

  // Strategy 3: Demo session or offline existing cache
  if (remoteBrands.length === 0 && isDemoSession()) {
    const existing = await db.brands.toArray();
    for (const b of existing) {
      await db.brands.update(b.id, {
        syncStatus: 'SYNCED',
        lastSyncedAt: now,
      });
      updatedCount++;
    }
    const allBrands = await db.brands.toArray();
    return { importedCount, updatedCount, brands: allBrands };
  }

  // Persist into Dexie with deduplication guarantee
  if (remoteBrands.length > 0) {
    for (const rb of remoteBrands) {
      const wooId = Number(rb.id);
      const name = String(rb.name || '').trim();
      const slug = String(rb.slug || '').trim() || name.toLowerCase().replace(/\s+/g, '-');
      const taxonomy = rb.taxonomy || 'product_brand';
      const count = Number(rb.count || 0);
      const description = rb.description || '';

      // Match existing by wooId first, then by slug or lowercase name
      let existing = await db.brands.where('wooId').equals(wooId).first();
      if (!existing && slug) {
        existing = await db.brands.where('slug').equals(slug).first();
      }

      if (existing) {
        await db.brands.update(existing.id, {
          wooId,
          name,
          slug,
          taxonomy,
          count,
          description,
          syncStatus: 'SYNCED',
          lastSyncedAt: now,
        });
        updatedCount++;
      } else {
        await db.brands.add({
          wooId,
          name,
          slug,
          taxonomy,
          count,
          description,
          syncStatus: 'SYNCED',
          lastSyncedAt: now,
        } as unknown as Brand);
        importedCount++;
      }
    }
  }

  const allBrands = await db.brands.toArray();
  return { importedCount, updatedCount, brands: allBrands };
}

/**
 * Retrieve a brand by its local Dexie database ID.
 */
export async function getBrandById(id: number): Promise<Brand | undefined> {
  return db.brands.get(id);
}

/**
 * Retrieve a brand by its WooCommerce ID.
 */
export async function getBrandByWooId(wooId: number): Promise<Brand | undefined> {
  return db.brands.where('wooId').equals(wooId).first();
}

/**
 * Retrieve all synced brands from local Dexie database.
 */
export async function getAllBrands(): Promise<Brand[]> {
  return db.brands.toArray();
}
