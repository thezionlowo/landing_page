/** Validate every page before it can advance a persisted import checkpoint. */
export function validateImportPage(
  rows: unknown, page: number, perPage: number,
  totalPages?: number, totalItems?: number,
): { rows: any[]; more: boolean; totalPages?: number; totalItems?: number } {
  if (!Array.isArray(rows) || rows.length > perPage) throw new Error(`Invalid response on page ${page}`);
  const pages = Number.isSafeInteger(totalPages) && totalPages! > 0 ? totalPages : undefined;
  const total = Number.isSafeInteger(totalItems) && totalItems! >= 0 ? totalItems : undefined;
  if (pages !== undefined && total !== undefined && Math.max(1, Math.ceil(total / perPage)) !== pages) {
    throw new Error('Pagination totals disagree; retry the import');
  }
  const expected = total === undefined ? undefined : Math.max(0, Math.min(perPage, total - (page - 1) * perPage));
  if (expected !== undefined && rows.length !== expected) throw new Error(`Incomplete response on page ${page}`);
  if (pages !== undefined && page < pages && rows.length !== perPage) throw new Error(`Incomplete response on page ${page}`);
  if (pages !== undefined && page > pages && rows.length) throw new Error('Pagination changed; retry the import');
  const ids = rows.map(row => Number(row?.id));
  if (ids.some(id => !Number.isSafeInteger(id) || id < 1) || new Set(ids).size !== ids.length) {
    throw new Error(`Invalid or duplicate record IDs on page ${page}`);
  }
  // Some proxies hide the pagination headers. A full page is never proof of EOF.
  return { rows, more: pages !== undefined ? page < pages : rows.length === perPage, totalPages: pages, totalItems: total };
}

export function checkImportSnapshot(previous: number | undefined, next: number | undefined): number | undefined {
  if (previous !== undefined && next !== undefined && previous !== next) throw new Error('Import total changed; restart required');
  return next ?? previous;
}
