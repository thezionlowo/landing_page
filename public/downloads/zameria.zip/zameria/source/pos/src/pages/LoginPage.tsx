import { StoreEntry, type StoreEntryMode } from '@/components/onboarding/StoreEntry';
import React, { useEffect, useState } from 'react';
import { useNavigate, useLocation } from 'react-router';
import { useAuthStore } from '@/store/authStore';
import {
  clearRequestedStore,
  connectedStore,
  requestedStore,
  zameriaConfig,
  demoLoginEnabled,
} from '@/services/zameria/config';
import { connectStore, discoverStore, hostOf } from '@/services/zameria/storeConnect';
import {
  Store,
  User,
  Lock,
  Globe,
  Eye,
  EyeOff,
  ArrowRight,
  ShieldCheck,
  AlertCircle,
  RefreshCw,
  Zap,
} from 'lucide-react';
import { toast } from 'sonner';
import { DEMO_USERS } from '@/services/auth/permissions';
import { db } from '@/db';

/**
 * Where the store address comes from, in priority order:
 *   1. the plugin serves this app from the store itself (fixed);
 *   2. the WordPress plugin's "Open ZAMERIA POS" button (?store=...);
 *   3. the store this device last connected to (remembered after sign-out and restarts);
 *   4. nothing yet: a first-time user types it.
 */
function initialStore(): { url: string; source: 'plugin' | 'wordpress' | 'remembered' | 'new' } {
  if (zameriaConfig.servedByPlugin) return { url: zameriaConfig.storeUrl, source: 'plugin' };
  const fromWordPress = requestedStore();
  if (fromWordPress) return { url: fromWordPress, source: 'wordpress' };
  const remembered = connectedStore();
  if (remembered) return { url: remembered.storeUrl, source: 'remembered' };
  // Address typed on the previous version of this page (it saved it but never connected).
  try {
    const legacy = localStorage.getItem('zameria_last_store_url');
    if (legacy && !legacy.includes('glowbeauty')) return { url: legacy, source: 'remembered' };
  } catch {}
  return { url: '', source: 'new' };
}

function sameHost(a: string, b: string): boolean {
  return hostOf(a).replace(/^www\./, '') === hostOf(b).replace(/^www\./, '');
}

export function LoginPage() {
  const navigate = useNavigate();
  const location = useLocation();
  const { login, isLoading, error, setError, isAuthenticated, user } = useAuthStore();

  const [store] = useState(initialStore);
  const [entryMode, setEntryMode] = useState<StoreEntryMode>('staff');
  const native = typeof window !== 'undefined' && Boolean((window as any).Capacitor?.isNativePlatform?.());
  const [storeUrl, setStoreUrl] = useState(store.url);
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [registerName] = useState(() => {
    try {
      const saved = localStorage.getItem('zameria_saved_device_name');
      if (saved) return saved;
      const isMobile = typeof navigator !== 'undefined' && /iPhone|iPad|iPod|Android/i.test(navigator.userAgent);
      const generated = (isMobile ? 'Mobile POS - ' : 'Register - ') + Math.random().toString(36).substring(2, 6).toUpperCase();
      localStorage.setItem('zameria_saved_device_name', generated);
      return generated;
    } catch {
      return 'Main Register';
    }
  });

  // Determine redirect target after login
  const from = (location.state as any)?.from?.pathname || '/sale';

  // Already signed in to this store (e.g. clicked "Open ZAMERIA POS" again): go straight to the till.
  useEffect(() => {
    if (!isAuthenticated || !user?.token) return;
    const wanted = requestedStore();
    if (!wanted || sameHost(wanted, zameriaConfig.storeUrl)) {
      clearRequestedStore();
      navigate(from, { replace: true });
    }
  }, [isAuthenticated, user?.token, from, navigate]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    if (!storeUrl.trim()) {
      toast.error('Please enter your store website URL.');
      return;
    }
    if (!username.trim()) {
      toast.error('Please enter your username or email.');
      return;
    }
    if (!password) {
      toast.error('Please enter your password.');
      return;
    }

    setIsSubmitting(true);
    if (setError) setError(null);

    try {
      // Find the store and check the Zameria plugin is active on it. The store is remembered on
      // this device, so next time (after sign-out or a restart) only username + password are needed.
      let switched = false;
      if (!zameriaConfig.servedByPlugin) {
        const found = await discoverStore(storeUrl);
        switched = (await connectStore(found)).switched;
      }

      // No storeUrl here: the store is already connected above, so login() shouldn't look it up again.
      await login({
        username: username.trim(),
        password,
        deviceName: registerName.trim() || 'Main Register',
      });
      clearRequestedStore();

      toast.success('Signed in', {
        description: `Connected to ${zameriaConfig.storeName}`,
      });
      if (switched) {
        // First sign-in to this store on this device: reload so nothing from before survives.
        const base = document.baseURI.endsWith('/') ? document.baseURI : `${document.baseURI}/`;
        window.location.assign(new URL('sale', base).toString());
        return;
      }
      navigate(from, { replace: true });
    } catch (err: any) {
      const message = err.message || 'Sign-in failed. Check your store website URL and credentials.';
      if (setError) setError(message);
      toast.error(message);
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleQuickLogin = async (persona: keyof typeof DEMO_USERS) => {
    if (!(import.meta.env.DEV || import.meta.env.MODE === 'product-preview') || !demoLoginEnabled()) return;
    setIsSubmitting(true);
    if (setError) setError(null);
    try {
      const prodCount = await db.products.count();
      if (prodCount === 0) {
        if (import.meta.env.MODE === 'product-preview') {
          const { seedSkincareDemo } = await import('@/mocks/skincareDemo');
          await seedSkincareDemo(window.location.href);
        } else {
          const { seedDemoData } = await import('@/mocks/data');
          await seedDemoData(db);
        }
      }
      const targetUser = DEMO_USERS[persona];
      if (targetUser) {
        await login(targetUser);
        toast.success(`Signed in as ${targetUser.displayName}`, {
          description: `Role: ${targetUser.roleLabel}`,
        });
        navigate(from, { replace: true });
      }
    } catch (err: any) {
      const msg = err?.message || 'Quick login failed.';
      if (setError) setError(msg);
      toast.error(msg);
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="pos-login min-h-screen w-full flex items-center justify-center p-4 sm:p-6 md:p-8 bg-[#F8FAFC] dark:bg-[#071A31] text-[#071A31] dark:text-white font-sans select-none">
      {/* Central responsive container */}
      <div className="w-full max-w-[420px] mx-auto flex flex-col items-center justify-center space-y-6">
        
        {/* BRAND HEADER — Clean, Minimal, Prominent Logo */}
        <div className="text-center space-y-2">
          <div className="flex items-center justify-center">
            {/* Relative to the Vite base: / on hosted POS, /pos/ in WordPress. */}
            <img
              src="zameria-wordmark.png"
              alt="ZAMERIA"
              className="h-11 w-auto max-w-full object-contain"
              onError={(e) => {
                e.currentTarget.style.display = 'none';
              }}
            />
          </div>
          <p className="text-xs text-[#64748B] dark:text-slate-400 font-medium">
            Sign in to access your store
          </p>
        </div>

        {/* ACCESS RESTRICTED ALERT (If redirected) */}
        {(location.state as any)?.accessDenied && (
          <div className="w-full p-3.5 rounded-xl bg-rose-50 dark:bg-rose-950/40 border border-rose-200 dark:border-rose-900/60 text-rose-700 dark:text-rose-300 text-xs flex items-start gap-2.5 shadow-2xs">
            <AlertCircle className="w-4 h-4 flex-shrink-0 mt-0.5 text-rose-600" />
            <div className="leading-relaxed">
              <strong className="font-bold block text-rose-800 dark:text-rose-200">Access Restricted</strong>
              {(location.state as any)?.message || 'Your account does not have permission to access ZAMERIA.'}
            </div>
          </div>
        )}

        {/* MAIN LOGIN CARD */}
        <div className="w-full bg-white dark:bg-[#0C2340] border border-[#E2E8F0] dark:border-[#123158] rounded-2xl p-6 sm:p-8 shadow-sm hover:shadow-md transition-shadow space-y-5">
          {entryMode !== 'staff' && <StoreEntry mode={entryMode} native={native} onChoose={setEntryMode} />}
          {entryMode === 'staff' && <>
          {error && (
            <div role="alert" className="p-3 bg-rose-50 dark:bg-rose-950/40 border border-rose-200 dark:border-rose-900/60 rounded-3xl text-xs text-rose-700 dark:text-rose-300 flex items-center gap-2">
              <AlertCircle className="w-4 h-4 text-rose-600 flex-shrink-0" />
              <span>{error}</span>
            </div>
          )}

          <form onSubmit={handleSubmit} className="space-y-4">
            <div className="mb-5"><h1 className="text-2xl font-semibold tracking-tight">Welcome back</h1><p className="text-sm text-slate-500 mt-1">Sign in with your store account to start selling.</p></div>
            {/* INPUT FIELD 1: STORE WEBSITE URL */}
            <div className="space-y-1.5">
              <div className="flex items-center justify-between">
                <label htmlFor="store-url-input" className="text-xs font-bold text-[#071A31] dark:text-slate-100 flex items-center gap-1.5">
                  <Store className="w-3.5 h-3.5 text-[#60A5FA]" />
                  <span>Store Website URL</span>
                </label>
                {store.source !== 'new' && storeUrl === store.url && (
                  <span className="text-xs text-emerald-600 dark:text-emerald-400 font-semibold flex items-center gap-1">
                    <ShieldCheck className="w-3 h-3" />
                    {store.source === 'remembered' ? 'Remembered on this device' : 'Your store'}
                  </span>
                )}
              </div>

              <div className="relative">
                <div className="absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-400 pointer-events-none">
                  <Globe className="w-4 h-4" />
                </div>
                <input
                  id="store-url-input"
                  type="text"
                  inputMode="url"
                  autoCapitalize="none"
                  autoCorrect="off"
                  spellCheck={false}
                  autoComplete="url"
                  required
                  readOnly={zameriaConfig.servedByPlugin}
                  value={storeUrl}
                  onChange={(e) => setStoreUrl(e.target.value)}
                  placeholder="Enter your store website URL"
                  className="w-full h-10.5 pl-10 pr-3 text-xs font-mono bg-[#F8FAFC] dark:bg-[#071A31] border border-[#CBD5E1] dark:border-[#123158] rounded-full text-[#071A31] dark:text-white placeholder:text-slate-400 focus:bg-white dark:focus:bg-[#071A31] focus:outline-none focus:ring-2 focus:ring-[#60A5FA] focus:border-transparent transition-all"
                />
              </div>
            </div>

            {/* INPUT FIELD 2: USERNAME */}
            <div className="space-y-1.5">
              <label htmlFor="username-input" className="text-xs font-bold text-[#071A31] dark:text-slate-100 flex items-center gap-1.5">
                <User className="w-3.5 h-3.5 text-[#60A5FA]" />
                <span>Username or Email</span>
              </label>

              <div className="relative">
                <div className="absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-400 pointer-events-none">
                  <User className="w-4 h-4" />
                </div>
                <input
                  id="username-input"
                  type="text"
                  required
                  autoComplete="username"
                  value={username}
                  onChange={(e) => setUsername(e.target.value)}
                  placeholder="Enter your username or email"
                  className="w-full h-10.5 pl-10 pr-3 text-xs bg-[#F8FAFC] dark:bg-[#071A31] border border-[#CBD5E1] dark:border-[#123158] rounded-full text-[#071A31] dark:text-white placeholder:text-slate-400 focus:bg-white dark:focus:bg-[#071A31] focus:outline-none focus:ring-2 focus:ring-[#60A5FA] focus:border-transparent transition-all"
                />
              </div>
            </div>

            {/* INPUT FIELD 3: PASSWORD */}
            <div className="space-y-1.5">
              <div className="flex items-center justify-between">
                <label htmlFor="password-input" className="text-xs font-bold text-[#071A31] dark:text-slate-100 flex items-center gap-1.5">
                  <Lock className="w-3.5 h-3.5 text-[#60A5FA]" />
                  <span>Password</span>
                </label>
                <button
                  type="button"
                  onClick={() => toast.info('Reset your password inside your WordPress admin dashboard (Users > Profile).')}
                  className="text-xs text-blue-600 dark:text-[#60A5FA] hover:underline font-medium cursor-pointer"
                >
                  Forgot password?
                </button>
              </div>

              <div className="relative">
                <div className="absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-400 pointer-events-none">
                  <Lock className="w-4 h-4" />
                </div>
                <input
                  id="password-input"
                  type={showPassword ? 'text' : 'password'}
                  required
                  autoComplete="current-password"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="Enter your password"
                  className="w-full h-10.5 pl-10 pr-10 text-xs bg-[#F8FAFC] dark:bg-[#071A31] border border-[#CBD5E1] dark:border-[#123158] rounded-full text-[#071A31] dark:text-white placeholder:text-slate-400 focus:bg-white dark:focus:bg-[#071A31] focus:outline-none focus:ring-2 focus:ring-[#60A5FA] focus:border-transparent transition-all"
                />
                <button
                  type="button"
                  onClick={() => setShowPassword(!showPassword)}
                  className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 cursor-pointer p-1"
                  title={showPassword ? 'Hide password' : 'Show password'}
                  aria-label={showPassword ? 'Hide password' : 'Show password'}
                >
                  {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                </button>
              </div>
            </div>


            {/* SUBMIT BUTTON */}
            <div className="pt-2">
              <button
                type="submit"
                disabled={isSubmitting || isLoading}
                className="w-full h-11 px-4 rounded-full bg-[#071A31] hover:bg-[#0C2340] active:bg-[#040E1B] text-white font-bold text-xs sm:text-sm transition-all flex items-center justify-center gap-2 cursor-pointer shadow-sm hover:shadow-md disabled:opacity-50 disabled:cursor-not-allowed focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#60A5FA] focus-visible:ring-offset-2"
              >
                {isSubmitting || isLoading ? (
                  <>
                    <RefreshCw className="w-4 h-4 animate-spin text-[#60A5FA]" />
                    <span>Signing in...</span>
                  </>
                ) : (
                  <>
                    <span>Sign In to ZAMERIA</span>
                    <ArrowRight className="w-4 h-4 text-[#60A5FA]" />
                  </>
                )}
              </button>
            </div>

            {/* QUICK TEST DEMO PERSONAS (Hidden in production with connected store) */}
            {(import.meta.env.DEV || import.meta.env.MODE === 'product-preview') && demoLoginEnabled() && (
              <div className="pt-3 border-t border-slate-100 dark:border-slate-800 space-y-2">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-bold text-slate-500 dark:text-slate-400 flex items-center gap-1">
                    <Zap className="w-3 h-3 text-amber-500" />
                    Quick Test Logins
                  </span>
                  <span className="text-xs text-blue-600 dark:text-[#60A5FA] font-medium">1-Click Sign In</span>
                </div>
                <div className="grid grid-cols-3 gap-2">
                  <button
                    type="button"
                    disabled={isSubmitting || isLoading}
                    onClick={() => handleQuickLogin('admin')}
                    className="p-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800/80 hover:bg-blue-50 dark:hover:bg-blue-950/40 hover:border-blue-400 text-left transition-all cursor-pointer group"
                  >
                    <span className="block text-xs font-bold text-slate-800 dark:text-slate-100 group-hover:text-blue-600 dark:group-hover:text-[#60A5FA]">Admin</span>
                    <span className="block text-[9px] text-slate-500 dark:text-slate-400 truncate">Sarah (Owner)</span>
                  </button>
                  <button
                    type="button"
                    disabled={isSubmitting || isLoading}
                    onClick={() => handleQuickLogin('manager')}
                    className="p-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800/80 hover:bg-blue-50 dark:hover:bg-blue-950/40 hover:border-blue-400 text-left transition-all cursor-pointer group"
                  >
                    <span className="block text-xs font-bold text-slate-800 dark:text-slate-100 group-hover:text-blue-600 dark:group-hover:text-[#60A5FA]">Manager</span>
                    <span className="block text-[9px] text-slate-500 dark:text-slate-400 truncate">David Okafor</span>
                  </button>
                  <button
                    type="button"
                    disabled={isSubmitting || isLoading}
                    onClick={() => handleQuickLogin('cashier')}
                    className="p-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800/80 hover:bg-blue-50 dark:hover:bg-blue-950/40 hover:border-blue-400 text-left transition-all cursor-pointer group"
                  >
                    <span className="block text-xs font-bold text-slate-800 dark:text-slate-100 group-hover:text-blue-600 dark:group-hover:text-[#60A5FA]">Cashier</span>
                    <span className="block text-[9px] text-slate-500 dark:text-slate-400 truncate">Amara Nwosu</span>
                  </button>
                </div>
              </div>
            )}
          </form>
          </>}

        </div>
        {!store.url && entryMode === 'staff' && <button type="button" onClick={() => setEntryMode('choose')} className="text-xs text-blue-600 dark:text-blue-400 hover:underline">Set up a new store</button>}

      </div>
    </div>
  );
}
export default LoginPage;
