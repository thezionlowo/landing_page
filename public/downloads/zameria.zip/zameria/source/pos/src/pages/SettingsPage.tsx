import { useState, useRef } from 'react';
import { useConnectionStore, useUIStore, useSyncStore, useAuthStore } from '@/store';
import { Button, Modal, SyncButton } from '@/components/ui';
import { syncEngine } from '@/services/woocommerce/syncEngine';
import { getDataSyncIntervalMinutes, setDataSyncIntervalMinutes } from '@/services/zameria/posSync';
import { getStoreLogo, saveStoreLogo, removeStoreLogo } from '@/services/storeLogoService';
import { getReceiptPaperWidth, setReceiptPaperWidth, type ThermalPaperWidth } from '@/services/printService';
import { cn, timeAgo } from '@/lib';
import { toast } from 'sonner';
import {
  User,
  Store,
  WifiOff,
  RefreshCw,
  Bell,
  Printer,
  Monitor,
  CreditCard,
  Sun,
  Moon,
  LayoutGrid,
  List,
  Eye,
  EyeOff,
  ExternalLink,
  Download,
  Trash2,
  Clock,
  CheckCircle2,
  AlertTriangle,
  ShieldCheck,
  Lock,
  Shield,
  UserCheck,
  Image as ImageIcon,
  Upload,
} from 'lucide-react';
import type { Theme, ListMode, ZameriaRole } from '@/types';

export function SettingsPage() {
  const { storeName, storeUrl } = useConnectionStore();
  const {
    theme,
    setTheme,
    listMode,
    setListMode,
    showCartThumbnails,
    setShowCartThumbnails,
    isDemoMode,
  } = useUIStore();
  const { lastSyncedAt, pendingCount, clearPending } = useSyncStore();
  const { user, hasPermission, revalidate, switchDemoRole } = useAuthStore();

  const [syncInterval, setSyncInterval] = useState(getDataSyncIntervalMinutes);
  const [offlineMode, setOfflineMode] = useState(true);
  const [autoPrint, setAutoPrintState] = useState<boolean>(() => {
    return typeof window !== 'undefined' && localStorage.getItem('zameria_auto_print') === 'true';
  });

  const handleSetAutoPrint = (val: boolean) => {
    setAutoPrintState(val);
    if (typeof window !== 'undefined') {
      localStorage.setItem('zameria_auto_print', String(val));
    }
  };

  const [paperWidth, setPaperWidthState] = useState<ThermalPaperWidth>(() => getReceiptPaperWidth());

  const handleSetPaperWidth = (width: ThermalPaperWidth) => {
    setPaperWidthState(width);
    setReceiptPaperWidth(width);
  };
  const [alerts, setAlerts] = useState(true);
  const [showClearConfirmModal, setShowClearConfirmModal] = useState(false);
  const [showFullResyncModal, setShowFullResyncModal] = useState(false);
  const [isFullResyncing, setIsFullResyncing] = useState(false);
  const [isRevalidating, setIsRevalidating] = useState(false);

  const connectedStoreUrl = user?.storeUrl || storeUrl;
  // Same key the receipt uses to look the logo up (see ReceiptModal).
  const currentStoreIdentifier = isDemoMode ? 'demo.zameria.co' : (connectedStoreUrl || user?.storeName || storeName || 'default');
  const [storeLogo, setStoreLogoState] = useState<string | null>(() => getStoreLogo(currentStoreIdentifier));
  const logoInputRef = useRef<HTMLInputElement>(null);
  const canManageWoo = hasPermission('canManageWooConnection');
  const canManageStoreLogo = hasPermission('canManageStoreLogo');

  const handleLogoUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    if (!file.type.startsWith('image/')) {
      toast.error('Please upload an image file (PNG, JPG, WebP, or SVG).');
      return;
    }

    if (file.size > 2 * 1024 * 1024) {
      toast.error('Store logo must be under 2MB.');
      return;
    }

    const reader = new FileReader();
    reader.onload = async () => {
      const dataUrl = reader.result as string;
      await saveStoreLogo(currentStoreIdentifier, dataUrl);
      setStoreLogoState(dataUrl);
      toast.success('Store logo updated! It will appear on all your store receipts.');
    };
    reader.readAsDataURL(file);
    e.target.value = '';
  };

  const handleRemoveLogo = async () => {
    await removeStoreLogo(currentStoreIdentifier);
    setStoreLogoState(null);
    toast.success('Store logo removed. Receipts will now use the default ZAMERIA logo.');
  };

  const handleExecuteFullResync = async () => {
    setIsFullResyncing(true);
    try {
      toast.info('Starting full reconciliation with WooCommerce...');
      const summary = await syncEngine.sync({ scope: 'full', forceFull: true });
      if (summary.status !== 'success') throw new Error(summary.error || 'Some store data could not be synchronized. Please retry.');
      setShowFullResyncModal(false);
      toast.success('Full store resynchronization completed successfully!');
    } catch (err: any) {
      toast.error(err?.message || 'Full resync failed');
    } finally {
      setIsFullResyncing(false);
    }
  };

  const handleRevalidateSession = async () => {
    setIsRevalidating(true);
    try {
      await revalidate();
      toast.success('WooCommerce permissions revalidated successfully!');
    } catch (err: any) {
      toast.error(err.message || 'Failed to revalidate WooCommerce permissions.');
    } finally {
      setIsRevalidating(false);
    }
  };

  const handleExportOfflineActivity = () => {
    const exportData = {
      exportDate: new Date().toISOString(),
      storeName: isDemoMode ? 'ZAMERIA Demo Store' : storeName,
      offlineQueueCount: pendingCount,
    };
    const blob = new Blob([JSON.stringify(exportData, null, 2)], {
      type: 'application/json',
    });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `zameria-offline-export-${Date.now()}.json`;
    a.click();
    URL.revokeObjectURL(url);
    toast.success('Offline activity exported');
  };

  const handleClearOfflineActivity = () => {
    clearPending();
    setShowClearConfirmModal(false);
    toast.success('Offline queue cleared');
  };

  const roleStyles: Record<ZameriaRole, string> = {
    administrator: 'bg-emerald-500/10 text-emerald-600 border-emerald-500/20',
    shop_manager: 'bg-sky-500/10 text-sky-600 border-sky-500/20',
    cashier: 'bg-amber-500/10 text-amber-600 border-amber-500/20',
    restricted: 'bg-purple-500/10 text-purple-600 border-purple-500/20',
  };

  const currentRole: ZameriaRole = user?.role || 'restricted';

  return (
    <div className="h-full overflow-y-auto bg-surface">
      <div className="max-w-3xl mx-auto p-6 space-y-6">
        {/* Page Header */}
        <div className="pb-4 border-b border-outline-variant/60">
          <h1 className="text-xl font-bold text-on-surface tracking-tight">Settings</h1>
          <p className="text-xs text-on-surface-variant mt-0.5">
            Configure store operations, till interface, offline caching, and synchronization rules.
          </p>
        </div>

        {/* 1. Authenticated Staff & WooCommerce Role */}
        <SettingsSection
          title="WooCommerce Staff Account"
          description="Resolved directly from WordPress REST API. Source of truth for your permissions."
          icon={<ShieldCheck className="w-4 h-4 text-primary" />}
        >
          <div className="m3-card-outlined rounded-xl p-4.5 space-y-4 bg-surface text-xs">
            <div className="flex items-start justify-between">
              <div>
                <div className="flex items-center gap-2">
                  <h3 className="font-bold text-sm text-on-surface">{user?.displayName}</h3>
                  <span
                    className={cn(
                      'text-[10px] uppercase font-bold tracking-wider px-2 py-0.5 rounded-md border',
                      roleStyles[currentRole]
                    )}
                  >
                    {currentRole.replace('_', ' ')}
                  </span>
                </div>
                <p className="text-on-surface-variant font-mono text-[11px] mt-0.5">
                  @{user?.username} &bull; {user?.email}
                </p>
              </div>

              <Button
                variant="outline"
                size="sm"
                onClick={handleRevalidateSession}
                disabled={isRevalidating}
                className="text-xs flex items-center gap-1.5"
              >
                <RefreshCw className={cn('w-3.5 h-3.5', isRevalidating && 'animate-spin')} />
                Revalidate
              </Button>
            </div>

            <div className="pt-2.5 border-t border-outline-variant/40 flex items-center justify-between">
              <span className="text-on-surface-variant">Connected Store:</span>
              <span className="font-semibold text-on-surface">{user?.storeName}</span>
            </div>


          </div>
        </SettingsSection>

        {/* 2. Store Details */}
        <SettingsSection
          title="Store Details & Connection"
          description="WooCommerce REST API connection and synchronization settings."
          icon={<Store className="w-4 h-4 text-primary" />}
        >
          <div className="m3-card-outlined rounded-xl p-4.5 space-y-3.5 bg-surface text-xs">
            {!canManageWoo && (
              <div className="p-3 rounded-xl bg-warning/10 border border-warning/30 flex items-center gap-2 text-on-surface">
                <Lock className="w-4 h-4 text-warning flex-shrink-0" />
                <span>
                  <strong>Administrator Access Required:</strong> Your WooCommerce role (
                  {currentRole.toUpperCase()}) cannot modify connection settings or credentials.
                </span>
              </div>
            )}

            <div className="flex items-center justify-between">
              <span className="text-on-surface-variant">Connected Site:</span>
              <span className="font-mono font-medium text-on-surface">
                {isDemoMode ? 'https://demo.zameria.co' : connectedStoreUrl || 'Not connected'}
              </span>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-on-surface-variant">Store Name:</span>
              <span className="font-semibold text-on-surface">
                {isDemoMode ? 'ZAMERIA Demo Store' : user?.storeName || storeName || '—'}
              </span>
            </div>

            {canManageWoo && (
              <div className="flex items-center gap-2 pt-2.5 border-t border-outline-variant/40">
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => window.open(`${connectedStoreUrl.replace(/\/?$/, '/')}wp-admin/admin.php?page=zameria`, '_blank', 'noopener')}
                  icon={<ExternalLink className="w-3.5 h-3.5" />}
                  disabled={!connectedStoreUrl}
                >
                  WooCommerce Admin
                </Button>
                <Button
                  variant="secondary"
                  size="sm"
                  onClick={() => setShowFullResyncModal(true)}
                  icon={<RefreshCw className="w-3.5 h-3.5" />}
                >
                  Resync Data
                </Button>
              </div>
            )}
          </div>
        </SettingsSection>

        {/* Store Logo & Receipt Branding */}
        <SettingsSection
          title="Store Logo & Receipt Branding"
          description="Custom logo displayed on customer receipts. Replaces ZAMERIA logo on physical prints."
          icon={<ImageIcon className="w-4 h-4 text-primary" />}
        >
          <div className="m3-card-outlined rounded-xl p-4.5 space-y-4 bg-surface text-xs">
            {!canManageStoreLogo ? (
              <div className="p-3 rounded-xl bg-warning/10 border border-warning/30 flex items-center gap-2 text-on-surface">
                <Lock className="w-4 h-4 text-warning flex-shrink-0" />
                <span>
                  <strong>Manager / Administrator Access Required:</strong> Your role ({currentRole.toUpperCase()}) cannot modify store branding or receipt logos.
                </span>
              </div>
            ) : null}

            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
              <div className="flex items-center gap-4">
                {/* Logo Preview Container */}
                <div className="w-24 h-16 rounded-xl border border-outline-variant/80 bg-surface-container-low flex items-center justify-center p-2 overflow-hidden flex-shrink-0">
                  {storeLogo ? (
                    <img
                      src={storeLogo}
                      alt="Store Logo Preview"
                      className="max-h-full max-w-full object-contain"
                    />
                  ) : (
                    <div className="flex flex-col items-center justify-center text-center">
                      <img
                        src="zameria-logo.png"
                        alt="Default ZAMERIA Logo"
                        className="h-5 object-contain opacity-50"
                      />
                      <span className="text-[9px] text-on-surface-variant/70 mt-1 font-mono">
                        (Default)
                      </span>
                    </div>
                  )}
                </div>

                <div>
                  <h4 className="font-bold text-sm text-on-surface">
                    {storeLogo ? 'Custom Store Logo' : 'Default ZAMERIA Logo'}
                  </h4>
                  <p className="text-[11px] text-on-surface-variant mt-0.5">
                    {storeLogo
                      ? 'Active on customer receipts. Preserves natural aspect ratio.'
                      : 'No custom logo uploaded. Standard ZAMERIA logo will appear on receipts.'}
                  </p>
                  <p className="text-[10px] text-on-surface-variant/70 font-mono mt-0.5">
                    Store: {isDemoMode ? 'ZAMERIA Demo Store' : (storeName || storeUrl || 'Default Store')}
                  </p>
                </div>
              </div>

              {canManageStoreLogo && (
                <div className="flex items-center gap-2 flex-shrink-0">
                  <input
                    ref={logoInputRef}
                    type="file"
                    accept="image/png,image/jpeg,image/webp,image/svg+xml"
                    onChange={handleLogoUpload}
                    className="hidden"
                  />
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => logoInputRef.current?.click()}
                    icon={<Upload className="w-3.5 h-3.5" />}
                  >
                    {storeLogo ? 'Replace Logo' : 'Upload Logo'}
                  </Button>

                  {storeLogo && (
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={handleRemoveLogo}
                      icon={<Trash2 className="w-3.5 h-3.5 text-danger" />}
                      className="text-danger hover:bg-danger/10"
                    >
                      Remove
                    </Button>
                  )}
                </div>
              )}
            </div>
          </div>
        </SettingsSection>

        {/* 3. Offline Mode */}
        <SettingsSection
          title="Offline Mode"
          description="Local caching for uninterrupted sales without internet connectivity."
          icon={<WifiOff className="w-4 h-4 text-primary" />}
        >
          <div className="m3-card-outlined rounded-xl p-4.5 space-y-3.5 bg-surface text-xs">
            <SettingsToggle
              label="Use ZAMERIA POS without an active internet connection"
              checked={offlineMode}
              onChange={setOfflineMode}
            />
            <p className="text-[11px] text-on-surface-variant leading-relaxed">
              Sales are completed offline using locally cached IndexedDB products. Internet access is
              required for initial setup, catalogue sync, and remote customer profiles.
            </p>
            <div className="flex items-center justify-between pt-2.5 border-t border-outline-variant/40">
              <div className="text-on-surface-variant">
                Queue Status:{' '}
                <strong className="text-on-surface font-semibold">{pendingCount} sales waiting to sync</strong>
              </div>
              <div className="flex items-center gap-2">
                <Button
                  variant="outline"
                  size="sm"
                  onClick={handleExportOfflineActivity}
                  icon={<Download className="w-3.5 h-3.5" />}
                >
                  Export
                </Button>
                <Button
                  variant="destructive"
                  size="sm"
                  onClick={() => setShowClearConfirmModal(true)}
                  icon={<Trash2 className="w-3.5 h-3.5" />}
                >
                  Clear
                </Button>
              </div>
            </div>
          </div>
        </SettingsSection>

        {/* 4. Data Synchronization & Resync */}
        <SettingsSection
          title="Data Synchronization & Resync"
          description="Configure automatic background data polling and trigger on-demand sync by entity or full store resync."
          icon={<RefreshCw className="w-4 h-4 text-primary" />}
        >
          <div className="m3-card-outlined rounded-xl p-4.5 space-y-4 bg-surface text-xs">
            {/* Entity Quick Sync Rows */}
            <div className="space-y-2">
              <span className="font-bold text-on-surface uppercase tracking-wider text-[10px]">
                On-Demand Entity Synchronization
              </span>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                <div className="flex items-center justify-between p-2.5 rounded-lg bg-surface-container-low border border-outline-variant/40">
                  <div>
                    <div className="font-semibold text-on-surface">Product Catalogue</div>
                    <div className="text-[10px] text-on-surface-variant">Products, categories & media</div>
                  </div>
                  <SyncButton scope="products" label="Sync" size="sm" variant="outline" />
                </div>

                <div className="flex items-center justify-between p-2.5 rounded-lg bg-surface-container-low border border-outline-variant/40">
                  <div>
                    <div className="font-semibold text-on-surface">Inventory Stock</div>
                    <div className="text-[10px] text-on-surface-variant">Stock levels & stock statuses</div>
                  </div>
                  <SyncButton scope="inventory" label="Sync" size="sm" variant="outline" />
                </div>

                <div className="flex items-center justify-between p-2.5 rounded-lg bg-surface-container-low border border-outline-variant/40">
                  <div>
                    <div className="font-semibold text-on-surface">Orders & Sales</div>
                    <div className="text-[10px] text-on-surface-variant">Online web orders & POS sync</div>
                  </div>
                  <SyncButton scope="orders" label="Sync" size="sm" variant="outline" />
                </div>

                <div className="flex items-center justify-between p-2.5 rounded-lg bg-surface-container-low border border-outline-variant/40">
                  <div>
                    <div className="font-semibold text-on-surface">Customer Profiles</div>
                    <div className="text-[10px] text-on-surface-variant">Billing, addresses & history</div>
                  </div>
                  <SyncButton scope="customers" label="Sync" size="sm" variant="outline" />
                </div>

                <div className="flex items-center justify-between p-2.5 rounded-lg bg-surface-container-low border border-outline-variant/40 sm:col-span-2">
                  <div>
                    <div className="font-semibold text-on-surface">Coupons & Discounts</div>
                    <div className="text-[10px] text-on-surface-variant">WooCommerce coupon rules, limits & validity</div>
                  </div>
                  <SyncButton scope="coupons" label="Sync Coupons" size="sm" variant="outline" />
                </div>
              </div>
            </div>

            {/* Polling Frequency Slider */}
            <div className="pt-3 border-t border-outline-variant/40">
              <div className="flex justify-between font-semibold text-on-surface mb-1.5">
                <span>Customer, Category & Coupon Refresh:</span>
                <span className="tabular-nums font-bold text-primary">{syncInterval} minutes</span>
              </div>
              <input
                type="range"
                min={1}
                max={60}
                step={1}
                value={syncInterval}
                onChange={(e) => { const value = Number(e.target.value); setSyncInterval(value); setDataSyncIntervalMinutes(value); }}
                className="w-full h-1.5 bg-surface-container-highest rounded-lg appearance-none cursor-pointer accent-primary"
              />
              <div className="flex justify-between text-[10px] text-on-surface-variant mt-1">
                <span>1 min (frequent)</span>
                <span>60 min (battery saving)</span>
              </div>
            </div>

            {/* Full Store Resync Trigger */}
            <div className="pt-3 border-t border-outline-variant/40 flex items-center justify-between">
              <div>
                <div className="font-bold text-on-surface">Full Store Resync</div>
                <p className="text-[11px] text-on-surface-variant">
                  Re-fetch and reconcile all WooCommerce categories, products, inventory, customers, and orders.
                </p>
              </div>
              <Button
                variant="primary"
                size="sm"
                onClick={() => setShowFullResyncModal(true)}
                disabled={!canManageWoo}
                icon={<RefreshCw className="w-3.5 h-3.5" />}
              >
                Full Resync
              </Button>
            </div>
          </div>
        </SettingsSection>

        {/* 5. Alert Settings */}
        <SettingsSection
          title="Alert Settings"
          description="Control notifications for background orders and network status."
          icon={<Bell className="w-4 h-4 text-primary" />}
        >
          <div className="m3-card-outlined rounded-xl p-4.5 bg-surface">
            <SettingsToggle
              label="Show alerts for new orders fetched in the background"
              checked={alerts}
              onChange={setAlerts}
            />
          </div>
        </SettingsSection>

        {/* 6. Printer Settings */}
        <SettingsSection
          title="Printer Settings"
          description="Receipt format and hardware printing preferences."
          icon={<Printer className="w-4 h-4 text-primary" />}
        >
          <div className="m3-card-outlined rounded-xl p-4.5 space-y-4 bg-surface text-xs">
            <SettingsToggle
              label="Auto-print receipt after order completion"
              checked={autoPrint}
              onChange={handleSetAutoPrint}
            />
            <p className="text-[11px] text-on-surface-variant">
              When enabled, POS will automatically trigger the system print dialog when a sale is completed.
            </p>

            <div className="pt-2 border-t border-outline-variant/60 space-y-2">
              <span className="text-on-surface font-semibold block">Thermal Paper Roll Width:</span>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                {[
                  { value: '80mm' as const, label: '80mm Standard Thermal', desc: 'Standard POS thermal roll (Default)' },
                  { value: '58mm' as const, label: '58mm Compact Thermal', desc: 'Compact / mobile portable printers' },
                ].map((pw) => (
                  <button
                    key={pw.value}
                    type="button"
                    onClick={() => handleSetPaperWidth(pw.value)}
                    className={cn(
                      'p-2.5 rounded-lg border text-left transition-all cursor-pointer',
                      paperWidth === pw.value
                        ? 'bg-primary/10 border-primary text-primary font-bold shadow-xs'
                        : 'border-outline-variant hover:bg-surface-container-low text-on-surface'
                    )}
                  >
                    <div className="font-semibold">{pw.label}</div>
                    <div className="text-[10.5px] text-on-surface-variant mt-0.5">{pw.desc}</div>
                  </button>
                ))}
              </div>
            </div>
          </div>
        </SettingsSection>

        {/* 7. Interface Settings */}
        <SettingsSection
          title="Interface Settings"
          description="Customize the appearance, theme, and till display mode."
          icon={<Monitor className="w-4 h-4 text-primary" />}
        >
          <div className="m3-card-outlined rounded-xl p-4.5 space-y-4 bg-surface text-xs">
            {/* Appearance */}
            <div>
              <span className="text-on-surface font-semibold block mb-2">Appearance Theme:</span>
              <div className="grid grid-cols-3 gap-2">
                {[
                  { value: 'system' as Theme, icon: Monitor, label: 'System' },
                  { value: 'light' as Theme, icon: Sun, label: 'Light' },
                  { value: 'dark' as Theme, icon: Moon, label: 'Dark' },
                ].map((opt) => (
                  <button
                    key={opt.value}
                    type="button"
                    onClick={() => setTheme(opt.value)}
                    className={cn(
                      'flex items-center justify-center gap-2 py-2 px-3 rounded-lg border text-xs font-semibold transition-colors cursor-pointer',
                      theme === opt.value
                        ? 'border-primary bg-primary-container/25 text-primary font-bold shadow-xs'
                        : 'border-outline-variant/60 bg-surface text-on-surface-variant hover:bg-surface-container-low hover:text-on-surface'
                    )}
                  >
                    <opt.icon className="w-3.5 h-3.5" />
                    {opt.label}
                  </button>
                ))}
              </div>
            </div>

            {/* Sale Screen List Mode */}
            <div className="pt-3 border-t border-outline-variant/40">
              <span className="text-on-surface font-semibold block mb-2">
                Sale Screen Catalogue Mode:
              </span>
              <div className="grid grid-cols-2 gap-2">
                {[
                  { value: 'grid' as ListMode, icon: LayoutGrid, label: 'Grid View' },
                  { value: 'list' as ListMode, icon: List, label: 'List View' },
                ].map((opt) => (
                  <button
                    key={opt.value}
                    type="button"
                    onClick={() => setListMode(opt.value)}
                    className={cn(
                      'flex items-center justify-center gap-2 py-2 px-3 rounded-lg border text-xs font-semibold transition-colors cursor-pointer',
                      listMode === opt.value
                        ? 'border-primary bg-primary-container/25 text-primary font-bold shadow-xs'
                        : 'border-outline-variant/60 bg-surface text-on-surface-variant hover:bg-surface-container-low hover:text-on-surface'
                    )}
                  >
                    <opt.icon className="w-3.5 h-3.5" />
                    {opt.label}
                  </button>
                ))}
              </div>
            </div>

            {/* Cart Product Thumbnails */}
            <div className="pt-3 border-t border-outline-variant/40">
              <span className="text-on-surface font-semibold block mb-2">
                Cart Product Thumbnails:
              </span>
              <div className="grid grid-cols-2 gap-2">
                <button
                  type="button"
                  onClick={() => setShowCartThumbnails(true)}
                  className={cn(
                    'flex items-center justify-center gap-2 py-2 px-3 rounded-lg border text-xs font-semibold transition-colors cursor-pointer',
                    showCartThumbnails
                      ? 'border-primary bg-primary-container/25 text-primary font-bold shadow-xs'
                      : 'border-outline-variant/60 bg-surface text-on-surface-variant hover:bg-surface-container-low hover:text-on-surface'
                  )}
                >
                  <Eye className="w-3.5 h-3.5" />
                  Show Thumbnails
                </button>
                <button
                  type="button"
                  onClick={() => setShowCartThumbnails(false)}
                  className={cn(
                    'flex items-center justify-center gap-2 py-2 px-3 rounded-lg border text-xs font-semibold transition-colors cursor-pointer',
                    !showCartThumbnails
                      ? 'border-primary bg-primary-container/25 text-primary font-bold shadow-xs'
                      : 'border-outline-variant/60 bg-surface text-on-surface-variant hover:bg-surface-container-low hover:text-on-surface'
                  )}
                >
                  <EyeOff className="w-3.5 h-3.5" />
                  Hide Thumbnails
                </button>
              </div>
            </div>
          </div>
        </SettingsSection>

        {/* 8. Payment Integrations */}
        <SettingsSection
          title="Payment Integrations"
          description="Supported payment gateways and terminal hardware integrations."
          icon={<CreditCard className="w-4 h-4 text-primary" />}
        >
          <div className="space-y-2 text-xs">
            {[
              { name: 'Square', desc: 'Accept credit cards and Square contactless readers.' },
              { name: 'Stripe', desc: 'Accept Stripe Terminal BBPOS Chipper and online payments.' },
            ].map((provider) => (
              <div
                key={provider.name}
                className="m3-card-outlined rounded-xl p-4 bg-surface flex items-center justify-between"
              >
                <div>
                  <div className="flex items-center gap-2">
                    <span className="font-bold text-on-surface">{provider.name}</span>
                    <span className="text-[10px] text-on-surface-variant bg-surface-container-high px-1.5 py-0.5 rounded-md font-medium">
                      Not configured
                    </span>
                  </div>
                  <p className="text-[11px] text-on-surface-variant mt-0.5">{provider.desc}</p>
                </div>
                <a
                  href="#"
                  onClick={(e) => {
                    e.preventDefault();
                    toast.info(`Configure ${provider.name} in WooCommerce Settings → Payments.`);
                  }}
                  className="inline-flex items-center gap-1 font-semibold text-primary hover:underline cursor-pointer"
                >
                  Configure <ExternalLink className="w-3.5 h-3.5" />
                </a>
              </div>
            ))}
          </div>
        </SettingsSection>
      </div>

      {/* Confirmation Modal for Clearing Offline Activity */}
      <Modal
        open={showClearConfirmModal}
        onClose={() => setShowClearConfirmModal(false)}
        title="Confirm Clearing Offline Activity"
        size="sm"
      >
        <div className="space-y-4 text-xs">
          <div className="flex items-start gap-3 p-3.5 bg-error/10 text-error border border-error/20 rounded-xl">
            <AlertTriangle className="w-5 h-5 flex-shrink-0 mt-0.5" />
            <p className="leading-relaxed text-on-surface">
              <strong className="text-error">Warning:</strong> This will permanently erase all unsynchronized sales in the offline queue ({pendingCount} orders). This action cannot be undone.
            </p>
          </div>
          <div className="flex justify-end gap-2.5 pt-2">
            <Button
              variant="secondary"
              size="sm"
              onClick={() => setShowClearConfirmModal(false)}
            >
              Cancel
            </Button>
            <Button
              variant="destructive"
              size="sm"
              onClick={handleClearOfflineActivity}
            >
              Yes, Clear Queue
            </Button>
          </div>
        </div>
      </Modal>

      {/* Confirmation Modal for Full Store Resync */}
      <Modal
        open={showFullResyncModal}
        onClose={() => !isFullResyncing && setShowFullResyncModal(false)}
        title="Full Store Resynchronization"
        size="md"
      >
        <div className="space-y-4 text-xs">
          <div className="p-3.5 bg-primary/10 border border-primary/20 rounded-xl space-y-2 text-on-surface">
            <h4 className="font-bold text-sm text-primary flex items-center gap-1.5">
              <RefreshCw className="w-4 h-4" />
              Reconcile All Store Entities
            </h4>
            <p className="leading-relaxed text-on-surface-variant">
              This operation will query your connected WooCommerce store and update local catalogue items, stock quantities, customers, orders, and coupons using full API pagination.
            </p>
            <ul className="list-disc pl-4 space-y-1 text-on-surface-variant">
              <li>Local unsaved offline orders and completed historical transactions are safely preserved.</li>
              <li>Existing products and orders will be reconciled by WooCommerce ID (no duplicates).</li>
              <li>Depending on catalogue size, this operation may take a few moments.</li>
            </ul>
          </div>

          <div className="flex justify-end gap-2.5 pt-2">
            <Button
              variant="secondary"
              size="sm"
              disabled={isFullResyncing}
              onClick={() => setShowFullResyncModal(false)}
            >
              Cancel
            </Button>
            <Button
              variant="primary"
              size="sm"
              loading={isFullResyncing}
              onClick={handleExecuteFullResync}
              icon={<RefreshCw className={cn('w-3.5 h-3.5', isFullResyncing && 'animate-spin')} />}
            >
              Start Full Resync
            </Button>
          </div>
        </div>
      </Modal>
    </div>
  );
}

function SettingsSection({
  title,
  description,
  icon,
  children,
}: {
  title: string;
  description: string;
  icon: React.ReactNode;
  children: React.ReactNode;
}) {
  return (
    <section className="space-y-2">
      <div className="flex items-center gap-2">
        <span className="text-primary">{icon}</span>
        <h2 className="text-xs font-bold text-on-surface-variant uppercase tracking-wider">{title}</h2>
      </div>
      <p className="text-[11px] text-on-surface-variant">{description}</p>
      {children}
    </section>
  );
}

function SettingsToggle({
  label,
  checked,
  onChange,
}: {
  label: string;
  checked: boolean;
  onChange: (v: boolean) => void;
}) {
  return (
    <label className="flex items-center justify-between cursor-pointer select-none">
      <span className="text-xs font-semibold text-on-surface">{label}</span>
      <button
        type="button"
        role="switch"
        aria-checked={checked}
        onClick={() => onChange(!checked)}
        className={cn(
          'relative w-10 h-6 rounded-full transition-colors cursor-pointer',
          checked ? 'bg-primary' : 'bg-surface-container-highest border border-outline-variant/60'
        )}
      >
        <span
          className={cn(
            'absolute top-1 left-1 w-4 h-4 rounded-full transition-transform duration-150',
            checked ? 'translate-x-4 bg-on-primary shadow-xs' : 'translate-x-0 bg-outline'
          )}
        />
      </button>
    </label>
  );
}
