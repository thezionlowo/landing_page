import { PageHeader } from '@/components/layout/PageHeader';
import { useState, useRef, useEffect } from 'react';
import { useConnectionStore, useUIStore, useSyncStore, useAuthStore } from '@/store';
import { Button, Modal, SyncButton } from '@/components/ui';
import { syncEngine } from '@/services/woocommerce/syncEngine';
import { getDataSyncIntervalMinutes, setDataSyncIntervalMinutes, refreshPendingCount } from '@/services/zameria/posSync';
import { getStoreLogo, saveStoreLogo, removeStoreLogo } from '@/services/storeLogoService';
import { getReceiptPaperWidth, setReceiptPaperWidth, type ThermalPaperWidth } from '@/services/printService';
import { cn } from '@/lib';
import { toast } from 'sonner';
import {
  Store,
  WifiOff,
  RefreshCw,
  Bell,
  Printer,
  Monitor,
  CreditCard,
  Sun,
  Moon,
  LayoutGrid,
  List,
  Eye,
  EyeOff,
  ExternalLink,
  Download,
  Trash2,
  ShieldCheck,
  Lock,
  Image as ImageIcon,
  Upload,
} from 'lucide-react';
import type { Theme, ListMode, ZameriaRole } from '@/types';

const SETTINGS_SECTIONS = [
  { id: 'woocommerce-staff-account', label: 'Your account' },
  { id: 'store-details-connection', label: 'Store connection' },
  { id: 'store-logo-receipt-branding', label: 'Receipt branding' },
  { id: 'offline-mode', label: 'Offline sales' },
  { id: 'data-synchronization-resync', label: 'Data & sync' },
  { id: 'alert-settings', label: 'Notifications' },
  { id: 'printer-settings', label: 'Receipt printer' },
  { id: 'interface-settings', label: 'Appearance' },
  { id: 'payment-integrations', label: 'Payment recording' },
];

export function SettingsPage() {
  const settingsRef = useRef<HTMLDivElement>(null);
  const [activeSection, setActiveSection] = useState(SETTINGS_SECTIONS[0].id);
  useEffect(() => {
    const root = settingsRef.current;
    if (!root) return;
    const updateSection = () => {
      const threshold = root.getBoundingClientRect().top + 48;
      const sections = Array.from(root.querySelectorAll<HTMLElement>('.pos-settings-section'));
      const atEnd = root.scrollTop > 0 && root.scrollTop + root.clientHeight >= root.scrollHeight - 2;
      const current = atEnd ? sections.at(-1) : sections.filter(section => section.getBoundingClientRect().top <= threshold).at(-1) || sections[0];
      if (current) setActiveSection(current.id);
    };
    root.addEventListener('scroll', updateSection, { passive: true });
    updateSection();
    return () => root.removeEventListener('scroll', updateSection);
  }, []);
  const { storeName, storeUrl } = useConnectionStore();
  const {
    theme,
    setTheme,
    listMode,
    setListMode,
    showCartThumbnails,
    setShowCartThumbnails,
    isDemoMode,
  } = useUIStore();
  const { pendingCount } = useSyncStore();
  const { user, hasPermission, revalidate } = useAuthStore();

  const [syncInterval, setSyncInterval] = useState(getDataSyncIntervalMinutes);
  const [autoPrint, setAutoPrintState] = useState<boolean>(() => {
    return typeof window !== 'undefined' && localStorage.getItem('zameria_auto_print') === 'true';
  });

  const handleSetAutoPrint = (val: boolean) => {
    setAutoPrintState(val);
    if (typeof window !== 'undefined') {
      localStorage.setItem('zameria_auto_print', String(val));
    }
  };

  const [paperWidth, setPaperWidthState] = useState<ThermalPaperWidth>(() => getReceiptPaperWidth());

  const handleSetPaperWidth = (width: ThermalPaperWidth) => {
    setPaperWidthState(width);
    setReceiptPaperWidth(width);
  };
  const [showFullResyncModal, setShowFullResyncModal] = useState(false);
  const [isFullResyncing, setIsFullResyncing] = useState(false);
  const [isRevalidating, setIsRevalidating] = useState(false);

  const connectedStoreUrl = user?.storeUrl || storeUrl;
  // Same key the receipt uses to look the logo up (see ReceiptModal).
  const currentStoreIdentifier = isDemoMode ? 'demo.zameria.co' : (connectedStoreUrl || user?.storeName || storeName || 'default');
  const [storeLogo, setStoreLogoState] = useState<string | null>(() => getStoreLogo(currentStoreIdentifier));
  const logoInputRef = useRef<HTMLInputElement>(null);
  const canManageWoo = hasPermission('canManageWooConnection');
  const canManageStoreLogo = hasPermission('canManageStoreLogo');

  const handleLogoUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    if (!file.type.startsWith('image/')) {
      toast.error('Please upload an image file (PNG, JPG, WebP, or SVG).');
      return;
    }

    if (file.size > 2 * 1024 * 1024) {
      toast.error('Store logo must be under 2MB.');
      return;
    }

    const reader = new FileReader();
    reader.onload = async () => {
      const dataUrl = reader.result as string;
      await saveStoreLogo(currentStoreIdentifier, dataUrl);
      setStoreLogoState(dataUrl);
      toast.success('Store logo updated! It will appear on all your store receipts.');
    };
    reader.readAsDataURL(file);
    e.target.value = '';
  };

  const handleRemoveLogo = async () => {
    await removeStoreLogo(currentStoreIdentifier);
    setStoreLogoState(null);
    toast.success('Store logo removed. Receipts will now use the default ZAMERIA logo.');
  };

  const handleExecuteFullResync = async () => {
    setIsFullResyncing(true);
    try {
      toast.info('Starting full reconciliation with WooCommerce...');
      const summary = await syncEngine.sync({ scope: 'full', forceFull: true });
      if (summary.status !== 'success') throw new Error(summary.error || 'Some store data could not be synchronized. Please retry.');
      setShowFullResyncModal(false);
      toast.success('Full store resynchronization completed successfully!');
    } catch (err: any) {
      toast.error(err?.message || 'Full resync failed');
    } finally {
      setIsFullResyncing(false);
    }
  };

  const handleRevalidateSession = async () => {
    setIsRevalidating(true);
    try {
      await revalidate();
      toast.success('WooCommerce permissions revalidated successfully!');
    } catch (err: any) {
      toast.error(err.message || 'Failed to revalidate WooCommerce permissions.');
    } finally {
      setIsRevalidating(false);
    }
  };

  const handleExportOfflineActivity = () => {
    const exportData = {
      exportDate: new Date().toISOString(),
      storeName: isDemoMode ? 'ZAMERIA Demo Store' : storeName,
      offlineQueueCount: pendingCount,
    };
    const blob = new Blob([JSON.stringify(exportData, null, 2)], {
      type: 'application/json',
    });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `zameria-offline-export-${Date.now()}.json`;
    a.click();
    URL.revokeObjectURL(url);
    toast.success('Offline activity exported');
  };

  const handleRefreshOfflineActivity = async () => { await refreshPendingCount(); toast.success('Offline queue checked. Saved sales are preserved.'); };

  const roleStyles: Record<ZameriaRole, string> = {
    administrator: 'bg-emerald-500/10 text-emerald-600 border-emerald-500/20',
    shop_manager: 'bg-sky-500/10 text-sky-600 border-sky-500/20',
    cashier: 'bg-amber-500/10 text-amber-600 border-amber-500/20',
    restricted: 'bg-purple-500/10 text-purple-600 border-purple-500/20',
  };

  const currentRole: ZameriaRole = user?.role || 'restricted';

  return (
    <div ref={settingsRef} className="pos-settings h-full overflow-y-auto bg-surface-50">
      <PageHeader title="Settings" description="Set up your workspace, receipts and store connection." />
      <div className="pos-settings-layout">
        <nav aria-label="Settings sections" className="pos-settings-navigation">
          <p className="pos-settings-nav-caption">Preferences</p>
          {SETTINGS_SECTIONS.map(section => (
            <a
              key={section.id}
              href={`#${section.id}`}
              aria-current={activeSection === section.id ? 'location' : undefined}
              onClick={event => {
                event.preventDefault();
                document.getElementById(section.id)?.scrollIntoView({ block: 'start' });
              }}
            >{section.label}</a>
          ))}
        </nav>
        <div className="pos-settings-sections">
        {/* 1. Authenticated Staff & WooCommerce Role */}
        <SettingsSection
          id="woocommerce-staff-account"
          title="Your account"
          description="Your signed-in account and access level are managed in WordPress."
          icon={<ShieldCheck className="w-4 h-4 text-primary" />}
        >
          <div className="m3-card-outlined rounded-xl p-4.5 space-y-4 bg-surface text-xs">
            <div className="pos-settings-account flex items-start justify-between">
              <div>
                <div className="flex items-center gap-2">
                  <h3 className="font-bold text-sm text-on-surface">{user?.displayName}</h3>
                  <span
                    className={cn(
                      'text-xs uppercase font-bold tracking-wider px-2 py-0.5 rounded-md border',
                      roleStyles[currentRole]
                    )}
                  >
                    {currentRole.replace('_', ' ')}
                  </span>
                </div>
                <p className="text-on-surface-variant font-mono text-xs mt-0.5">
                  @{user?.username} &bull; {user?.email}
                </p>
              </div>

              <Button
                variant="outline"
                size="sm"
                onClick={handleRevalidateSession}
                disabled={isRevalidating}
                className="text-xs flex items-center gap-1.5"
              >
                <RefreshCw className={cn('w-3.5 h-3.5', isRevalidating && 'animate-spin')} />
                Revalidate
              </Button>
            </div>

            <div className="pt-2.5 border-t border-outline-variant/40 flex items-center justify-between">
              <span className="text-on-surface-variant">Connected Store:</span>
              <span className="font-semibold text-on-surface">{user?.storeName}</span>
            </div>


          </div>
        </SettingsSection>

        {/* 2. Store Details */}
        <SettingsSection
          id="store-details-connection"
          title="Store connection"
          description="Review the WooCommerce store connected to this workspace."
          icon={<Store className="w-4 h-4 text-primary" />}
        >
          <div className="m3-card-outlined rounded-xl p-4.5 space-y-3.5 bg-surface text-xs">
            {!canManageWoo && (
              <div className="p-3 rounded-xl bg-warning/10 border border-warning/30 flex items-center gap-2 text-on-surface">
                <Lock className="w-4 h-4 text-warning flex-shrink-0" />
                <span>
                  <strong>Administrator Access Required:</strong> Your WooCommerce role (
                  {currentRole.toUpperCase()}) cannot modify connection settings or credentials.
                </span>
              </div>
            )}

            <div className="flex items-center justify-between">
              <span className="text-on-surface-variant">Connected Site:</span>
              <span className="font-mono font-medium text-on-surface">
                {isDemoMode ? 'https://demo.zameria.co' : connectedStoreUrl || 'Not connected'}
              </span>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-on-surface-variant">Store Name:</span>
              <span className="font-semibold text-on-surface">
                {isDemoMode ? 'ZAMERIA Demo Store' : user?.storeName || storeName || '—'}
              </span>
            </div>

            {canManageWoo && (
              <div className="flex items-center gap-2 pt-2.5 border-t border-outline-variant/40">
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => window.open(`${connectedStoreUrl.replace(/\/?$/, '/')}wp-admin/admin.php?page=zameria`, '_blank', 'noopener')}
                  icon={<ExternalLink className="w-3.5 h-3.5" />}
                  disabled={!connectedStoreUrl}
                >
                  WooCommerce Admin
                </Button>
                <Button
                  variant="secondary"
                  size="sm"
                  onClick={() => setShowFullResyncModal(true)}
                  icon={<RefreshCw className="w-3.5 h-3.5" />}
                >
                  Resync Data
                </Button>
              </div>
            )}
          </div>
        </SettingsSection>

        {/* Store Logo & Receipt Branding */}
        <SettingsSection
          id="store-logo-receipt-branding"
          title="Receipt branding"
          description="Choose the logo customers see on receipts from this device."
          icon={<ImageIcon className="w-4 h-4 text-primary" />}
        >
          <div className="m3-card-outlined rounded-xl p-4.5 space-y-4 bg-surface text-xs">
            {!canManageStoreLogo ? (
              <div className="p-3 rounded-xl bg-warning/10 border border-warning/30 flex items-center gap-2 text-on-surface">
                <Lock className="w-4 h-4 text-warning flex-shrink-0" />
                <span>
                  <strong>Manager / Administrator Access Required:</strong> Your role ({currentRole.toUpperCase()}) cannot modify store branding or receipt logos.
                </span>
              </div>
            ) : null}

            <div className="pos-settings-branding flex flex-col sm:flex-row sm:items-center justify-between gap-4">
              <div className="flex items-center gap-4">
                {/* Logo Preview Container */}
                <div className="w-24 h-16 rounded-xl border border-outline-variant/80 bg-surface-container-low flex items-center justify-center p-2 overflow-hidden flex-shrink-0">
                  {storeLogo ? (
                    <img
                      src={storeLogo}
                      alt="Store Logo Preview"
                      className="max-h-full max-w-full object-contain"
                    />
                  ) : (
                    <div className="flex flex-col items-center justify-center text-center">
                      <img
                        src="zameria-logo.png"
                        alt="Default ZAMERIA Logo"
                        className="h-5 object-contain opacity-50"
                      />
                      <span className="text-[9px] text-on-surface-variant/70 mt-1 font-mono">
                        (Default)
                      </span>
                    </div>
                  )}
                </div>

                <div>
                  <h4 className="font-bold text-sm text-on-surface">
                    {storeLogo ? 'Custom Store Logo' : 'Default ZAMERIA Logo'}
                  </h4>
                  <p className="text-xs text-on-surface-variant mt-0.5">
                    {storeLogo
                      ? 'Active on customer receipts. Preserves natural aspect ratio.'
                      : 'No custom logo uploaded. Standard ZAMERIA logo will appear on receipts.'}
                  </p>
                  <p className="text-xs text-on-surface-variant/70 font-mono mt-0.5">
                    Store: {isDemoMode ? 'ZAMERIA Demo Store' : (storeName || storeUrl || 'Default Store')}
                  </p>
                </div>
              </div>

              {canManageStoreLogo && (
                <div className="flex items-center gap-2 flex-shrink-0">
                  <input
                    ref={logoInputRef}
                    type="file"
                    accept="image/png,image/jpeg,image/webp,image/svg+xml"
                    onChange={handleLogoUpload}
                    className="hidden"
                    aria-label="Store receipt logo"
                  />
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => logoInputRef.current?.click()}
                    icon={<Upload className="w-3.5 h-3.5" />}
                  >
                    {storeLogo ? 'Replace Logo' : 'Upload Logo'}
                  </Button>

                  {storeLogo && (
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={handleRemoveLogo}
                      icon={<Trash2 className="w-3.5 h-3.5 text-danger" />}
                      className="text-danger hover:bg-danger/10"
                    >
                      Remove
                    </Button>
                  )}
                </div>
              )}
            </div>
          </div>
        </SettingsSection>

        {/* 3. Offline Mode */}
        <SettingsSection
          id="offline-mode"
          title="Offline sales"
          description="Review saved sales and the queue waiting to reach your store."
          icon={<WifiOff className="w-4 h-4 text-primary" />}
        >
          <div className="m3-card-outlined rounded-xl p-4.5 space-y-3.5 bg-surface text-xs">
            <div className="flex items-center justify-between gap-3"><strong className="text-sm text-on-surface">Offline selling</strong><span className="pill pill-synced">Always available</span></div>
            <p className="text-xs text-on-surface-variant leading-relaxed">
              Sales are completed offline using products saved on this device. Internet access is
              required for initial setup, catalogue sync, and remote customer profiles.
            </p>
            <div className="flex items-center justify-between pt-2.5 border-t border-outline-variant/40">
              <div className="text-on-surface-variant">
                Queue Status:{' '}
                <strong className="text-on-surface font-semibold">{pendingCount} sales waiting to sync</strong>
              </div>
              <div className="flex items-center gap-2">
                <Button
                  variant="outline"
                  size="sm"
                  onClick={handleExportOfflineActivity}
                  icon={<Download className="w-3.5 h-3.5" />}
                >
                  Export summary
                </Button>
                <Button
                  variant="secondary"
                  size="sm"
                  onClick={() => void handleRefreshOfflineActivity()}
                  icon={<RefreshCw className="w-4 h-4" />}
                >
                  Recheck queue
                </Button>
              </div>
            </div>
          </div>
        </SettingsSection>

        {/* 4. Data Synchronization & Resync */}
        <SettingsSection
          id="data-synchronization-resync"
          title="Data & sync"
          description="Refresh store records and choose how often background data updates on this device."
          icon={<RefreshCw className="w-4 h-4 text-primary" />}
        >
          <div className="m3-card-outlined rounded-xl p-4.5 space-y-4 bg-surface text-xs">
            {/* Entity Quick Sync Rows */}
            <div className="space-y-2">
              <span className="font-semibold text-on-surface text-xs">
                Refresh individual records
              </span>
              <div className="pos-settings-sync-list grid grid-cols-1 sm:grid-cols-2 gap-2">
                <div className="flex items-center justify-between p-2.5 rounded-lg bg-surface-container-low border border-outline-variant/40">
                  <div>
                    <div className="font-semibold text-on-surface">Product Catalogue</div>
                    <div className="text-xs text-on-surface-variant">Products, categories & media</div>
                  </div>
                  <SyncButton scope="products" label="Sync" size="sm" variant="outline" />
                </div>

                <div className="flex items-center justify-between p-2.5 rounded-lg bg-surface-container-low border border-outline-variant/40">
                  <div>
                    <div className="font-semibold text-on-surface">Inventory Stock</div>
                    <div className="text-xs text-on-surface-variant">Stock levels & stock statuses</div>
                  </div>
                  <SyncButton scope="inventory" label="Sync" size="sm" variant="outline" />
                </div>

                <div className="flex items-center justify-between p-2.5 rounded-lg bg-surface-container-low border border-outline-variant/40">
                  <div>
                    <div className="font-semibold text-on-surface">Orders & Sales</div>
                    <div className="text-xs text-on-surface-variant">Online web orders & POS sync</div>
                  </div>
                  <SyncButton scope="orders" label="Sync" size="sm" variant="outline" />
                </div>

                <div className="flex items-center justify-between p-2.5 rounded-lg bg-surface-container-low border border-outline-variant/40">
                  <div>
                    <div className="font-semibold text-on-surface">Customer Profiles</div>
                    <div className="text-xs text-on-surface-variant">Billing, addresses & history</div>
                  </div>
                  <SyncButton scope="customers" label="Sync" size="sm" variant="outline" />
                </div>

                <div className="flex items-center justify-between p-2.5 rounded-lg bg-surface-container-low border border-outline-variant/40 sm:col-span-2">
                  <div>
                    <div className="font-semibold text-on-surface">Coupons & Discounts</div>
                    <div className="text-xs text-on-surface-variant">WooCommerce coupon rules, limits & validity</div>
                  </div>
                  <SyncButton scope="coupons" label="Sync Coupons" size="sm" variant="outline" />
                </div>
              </div>
            </div>

            {/* Polling Frequency Slider */}
            <div className="pt-3 border-t border-outline-variant/40">
              <div className="flex justify-between font-semibold text-on-surface mb-1.5">
                <label htmlFor="settings-refresh-interval">Customer, category & coupon refresh</label>
                <span className="tabular-nums font-bold text-primary">{syncInterval} minutes</span>
              </div>
              <input
                type="range"
                id="settings-refresh-interval"
                aria-valuetext={`${syncInterval} minutes`}
                min={1}
                max={60}
                step={1}
                value={syncInterval}
                onChange={(e) => { const value = Number(e.target.value); setSyncInterval(value); setDataSyncIntervalMinutes(value); }}
                className="w-full h-1.5 bg-surface-container-highest rounded-lg appearance-none cursor-pointer accent-primary"
              />
              <div className="flex justify-between text-xs text-on-surface-variant mt-1">
                <span>1 min (frequent)</span>
                <span>60 min (battery saving)</span>
              </div>
            </div>

            {/* Full Store Resync Trigger */}
            <div className="pt-3 border-t border-outline-variant/40 flex items-center justify-between">
              <div>
                <div className="font-bold text-on-surface">Full Store Resync</div>
                <p className="text-xs text-on-surface-variant">
                  Re-fetch and reconcile all WooCommerce categories, products, inventory, customers, and orders.
                </p>
              </div>
              <Button
                variant="secondary"
                size="sm"
                onClick={() => setShowFullResyncModal(true)}
                disabled={!canManageWoo}
                icon={<RefreshCw className="w-3.5 h-3.5" />}
              >
                Full Resync
              </Button>
            </div>
          </div>
        </SettingsSection>

        {/* 5. Alert Settings */}
        <SettingsSection
          id="alert-settings"
          title="Notifications"
          description="Control notifications for background orders and network status."
          icon={<Bell className="w-4 h-4 text-primary" />}
        >
          <div className="m3-card-outlined rounded-xl p-4.5 bg-surface">
            <p className="text-sm text-on-surface">Connection, payment and synchronization messages appear while you work.</p><p className="text-xs text-on-surface-variant mt-2">Check the status in the top bar to review queued sales and store updates.</p>
          </div>
        </SettingsSection>

        {/* 6. Printer Settings */}
        <SettingsSection
          id="printer-settings"
          title="Receipt printer"
          description="Set the receipt size and printing preferences for this device."
          icon={<Printer className="w-4 h-4 text-primary" />}
        >
          <div className="m3-card-outlined rounded-xl p-4.5 space-y-4 bg-surface text-xs">
            <SettingsToggle
              label="Auto-print receipt after order completion"
              checked={autoPrint}
              onChange={handleSetAutoPrint}
            />
            <p className="text-xs text-on-surface-variant">
              When enabled, POS will automatically trigger the system print dialog when a sale is completed.
            </p>

            <div className="pt-2 border-t border-outline-variant/60 space-y-2">
              <span className="text-on-surface font-semibold block">Thermal Paper Roll Width:</span>
              <div role="group" aria-label="Receipt paper width" className="pos-settings-choices grid grid-cols-1 sm:grid-cols-2 gap-2">
                {[
                  { value: '80mm' as const, label: '80mm Standard Thermal', desc: 'Standard POS thermal roll (Default)' },
                  { value: '58mm' as const, label: '58mm Compact Thermal', desc: 'Compact / mobile portable printers' },
                ].map((pw) => (
                  <button
                    key={pw.value}
                    type="button"
                    aria-pressed={paperWidth === pw.value}
                    onClick={() => handleSetPaperWidth(pw.value)}
                    className={cn(
                      'p-2.5 rounded-lg border text-left transition-all cursor-pointer',
                      paperWidth === pw.value
                        ? 'bg-primary/10 border-primary text-primary font-bold shadow-xs'
                        : 'border-outline-variant hover:bg-surface-container-low text-on-surface'
                    )}
                  >
                    <div className="font-semibold">{pw.label}</div>
                    <div className="text-xs text-on-surface-variant mt-0.5">{pw.desc}</div>
                  </button>
                ))}
              </div>
            </div>
          </div>
        </SettingsSection>

        {/* 7. Interface Settings */}
        <SettingsSection
          id="interface-settings"
          title="Appearance"
          description="Choose your theme and how products appear while selling. Changes apply immediately."
          icon={<Monitor className="w-4 h-4 text-primary" />}
        >
          <div className="m3-card-outlined rounded-xl p-4.5 space-y-4 bg-surface text-xs">
            {/* Appearance */}
            <div>
              <span className="text-on-surface font-semibold block mb-2">Appearance Theme:</span>
              <div role="group" aria-label="Colour theme" className="pos-settings-choices grid grid-cols-3 gap-2">
                {[
                  { value: 'system' as Theme, icon: Monitor, label: 'System' },
                  { value: 'light' as Theme, icon: Sun, label: 'Light' },
                  { value: 'dark' as Theme, icon: Moon, label: 'Dark' },
                ].map((opt) => (
                  <button
                    key={opt.value}
                    type="button"
                    aria-pressed={theme === opt.value}
                    onClick={() => setTheme(opt.value)}
                    className={cn(
                      'flex items-center justify-center gap-2 py-2 px-3 rounded-lg border text-xs font-semibold transition-colors cursor-pointer',
                      theme === opt.value
                        ? 'border-primary bg-primary-container/25 text-primary font-bold shadow-xs'
                        : 'border-outline-variant/60 bg-surface text-on-surface-variant hover:bg-surface-container-low hover:text-on-surface'
                    )}
                  >
                    <opt.icon className="w-3.5 h-3.5" />
                    {opt.label}
                  </button>
                ))}
              </div>
            </div>

            {/* Sale Screen List Mode */}
            <div className="pt-3 border-t border-outline-variant/40">
              <span className="text-on-surface font-semibold block mb-2">
                Sale Screen Catalogue Mode:
              </span>
              <div role="group" aria-label="Catalogue display" className="pos-settings-choices grid grid-cols-2 gap-2">
                {[
                  { value: 'grid' as ListMode, icon: LayoutGrid, label: 'Grid View' },
                  { value: 'list' as ListMode, icon: List, label: 'List View' },
                ].map((opt) => (
                  <button
                    key={opt.value}
                    type="button"
                    aria-pressed={listMode === opt.value}
                    onClick={() => setListMode(opt.value)}
                    className={cn(
                      'flex items-center justify-center gap-2 py-2 px-3 rounded-lg border text-xs font-semibold transition-colors cursor-pointer',
                      listMode === opt.value
                        ? 'border-primary bg-primary-container/25 text-primary font-bold shadow-xs'
                        : 'border-outline-variant/60 bg-surface text-on-surface-variant hover:bg-surface-container-low hover:text-on-surface'
                    )}
                  >
                    <opt.icon className="w-3.5 h-3.5" />
                    {opt.label}
                  </button>
                ))}
              </div>
            </div>

            {/* Cart Product Thumbnails */}
            <div className="pt-3 border-t border-outline-variant/40">
              <span className="text-on-surface font-semibold block mb-2">
                Cart Product Thumbnails:
              </span>
              <div role="group" aria-label="Cart thumbnails" className="pos-settings-choices grid grid-cols-2 gap-2">
                <button
                  type="button"
                  aria-pressed={showCartThumbnails}
                  onClick={() => setShowCartThumbnails(true)}
                  className={cn(
                    'flex items-center justify-center gap-2 py-2 px-3 rounded-lg border text-xs font-semibold transition-colors cursor-pointer',
                    showCartThumbnails
                      ? 'border-primary bg-primary-container/25 text-primary font-bold shadow-xs'
                      : 'border-outline-variant/60 bg-surface text-on-surface-variant hover:bg-surface-container-low hover:text-on-surface'
                  )}
                >
                  <Eye className="w-3.5 h-3.5" />
                  Show Thumbnails
                </button>
                <button
                  type="button"
                  aria-pressed={!showCartThumbnails}
                  onClick={() => setShowCartThumbnails(false)}
                  className={cn(
                    'flex items-center justify-center gap-2 py-2 px-3 rounded-lg border text-xs font-semibold transition-colors cursor-pointer',
                    !showCartThumbnails
                      ? 'border-primary bg-primary-container/25 text-primary font-bold shadow-xs'
                      : 'border-outline-variant/60 bg-surface text-on-surface-variant hover:bg-surface-container-low hover:text-on-surface'
                  )}
                >
                  <EyeOff className="w-3.5 h-3.5" />
                  Hide Thumbnails
                </button>
              </div>
            </div>
          </div>
        </SettingsSection>

        {/* 8. Payment Integrations */}
        <SettingsSection
          id="payment-integrations"
          title="Payment recording"
          description="How payments are recorded at your till."
          icon={<CreditCard className="w-4 h-4 text-primary" />}
        >
          <div className="pos-payment-settings m3-card-outlined rounded-xl p-5 bg-surface"><p className="text-sm text-on-surface">Record payments received as cash, by card terminal, by bank transfer, or across multiple methods.</p><p className="text-xs text-on-surface-variant mt-2">Card and bank payments take place on your terminal or banking app. Select the matching method when completing the sale in ZAMERIA.</p><div className="flex flex-wrap gap-2 mt-4">{['Cash','POS Terminal','Bank Transfer','Split Payment'].map(method=><span key={method} className="px-3 py-2 rounded-lg bg-surface-container-low border border-outline-variant text-xs font-medium text-on-surface">{method}</span>)}</div></div>
        </SettingsSection>
        </div>
      </div>



      {/* Confirmation Modal for Full Store Resync */}
      <Modal
        open={showFullResyncModal}
        onClose={() => !isFullResyncing && setShowFullResyncModal(false)}
        title="Full Store Resynchronization"
        size="md"
      >
        <div className="space-y-4 text-xs">
          <div className="p-3.5 bg-primary/10 border border-primary/20 rounded-xl space-y-2 text-on-surface">
            <h4 className="font-bold text-sm text-primary flex items-center gap-1.5">
              <RefreshCw className="w-4 h-4" />
              Reconcile All Store Entities
            </h4>
            <p className="leading-relaxed text-on-surface-variant">
              This operation will query your connected WooCommerce store and update local catalogue items, stock quantities, customers, orders, and coupons using full API pagination.
            </p>
            <ul className="list-disc pl-4 space-y-1 text-on-surface-variant">
              <li>Local unsaved offline orders and completed historical transactions are safely preserved.</li>
              <li>Existing products and orders will be reconciled by WooCommerce ID (no duplicates).</li>
              <li>Depending on catalogue size, this operation may take a few moments.</li>
            </ul>
          </div>

          <div className="flex justify-end gap-2.5 pt-2">
            <Button
              variant="secondary"
              size="sm"
              disabled={isFullResyncing}
              onClick={() => setShowFullResyncModal(false)}
            >
              Cancel
            </Button>
            <Button
              variant="primary"
              size="sm"
              loading={isFullResyncing}
              onClick={handleExecuteFullResync}
              icon={<RefreshCw className={cn('w-3.5 h-3.5', isFullResyncing && 'animate-spin')} />}
            >
              Start Full Resync
            </Button>
          </div>
        </div>
      </Modal>
    </div>
  );
}

function SettingsSection({
  id,
  title,
  description,
  icon,
  children,
}: {
  id: string;
  title: string;
  description: string;
  icon: React.ReactNode;
  children: React.ReactNode;
}) {
  return (
    <section id={id} aria-labelledby={`${id}-heading`} className="pos-settings-section space-y-3">
      <div className="pos-settings-section-heading">
        <div className="flex items-center gap-2">
          <span className="text-on-surface-variant" aria-hidden="true">{icon}</span>
          <h2 id={`${id}-heading`} className="text-base font-semibold text-on-surface">{title}</h2>
        </div>
        <p className="text-xs text-on-surface-variant">{description}</p>
      </div>
      {children}
    </section>
  );
}

function SettingsToggle({
  label,
  checked,
  onChange,
}: {
  label: string;
  checked: boolean;
  onChange: (v: boolean) => void;
}) {
  return (
    <label className="pos-settings-toggle flex items-center justify-between gap-4 cursor-pointer select-none">
      <span className="text-xs font-semibold text-on-surface">{label}</span>
      <button
        type="button"
        role="switch"
        aria-checked={checked}
        aria-label={label}
        onClick={() => onChange(!checked)}
        className={cn(
          'relative w-10 h-6 rounded-full transition-colors cursor-pointer',
          checked ? 'bg-primary' : 'bg-surface-container-highest border border-outline-variant/60'
        )}
      >
        <span
          className={cn(
            'absolute top-1 left-1 w-4 h-4 rounded-full transition-transform duration-150',
            checked ? 'translate-x-4 bg-on-primary shadow-xs' : 'translate-x-0 bg-outline'
          )}
        />
      </button>
    </label>
  );
}
