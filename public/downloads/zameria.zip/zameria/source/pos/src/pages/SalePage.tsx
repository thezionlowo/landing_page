import { PageHeader } from '@/components/layout/PageHeader';
import { useState, useMemo, useEffect, useRef } from 'react';
import { useLiveQuery } from 'dexie-react-hooks';
import { db } from '@/db';
import { useCartStore, useUIStore, useAuthStore, useSyncStore } from '@/store';
import {
  SearchInput,
  Button,
  Input,
  QuantityStepper,
  EmptyState,
  SkeletonRow,
  Drawer,
  Modal,
  Badge,
  ReceiptModal,
  BarcodeScannerModal,
  ResizableSplitView,
  SyncButton,
} from '@/components/ui';
import { formatMoney, cn, useResponsive, useStoreCurrency } from '@/lib';
import { toast } from 'sonner';
import {
  ScanBarcode,
  ShoppingCart,
  LayoutGrid,
  List,
  ChevronRight,
  Package,
  Trash2,
  Save,
  CheckCircle,
  User,
  SlidersHorizontal,
  X,
  Plus,
  AlertCircle,
  FileText,
  Tag,
  Loader2,
  Clock,
  Search,
  Mail,
} from 'lucide-react';
import { AddProductModal } from '@/components/product/AddProductModal';
import { HeldOrdersModal } from '@/components/order/HeldOrdersModal';
import { isOrderAccessibleToUser } from '@/services/auth/orderAccess';
import type { Product, ProductVariation, Discount, DiscountType, Order, OrderItem, PaymentSplit, Customer } from '@/types';
import { VariationPickerModal } from '@/components/product/VariationPickerModal';
import { createCustomer } from '@/services/woocommerce';

interface SplitRow {
  id: string;
  method: string;
  amountStr: string;
}

export function getProductStockInfo(p: Product): { text: string; variant: 'normal' | 'low' | 'out' | 'untracked' } {
  if (
    p.stockStatus === 'outofstock' ||
    (p.manageStock && p.stockQuantity !== null && p.stockQuantity !== undefined && p.stockQuantity <= 0)
  ) {
    return { text: 'Out of stock', variant: 'out' };
  }
  if (!p.manageStock || p.stockQuantity === null || p.stockQuantity === undefined) {
    return { text: 'Stock not tracked', variant: 'untracked' };
  }
  const qty = p.stockQuantity;
  const lowThreshold = p.lowStockThreshold ?? 5;
  if (qty <= lowThreshold) {
    return { text: `Stock: ${qty} left`, variant: 'low' };
  }
  return { text: `Stock: ${qty} left`, variant: 'normal' };
}

export function SalePage() {
  const [search, setSearch] = useState('');
  const [variationPickerProduct, setVariationPickerProduct] = useState<Product | null>(null);
  const [selectedCategory, setSelectedCategory] = useState<number | null>(null);
  const [selectedBrand, setSelectedBrand] = useState<number | null>(null);
  const [stockFilter, setStockFilter] = useState<'all' | 'instock' | 'lowstock'>('all');
  const [showFilterMenu, setShowFilterMenu] = useState(false);

  // Modals & Panels
  const { isMobile } = useResponsive();
  const currency = useStoreCurrency();
  const [showMobileCartDrawer, setShowMobileCartDrawer] = useState(false);
  const [productToolsItemId, setProductToolsItemId] = useState<number | null>(null);
  const [showScannerModal, setShowScannerModal] = useState(false);
  const [showCheckoutModal, setShowCheckoutModal] = useState(false);
  const [showCancelCartModal, setShowCancelCartModal] = useState(false);
  const [showAddModal, setShowAddModal] = useState(false);
  const [pendingBarcodeForModal, setPendingBarcodeForModal] = useState('');
  const [completedSale, setCompletedSale] = useState<{ order: Order; items: OrderItem[] } | null>(null);

  // Discount tool state
  const [discountType, setDiscountType] = useState<DiscountType>('percentage');
  const [discountValue, setDiscountValue] = useState('');

  // Checkout modal state
  const [paymentMethod, setPaymentMethod] = useState('cash');
  const [tenderedAmount, setTenderedAmount] = useState('');
  const [splits, setSplits] = useState<SplitRow[]>([
    { id: '1', method: 'cash', amountStr: '' },
    { id: '2', method: 'pos', amountStr: '' },
    { id: '3', method: 'transfer', amountStr: '' },
  ]);
  const [isProcessingCheckout, setIsProcessingCheckout] = useState(false);
  const [isHoldingOrder, setIsHoldingOrder] = useState(false);
  const [showHeldOrdersModal, setShowHeldOrdersModal] = useState(false);

  // Coupon & Note states
  const [couponInput, setCouponInput] = useState('');
  const [isApplyingCoupon, setIsApplyingCoupon] = useState(false);
  const [showNoteInput, setShowNoteInput] = useState(false);
  const [showCouponInput, setShowCouponInput] = useState(false);

  const { listMode, setListMode, showCartThumbnails } = useUIStore();
  const { user, hasPermission } = useAuthStore();
  const canManageProducts = hasPermission('canCreateProduct') || hasPermission('canEditProduct');
  const canApplyDiscount = hasPermission('canApplyDiscount');
  const canHoldOrder = hasPermission('canHoldOrder');
  const canCompleteSale = hasPermission('canCompleteSale');
  // Local register checkout remains unlocked; SaaS subscriptions govern cloud synchronization and multi-terminal management.
  const isEntitled = true;

  const cart = useCartStore();
  const totals = cart.getTotals();

  // Live query for held orders count accessible to current user
  const heldOrdersCount = useLiveQuery(async () => {
    const orders = await db.orders.where('status').equals('on-hold').toArray();
    return orders.filter((o) => isOrderAccessibleToUser(o, user)).length;
  }, [user]) || 0;

  // Initialize cart
  useEffect(() => {
    cart.initCart();
  }, []);

  // Customer assignment & inline creation state
  const [showCustomerSearchModal, setShowCustomerSearchModal] = useState(false);
  const [customerSearchQuery, setCustomerSearchQuery] = useState('');
  const [showAddCustomerModal, setShowAddCustomerModal] = useState(false);
  const [newCustName, setNewCustName] = useState('');
  const [newCustPhone, setNewCustPhone] = useState('');
  const [newCustEmail, setNewCustEmail] = useState('');
  const [isCreatingCustomer, setIsCreatingCustomer] = useState(false);
  const [addCustError, setAddCustError] = useState<string | null>(null);
  const [duplicateCust, setDuplicateCust] = useState<Customer | null>(null);

  // Progressive rendering state to prevent DOM explosion and browser memory crashes
  const [visibleProductCount, setVisibleProductCount] = useState(60);

  // Targeted customer search query (only queries when modal is open, max 20 results)
  const customerSearchResults = useLiveQuery(
    async () => {
      if (!showCustomerSearchModal) return [];
      const q = customerSearchQuery.trim().toLowerCase();
      if (!q) {
        return await db.customers.orderBy('id').reverse().limit(20).toArray();
      }
      const cleanDigits = q.replace(/\D/g, '');
      return await db.customers
        .filter((c) => {
          const fullName = `${c.firstName} ${c.lastName}`.toLowerCase();
          const email = (c.email || '').toLowerCase();
          const phone = (c.billing?.phone || '').replace(/\D/g, '');
          return (
            fullName.includes(q) ||
            email.includes(q) ||
            (cleanDigits.length >= 3 && phone.includes(cleanDigits))
          );
        })
        .limit(20)
        .toArray();
    },
    [showCustomerSearchModal, customerSearchQuery]
  );

  // Live queries (Active catalogue restricted to published products via indexed B-tree lookup)
  const products = useLiveQuery(
    () => db.products.where('status').equals('publish').toArray(),
    []
  );
  const categories = useLiveQuery(() => db.categories.toArray(), []);
  const brands = useLiveQuery(() => db.brands.toArray(), []);

  // Alphabetically sorted brand list for the POS toolbar filter dropdown
  const sortedBrands = useMemo(() => {
    if (!brands) return [];
    return [...brands].sort((a, b) =>
      (a.name || '').localeCompare(b.name || '', undefined, {
        sensitivity: 'base',
        numeric: true,
      })
    );
  }, [brands]);

  const salesReady = useSyncStore((s) => s.salesReady);

  useEffect(() => {
    if (products && products.length > 0 && !salesReady) {
      useSyncStore.getState().setSalesReady(true);
    }
  }, [products, salesReady]);

  // Filter products
  const filteredProducts = useMemo(() => {
    if (!products) return [];
    let list = products;

    if (search.trim()) {
      const q = search.trim().toLowerCase();
      list = list.filter(
        (p) =>
          (p.name || '').toLowerCase().includes(q) ||
          (p.sku || '').toLowerCase().includes(q) ||
          (p.brandName && p.brandName.toLowerCase().includes(q)) ||
          (p.brand?.name && p.brand.name.toLowerCase().includes(q)) ||
          (p.barcode && p.barcode.toLowerCase().includes(q)) ||
          (p.upc && p.upc.toLowerCase().includes(q)) ||
          (p.ean && p.ean.toLowerCase().includes(q)) ||
          (p.gtin && p.gtin.toLowerCase().includes(q)) ||
          (p.isbn && p.isbn.toLowerCase().includes(q)) ||
          String(p.wooId || '').includes(q)
      );
    }

    if (selectedCategory !== null) {
      list = list.filter((p) => p.categoryIds?.includes(selectedCategory));
    }

    if (selectedBrand !== null) {
      list = list.filter((p) => p.brandId === selectedBrand || p.wooBrandId === selectedBrand);
    }

    if (stockFilter === 'instock') {
      list = list.filter((p) => p.stockStatus === 'instock');
    } else if (stockFilter === 'lowstock') {
      list = list.filter((p) => p.manageStock && p.stockQuantity !== null && p.stockQuantity <= 5);
    }

    return list;
  }, [products, search, selectedCategory, selectedBrand, stockFilter]);

  // Reset progressive display count when search or filter criteria change
  useEffect(() => {
    setVisibleProductCount(60);
  }, [search, selectedCategory, selectedBrand, stockFilter]);

  const displayedProducts = useMemo(() => {
    return filteredProducts.slice(0, visibleProductCount);
  }, [filteredProducts, visibleProductCount]);

  // Hardware barcode scanner buffer
  const barcodeBuffer = useRef('');
  const lastKeyTime = useRef(0);

  useEffect(() => {
    const handleWindowKeyDown = async (e: KeyboardEvent) => {
      const target = e.target as HTMLElement;
      const isInput = target.tagName === 'INPUT' || target.tagName === 'TEXTAREA' || target.isContentEditable;

      const now = Date.now();
      const timeDiff = now - lastKeyTime.current;

      // Hardware barcode scanners send keystrokes extremely rapidly (typically 10-50ms apart).
      // If delay between keystrokes exceeds 120ms, it is a new sequence.
      if (timeDiff > 120) {
        barcodeBuffer.current = '';
      }
      lastKeyTime.current = now;

      // Handle barcode terminators (Enter or Tab)
      if (e.key === 'Enter' || e.key === 'Tab') {
        const candidate = barcodeBuffer.current.trim();
        if (candidate.length >= 3) {
          e.preventDefault();
          barcodeBuffer.current = '';
          await handleBarcodeScanned(candidate);
          return;
        }
      }

      // If typing manually in a form input (> 80ms delay between keys), let native input handle it
      if (isInput && timeDiff > 80 && barcodeBuffer.current.length < 2) {
        barcodeBuffer.current = '';
        return;
      }

      // Buffer printable characters (length 1), ignoring control modifier combinations
      if (e.key.length === 1 && !e.ctrlKey && !e.metaKey && !e.altKey) {
        barcodeBuffer.current += e.key;
      }
    };

    window.addEventListener('keydown', handleWindowKeyDown);
    return () => window.removeEventListener('keydown', handleWindowKeyDown);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [products]);

  const handleBarcodeScanned = async (code: string): Promise<boolean> => {
    // 1. Strip hidden ASCII control characters (\x00-\x1F, \x7F-\x9F), newlines, carriage returns, tabs
    const rawCleaned = code.replace(/[\x00-\x1F\x7F-\x9F]/g, '').trim();
    if (!rawCleaned) return false;
    const query = rawCleaned.toLowerCase();

    if (!products || products.length === 0) {
      toast.error('Product catalog not loaded yet.');
      return false;
    }

    // 2. Direct product barcode match
    let matchedProduct: Product | undefined = products.find(
      (p) => p.barcode?.trim().toLowerCase() === query
    );
    let matchedVariation: ProductVariation | undefined = undefined;

    // 3. Variable product variation barcode match
    if (!matchedProduct) {
      for (const p of products) {
        if (p.variations && p.variations.length > 0) {
          const v = p.variations.find((varItem) => varItem.barcode?.trim().toLowerCase() === query);
          if (v) {
            matchedProduct = p;
            matchedVariation = v;
            break;
          }
        }
      }
    }

    // 4. Match with leading zeros stripped (e.g. scanner sent 001234 but barcode stored as 1234)
    const strippedZeros = query.replace(/^0+/, '');
    if (!matchedProduct && strippedZeros && strippedZeros !== query) {
      matchedProduct = products.find(
        (p) => p.barcode?.trim().toLowerCase() === strippedZeros || p.sku?.trim().toLowerCase() === strippedZeros
      );
      if (!matchedProduct) {
        for (const p of products) {
          if (p.variations && p.variations.length > 0) {
            const v = p.variations.find(
              (varItem) =>
                varItem.barcode?.trim().toLowerCase() === strippedZeros ||
                varItem.sku?.trim().toLowerCase() === strippedZeros
            );
            if (v) {
              matchedProduct = p;
              matchedVariation = v;
              break;
            }
          }
        }
      }
    }

    // 5. Fallback: match by SKU or variation SKU
    if (!matchedProduct) {
      matchedProduct = products.find((p) => p.sku?.trim().toLowerCase() === query);
      if (!matchedProduct) {
        for (const p of products) {
          if (p.variations && p.variations.length > 0) {
            const v = p.variations.find((varItem) => varItem.sku?.trim().toLowerCase() === query);
            if (v) {
              matchedProduct = p;
              matchedVariation = v;
              break;
            }
          }
        }
      }
    }

    // 6. Fallback: match by standard identifiers (UPC, EAN, GTIN, ISBN, WooCommerce ID, local ID)
    if (!matchedProduct) {
      matchedProduct = products.find(
        (p) =>
          p.upc?.trim().toLowerCase() === query ||
          p.ean?.trim().toLowerCase() === query ||
          p.gtin?.trim().toLowerCase() === query ||
          p.isbn?.trim().toLowerCase() === query ||
          String(p.wooId) === query ||
          String(p.id) === query
      );
    }

    if (matchedProduct) {
      const displayName = matchedVariation
        ? `${matchedProduct.name}${matchedVariation.attributes?.length ? ` (${matchedVariation.attributes.map((a) => a.option).join(' / ')})` : ''}`
        : matchedProduct.name;

      // Check stock rules
      const isOutOfStock = matchedVariation
        ? matchedVariation.stockStatus === 'outofstock' ||
          (matchedVariation.manageStock &&
            matchedVariation.stockQuantity !== null &&
            matchedVariation.stockQuantity <= 0)
        : matchedProduct.stockStatus === 'outofstock' ||
          (matchedProduct.manageStock &&
            matchedProduct.stockQuantity !== null &&
            matchedProduct.stockQuantity <= 0);

      if (isOutOfStock) {
        toast.error(`${displayName} is currently out of stock`);
        return true;
      }

      // Check remaining available stock against cart
      const targetManageStock = matchedVariation ? matchedVariation.manageStock : matchedProduct.manageStock;
      const targetStockQty = matchedVariation ? matchedVariation.stockQuantity : matchedProduct.stockQuantity;

      if (targetManageStock && targetStockQty !== null && targetStockQty !== undefined) {
        const inCartItem = cart.items.find((i) =>
          matchedVariation
            ? i.productId === matchedProduct!.id && i.variationId === matchedVariation.id
            : i.productId === matchedProduct!.id && !i.variationId
        );
        if (inCartItem && inCartItem.quantity >= targetStockQty) {
          toast.warning(`Cannot add more: only ${targetStockQty} available in stock.`);
          return true;
        }
      }

      // Add to current active cart through sequential mutex queue
      await cart.addItem(matchedProduct, matchedVariation);

      toast.success(`✓ Scanned: ${displayName}`, {
        description: `${formatMoney(
          matchedVariation
            ? (matchedVariation.salePrice ?? matchedVariation.price)
            : (matchedProduct.salePrice ?? matchedProduct.price)
        )}`,
        icon: <CheckCircle className="w-4 h-4 text-emerald-600" />,
      });
      return true;
    }

    // Product not found
    toast.error('Product not found', {
      description: `Barcode: ${rawCleaned}`,
      action: canManageProducts
        ? {
            label: 'Add Product',
            onClick: () => {
              setPendingBarcodeForModal(rawCleaned);
              setShowAddModal(true);
            },
          }
        : {
            label: 'Try Again',
            onClick: () => setShowScannerModal(true),
          },
    });
    return false;
  };

  const handleAddToCart = async (product: Product) => {
    // Variable products: the cashier must pick the exact variation that is being sold.
    if (product.type === 'variable' && product.variations?.length) {
      setVariationPickerProduct(product);
      return;
    }
    if (
      product.stockStatus === 'outofstock' ||
      (product.manageStock && product.stockQuantity !== null && product.stockQuantity <= 0)
    ) {
      toast.error(`${product.name} is out of stock`);
      return;
    }
    if (product.manageStock && product.stockQuantity !== null) {
      const inCart = cart.items.find((i) => i.productId === product.id && !i.variationId);
      if (inCart && inCart.quantity >= product.stockQuantity) {
        toast.warning(`Cannot add more: only ${product.stockQuantity} available in stock.`);
        return;
      }
    }
    await cart.addItem(product);
  };

  const handlePickVariation = async (product: Product, variation: ProductVariation) => {
    setVariationPickerProduct(null);
    const inCart = cart.items.find((i) => i.productId === product.id && i.variationId === variation.id);
    if (variation.manageStock && variation.stockQuantity !== null && (inCart?.quantity ?? 0) >= variation.stockQuantity) {
      toast.warning(`Cannot add more: only ${variation.stockQuantity} available in stock.`);
      return;
    }
    await cart.addItem(product, variation);
  };

  const toolsItem = cart.items.find((i) => i.id === productToolsItemId);

  const handleApplyDiscount = () => {
    if (!toolsItem || !discountValue) return;
    if (!canApplyDiscount) {
      toast.error('You do not have permission to apply discounts.');
      return;
    }
    const val = parseFloat(discountValue);
    if (isNaN(val) || val < 0) {
      toast.error('Please enter a valid positive discount value.');
      return;
    }

    let discount: Discount;
    if (discountType === 'percentage') {
      if (val > 100) {
        toast.error('Percentage discount cannot exceed 100%');
        return;
      }
      discount = { type: 'percentage', value: val };
    } else if (discountType === 'fixed_amount') {
      discount = { type: 'fixed_amount', value: Math.round(val * 100) };
    } else {
      toast.error('Invalid discount type');
      return;
    }

    cart.applyDiscount(toolsItem.id, discount);
    setProductToolsItemId(null);
    setDiscountValue('');
    toast.success('Discount applied');
  };

  const handleApplyCoupon = async () => {
    if (!couponInput.trim()) return;
    if (!canApplyDiscount) {
      toast.error('You do not have permission to apply coupons.');
      return;
    }
    setIsApplyingCoupon(true);
    try {
      const res = await cart.applyCoupon(couponInput.trim());
      if (res.success && res.coupon) {
        toast.success(`Coupon "${res.coupon.code}" applied (-${formatMoney(res.coupon.discountKobo)})`);
        setCouponInput('');
      } else {
        toast.error(res.error || 'Failed to apply coupon.');
      }
    } catch {
      toast.error('Unexpected error while validating coupon.');
    } finally {
      setIsApplyingCoupon(false);
    }
  };

  const handleRemoveCoupon = async () => {
    await cart.removeCoupon();
    toast.info('Coupon removed');
  };

  const handleSaveOrder = async () => {
    if (isHoldingOrder || cart.items.length === 0) return;
    if (!canHoldOrder) {
      toast.error('You do not have permission to hold orders.');
      return;
    }
    setIsHoldingOrder(true);
    try {
      const wasResumed = Boolean(cart.resumedOrderId);
      const id = await cart.saveAsOnHold();
      if (id > 0) {
        setShowMobileCartDrawer(false);
        toast.success(wasResumed ? 'Held order updated successfully' : 'Order saved as on-hold');
      } else {
        toast.error('Failed to hold order: Active cart is empty or invalid.');
      }
    } catch {
      toast.error('Failed to hold order');
    } finally {
      setIsHoldingOrder(false);
    }
  };

  const handleAddRemainingToSplit = (id: string) => {
    if (splitTotals.remainingKobo <= 0) return;
    const target = splits.find((s) => s.id === id);
    if (!target) return;

    const currentVal = parseFloat(target.amountStr) || 0;
    const currentKobo = Math.round(currentVal * 100);

    // If row has 0 or empty, fill with exact remaining balance
    // If row already has an amount, add the remaining balance so that this row completes the balance to ₦0
    const newKobo = currentKobo + splitTotals.remainingKobo;
    const newAmountStr = (newKobo / 100).toString();

    setSplits((prev) =>
      prev.map((s) => (s.id === id ? { ...s, amountStr: newAmountStr } : s))
    );
  };

  const splitTotals = useMemo(() => {
    let paidKobo = 0;
    let hasInvalid = false;
    let hasAnyAmount = false;

    for (const s of splits) {
      const trimmed = s.amountStr.trim();
      if (trimmed === '') {
        // Unfilled split field counts as ₦0 (cashier chooses which methods to use)
        continue;
      }
      const val = parseFloat(trimmed);
      if (isNaN(val) || val < 0) {
        hasInvalid = true;
      } else if (val > 0) {
        hasAnyAmount = true;
        paidKobo += Math.round(val * 100);
      }
    }

    const remainingKobo = totals.total - paidKobo;
    const isExact = paidKobo === totals.total && totals.total > 0 && !hasInvalid && hasAnyAmount;
    const isOverpaid = paidKobo > totals.total;
    const isUnderpaid = paidKobo < totals.total;

    return {
      paidKobo,
      remainingKobo,
      isExact,
      isOverpaid,
      isUnderpaid,
      hasInvalid,
    };
  }, [splits, totals.total]);

  const handleAddSplit = () => {
    const existingMethods = new Set(splits.map((s) => s.method));
    const nextMethod = !existingMethods.has('pos')
      ? 'pos'
      : !existingMethods.has('transfer')
      ? 'transfer'
      : !existingMethods.has('online')
      ? 'online'
      : 'cash';

    // NEVER auto-fill remaining balance — cashier enters every amount explicitly
    setSplits((prev) => [
      ...prev,
      {
        id: Math.random().toString(36).substring(2, 9),
        method: nextMethod,
        amountStr: '',
      },
    ]);
  };

  const handleRemoveSplit = (id: string) => {
    setSplits((prev) => {
      if (prev.length <= 1) {
        return [{ id: '1', method: 'cash', amountStr: '' }];
      }
      return prev.filter((s) => s.id !== id);
    });
  };

  const handleUpdateSplitAmount = (id: string, val: string) => {
    setSplits((prev) =>
      prev.map((s) => (s.id === id ? { ...s, amountStr: val } : s))
    );
  };

  const handleUpdateSplitMethod = (id: string, method: string) => {
    setSplits((prev) =>
      prev.map((s) => (s.id === id ? { ...s, method } : s))
    );
  };

  const handleOpenCheckout = () => {
    if (cart.items.length === 0 || totals.total <= 0) return;
    if (!canCompleteSale) {
      toast.error('You do not have permission to complete sales.');
      return;
    }
    if (!isEntitled) {
      toast.error('Free trial expired. Please upgrade your subscription at zameria.co to continue processing sales.');
      return;
    }
    setTenderedAmount((totals.total / 100).toString());
    // NEVER automatically divide order total or pre-fill amounts
    // Cashier decides payment methods and enters amounts from scratch
    setSplits([
      { id: '1', method: 'cash', amountStr: '' },
      { id: '2', method: 'pos', amountStr: '' },
      { id: '3', method: 'transfer', amountStr: '' },
    ]);
    setShowCheckoutModal(true);
  };

  const tenderedNum = parseFloat(tenderedAmount) || 0;
  const totalInMajorUnit = totals.total / 100;
  const changeDue = Math.max(0, tenderedNum - totalInMajorUnit);

  const quickCashOptions = useMemo(() => {
    const isMajorCurrency = ['USD', 'EUR', 'GBP', 'CAD', 'AUD'].includes(currency.code);
    const steps = isMajorCurrency
      ? [5, 10, 20, 50, 100]
      : [1000, 5000, 10000, 20000, 50000];

    return [
      { label: 'Exact', val: totalInMajorUnit },
      ...steps.map((val) => ({
        label: formatMoney(val * 100, undefined, true),
        val,
      })),
    ];
  }, [currency.code, currency.symbol, totalInMajorUnit]);

  const isSaleCompletable = useMemo(() => {
    if (cart.items.length === 0 || totals.total <= 0) return false;
    if (!canCompleteSale) return false;
    if (!isEntitled) return false;

    if (paymentMethod === 'cash') {
      return tenderedNum >= totalInMajorUnit;
    }
    if (paymentMethod === 'split') {
      return splitTotals.isExact;
    }
    if (paymentMethod === 'pos' || paymentMethod === 'transfer') {
      return true;
    }
    return false;
  }, [cart.items.length, totals.total, canCompleteSale, isEntitled, paymentMethod, tenderedNum, totalInMajorUnit, splitTotals.isExact]);

  const handleProcessCheckout = async () => {
    if (isProcessingCheckout || !isSaleCompletable) return;
    setIsProcessingCheckout(true);
    try {
      const titles: Record<string, string> = {
        cash: 'Cash',
        pos: 'POS Terminal / Card',
        transfer: 'Bank Transfer',
        online: 'Online Payment Gateway',
        split: 'Split Payment',
      };

      let paymentSplits: PaymentSplit[] | undefined = undefined;
      if (paymentMethod === 'split') {
        if (!splitTotals.isExact) {
          toast.error('Split payments must exactly equal the order total.');
          setIsProcessingCheckout(false);
          return;
        }
        paymentSplits = splits
          .filter((s) => {
            const val = parseFloat(s.amountStr.trim());
            return !isNaN(val) && val > 0;
          })
          .map((s, idx) => ({
            id: s.id || String(idx + 1),
            method: s.method,
            methodTitle: titles[s.method] || s.method.toUpperCase(),
            amount: Math.round(parseFloat(s.amountStr.trim()) * 100),
          }));
      }

      const result = await cart.completeCheckout({
        paymentMethod,
        paymentMethodTitle: titles[paymentMethod] || 'Cash',
        tenderedAmount:
          paymentMethod === 'cash'
            ? Math.round(parseFloat(tenderedAmount) * 100)
            : totals.total,
        paymentSplits,
        note: cart.note,
      });

      if (result) {
        setShowMobileCartDrawer(false);
        setShowCheckoutModal(false);
        setCouponInput('');
        setSplits([
          { id: '1', method: 'cash', amountStr: '' },
          { id: '2', method: 'pos', amountStr: '' },
          { id: '3', method: 'transfer', amountStr: '' },
        ]);
        setCompletedSale(result);
        toast.success(`Sale completed: ${result.order.orderNumber}`);
      }
    } catch {
      toast.error('Failed to complete transaction');
    } finally {
      setIsProcessingCheckout(false);
    }
  };

  const renderCartPanel = () => (
    <div className="pos-basket flex-1 flex flex-col h-full bg-surface overflow-hidden select-none">
      <div className="pos-basket-heading"><h2>Current sale</h2><span>{totals.itemCount} {totals.itemCount === 1 ? 'item' : 'items'}</span></div>
      {/* Customer selection */}
      <div className="px-3 py-2 border-b border-surface-200 bg-surface flex items-center justify-between gap-2 flex-shrink-0">
        <div className="flex items-center gap-2 min-w-0 flex-1">
          <div
            className={cn(
              'w-6.5 h-6.5 rounded-full flex items-center justify-center flex-shrink-0 transition-colors',
              cart.customerId
                ? 'bg-primary-50 text-primary-700 border border-primary-200'
                : 'bg-surface-100 text-surface-500 border border-surface-200'
            )}
          >
            <User className="w-3.5 h-3.5" />
          </div>
          <div className="min-w-0 flex-1">
            <div className="flex items-center gap-1.5">
              <span className="text-xs font-bold text-on-surface truncate">
                {cart.customerName || 'Walk-in Customer'}
              </span>
              {cart.customerId ? (
                <Badge variant="info" size="sm" className="text-xs py-0 px-1.5 h-4">
                  {cart.wooCustomerId ? `#${cart.wooCustomerId}` : 'POS'}
                </Badge>
              ) : null}
            </div>
            {cart.customerId && (cart.customerPhone || cart.customerEmail) && (
              <div className="text-xs text-surface-500 truncate flex items-center gap-1">
                {cart.customerPhone && <span className="font-mono">{cart.customerPhone}</span>}
                {cart.customerPhone && cart.customerEmail && <span>•</span>}
                {cart.customerEmail && <span className="truncate">{cart.customerEmail}</span>}
              </div>
            )}
          </div>
        </div>

        {/* Customer Actions */}
        {cart.customerId ? (
          <div className="flex items-center gap-1 flex-shrink-0">
            <Button
              variant="outline"
              size="sm"
              onClick={() => {
                setCustomerSearchQuery('');
                setShowCustomerSearchModal(true);
              }}
              className="h-7 px-2 text-xs font-semibold text-primary hover:text-primary-hover"
            >
              Change
            </Button>
            <button
              type="button"
              onClick={() => {
                cart.setCustomer(null, 'Walk-in Customer', '', '', null);
                toast.info('Removed customer, reset to Walk-in');
              }}
              title="Remove customer"
              className="w-7 h-7 flex items-center justify-center rounded-lg hover:bg-surface-100 text-surface-400 hover:text-surface-700 transition-colors cursor-pointer"
            >
              <X className="w-3.5 h-3.5" />
            </button>
          </div>
        ) : (
          <div className="flex items-center gap-1 flex-shrink-0">
            <Button
              variant="secondary"
              size="sm"
              onClick={() => {
                setCustomerSearchQuery('');
                setShowCustomerSearchModal(true);
              }}
              className="h-7 px-2 text-xs font-medium gap-1 text-surface-700 hover:text-surface-900"
              title="Search customer"
            >
              <Search className="w-3 h-3 text-surface-500" />
              <span>Customer</span>
            </Button>
            <Button
              variant="primary"
              size="sm"
              onClick={() => {
                setAddCustError(null);
                setDuplicateCust(null);
                setNewCustName('');
                setNewCustPhone('');
                setNewCustEmail('');
                setShowAddCustomerModal(true);
              }}
              className="h-7 px-2 text-xs font-bold"
              title="Add new customer"
            >
              <Plus className="w-3 h-3" />
              <span className="hidden sm:inline">Add</span>
            </Button>
          </div>
        )}
      </div>

      {/* Resumed Order Banner */}
      {cart.resumedOrderId && (
        <div className="bg-amber-50 dark:bg-amber-950/40 border-b border-amber-200 dark:border-amber-800/60 px-4 py-2 flex items-center justify-between text-xs flex-shrink-0">
          <div className="flex items-center gap-2 min-w-0">
            <Clock className="w-3.5 h-3.5 text-amber-600 dark:text-amber-400 flex-shrink-0" />
            <span className="font-semibold text-amber-900 dark:text-amber-200 truncate">
              Editing: <span className="font-mono">{cart.resumedOrderNumber || `#${cart.resumedOrderId}`}</span>
            </span>
          </div>
          <div className="flex items-center gap-1.5 flex-shrink-0">
            <button
              type="button"
              onClick={handleSaveOrder}
              disabled={isHoldingOrder}
              className="px-2 py-0.5 text-xs font-bold bg-amber-600 hover:bg-amber-700 text-white rounded cursor-pointer transition-colors shadow-2xs"
              title="Update this held order with current basket"
            >
              Update Hold
            </button>
            <button
              type="button"
              onClick={() => cart.clearCart()}
              className="px-2 py-0.5 text-xs font-medium text-amber-800 dark:text-amber-300 hover:bg-amber-200/50 dark:hover:bg-amber-900/50 rounded cursor-pointer transition-colors"
              title="Put order back on hold and clear active basket"
            >
              Park
            </button>
          </div>
        </div>
      )}

      {/* Cart Item Rows OR Empty State */}
      <div className="flex-1 overflow-y-auto">
        {cart.items.length === 0 ? (
          /* Clean Empty Cart State */
          <div className="h-full flex flex-col items-center justify-center p-6 text-center select-none">
            {/* Clean Till/Cart outline box */}
            <div className="w-16 h-12 border-2 border-outline-variant rounded-md mb-3 flex items-center justify-center relative bg-surface-container-lowest">
              <div className="w-8 h-1 bg-outline-variant rounded-full" />
            </div>
            <h3 className="text-xs font-bold text-surface-700 uppercase tracking-wider mb-1">
              CART EMPTY
            </h3>
            <p className="text-xs text-surface-400 max-w-[200px] leading-relaxed">
              Scan a product barcode or add a product from the list
            </p>
          </div>
        ) : (
          <div className="divide-y divide-surface-100">
            {cart.items.map((item) => (
              <div
                key={item.id}
                className="pos-basket-line hover:bg-surface-container-low transition-colors"
                data-thumbnails={showCartThumbnails && !!item.image}
              >
                {/* Thumbnail (if enabled in settings) */}
                {showCartThumbnails && item.image ? (
                  <img
                    src={item.image}
                    alt={item.name}
                    className="pos-basket-line-image rounded-lg object-cover bg-surface-container-low border border-outline-variant"
                  />
                ) : null}

                {/* Product Name & Unit Price */}
                <div className="pos-basket-line-copy min-w-0">
                  <p className="text-sm font-semibold text-on-surface leading-snug">
                    {item.name}
                  </p>
                  <div className="flex items-center gap-1.5 mt-0.5 text-xs text-surface-500 tabular-nums">
                    <span>{formatMoney(item.unitPrice)} each</span>
                    {item.discount && (
                      <Badge variant="primary" size="sm">
                        {item.discount.type === 'percentage'
                          ? `${item.discount.value}% off`
                          : `${formatMoney(item.discount.value)} off`}
                      </Badge>
                    )}
                  </div>
                </div>

                {/* Stepper controls */}
                <div className="pos-basket-line-quantity"><QuantityStepper
                  size="sm"
                  value={item.quantity}
                  onChange={(qty) => cart.updateQuantity(item.id, qty)}
                /></div>

                {/* Item Total */}
                <div className="pos-basket-line-total text-right">
                  <span className="text-xs font-bold text-on-surface tabular-nums">
                    {formatMoney(item.lineTotal)}
                  </span>
                </div>

                {/* Chevron to open Product Tools drawer */}
                <button
                  type="button"
                  onClick={() => {
                    setProductToolsItemId(item.id);
                    setDiscountType('percentage');
                    setDiscountValue('');
                  }}
                  className="pos-icon-button pos-basket-line-tools text-surface-400 hover:text-on-surface"
                  title="Item discount & options"
                >
                  <ChevronRight className="w-4 h-4" />
                </button>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* Cart Bottom Summary & Checkout Dock */}
      <div className="border-t border-surface-200 bg-surface-container-lowest p-3 pb-[max(0.75rem,env(safe-area-inset-bottom))] space-y-2 flex-shrink-0 z-10 shadow-[0_-2px_8px_rgba(0,0,0,0.03)]">
        {/* Secondary Utilities Strip: Notes & Coupon as sleek expandable micro-actions */}
        <div className="space-y-1.5">
          {/* Active Note display or Note input */}
          {(showNoteInput || cart.note) ? (
            <div className="flex items-center gap-2 px-2.5 py-1.5 bg-surface border border-outline-variant rounded-lg text-xs focus-within:border-primary focus-within:ring-1 focus-within:ring-primary/20 transition-all">
              <FileText className="w-3.5 h-3.5 text-primary flex-shrink-0" />
              <input
                type="text"
                autoFocus={showNoteInput && !cart.note}
                value={cart.note}
                onChange={(e) => cart.setNote(e.target.value)}
                placeholder="Add order note / instructions..."
                className="w-full bg-transparent text-xs text-on-surface placeholder:text-surface-400 focus:outline-none font-medium"
              />
              <button
                type="button"
                onClick={() => {
                  cart.setNote('');
                  setShowNoteInput(false);
                }}
                className="text-surface-400 hover:text-on-surface p-0.5 cursor-pointer"
                title="Close or clear note"
              >
                <X className="w-3.5 h-3.5" />
              </button>
            </div>
          ) : null}

          {/* Active Coupon Banner or Coupon Input */}
          {cart.appliedCoupon ? (
            <div className="flex items-center justify-between p-2 bg-success-container/30 border border-success/30 rounded-lg text-xs">
              <div className="flex items-center gap-2 min-w-0">
                <Tag className="w-3.5 h-3.5 text-success flex-shrink-0" />
                <div className="min-w-0">
                  <div className="flex items-center gap-1.5">
                    <span className="font-bold text-on-surface uppercase tracking-wide">
                      {cart.appliedCoupon.code}
                    </span>
                    <span className="text-xs px-1.5 py-0.2 bg-success/15 text-success font-bold rounded">
                      {cart.appliedCoupon.discountType === 'percent'
                        ? `${cart.appliedCoupon.amount}% off`
                        : 'Fixed discount'}
                    </span>
                  </div>
                  {cart.appliedCoupon.description && (
                    <p className="text-xs text-surface-500 truncate">
                      {cart.appliedCoupon.description}
                    </p>
                  )}
                </div>
              </div>
              <div className="flex items-center gap-2 flex-shrink-0 pl-2">
                <span className="font-black text-success tabular-nums text-xs">
                  -{formatMoney(cart.appliedCoupon.discountKobo)}
                </span>
                <button
                  type="button"
                  onClick={handleRemoveCoupon}
                  className="p-1 text-surface-400 hover:text-danger rounded hover:bg-danger-container/30 transition-colors cursor-pointer"
                  title="Remove coupon"
                >
                  <X className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>
          ) : showCouponInput ? (
            <div className="flex items-center gap-1.5">
              <div className="relative flex-1">
                <Tag className="w-3.5 h-3.5 text-surface-400 absolute left-2.5 top-1/2 -translate-y-1/2" />
                <input
                  type="text"
                  autoFocus
                  value={couponInput}
                  onChange={(e) => setCouponInput(e.target.value.toUpperCase())}
                  onKeyDown={(e) => {
                    if (e.key === 'Enter') {
                      e.preventDefault();
                      handleApplyCoupon();
                    }
                  }}
                  placeholder="Coupon code"
                  disabled={cart.items.length === 0 || isApplyingCoupon}
                  className="w-full h-8 pl-8 pr-2 bg-surface border border-outline-variant rounded-lg text-xs font-semibold uppercase tracking-wider text-on-surface placeholder:normal-case placeholder:font-normal placeholder:tracking-normal placeholder:text-surface-400 focus:outline-none focus:border-primary disabled:opacity-50"
                />
              </div>
              <Button
                variant="secondary"
                size="sm"
                disabled={cart.items.length === 0 || !couponInput.trim() || isApplyingCoupon}
                onClick={handleApplyCoupon}
                className="h-8 px-2.5 text-xs font-bold whitespace-nowrap"
              >
                {isApplyingCoupon ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : 'Apply'}
              </Button>
              <SyncButton
                scope="coupons"
                label=""
                size="sm"
                variant="tonal"
                className="h-8 w-8 p-0"
              />
              <button
                type="button"
                onClick={() => setShowCouponInput(false)}
                className="p-1 text-surface-400 hover:text-on-surface cursor-pointer"
                title="Cancel coupon input"
              >
                <X className="w-3.5 h-3.5" />
              </button>
            </div>
          ) : null}

          {/* Compact Chip Actions when Note / Coupon are not active */}
          {(!cart.note && !showNoteInput) || (!cart.appliedCoupon && !showCouponInput) ? (
            <div className="flex items-center gap-1.5 text-xs">
              {!cart.note && !showNoteInput && (
                <button
                  type="button"
                  onClick={() => setShowNoteInput(true)}
                  className="inline-flex items-center gap-1 px-2 py-0.5 rounded-md border border-outline-variant/70 bg-surface hover:bg-surface-container text-surface-600 text-xs font-medium transition-colors cursor-pointer"
                  title="Add note to order"
                >
                  <FileText className="w-3 h-3 text-surface-400" />
                  <span>+ Note</span>
                </button>
              )}
              {!cart.appliedCoupon && !showCouponInput && (
                <button
                  type="button"
                  onClick={() => setShowCouponInput(true)}
                  disabled={cart.items.length === 0}
                  className="inline-flex items-center gap-1 px-2 py-0.5 rounded-md border border-outline-variant/70 bg-surface hover:bg-surface-container text-surface-600 text-xs font-medium transition-colors cursor-pointer disabled:opacity-40 disabled:cursor-not-allowed"
                  title="Apply coupon code"
                >
                  <Tag className="w-3 h-3 text-surface-400" />
                  <span>+ Coupon</span>
                </button>
              )}
            </div>
          ) : null}
        </div>

        {/* Totals Breakdown - Crisp & Compact */}
        <div className="pt-1.5 border-t border-surface-200/80 space-y-1 text-xs">
          <div className="flex justify-between items-center text-surface-500">
            <span>Subtotal ({totals.itemCount} {totals.itemCount === 1 ? 'item' : 'items'})</span>
            <span className="tabular-nums font-semibold text-on-surface">{formatMoney(totals.subtotal)}</span>
          </div>

          {totals.couponDiscount > 0 && (
            <div className="flex justify-between items-center text-success font-medium">
              <span className="flex items-center gap-1 text-xs">
                <Tag className="w-3 h-3" />
                Coupon Discount ({cart.appliedCoupon?.code})
              </span>
              <span className="tabular-nums font-bold">-{formatMoney(totals.couponDiscount)}</span>
            </div>
          )}

          <div className="flex justify-between items-baseline pt-0.5">
            <span className="text-xs font-bold uppercase tracking-wider text-surface-600">Total</span>
            <span className="text-xl font-black text-on-surface tabular-nums">
              {formatMoney(totals.total)}
            </span>
          </div>
        </div>

        {/* Action Buttons: Unified Checkout Dock */}
        <div className="pos-cart-actions pt-0.5">
          {/* Cancel Sale Button */}
          <Button
            variant="ghost"
            size="sm"
            disabled={cart.items.length === 0}
            onClick={() => setShowCancelCartModal(true)}
            className="h-10 px-2.5 text-xs text-danger hover:bg-danger-container/30 hover:text-danger rounded-xl flex items-center justify-center gap-1 font-medium shrink-0"
            title="Cancel sale and clear basket"
          >
            <Trash2 className="w-4 h-4 flex-shrink-0" />
            <span className="hidden sm:inline">Cancel</span>
          </Button>

          {/* Save / Hold Sale Button */}
          <Button
            variant="secondary"
            size="sm"
            disabled={cart.items.length === 0 || isHoldingOrder}
            loading={isHoldingOrder}
            onClick={handleSaveOrder}
            className="h-10 px-3 text-xs font-semibold rounded-xl flex items-center justify-center gap-1.5 shrink-0 text-surface-700"
            title={cart.resumedOrderId ? "Update current held order" : "Save as on-hold order"}
          >
            <Save className="w-3.5 h-3.5 flex-shrink-0" />
            <span>{cart.resumedOrderId ? 'Update' : 'Hold'}</span>
          </Button>

          {/* Primary Checkout Button */}
          <Button
            variant="primary"
            size="lg"
            disabled={cart.items.length === 0 || !isEntitled}
            onClick={handleOpenCheckout}
            className="pos-cart-checkout min-w-0 text-sm font-semibold rounded-xl shadow-xs active:scale-[0.99] transition-all"
            aria-label={!isEntitled ? 'Upgrade Plan' : 'Proceed to Checkout'}
          >
            <span>{!isEntitled ? 'Upgrade Plan' : 'Proceed to Checkout'}</span>
          </Button>
        </div>
      </div>
    </div>
  );

  return (
    <div className="pos-sale-screen flex h-full w-full overflow-hidden bg-surface-50 relative">
      <ResizableSplitView
        storageKey="zameria-split-sale-v2"
        defaultSplit={68}
        minLeftPercent={30}
        maxLeftPercent={80}
        rightClassName="pos-basket-panel"
        minRightPixels={340}
        isRightVisible={!isMobile}
        left={
          <div className="flex-1 flex flex-col min-w-0 h-full bg-surface-0 overflow-hidden">
        <PageHeader title="New sale" description="Search, scan or select a product to get started." actions={<span className="pos-shortcut-hint"><kbd>/</kbd> Search products</span>} />
        {/* Top Control Bar with responsive layout */}
        {isMobile ? (
          <div className="pos-sale-tools border-b border-surface-200 bg-surface flex flex-col gap-3 p-4 flex-shrink-0">
            {/* Row 1: Full-width search + Scan Barcode button */}
            <div className="flex items-center gap-2">
              <SearchInput
                value={search}
                onChange={setSearch}
                placeholder="Search products, SKU, barcode..."
                onKeyDown={async (e) => {
                  if ((e.key === 'Enter' || e.key === 'Tab') && search.trim()) {
                    e.preventDefault();
                    const handled = await handleBarcodeScanned(search.trim());
                    if (handled) {
                      setSearch('');
                    }
                  }
                }}
                containerClassName="flex-1 min-w-0"
                className="text-xs h-9.5 placeholder:text-xs"
              />

              <Button
                type="button"
                variant="secondary"
                size="sm"
                onClick={() => setShowScannerModal(true)}
                className="h-9.5 px-3 text-xs font-semibold flex items-center gap-1.5 border-outline-variant hover:border-primary/50 flex-shrink-0 active:scale-95 transition-transform"
                icon={<ScanBarcode className="w-4 h-4 text-primary" />}
                title="Scan barcode with camera or enter code"
              >
                <span>Scan</span>
              </Button>
            </div>

            {/* Row 2: Actions row (Held Orders, Filter, Sync, Grid/List) */}
            <div className="flex items-center justify-between gap-1.5 py-0.5">
              <div className="flex items-center gap-1.5">
                {/* Held Orders Button */}
                <Button
                  type="button"
                  variant="secondary"
                  size="sm"
                  onClick={() => setShowHeldOrdersModal(true)}
                  className="h-8 px-2.5 text-xs font-semibold flex items-center gap-1.5 border-outline-variant hover:border-amber-500/50 flex-shrink-0"
                  icon={<Clock className="w-3.5 h-3.5 text-amber-600" />}
                  title="View held orders"
                >
                  <span>Held</span>
                  {heldOrdersCount > 0 && (
                    <span className="px-1.5 py-0.2 bg-amber-500 text-white text-xs font-bold rounded-full">
                      {heldOrdersCount}
                    </span>
                  )}
                </Button>

                {/* Filter Toggle */}
                <div className="relative flex-shrink-0">
                  <button
                    type="button"
                    onClick={() => setShowFilterMenu(!showFilterMenu)}
                    className={cn(
                      'h-8 px-2.5 flex items-center gap-1.5 rounded-lg border text-xs transition-colors cursor-pointer',
                      stockFilter !== 'all'
                        ? 'border-primary bg-primary-container text-on-primary-container font-semibold'
                        : 'border-outline-variant bg-surface text-surface-600 hover:bg-surface-container-low'
                    )}
                    title="Filter inventory"
                  >
                    <SlidersHorizontal className="w-3.5 h-3.5" />
                    <span className="capitalize">{stockFilter === 'all' ? 'Stock' : stockFilter}</span>
                  </button>

                  {showFilterMenu && (
                    <div className="absolute left-0 mt-1 w-44 bg-surface border border-outline-variant rounded-xl shadow-lg z-30 p-1.5 space-y-0.5 text-xs">
                      {[
                        { id: 'all', label: 'All Products' },
                        { id: 'instock', label: 'In Stock' },
                        { id: 'lowstock', label: 'Low Stock (≤ 5)' },
                      ].map((opt) => (
                        <button
                          key={opt.id}
                          type="button"
                          onClick={() => {
                            setStockFilter(opt.id as typeof stockFilter);
                            setShowFilterMenu(false);
                          }}
                          className={cn(
                            'w-full text-left px-2.5 py-1.5 rounded-lg cursor-pointer transition-colors',
                            stockFilter === opt.id
                              ? 'bg-primary-container text-on-primary-container font-semibold'
                              : 'text-on-surface hover:bg-surface-container-low'
                          )}
                        >
                          {opt.label}
                        </button>
                      ))}
                    </div>
                  )}
                </div>
              </div>

              <div className="flex items-center gap-1.5">
                {/* POS Catalogue Sync Button */}
                <div className="flex-shrink-0">
                  <SyncButton
                    scope="pos"
                    label="Sync"
                    size="sm"
                    variant="tonal"
                    className="h-8.5 px-2.5 text-xs"
                  />
                </div>

                {/* List/Grid View Switcher */}
                <div className="flex border border-outline-variant rounded-lg overflow-hidden bg-surface-container-lowest p-0.5 flex-shrink-0">
                  <button
                    type="button"
                    onClick={() => setListMode('list')}
                    className={cn(
                      'h-7 w-7 flex items-center justify-center rounded transition-colors cursor-pointer',
                      listMode === 'list'
                        ? 'bg-surface text-on-surface shadow-xs font-bold'
                        : 'text-surface-400 hover:text-on-surface'
                    )}
                    title="Compact list view"
                  >
                    <List className="w-3.5 h-3.5" />
                  </button>
                  <button
                    type="button"
                    onClick={() => setListMode('grid')}
                    className={cn(
                      'h-7 w-7 flex items-center justify-center rounded transition-colors cursor-pointer',
                      listMode === 'grid'
                        ? 'bg-surface text-on-surface shadow-xs font-bold'
                        : 'text-surface-400 hover:text-on-surface'
                    )}
                    title="Grid view"
                  >
                    <LayoutGrid className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>
            </div>
          </div>
        ) : (
          <div className="pos-record-toolbar">
            {/* Search Input */}
            <SearchInput
              value={search}
              onChange={setSearch}
              placeholder="Search products, SKU or barcode..."
              onKeyDown={async (e) => {
                if ((e.key === 'Enter' || e.key === 'Tab') && search.trim()) {
                  e.preventDefault();
                  const handled = await handleBarcodeScanned(search.trim());
                  if (handled) {
                    setSearch('');
                  }
                }
              }}
              containerClassName="flex-1 min-w-[140px] md:min-w-[180px]"
              className="text-xs placeholder:text-xs"
            />

            {/* Barcode Scanner Button */}
            <Button
              type="button"
              variant="secondary"
              size="sm"
              onClick={() => setShowScannerModal(true)}
              className="h-9 px-3 text-xs font-semibold flex items-center gap-1.5 border-outline-variant hover:border-primary/50 flex-shrink-0"
              icon={<ScanBarcode className="w-4 h-4 text-primary" />}
              title="Scan barcode with camera or enter code"
            >
              <span className="hidden md:inline">Scan Barcode</span>
            </Button>

            {/* Held Orders Button */}
            <Button
              type="button"
              variant="secondary"
              size="sm"
              onClick={() => setShowHeldOrdersModal(true)}
              className="h-9 px-3 text-xs font-semibold flex items-center gap-1.5 border-outline-variant hover:border-amber-500/50 flex-shrink-0"
              icon={<Clock className="w-4 h-4 text-amber-600" />}
              title="View held orders"
            >
              <span>Held Orders</span>
              {heldOrdersCount > 0 && (
                <span className="px-1.5 py-0.2 bg-amber-500 text-white text-xs font-bold rounded-full">
                  {heldOrdersCount}
                </span>
              )}
            </Button>

            {/* Category Dropdown */}
            <select
              value={selectedCategory ?? ''}
              onChange={(e) => setSelectedCategory(e.target.value ? Number(e.target.value) : null)}
              className="pos-filter-select hidden sm:inline-block w-[90px] shrink-0 truncate"
              title="Filter by category"
            >
              <option value="">Category</option>
              {categories?.map((c) => (
                <option key={c.id} value={c.id}>
                  {c.name}
                </option>
              ))}
            </select>

            {/* Brand Dropdown */}
            <select
              value={selectedBrand ?? ''}
              onChange={(e) => setSelectedBrand(e.target.value ? Number(e.target.value) : null)}
              className="pos-filter-select hidden sm:inline-block w-[74px] shrink-0 truncate"
              title="Filter by brand"
            >
              <option value="">Brand</option>
              {sortedBrands.map((b) => (
                <option key={b.id} value={b.id}>
                  {b.name}
                </option>
              ))}
            </select>

            {/* Filter Toggle */}
            <div className="relative flex-shrink-0">
              <button
                type="button"
                onClick={() => setShowFilterMenu(!showFilterMenu)}
                className={cn(
                  'h-9 w-9 flex items-center justify-center rounded-lg border transition-colors cursor-pointer',
                  stockFilter !== 'all'
                    ? 'border-primary bg-primary-container text-on-primary-container font-semibold'
                    : 'border-outline-variant bg-surface text-surface-500 hover:bg-surface-container-low'
                )}
                title="Filter inventory"
              >
                <SlidersHorizontal className="w-3.5 h-3.5" />
              </button>

              {showFilterMenu && (
                <div className="absolute right-0 mt-1 w-44 bg-surface border border-outline-variant rounded-xl shadow-md z-30 p-1.5 space-y-0.5 text-xs">
                  {[
                    { id: 'all', label: 'All Products' },
                    { id: 'instock', label: 'In Stock' },
                    { id: 'lowstock', label: 'Low Stock (≤ 5)' },
                  ].map((opt) => (
                    <button
                      key={opt.id}
                      type="button"
                      onClick={() => {
                        setStockFilter(opt.id as typeof stockFilter);
                        setShowFilterMenu(false);
                      }}
                      className={cn(
                        'w-full text-left px-2.5 py-1.5 rounded-lg cursor-pointer transition-colors',
                        stockFilter === opt.id
                          ? 'bg-primary-container text-on-primary-container font-semibold'
                          : 'text-on-surface hover:bg-surface-container-low'
                      )}
                    >
                      {opt.label}
                    </button>
                  ))}
                </div>
              )}
            </div>

            {/* POS Catalogue Sync Button */}
            <div className="flex-shrink-0">
              <SyncButton
                scope="pos"
                label="Sync"
                size="sm"
                variant="tonal"
                className="h-8.5 px-2.5 text-xs"
              />
            </div>

            {/* List/Grid View Switcher */}
            <div className="flex border border-outline-variant rounded-lg overflow-hidden bg-surface-container-lowest p-0.5 flex-shrink-0">
              <button
                type="button"
                onClick={() => setListMode('list')}
                className={cn(
                  'h-7.5 w-7 flex items-center justify-center rounded transition-colors cursor-pointer',
                  listMode === 'list'
                    ? 'bg-surface text-on-surface shadow-xs font-bold'
                    : 'text-surface-400 hover:text-on-surface'
                )}
                title="Compact list view"
              >
                <List className="w-3.5 h-3.5" />
              </button>
              <button
                type="button"
                onClick={() => setListMode('grid')}
                className={cn(
                  'h-7.5 w-7 flex items-center justify-center rounded transition-colors cursor-pointer',
                  listMode === 'grid'
                    ? 'bg-surface text-on-surface shadow-xs font-bold'
                    : 'text-surface-400 hover:text-on-surface'
                )}
                title="Grid view"
              >
                <LayoutGrid className="w-3.5 h-3.5" />
              </button>
            </div>
          </div>
        )}

        {/* Mobile Horizontal Category Pills (< 768px) */}
        {isMobile && categories && categories.length > 0 && (
          <div className="flex items-center gap-1.5 px-3 py-1.5 overflow-x-auto no-scrollbar border-b border-surface-200 bg-surface flex-shrink-0 select-none">
            <button
              type="button"
              onClick={() => setSelectedCategory(null)}
              className={cn(
                'px-2.5 py-1 rounded-full text-xs font-semibold whitespace-nowrap transition-colors cursor-pointer',
                selectedCategory === null
                  ? 'bg-primary text-white shadow-xs'
                  : 'bg-surface-100 text-surface-600 hover:bg-surface-200'
              )}
            >
              All
            </button>
            {categories.map((c) => (
              <button
                key={c.id}
                type="button"
                onClick={() => setSelectedCategory(selectedCategory === c.id ? null : c.id)}
                className={cn(
                  'px-2.5 py-1 rounded-full text-xs font-semibold whitespace-nowrap transition-colors cursor-pointer',
                  selectedCategory === c.id
                    ? 'bg-primary text-white shadow-xs'
                    : 'bg-surface-100 text-surface-600 hover:bg-surface-200'
                )}
              >
                {c.name}
              </button>
            ))}
          </div>
        )}

        {/* Product Catalog Rows with M3 Cards */}
        <div className={cn('flex-1 overflow-y-auto', isMobile && 'pb-28')}>
          {!products ? (
            <div className="p-4 space-y-1">
              {Array.from({ length: 10 }).map((_, i) => (
                <SkeletonRow key={i} />
              ))}
            </div>
          ) : filteredProducts.length === 0 ? (
            <EmptyState
              icon={<Package className="w-10 h-10 text-surface-300" />}
              title="No Products Found"
              description={search ? `No products match "${search}"` : 'No products available'}
              className="py-20"
            />
          ) : listMode === 'list' ? (
            <div className="divide-y divide-surface-100">
              {displayedProducts.map((p) => {
                const stockInfo = getProductStockInfo(p);
                const isOutOfStock = stockInfo.variant === 'out';
                const hasDiscount = p.onSale && p.regularPrice > p.price;

                return (
                  <div
                    key={p.id}
                    role="button"
                    tabIndex={0}
                    onClick={() => !isOutOfStock && handleAddToCart(p)}
                    onKeyDown={(e) => {
                      if (e.key === 'Enter' || e.key === ' ') {
                        e.preventDefault();
                        if (!isOutOfStock) handleAddToCart(p);
                      }
                    }}
                    className={cn(
                      'px-4 py-2.5 flex items-center gap-3.5 transition-colors cursor-pointer select-none bg-surface hover:bg-surface-container-low',
                      isOutOfStock ? 'opacity-40 cursor-not-allowed hover:bg-surface' : ''
                    )}
                  >
                    {/* Small square thumbnail */}
                    <div className="w-9 h-9 rounded-lg overflow-hidden bg-surface-container-low border border-outline-variant/60 flex-shrink-0 flex items-center justify-center">
                      {p.images?.[0]?.src ? (
                        <img
                          src={p.images[0].src}
                          alt={p.name || 'Product'}
                          className="w-full h-full object-cover"
                          loading="lazy"
                        />
                      ) : (
                        <Package className="w-4 h-4 text-surface-400" />
                      )}
                    </div>

                    {/* Product Name & ID */}
                    <div className="flex-1 min-w-0">
                      <p className="text-xs font-semibold text-on-surface truncate leading-tight">
                        {p.name}
                      </p>
                      <div className="flex items-center gap-2 mt-0.5 text-xs text-surface-400">
                        <span>ID: {p.wooId || p.id}</span>
                        {p.barcode && <span className="text-surface-600 font-mono">· Barcode: {p.barcode}</span>}
                      </div>
                    </div>

                    {/* Stock status badge */}
                    <div className="text-right flex-shrink-0">
                      <span
                        className={cn(
                          'text-xs font-semibold tabular-nums px-2.5 py-0.5 rounded-full inline-block',
                          stockInfo.variant === 'out' && 'bg-danger/10 text-danger font-bold border border-danger/20',
                          stockInfo.variant === 'low' && 'bg-amber-500/15 text-amber-700 dark:text-amber-400 font-bold border border-amber-500/30',
                          stockInfo.variant === 'normal' && 'bg-emerald-500/10 text-emerald-700 dark:text-emerald-400 font-medium',
                          stockInfo.variant === 'untracked' && 'text-surface-400 text-xs'
                        )}
                      >
                        {stockInfo.text}
                      </span>
                    </div>

                    {/* Price */}
                    <div className="text-right min-w-[80px] flex-shrink-0">
                      <div className="text-xs font-bold text-on-surface tabular-nums">
                        {formatMoney(p.price)}
                      </div>
                      {hasDiscount && (
                        <div className="text-xs text-surface-400 line-through tabular-nums">
                          {formatMoney(p.regularPrice)}
                        </div>
                      )}
                    </div>
                  </div>
                );
              })}
            </div>
          ) : (
            <div className="pos-product-grid">
              {displayedProducts.map((p) => {
                const stockInfo = getProductStockInfo(p);
                const isOutOfStock = stockInfo.variant === 'out';
                return (
                  <div
                    key={p.id}
                    role="button"
                    tabIndex={isOutOfStock ? -1 : 0}
                    aria-disabled={isOutOfStock}
                    aria-label={`Add ${p.name} to sale`}
                    onKeyDown={event=>{if(event.key==='Enter'||event.key===' '){event.preventDefault();if(!isOutOfStock)void handleAddToCart(p);}}}
                    onClick={() => !isOutOfStock && handleAddToCart(p)}
                    className={cn(
                      'pos-product-card m3-card-outlined flex flex-col justify-between text-left cursor-pointer select-none bg-surface transition-all group',
                      isOutOfStock ? 'opacity-40 cursor-not-allowed hover:border-outline-variant' : ''
                    )}
                  >
                    <div className="pos-product-image">
                      {p.images?.[0]?.src ? (
                        <img
                          src={p.images[0].src}
                          alt={p.name || 'Product'}
                          className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-200"
                          loading="lazy"
                        />
                      ) : (
                        <Package className="w-6 h-6 text-surface-400" />
                      )}
                      {isOutOfStock ? (
                        <div className="absolute inset-0 bg-surface/80 backdrop-blur-xs flex items-center justify-center">
                          <Badge variant="danger" size="sm">Out of stock</Badge>
                        </div>
                      ) : stockInfo.variant === 'low' ? (
                        <div className="absolute top-1.5 right-1.5">
                          <Badge variant="warning" size="sm">Low stock</Badge>
                        </div>
                      ) : null}
                    </div>
                    <div>
                      <p className="text-xs font-semibold text-on-surface line-clamp-2 leading-tight">
                        {p.name}
                      </p>
                      <div className="flex items-baseline justify-between mt-2 pt-1 border-t border-surface-100">
                        <span className="text-xs font-bold text-on-surface tabular-nums">
                          {formatMoney(p.price)}
                        </span>
                        <span className="text-xs text-surface-400">ID: {p.wooId || p.id}</span>
                      </div>
                      <div className="mt-1 flex items-center justify-between">
                        <span
                          className={cn(
                            'text-xs font-semibold tabular-nums',
                            stockInfo.variant === 'out' && 'text-danger font-bold',
                            stockInfo.variant === 'low' && 'text-amber-600 dark:text-amber-400 font-bold',
                            stockInfo.variant === 'normal' && 'text-surface-500 font-medium',
                            stockInfo.variant === 'untracked' && 'text-surface-400'
                          )}
                        >
                          {stockInfo.text}
                        </span>
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          )}

          {/* Progressive Load More button when catalogue is large */}
          {filteredProducts.length > visibleProductCount && (
            <div className="p-4 text-center border-t border-surface-200/50 bg-surface">
              <Button
                type="button"
                variant="secondary"
                size="sm"
                onClick={() => setVisibleProductCount((prev) => prev + 60)}
                className="w-full max-w-xs mx-auto text-xs font-semibold"
              >
                Load More Products ({filteredProducts.length - visibleProductCount} remaining)
              </Button>
            </div>
          )}
        </div>
      </div>
    }
    right={renderCartPanel()}
    />

      {/* Mobile Sticky Cart Bar & Drawer (< 768px) */}
      {isMobile && (
        <>
          <div className="pos-mobile-cart-bar fixed left-0 right-0 z-30 px-3 py-2 bg-surface/95 backdrop-blur-md border-t border-surface-200 shadow-md flex items-center justify-between gap-3 select-none">
            <button
              type="button"
              onClick={() => setShowMobileCartDrawer(true)}
              className="flex items-center gap-2.5 min-w-0 flex-1 text-left cursor-pointer group"
            >
              <div className="relative flex items-center justify-center w-10 h-10 rounded-xl bg-primary text-white flex-shrink-0 shadow-sm transition-transform active:scale-95">
                <ShoppingCart className="w-5 h-5" />
                {cart.items.length > 0 && (
                  <span className="absolute -top-1.5 -right-1.5 bg-amber-500 text-white text-xs font-black px-1.5 py-0.2 rounded-full min-w-[18px] text-center border-2 border-surface">
                    {cart.items.reduce((sum, item) => sum + item.quantity, 0)}
                  </span>
                )}
              </div>
              <div className="min-w-0 flex-1">
                <div className="text-xs font-medium text-surface-500">
                  {cart.items.length === 0 ? 'Cart is empty' : `${cart.items.length} line item${cart.items.length > 1 ? 's' : ''}`}
                </div>
                <div className="text-sm font-black text-surface-900 tracking-tight tabular-nums">
                  {formatMoney(totals.total)}
                </div>
              </div>
            </button>
            <Button
              type="button"
              variant="primary"
              size="md"
              disabled={cart.items.length === 0 || !isEntitled}
              onClick={() => {
                if (cart.items.length > 0) {
                  setShowMobileCartDrawer(true);
                }
              }}
              className="h-10 px-4 text-xs font-bold shadow-sm"
              icon={<ChevronRight className="w-4 h-4" />}
            >
              View Cart
            </Button>
          </div>

          <Drawer
            open={showMobileCartDrawer}
            bodyClassName="pos-mobile-basket-body"
            onClose={() => setShowMobileCartDrawer(false)}
            title={
              <div className="flex items-center justify-between gap-3 w-full pr-2">
                <span className="truncate">Active Cart ({cart.items.reduce((sum, item) => sum + item.quantity, 0)} items)</span>
                <SyncButton
                  scope="pos"
                  label="Sync"
                  size="sm"
                  variant="tonal"
                  className="h-7 px-2 text-xs"
                />
              </div>
            }
            width="lg"
          >
            <div className="h-full min-h-0 flex flex-col">
              {renderCartPanel()}
            </div>
          </Drawer>
        </>
      )}

      {/* =====================================================================
          PRODUCT TOOLS SLIDE-OVER DRAWER
          ===================================================================== */}
      <Drawer
        open={productToolsItemId !== null}
        onClose={() => setProductToolsItemId(null)}
        title="Product Options"
        width="sm"
        footer={
          toolsItem && (
            <div className="flex items-center justify-between gap-2">
              <Button
                variant="ghost"
                size="sm"
                className="text-danger-600 hover:bg-danger-50"
                onClick={() => {
                  cart.removeItem(toolsItem.id);
                  setProductToolsItemId(null);
                  toast.success('Removed from cart');
                }}
              >
                Remove from Cart
              </Button>
              <div className="flex items-center gap-2">
                <Button
                  variant="secondary"
                  size="sm"
                  onClick={() => setProductToolsItemId(null)}
                >
                  Cancel
                </Button>
                <Button variant="primary" size="sm" onClick={handleApplyDiscount}>
                  Apply
                </Button>
              </div>
            </div>
          )
        }
      >
        {toolsItem && (
          <div className="space-y-4">
            {/* Summary */}
            <div className="flex items-start gap-3 p-3 bg-surface-50 border border-surface-200 rounded">
              {toolsItem.image ? (
                <img
                  src={toolsItem.image}
                  alt={toolsItem.name}
                  className="w-12 h-12 rounded object-cover bg-surface-100 border border-surface-200 flex-shrink-0"
                />
              ) : (
                <div className="w-12 h-12 rounded bg-surface-200 flex items-center justify-center text-surface-400">
                  <Package className="w-6 h-6" />
                </div>
              )}
              <div className="min-w-0 flex-1">
                <p className="text-xs font-bold text-surface-900 truncate">{toolsItem.name}</p>
                <p className="text-xs text-surface-500 font-mono mt-0.5">
                  ID: {toolsItem.wooProductId || toolsItem.productId}
                </p>
                <p className="text-xs font-semibold text-surface-800 mt-1 tabular-nums">
                  {formatMoney(toolsItem.unitPrice)} × {toolsItem.quantity}
                </p>
              </div>
            </div>

            {/* Discount selector */}
            {!canApplyDiscount ? (
              <div className="p-3 bg-surface-100 border border-surface-200 rounded text-xs text-surface-600">
                Discounts are restricted for your role. Contact an administrator or manager to apply discounts.
              </div>
            ) : (
              <div className="space-y-2.5">
                <label className="text-xs font-bold text-surface-700 uppercase tracking-wider block">
                  Discount Options
                </label>
                <div className="grid gap-1.5 p-1 bg-surface-100 rounded grid-cols-2">
                  {(['percentage', 'fixed_amount'] as DiscountType[]).map((mode) => (
                    <button
                      key={mode}
                      type="button"
                      onClick={() => setDiscountType(mode)}
                      className={cn(
                        'py-1.5 text-xs font-semibold rounded text-center transition-colors cursor-pointer',
                        discountType === mode
                          ? 'bg-surface-0 text-surface-900 shadow-xs'
                          : 'text-surface-500 hover:text-surface-800'
                      )}
                    >
                      {mode === 'percentage'
                        ? 'Percentage (%)'
                        : `Fixed (${currency.symbol})`}
                    </button>
                  ))}
                </div>

                <div>
                  <input
                    type="number"
                    min="0"
                    step="any"
                    value={discountValue}
                    onChange={(e) => setDiscountValue(e.target.value)}
                    placeholder={
                      discountType === 'percentage'
                        ? 'Enter percentage'
                        : `Enter amount (${currency.symbol})`
                    }
                    className="w-full h-9 px-3 border border-surface-200 rounded text-xs focus:outline-none focus:border-[#60A5FA] focus:ring-2 focus:ring-[#60A5FA]/20 font-medium"
                  />
                </div>

                {toolsItem.discount && (
                  <div className="flex items-center justify-between p-2 bg-blue-50 text-blue-900 border border-blue-200/60 rounded text-xs">
                    <span className="font-medium">Active Discount Applied</span>
                    <button
                      type="button"
                      onClick={() => {
                        cart.removeDiscount(toolsItem.id);
                        toast.success('Discount cleared');
                      }}
                      className="font-semibold underline text-blue-700 hover:text-[#071A31] cursor-pointer"
                    >
                      Remove
                    </button>
                  </div>
                )}
              </div>
            )}
          </div>
        )}
      </Drawer>

      {/* =====================================================================
          CHECKOUT MODAL
          ===================================================================== */}
      <Modal
        open={showCheckoutModal}
        onClose={() => { if(!isProcessingCheckout)setShowCheckoutModal(false); }}
        title="Complete Sale"
        size="md"
        showCloseButton={!isProcessingCheckout}
        footer={<>
          {/* Action Buttons */}
          <div className="pos-checkout-actions w-full flex flex-wrap items-center justify-between gap-3">
            <div>
              {paymentMethod === 'split' && !splitTotals.isExact && (
                <span className="text-xs font-medium text-surface-500">
                  {splitTotals.isOverpaid
                    ? 'Overpayment must be corrected'
                    : 'Pay exact remaining balance to complete'}
                </span>
              )}
            </div>
            <div className="flex items-center gap-2">
              <Button
                variant="secondary"
                size="sm"
                disabled={isProcessingCheckout}
                onClick={() => setShowCheckoutModal(false)}
              >
                Cancel
              </Button>
              <Button
                variant="primary"
                size="md"
                loading={isProcessingCheckout}
                disabled={!isSaleCompletable || isProcessingCheckout}
                onClick={handleProcessCheckout}
                icon={<CheckCircle className="w-4 h-4" />}
                className="font-bold shadow-xs"
              >
                Complete Sale
              </Button>
            </div>
          </div>
        </>}
      >
        <div className="space-y-4">
          <p className="text-sm text-on-surface-variant">Choose how the customer is paying, then record the sale.</p>
          {/* Total Banner */}
          <div className="pos-checkout-total">
            <div>
              <span className="text-xs text-surface-500 uppercase tracking-wider block font-bold">
                Amount Due
              </span>
              <span className="text-2xl font-black text-on-surface tabular-nums">
                {formatMoney(totals.total)}
              </span>
            </div>
            <div className="text-right text-xs text-surface-500">
              <span className="font-semibold text-on-surface">{totals.itemCount} items</span>
            </div>
          </div>

          {/* Applied WooCommerce Coupon Banner in Checkout */}
          {cart.appliedCoupon && (
            <div className="flex items-center justify-between p-2.5 bg-success-container/30 border border-success/30 rounded-xl text-xs">
              <div className="flex items-center gap-2">
                <Tag className="w-4 h-4 text-success flex-shrink-0" />
                <div>
                  <span className="font-bold text-on-surface uppercase tracking-wide">
                    {cart.appliedCoupon.code}
                  </span>
                  <span className="text-xs px-1.5 py-0.2 bg-success/15 text-success font-bold rounded ml-1.5">
                    {cart.appliedCoupon.discountType === 'percent'
                      ? `${cart.appliedCoupon.amount}% off`
                      : 'Fixed discount'}
                  </span>
                  {cart.appliedCoupon.description && (
                    <p className="text-xs text-surface-500 mt-0.5">
                      {cart.appliedCoupon.description}
                    </p>
                  )}
                </div>
              </div>
              <span className="font-black text-success tabular-nums">
                -{formatMoney(totals.couponDiscount)}
              </span>
            </div>
          )}

          {/* Payment Method Selector */}
          <div className="space-y-2">
            <label className="text-xs font-bold text-surface-700 uppercase tracking-wider block">
              Payment Method
            </label>
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
              {[
                { id: 'cash', label: 'Cash' },
                { id: 'pos', label: 'POS Terminal' },
                { id: 'transfer', label: 'Bank Transfer' },
                { id: 'split', label: 'Split Payment' },
              ].map((m) => (
                <button
                  key={m.id}
                  type="button"
                  aria-pressed={paymentMethod === m.id}
                  onClick={() => setPaymentMethod(m.id)}
                  className={cn(
                    'min-h-16 py-3 px-3 rounded-xl border text-sm font-semibold transition-all text-center cursor-pointer',
                    paymentMethod === m.id
                      ? 'border-primary bg-primary-container text-on-primary-container shadow-xs font-bold'
                      : 'border-outline-variant bg-surface text-on-surface hover:bg-surface-container-low'
                  )}
                >
                  {m.label}
                </button>
              ))}
            </div>
          </div>

          {/* Cash Calculation */}
          {paymentMethod === 'cash' && (
            <div className="space-y-3 p-3.5 bg-surface-container-low border border-outline-variant rounded-xl">
              <div className="flex items-center justify-between gap-3">
                <label htmlFor="checkout-cash-tendered" className="text-xs font-semibold text-on-surface">Cash Tendered ({currency.symbol}):</label>
                <input
                  type="number"
                  value={tenderedAmount}
                  id="checkout-cash-tendered"
                  aria-label="Cash tendered"
                  min="0"
                  step="0.01"
                  inputMode="decimal"
                  onChange={(e) => setTenderedAmount(e.target.value)}
                  className="w-36 h-9 px-3 border border-outline-variant rounded-lg text-right font-bold text-xs bg-surface text-on-surface focus:outline-none focus:border-primary focus:ring-2 focus:ring-primary/20"
                />
              </div>

              {/* Quick Cash Buttons */}
              <div className="flex flex-wrap gap-1.5 pt-1">
                {quickCashOptions.map((btn) => (
                  <button
                    key={btn.label}
                    type="button"
                    onClick={() => setTenderedAmount(btn.val.toString())}
                    className="min-h-10 px-3 py-2 text-xs font-semibold bg-surface border border-outline-variant rounded-lg text-on-surface hover:bg-surface-container-high transition-colors cursor-pointer"
                  >
                    {btn.label}
                  </button>
                ))}
              </div>

              <div className="flex justify-between items-center pt-2.5 border-t border-outline-variant/60 text-xs font-bold">
                <span className="text-surface-600">Change Due:</span>
                <span
                  className={cn(
                    'text-base tabular-nums font-black',
                    changeDue > 0 ? 'text-success font-black' : 'text-on-surface'
                  )}
                >
                  {formatMoney(Math.round(changeDue * 100))}
                </span>
              </div>
            </div>
          )}

          {/* Split Payment Calculation & List */}
          {paymentMethod === 'split' && (
            <div className="space-y-3 p-3.5 bg-surface-container-low border border-outline-variant rounded-xl">
              {/* Live Balance Summary Bar */}
              <div className="grid grid-cols-3 gap-2 p-3 bg-surface border border-outline-variant rounded-xl text-center">
                <div className="border-r border-outline-variant/60 pr-1">
                  <span className="text-xs uppercase font-bold text-surface-400 block tracking-wider">
                    Order Total
                  </span>
                  <span className="text-xs font-black text-on-surface tabular-nums">
                    {formatMoney(totals.total)}
                  </span>
                </div>
                <div className="border-r border-outline-variant/60 px-1">
                  <span className="text-xs uppercase font-bold text-surface-400 block tracking-wider">
                    Total Paid
                  </span>
                  <span
                    className={cn(
                      'text-xs font-black tabular-nums',
                      splitTotals.isExact
                        ? 'text-success'
                        : splitTotals.isOverpaid
                        ? 'text-danger'
                        : 'text-on-surface'
                    )}
                  >
                    {formatMoney(splitTotals.paidKobo)}
                  </span>
                </div>
                <div className="pl-1">
                  <span className="text-xs uppercase font-bold text-surface-400 block tracking-wider">
                    Remaining
                  </span>
                  <span
                    className={cn(
                      'text-xs font-black tabular-nums',
                      splitTotals.remainingKobo === 0
                        ? 'text-success'
                        : splitTotals.remainingKobo < 0
                        ? 'text-danger'
                        : 'text-warning'
                    )}
                  >
                    {formatMoney(Math.max(0, splitTotals.remainingKobo))}
                  </span>
                </div>
              </div>

              {/* Status feedback alerts */}
              {splitTotals.isOverpaid && (
                <div className="p-2.5 bg-danger-container border border-danger/30 rounded-xl text-xs text-danger flex items-center gap-2 font-medium">
                  <AlertCircle className="w-4 h-4 flex-shrink-0 text-danger" />
                  <span>
                    Overpayment of {formatMoney(splitTotals.paidKobo - totals.total)}. Split total cannot exceed order total.
                  </span>
                </div>
              )}

              {splitTotals.isExact && (
                <div className="p-2.5 bg-success-container border border-success/30 rounded-xl text-xs text-success flex items-center gap-2 font-medium">
                  <CheckCircle className="w-4 h-4 flex-shrink-0 text-success" />
                  <span>Exact balance reached ({formatMoney(0)} Remaining). Ready to complete sale!</span>
                </div>
              )}

              {splitTotals.isUnderpaid && (
                <div className="p-2.5 bg-warning-container border border-warning/30 rounded-xl text-xs text-warning flex items-center justify-between gap-2 font-medium">
                  <div className="flex items-center gap-2">
                    <AlertCircle className="w-4 h-4 flex-shrink-0 text-warning" />
                    <span>Remaining to pay: {formatMoney(splitTotals.remainingKobo)}</span>
                  </div>
                  <button
                    type="button"
                    onClick={handleAddSplit}
                    className="text-xs font-bold text-warning underline hover:opacity-80 cursor-pointer"
                  >
                    Add split
                  </button>
                </div>
              )}

              {/* Splits List */}
              <div className="space-y-2 pt-1">
                <div className="flex items-center justify-between">
                  <label className="text-xs font-bold text-surface-700 uppercase tracking-wider">
                    Payment Breakdown ({splits.length})
                  </label>
                  {splits.length < 6 && (
                    <button
                      type="button"
                      onClick={handleAddSplit}
                      className="text-xs font-bold text-primary hover:text-primary-hover inline-flex items-center gap-1 cursor-pointer"
                    >
                      <Plus className="w-3.5 h-3.5" />
                      Add Payment Split
                    </button>
                  )}
                </div>

                <div className="space-y-2">
                  {splits.map((split) => {
                    const val = parseFloat(split.amountStr);
                    const currentKobo = isNaN(val) ? 0 : Math.round(val * 100);

                    return (
                      <div
                        key={split.id}
                        className="p-2.5 bg-surface border border-outline-variant rounded-xl space-y-2"
                      >
                        <div className="flex items-center gap-2">
                          {/* Method Selector */}
                          <select
                            aria-label="Split payment method"
                            value={split.method}
                            onChange={(e) => handleUpdateSplitMethod(split.id, e.target.value)}
                            className="h-9 px-2.5 border border-outline-variant rounded-lg text-xs font-semibold text-on-surface bg-surface focus:outline-none focus:border-primary cursor-pointer"
                          >
                            <option value="cash">Cash</option>
                            <option value="pos">POS Terminal</option>
                            <option value="transfer">Bank Transfer</option>
                            <option value="online">Online Payment</option>
                          </select>

                          {/* Amount Input */}
                          <div className="relative flex-1">
                            <span className="absolute left-2.5 top-1/2 -translate-y-1/2 text-xs font-bold text-surface-400">
                              {currency.symbol}
                            </span>
                            <input
                              type="number"
                              min="0"
                              step="any"
                              aria-label="Split payment amount"
                              value={split.amountStr}
                              onChange={(e) => handleUpdateSplitAmount(split.id, e.target.value)}
                              placeholder="0.00"
                              className={cn(
                                'w-full h-9 pl-6 pr-2.5 border rounded-lg text-xs font-bold tabular-nums focus:outline-none focus:border-primary',
                                splitTotals.isOverpaid && currentKobo > 0
                                  ? 'border-danger bg-danger-container/20 text-danger'
                                  : 'border-outline-variant bg-surface text-on-surface'
                              )}
                            />
                          </div>

                          {/* Delete split */}
                          <button
                            type="button"
                            onClick={() => handleRemoveSplit(split.id)}
                            disabled={splits.length === 1}
                            className={cn(
                              'h-9 w-9 flex items-center justify-center rounded-lg border transition-colors flex-shrink-0',
                              splits.length === 1
                                ? 'opacity-30 cursor-not-allowed border-outline-variant text-surface-400'
                                : 'border-outline-variant text-surface-400 hover:text-danger hover:border-danger/30 hover:bg-danger-container/30 cursor-pointer'
                            )}
                            title="Remove split"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        </div>

                        {/* Dynamic Contextual "Add remaining" action */}
                        {splitTotals.remainingKobo > 0 && (
                          <div className="flex items-center justify-between text-xs pt-0.5 border-t border-outline-variant/40">
                            <span className="text-surface-400 font-medium">
                              {currentKobo > 0
                                ? `Current: ${formatMoney(currentKobo)}`
                                : 'Unallocated'}
                            </span>
                            <button
                              type="button"
                              onClick={() => handleAddRemainingToSplit(split.id)}
                              className="font-bold text-primary hover:text-primary-hover hover:underline inline-flex items-center gap-1 cursor-pointer bg-primary-container/20 hover:bg-primary-container/40 px-2 py-0.5 rounded transition-colors"
                            >
                              <Plus className="w-3 h-3" />
                              Add remaining {formatMoney(splitTotals.remainingKobo)}
                            </button>
                          </div>
                        )}
                      </div>
                    );
                  })}
                </div>
              </div>
            </div>
          )}

          {/* Customer Email for Order Confirmation */}
          <div>
            <div className="flex items-center justify-between mb-1">
              <label className="text-xs font-semibold text-surface-700 flex items-center gap-1.5">
                <Mail className="w-3.5 h-3.5 text-primary" />
                <span>Customer Email (Order Confirmation)</span>
              </label>
              {cart.customerName && cart.customerName !== 'Walk-in Customer' && (
                <span className="text-xs text-surface-500 font-medium truncate max-w-[200px]">
                  {cart.customerName}
                </span>
              )}
            </div>
            <input
              type="email"
              value={cart.customerEmail || ''}
              onChange={(e) => {
                cart.setCustomer(
                  cart.customerId,
                  cart.customerName || 'Walk-in Customer',
                  e.target.value,
                  cart.customerPhone || '',
                  cart.wooCustomerId
                );
              }}
              placeholder="customer@example.com (optional)"
              className="w-full h-9 px-3 border border-outline-variant rounded-lg text-xs focus:outline-none focus:border-primary focus:ring-2 focus:ring-primary/20 font-medium bg-surface text-on-surface"
            />
          </div>

          {/* Order Note in Checkout Modal */}
          <div>
            <label className="text-xs font-semibold text-surface-700 block mb-1">
              Order Note / Customer Instructions (Optional)
            </label>
            <textarea
              value={cart.note}
              onChange={(e) => cart.setNote(e.target.value)}
              placeholder="Add special instructions or order notes..."
              rows={2}
              className="w-full px-3 py-2 border border-outline-variant rounded-lg text-xs focus:outline-none focus:border-primary focus:ring-2 focus:ring-primary/20 resize-none font-medium bg-surface text-on-surface"
            />
          </div>


        </div>
      </Modal>

      {/* =====================================================================
          CANCEL CART CONFIRMATION MODAL
          ===================================================================== */}
      <Modal
        open={showCancelCartModal}
        onClose={() => setShowCancelCartModal(false)}
        title="Discard Sale"
        size="sm"
      >
        <div className="space-y-4">
          <p className="text-xs text-surface-600 leading-relaxed">
            Do you want to discard this active order? All items currently in the cart will be cleared.
          </p>
          <div className="flex justify-end gap-2 pt-2">
            <Button variant="secondary" size="sm" onClick={() => setShowCancelCartModal(false)}>
              Keep Order
            </Button>
            <Button
              variant="destructive"
              size="sm"
              onClick={() => {
                cart.clearCart();
                setShowCancelCartModal(false);
                toast.success('Sale discarded');
              }}
            >
              Discard
            </Button>
          </div>
        </div>
      </Modal>

      {/* =====================================================================
          BARCODE SCANNER MODAL
          ===================================================================== */}
      <BarcodeScannerModal
        open={showScannerModal}
        onClose={() => setShowScannerModal(false)}
        onScan={handleBarcodeScanned}
        title="POS Barcode Scanner"
        submitLabel="Add Product to Cart"
      />

      {/* =====================================================================
          ADD PRODUCT MODAL (QUICK ADD FROM UNKNOWN BARCODE)
          ===================================================================== */}
      {showAddModal && (
        <AddProductModal
          open={showAddModal}
          initialBarcode={pendingBarcodeForModal}
          onClose={() => {
            setShowAddModal(false);
            setPendingBarcodeForModal('');
          }}
          onProductCreated={async (newId) => {
            const prod = await db.products.get(newId);
            if (prod) {
              cart.addItem(prod);
              toast.success(`✓ Added ${prod.name} to cart`);
            }
          }}
        />
      )}

      {/* =====================================================================
          RECEIPT PREVIEW MODAL
          ===================================================================== */}
      <VariationPickerModal
        product={variationPickerProduct}
        onClose={() => setVariationPickerProduct(null)}
        onSelect={handlePickVariation}
      />

      {completedSale && (
        <ReceiptModal
          open={completedSale !== null}
          onClose={() => setCompletedSale(null)}
          order={completedSale.order}
          items={completedSale.items}
        />
      )}

      {/* HELD ORDERS MODAL */}
      <HeldOrdersModal
        open={showHeldOrdersModal}
        onClose={() => setShowHeldOrdersModal(false)}
      />

      {/* =====================================================================
          CUSTOMER SEARCH MODAL
          ===================================================================== */}
      <Modal
        open={showCustomerSearchModal}
        onClose={() => {
          setShowCustomerSearchModal(false);
          setCustomerSearchQuery('');
        }}
        title="Search Customers"
        size="md"
      >
        <div className="space-y-3">
          <div className="flex items-center gap-2">
            <div className="flex-1">
              <SearchInput
                value={customerSearchQuery}
                onChange={setCustomerSearchQuery}
                placeholder="Search by name, phone, or email..."
                autoFocus
              />
            </div>
            <Button
              variant="outline"
              size="sm"
              onClick={() => {
                setShowCustomerSearchModal(false);
                setAddCustError(null);
                setDuplicateCust(null);
                setNewCustName('');
                setNewCustPhone('');
                setNewCustEmail('');
                setShowAddCustomerModal(true);
              }}
              className="h-9 px-3 text-xs gap-1.5 flex-shrink-0"
            >
              <Plus className="w-3.5 h-3.5 text-primary" />
              <span>+ Add Customer</span>
            </Button>
          </div>

          <div className="max-h-[360px] overflow-y-auto divide-y divide-surface-100 rounded-lg border border-surface-200">
            {customerSearchResults && customerSearchResults.length > 0 ? (
              customerSearchResults.map((c) => {
                const fullName = `${c.firstName} ${c.lastName}`.trim() || c.email || 'Unnamed Customer';
                const isCurrent = cart.customerId === c.id;
                return (
                  <button
                    key={c.id}
                    type="button"
                    onClick={() => {
                      cart.setCustomer(
                        c.id,
                        fullName,
                        c.email,
                        c.billing?.phone || '',
                        c.wooId ?? null
                      );
                      setShowCustomerSearchModal(false);
                      setCustomerSearchQuery('');
                      toast.success(`Attached ${fullName} to sale`);
                    }}
                    className={cn(
                      'w-full text-left p-3 hover:bg-primary-50/50 flex items-center justify-between transition-colors group',
                      isCurrent && 'bg-primary-50'
                    )}
                  >
                    <div className="min-w-0 flex-1 pr-3">
                      <div className="flex items-center gap-2">
                        <span className="font-semibold text-xs text-surface-900 group-hover:text-primary-700">
                          {fullName}
                        </span>
                        {c.wooId && (
                          <Badge variant="neutral" size="sm" className="text-xs py-0 px-1">
                            #{c.wooId}
                          </Badge>
                        )}
                        {isCurrent && (
                          <Badge variant="success" size="sm" className="text-xs py-0 px-1">
                            Attached
                          </Badge>
                        )}
                      </div>
                      <div className="text-xs text-surface-500 mt-0.5 flex items-center gap-2">
                        {c.billing?.phone && (
                          <span className="font-mono">{c.billing.phone}</span>
                        )}
                        {c.billing?.phone && c.email && <span>•</span>}
                        {c.email && <span className="truncate">{c.email}</span>}
                      </div>
                    </div>
                    <div className="text-right flex-shrink-0">
                      <span className="text-xs font-semibold text-primary group-hover:underline">
                        {isCurrent ? 'Selected' : 'Select →'}
                      </span>
                    </div>
                  </button>
                );
              })
            ) : (
              <div className="py-8 text-center text-surface-400 text-xs">
                {customerSearchQuery ? 'No matching customers found' : 'No customers in local database'}
              </div>
            )}
          </div>

          <div className="flex justify-between items-center pt-2 border-t border-surface-100">
            <Button
              variant="ghost"
              size="sm"
              onClick={() => {
                cart.setCustomer(null, 'Walk-in Customer', '', '', null);
                setShowCustomerSearchModal(false);
                setCustomerSearchQuery('');
                toast.info('Sale set to Walk-in Customer');
              }}
              className="text-surface-500 hover:text-surface-700 text-xs"
            >
              Reset to Walk-in Customer
            </Button>
            <Button
              variant="secondary"
              size="sm"
              onClick={() => {
                setShowCustomerSearchModal(false);
                setCustomerSearchQuery('');
              }}
            >
              Close
            </Button>
          </div>
        </div>
      </Modal>

      {/* =====================================================================
          INLINE ADD CUSTOMER MODAL
          ===================================================================== */}
      <Modal
        open={showAddCustomerModal}
        onClose={() => {
          if (!isCreatingCustomer) {
            setShowAddCustomerModal(false);
            setAddCustError(null);
            setDuplicateCust(null);
          }
        }}
        title="Add Customer to Sale"
        size="sm"
      >
        <form
          onSubmit={async (e) => {
            e.preventDefault();
            if (!newCustName.trim()) {
              setAddCustError('Customer name is required');
              return;
            }
            setIsCreatingCustomer(true);
            setAddCustError(null);
            setDuplicateCust(null);

            const nameParts = newCustName.trim().split(/\s+/);
            const firstName = nameParts[0] || '';
            const lastName = nameParts.slice(1).join(' ') || '';

            const res = await createCustomer({
              firstName,
              lastName,
              phone: newCustPhone.trim(),
              email: newCustEmail.trim(),
            });

            setIsCreatingCustomer(false);

            if (res.isDuplicate && res.customer) {
              setDuplicateCust(res.customer);
              setAddCustError(res.error || 'A customer with this phone or email already exists.');
              return;
            }

            if (!res.success || !res.customer) {
              setAddCustError(res.error || 'Failed to create customer');
              return;
            }

            const fullName = `${res.customer.firstName} ${res.customer.lastName}`.trim() || res.customer.email;
            cart.setCustomer(
              res.customer.id,
              fullName,
              res.customer.email,
              res.customer.billing?.phone || newCustPhone.trim(),
              res.customer.wooId ?? null
            );

            setShowAddCustomerModal(false);
            setNewCustName('');
            setNewCustPhone('');
            setNewCustEmail('');
            toast.success(`✓ Created and attached ${fullName} to sale`);
          }}
          className="space-y-4"
        >
          {addCustError && (
            <div className="p-3 rounded-lg bg-danger-50 border border-danger-200 text-xs text-danger-800 flex items-start gap-2">
              <AlertCircle className="w-4 h-4 text-danger-500 flex-shrink-0 mt-0.5" />
              <div className="space-y-2 flex-1">
                <p>{addCustError}</p>
                {duplicateCust && (
                  <Button
                    type="button"
                    variant="primary"
                    size="sm"
                    className="w-full text-xs py-1.5 h-auto"
                    onClick={() => {
                      const fullName = `${duplicateCust.firstName} ${duplicateCust.lastName}`.trim() || duplicateCust.email;
                      cart.setCustomer(
                        duplicateCust.id,
                        fullName,
                        duplicateCust.email,
                        duplicateCust.billing?.phone || '',
                        duplicateCust.wooId ?? null
                      );
                      setShowAddCustomerModal(false);
                      setAddCustError(null);
                      setDuplicateCust(null);
                      setNewCustName('');
                      setNewCustPhone('');
                      setNewCustEmail('');
                      toast.success(`Attached existing customer ${fullName} to sale`);
                    }}
                  >
                    Attach Existing Customer: {duplicateCust.firstName} {duplicateCust.lastName}
                  </Button>
                )}
              </div>
            </div>
          )}

          <Input
            label="Name *"
            placeholder="e.g. Amina Bello"
            value={newCustName}
            onChange={(e) => setNewCustName(e.target.value)}
            disabled={isCreatingCustomer}
            required
            autoFocus
          />

          <Input
            label="Phone Number"
            type="tel"
            placeholder="e.g. 0803 123 4567"
            value={newCustPhone}
            onChange={(e) => setNewCustPhone(e.target.value)}
            disabled={isCreatingCustomer}
          />

          <Input
            label="Email"
            type="email"
            placeholder="e.g. amina@example.com"
            value={newCustEmail}
            onChange={(e) => setNewCustEmail(e.target.value)}
            disabled={isCreatingCustomer}
          />

          <div className="flex justify-end gap-2 pt-2 border-t border-surface-100">
            <Button
              type="button"
              variant="secondary"
              size="sm"
              disabled={isCreatingCustomer}
              onClick={() => {
                setShowAddCustomerModal(false);
                setAddCustError(null);
                setDuplicateCust(null);
              }}
            >
              Cancel
            </Button>
            <Button
              type="submit"
              variant="primary"
              size="sm"
              disabled={isCreatingCustomer || !newCustName.trim()}
              className="gap-1.5"
            >
              {isCreatingCustomer ? (
                <>
                  <Loader2 className="w-3.5 h-3.5 animate-spin" />
                  <span>Saving...</span>
                </>
              ) : (
                <span>Save &amp; Attach</span>
              )}
            </Button>
          </div>
        </form>
      </Modal>

    </div>
  );
}
