import { useState, useMemo } from 'react';
import { useNavigate } from 'react-router';
import { useLiveQuery } from 'dexie-react-hooks';
import { db } from '@/db';
import { useAuthStore, useConnectionStore } from '@/store';
import { isOrderAccessibleToUser } from '@/services/auth/orderAccess';
import { useDashboardSummary } from '@/services/zameria/dashboardSummary';
import { syncScope } from '@/services/woocommerce/syncCoordinator';
import { historicalSyncService } from '@/services/woocommerce/historicalSyncService';
import { OrderDetailView } from '@/components/order/OrderDetailView';
import { StatusPill, Modal, Button, Badge, ChannelBadge, SyncButton } from '@/components/ui';
import { GlobalSyncStatus } from '@/components/layout/GlobalSyncStatus';
import { formatMoney, formatTime, cn } from '@/lib';
import { toast } from 'sonner';
import {
  DollarSign,
  Globe,
  Store,
  ShoppingBag,
  Users,
  TrendingUp,
  TrendingDown,
  Calendar,
  CreditCard,
  Wallet,
  Smartphone,
  ChevronDown,
  BarChart3,
  LineChart as LineChartIcon,
  Package,
  Boxes,
  CheckCircle2,
  AlertTriangle,
  AlertCircle,
  ArrowRight,
} from 'lucide-react';
import type { Order, OrderItem } from '@/types';

type DateRangeKey =
  | 'today'
  | 'yesterday'
  | 'this_week'
  | 'last_week'
  | 'this_month'
  | 'last_month'
  | 'this_year'
  | 'last_year'
  | 'custom';

interface DateFilterBounds {
  start: Date;
  end: Date;
  prevStart: Date;
  prevEnd: Date;
  grouping: 'hour' | 'day' | 'month';
  label: string;
  prevLabel: string;
}

export function DashboardPage() {
  const navigate = useNavigate();
  const [dateRange, setDateRange] = useState<DateRangeKey>('this_month');
  const [customStartDate, setCustomStartDate] = useState(() => {
    const d = new Date();
    d.setDate(d.getDate() - 14);
    return d.toISOString().split('T')[0];
  });
  const [customEndDate, setCustomEndDate] = useState(() => {
    return new Date().toISOString().split('T')[0];
  });
  const [chartType, setChartType] = useState<'line' | 'bar'>(() => {
    try {
      const saved = localStorage.getItem('zameria_dashboard_chart_type');
      return saved === 'line' || saved === 'bar' ? saved : 'bar';
    } catch {
      return 'bar';
    }
  });

  const handleSelectChartType = (type: 'line' | 'bar') => {
    setChartType(type);
    try {
      localStorage.setItem('zameria_dashboard_chart_type', type);
    } catch {
      // Ignore storage errors
    }
  };
  const [hoveredDataIndex, setHoveredDataIndex] = useState<number | null>(null);

  // Order Details Modal
  const [inspectOrderId, setInspectOrderId] = useState<number | null>(null);


  // Date range bounds calculator using local business timezone
  const bounds: DateFilterBounds = useMemo(() => {
    const now = new Date();

    switch (dateRange) {
      case 'today': {
        const start = new Date(now.getFullYear(), now.getMonth(), now.getDate(), 0, 0, 0, 0);
        const end = new Date(now.getFullYear(), now.getMonth(), now.getDate(), 23, 59, 59, 999);
        const prevStart = new Date(start);
        prevStart.setDate(prevStart.getDate() - 1);
        const prevEnd = new Date(end);
        prevEnd.setDate(prevEnd.getDate() - 1);
        return {
          start,
          end,
          prevStart,
          prevEnd,
          grouping: 'hour',
          label: 'Today',
          prevLabel: 'Yesterday',
        };
      }
      case 'yesterday': {
        const start = new Date(now.getFullYear(), now.getMonth(), now.getDate() - 1, 0, 0, 0, 0);
        const end = new Date(now.getFullYear(), now.getMonth(), now.getDate() - 1, 23, 59, 59, 999);
        const prevStart = new Date(start);
        prevStart.setDate(prevStart.getDate() - 1);
        const prevEnd = new Date(end);
        prevEnd.setDate(prevEnd.getDate() - 1);
        return {
          start,
          end,
          prevStart,
          prevEnd,
          grouping: 'hour',
          label: 'Yesterday',
          prevLabel: '2 Days Ago',
        };
      }
      case 'this_week': {
        // Current week starting Monday
        const dayOfWeek = now.getDay() === 0 ? 6 : now.getDay() - 1;
        const start = new Date(now.getFullYear(), now.getMonth(), now.getDate() - dayOfWeek, 0, 0, 0, 0);
        const end = new Date(start);
        end.setDate(end.getDate() + 6);
        end.setHours(23, 59, 59, 999);
        const prevStart = new Date(start);
        prevStart.setDate(prevStart.getDate() - 7);
        const prevEnd = new Date(end);
        prevEnd.setDate(prevEnd.getDate() - 7);
        return {
          start,
          end,
          prevStart,
          prevEnd,
          grouping: 'day',
          label: 'This Week',
          prevLabel: 'Last Week',
        };
      }
      case 'last_week': {
        const dayOfWeek = now.getDay() === 0 ? 6 : now.getDay() - 1;
        const start = new Date(now.getFullYear(), now.getMonth(), now.getDate() - dayOfWeek - 7, 0, 0, 0, 0);
        const end = new Date(start);
        end.setDate(end.getDate() + 6);
        end.setHours(23, 59, 59, 999);
        const prevStart = new Date(start);
        prevStart.setDate(prevStart.getDate() - 7);
        const prevEnd = new Date(end);
        prevEnd.setDate(prevEnd.getDate() - 7);
        return {
          start,
          end,
          prevStart,
          prevEnd,
          grouping: 'day',
          label: 'Last Week',
          prevLabel: 'Prior Week',
        };
      }
      case 'this_month': {
        const start = new Date(now.getFullYear(), now.getMonth(), 1, 0, 0, 0, 0);
        const end = new Date(now.getFullYear(), now.getMonth() + 1, 0, 23, 59, 59, 999);
        const prevStart = new Date(now.getFullYear(), now.getMonth() - 1, 1, 0, 0, 0, 0);
        const prevEnd = new Date(now.getFullYear(), now.getMonth(), 0, 23, 59, 59, 999);
        return {
          start,
          end,
          prevStart,
          prevEnd,
          grouping: 'day',
          label: 'This Month',
          prevLabel: 'Last Month',
        };
      }
      case 'last_month': {
        const start = new Date(now.getFullYear(), now.getMonth() - 1, 1, 0, 0, 0, 0);
        const end = new Date(now.getFullYear(), now.getMonth(), 0, 23, 59, 59, 999);
        const prevStart = new Date(now.getFullYear(), now.getMonth() - 2, 1, 0, 0, 0, 0);
        const prevEnd = new Date(now.getFullYear(), now.getMonth() - 1, 0, 23, 59, 59, 999);
        return {
          start,
          end,
          prevStart,
          prevEnd,
          grouping: 'day',
          label: 'Last Month',
          prevLabel: 'Prior Month',
        };
      }
      case 'this_year': {
        const start = new Date(now.getFullYear(), 0, 1, 0, 0, 0, 0);
        const end = new Date(now.getFullYear(), 11, 31, 23, 59, 59, 999);
        const prevStart = new Date(now.getFullYear() - 1, 0, 1, 0, 0, 0, 0);
        const prevEnd = new Date(now.getFullYear() - 1, 11, 31, 23, 59, 59, 999);
        return {
          start,
          end,
          prevStart,
          prevEnd,
          grouping: 'month',
          label: 'This Year',
          prevLabel: 'Last Year',
        };
      }
      case 'last_year': {
        const start = new Date(now.getFullYear() - 1, 0, 1, 0, 0, 0, 0);
        const end = new Date(now.getFullYear() - 1, 11, 31, 23, 59, 59, 999);
        const prevStart = new Date(now.getFullYear() - 2, 0, 1, 0, 0, 0, 0);
        const prevEnd = new Date(now.getFullYear() - 2, 11, 31, 23, 59, 59, 999);
        return {
          start,
          end,
          prevStart,
          prevEnd,
          grouping: 'month',
          label: 'Last Year',
          prevLabel: 'Prior Year',
        };
      }
      case 'custom': {
        const start = new Date(`${customStartDate}T00:00:00`);
        const end = new Date(`${customEndDate}T23:59:59.999`);
        const durationMs = end.getTime() - start.getTime();
        const prevEnd = new Date(start.getTime() - 1);
        const prevStart = new Date(prevEnd.getTime() - durationMs);
        const daysSpan = durationMs / (1000 * 60 * 60 * 24);
        const grouping: 'hour' | 'day' | 'month' =
          daysSpan <= 2 ? 'hour' : daysSpan <= 60 ? 'day' : 'month';
        return {
          start,
          end,
          prevStart,
          prevEnd,
          grouping,
          label: 'Custom Range',
          prevLabel: 'Previous Period',
        };
      }
    }
  }, [dateRange, customStartDate, customEndDate]);

  // Channel classification helper
  // Live Dexie queries
  const user = useAuthStore(state=>state.user);
  const online = useConnectionStore(state=>state.isOnline);
  const scope=syncScope();
  const remote = useDashboardSummary(bounds,online);
  const pendingCount=useLiveQuery(()=>db.orders.where('syncStatus').anyOf('PENDING_SYNC','SYNC_ERROR','LOCAL_ONLY').filter(order=>isOrderAccessibleToUser(order,user)).count(),[scope]) || 0;
  const serverSummary = online && !pendingCount ? remote.summary : undefined;
  const recentOrders = useLiveQuery(()=>db.orders.orderBy('createdAt').reverse().filter(order=>isOrderAccessibleToUser(order,user)).limit(6).toArray(),[scope]) || [];
  const totalCachedOrders=useLiveQuery(()=>db.orders.filter(order=>isOrderAccessibleToUser(order,user)).count(),[scope]) || 0;
  const orders = useLiveQuery(async()=>{
    if(serverSummary)return [];
    const lower=new Date(Math.min(bounds.start.getTime(),bounds.prevStart.getTime())).toISOString();
    const upper=new Date(Math.max(bounds.end.getTime(),bounds.prevEnd.getTime())).toISOString();
    return db.orders.where('createdAt').between(lower,upper,true,true).filter(order=>isOrderAccessibleToUser(order,user)).toArray();
  },[bounds,scope,Boolean(serverSummary)]) || [];
  const products = useLiveQuery(() => db.products.toArray(), []) || [];

  // Canonical published products for inventory valuation & health metrics
  const publishedProducts = useMemo(() => {
    return products.filter((p) => !p.status || p.status === 'publish');
  }, [products]);

  // Aggregate Inventory Metrics (Single Source of Truth)
  const inventoryMetrics = useMemo(() => {
    let currentStockValue = 0;
    let inStockCount = 0;
    let lowStockCount = 0;
    let outOfStockCount = 0;

    for (const p of publishedProducts) {
      const lowThreshold = p.lowStockThreshold ?? 5;

      if (p.type === 'variable' && p.variations && p.variations.length > 0) {
        // Variable product: calculate stock value from variations without double-counting parent
        let varTotalStock = 0;
        let hasManagedVariations = false;
        let allVariationsOut = true;
        let anyVariationLow = false;

        for (const v of p.variations) {
          const vPrice = v.salePrice ?? v.price ?? p.price ?? 0;
          const vManage = v.manageStock;
          const vQty = v.stockQuantity;
          const vOut = v.stockStatus === 'outofstock' || (vManage && typeof vQty === 'number' && vQty <= 0);

          if (!vOut) {
            allVariationsOut = false;
          }

          if (vManage && typeof vQty === 'number') {
            hasManagedVariations = true;
            if (vQty > 0) {
              currentStockValue += vPrice * vQty;
              varTotalStock += vQty;
              if (vQty <= lowThreshold) {
                anyVariationLow = true;
              }
            }
          }
        }

        // Health classification for variable product
        if (p.stockStatus === 'outofstock' || allVariationsOut) {
          outOfStockCount++;
        } else if (anyVariationLow || (hasManagedVariations && varTotalStock <= lowThreshold)) {
          lowStockCount++;
        } else {
          inStockCount++;
        }
      } else {
        // Simple product
        const pPrice = p.salePrice ?? p.price ?? 0;
        const pManage = p.manageStock;
        const pQty = p.stockQuantity;
        const isOut = p.stockStatus === 'outofstock' || (pManage && typeof pQty === 'number' && pQty <= 0);

        if (isOut) {
          outOfStockCount++;
        } else if (pManage && typeof pQty === 'number' && pQty <= lowThreshold) {
          lowStockCount++;
          if (pQty > 0) {
            currentStockValue += pPrice * pQty;
          }
        } else {
          inStockCount++;
          if (pManage && typeof pQty === 'number' && pQty > 0) {
            currentStockValue += pPrice * pQty;
          }
        }
      }
    }

    const totalProducts = publishedProducts.length;

    return {
      totalProducts,
      currentStockValue,
      inStockCount,
      lowStockCount,
      outOfStockCount,
      inStockPct: totalProducts > 0 ? Math.round((inStockCount / totalProducts) * 100) : 0,
      lowStockPct: totalProducts > 0 ? Math.round((lowStockCount / totalProducts) * 100) : 0,
      outOfStockPct: totalProducts > 0 ? Math.round((outOfStockCount / totalProducts) * 100) : 0,
    };
  }, [publishedProducts]);

  // Donut chart stroke calculations
  const donutData = useMemo(() => {
    const total = inventoryMetrics.totalProducts;
    const radius = 54;
    const circumference = 2 * Math.PI * radius;

    if (total === 0) {
      return {
        circumference,
        radius,
        inStockLength: 0,
        lowStockLength: 0,
        outOfStockLength: 0,
        lowStockOffset: 0,
        outOfStockOffset: 0,
      };
    }

    const inStockLength = (inventoryMetrics.inStockCount / total) * circumference;
    const lowStockLength = (inventoryMetrics.lowStockCount / total) * circumference;
    const outOfStockLength = (inventoryMetrics.outOfStockCount / total) * circumference;

    const lowStockOffset = -inStockLength;
    const outOfStockOffset = -(inStockLength + lowStockLength);

    return {
      circumference,
      radius,
      inStockLength,
      lowStockLength,
      outOfStockLength,
      lowStockOffset,
      outOfStockOffset,
    };
  }, [inventoryMetrics]);

  // Items for selected inspect order
  const inspectOrderItems = useLiveQuery<OrderItem[]>(
    async () => {
      if (!inspectOrderId) return [];
      return db.orderItems.where('orderId').equals(inspectOrderId).toArray();
    },
    [inspectOrderId]
  ) || [];

  const selectedInspectOrder = useMemo(() => {
    if (!inspectOrderId) return null;
    return recentOrders.find((o) => o.id === inspectOrderId) || orders.find((o) => o.id === inspectOrderId) || null;
  }, [inspectOrderId, orders, recentOrders]);

  const isWebsiteOrder = (order: Order): boolean => {
    if (order.source === 'website') return true;
    if (order.source === 'pos') return false;
    return order.wooId !== null && order.shippingMethod !== 'in-store' && order.shippingMethod !== 'walk-in';
  };

  // Filter orders in range
  const {
    currentOrders,
    completedCurrentOrders,
    completedPreviousOrders,
  } = useMemo(() => {
    const startMs = bounds.start.getTime();
    const endMs = bounds.end.getTime();
    const prevStartMs = bounds.prevStart.getTime();
    const prevEndMs = bounds.prevEnd.getTime();

    const current: Order[] = [];
    const compCurrent: Order[] = [];
    const compPrev: Order[] = [];

    const isRevenueStatus = (status: string) => status === 'completed' || status === 'processing';

    for (const ord of orders) {
      const ordMs = new Date(ord.createdAt).getTime();
      if (ordMs >= startMs && ordMs <= endMs) {
        current.push(ord);
        if (isRevenueStatus(ord.status)) {
          compCurrent.push(ord);
        }
      } else if (ordMs >= prevStartMs && ordMs <= prevEndMs) {
        if (isRevenueStatus(ord.status)) {
          compPrev.push(ord);
        }
      }
    }

    return {
      currentOrders: current,
      completedCurrentOrders: compCurrent,
      completedPreviousOrders: compPrev,
    };
  }, [orders, bounds]);

  // Core metrics calculation
  const localMetrics = useMemo(() => {
    let totalSales = 0;
    let websiteSales = 0;
    let posSales = 0;
    let websiteOrdersCount = 0;
    let posOrdersCount = 0;
    let itemsSold = 0;

    for (const ord of completedCurrentOrders) {
      const value = ord.netTotal ?? ord.total;
      totalSales += value;
      itemsSold += ord.itemCount || 1;
      if (isWebsiteOrder(ord)) {
        websiteSales += value;
        websiteOrdersCount++;
      } else {
        posSales += value;
        posOrdersCount++;
      }
    }

    // Previous period sales
    let prevTotalSales = 0;
    for (const ord of completedPreviousOrders) {
      prevTotalSales += ord.netTotal ?? ord.total;
    }

    // Percentage change vs previous period
    let salesChangePct = 0;
    let salesChangeSign: 'pos' | 'neg' | 'neutral' = 'neutral';
    if (prevTotalSales > 0) {
      const diff = totalSales - prevTotalSales;
      salesChangePct = Math.round((diff / prevTotalSales) * 1000) / 10;
      salesChangeSign = diff >= 0 ? 'pos' : 'neg';
    } else if (totalSales > 0) {
      salesChangePct = 100;
      salesChangeSign = 'pos';
    }

    // Channel proportions
    const websiteSalesPct = totalSales > 0 ? Math.round((websiteSales / totalSales) * 1000) / 10 : 0;
    const posSalesPct = totalSales > 0 ? Math.round((posSales / totalSales) * 1000) / 10 : 0;

    // Total orders count in range (all statuses)
    const totalOrdersCount = currentOrders.length;
    const pendingOrdersCount = currentOrders.filter(
      (o) => o.status === 'on-hold' || o.status === 'pending'
    ).length;

    // AOV (Average Order Value)
    const aov = completedCurrentOrders.length > 0 ? Math.round(totalSales / completedCurrentOrders.length) : 0;

    // Unique customers in period
    const uniqueCustomerIds = new Set<string>();
    let hasWalkIn = false;
    for (const ord of currentOrders) {
      if (ord.customerId) uniqueCustomerIds.add(`id-${ord.customerId}`);
      else if (ord.wooCustomerId) uniqueCustomerIds.add(`woo-${ord.wooCustomerId}`);
      else if (ord.customerEmail && ord.customerEmail.trim()) uniqueCustomerIds.add(`email-${ord.customerEmail.trim().toLowerCase()}`);
      else hasWalkIn = true;
    }
    const uniqueCustomersCount = uniqueCustomerIds.size + (hasWalkIn ? 1 : 0);

    return {
      totalSales,
      websiteSales,
      posSales,
      websiteSalesPct,
      posSalesPct,
      websiteOrdersCount,
      posOrdersCount,
      completedOrdersCount: completedCurrentOrders.length,
      totalOrdersCount,
      pendingOrdersCount,
      itemsSold,
      aov,
      uniqueCustomersCount,
      salesChangePct: Math.abs(salesChangePct),
      salesChangeSign,
      prevTotalSales,
    };
  }, [completedCurrentOrders, completedPreviousOrders, currentOrders]);

  const metrics = serverSummary?.metrics || localMetrics;

  // Payment Methods Breakdown (Physical POS collection methods)
  const paymentBreakdown = useMemo(() => {
    const buckets: Record<string, { label: string; amount: number; count: number; icon: any }> = {
      cash: { label: 'Cash', amount: 0, count: 0, icon: Wallet },
      pos: { label: 'POS Terminal / Card', amount: 0, count: 0, icon: CreditCard },
      transfer: { label: 'Bank Transfer', amount: 0, count: 0, icon: Smartphone },
    };

    for (const ord of completedCurrentOrders) {
      if (ord.paymentSplits && ord.paymentSplits.length > 0) {
        // Attributed strictly according to each split's method and amount
        for (const split of ord.paymentSplits) {
          const m = (split.method || '').toLowerCase();
          const key = (m === 'cash' || m === 'cod') ? 'cash'
            : (m === 'transfer' || m === 'bacs' || m === 'bank_transfer') ? 'transfer'
            : (m === 'pos' || m === 'card' || m === 'terminal') ? 'pos'
            : null;
          if (key && buckets[key]) {
            buckets[key].amount += Math.round(split.amount * (ord.total > 0 ? (ord.netTotal ?? ord.total) / ord.total : 0));
            buckets[key].count++;
          }
        }
      } else {
        const m = (ord.paymentMethod || '').toLowerCase();
        let key: string | null = null;
        if (m === 'cash' || m === 'cod') key = 'cash';
        else if (m === 'transfer' || m === 'bacs' || m === 'bank_transfer') key = 'transfer';
        else if (m === 'pos' || m === 'card' || m === 'terminal') key = 'pos';
        else if (!isWebsiteOrder(ord)) key = 'pos';

        if (key && buckets[key]) {
          buckets[key].amount += ord.netTotal ?? ord.total;
          buckets[key].count++;
        }
      }
    }

    if(serverSummary) for(const [key,bucket] of Object.entries(buckets)){const remotePayment=serverSummary.payments[key];bucket.amount=remotePayment?.amount||0;bucket.count=remotePayment?.count||0;}
    const totalCollected = Object.values(buckets).reduce((sum, b) => sum + b.amount, 0);

    return Object.entries(buckets).map(([key, data]) => ({
      key,
      label: data.label,
      amount: data.amount,
      count: data.count,
      percent: totalCollected > 0 ? Math.round((data.amount / totalCollected) * 1000) / 10 : 0,
      icon: data.icon,
    }));
  }, [completedCurrentOrders,serverSummary]);

  // Every order in the selected period contributes; bounded indexed batches avoid a huge anyOf request.
  const periodOrderIdsKey = useMemo(() => {
    return completedCurrentOrders.map((o) => o.id).join(',');
  }, [completedCurrentOrders]);

  const periodOrderItems = useLiveQuery<OrderItem[]>(
    async () => {
      if (!periodOrderIdsKey) return [];
      const ids = periodOrderIdsKey.split(',').map(Number).filter(Boolean);
      const items: OrderItem[]=[];
      for(let n=0;n<ids.length;n+=100) items.push(...await db.orderItems.where('orderId').anyOf(ids.slice(n,n+100)).toArray());
      return items;
    },
    [periodOrderIdsKey]
  ) || [];

  // Top Selling Products in period
  const topProducts = useMemo(() => {
    if(serverSummary)return serverSummary.topProducts;
    const completedOrderIds = new Set(completedCurrentOrders.map((o) => o.id));
    const completedOrderMap = new Map(completedCurrentOrders.map((o) => [o.id, o]));

    const productMap = new Map<
      string,
      {
        name: string;
        sku: string;
        unitsSold: number;
        revenue: number;
        hasWebsite: boolean;
        hasPOS: boolean;
      }
    >();

    for (const item of periodOrderItems) {
      if (!completedOrderIds.has(item.orderId)) continue;
      const order = completedOrderMap.get(item.orderId);
      const isWeb = order ? isWebsiteOrder(order) : false;

      const key = item.productId > 0 ? String(item.productId) : item.name;
      const existing = productMap.get(key);

      if (existing) {
        existing.unitsSold += item.quantity;
        existing.revenue += item.total;
        if (isWeb) existing.hasWebsite = true;
        else existing.hasPOS = true;
      } else {
        productMap.set(key, {
          name: item.name,
          sku: item.sku || 'N/A',
          unitsSold: item.quantity,
          revenue: item.total,
          hasWebsite: isWeb,
          hasPOS: !isWeb,
        });
      }
    }

    return Array.from(productMap.values())
      .sort((a, b) => b.revenue - a.revenue)
      .slice(0, 6);
  }, [completedCurrentOrders, periodOrderItems,serverSummary]);

  // Primary Sales Chart Data Series
  const chartData = useMemo(() => {
    const { start, end, grouping } = bounds;

    interface Bucket {
      label: string;
      fullDateLabel: string;
      website: number;
      pos: number;
      total: number;
    }

    const buckets: Bucket[] = [];

    if (grouping === 'hour') {
      // 24 hourly buckets: 00:00 to 23:00
      for (let h = 0; h < 24; h++) {
        const label = `${h.toString().padStart(2, '0')}:00`;
        buckets.push({
          label,
          fullDateLabel: `${label} - ${h}:59`,
          website: 0,
          pos: 0,
          total: 0,
        });
      }
      for (const ord of completedCurrentOrders) {
        const d = new Date(ord.createdAt);
        const h = d.getHours();
        if (h >= 0 && h < 24) {
          if (isWebsiteOrder(ord)) {
            buckets[h].website += ord.netTotal ?? ord.total;
          } else {
            buckets[h].pos += ord.netTotal ?? ord.total;
          }
          buckets[h].total += ord.netTotal ?? ord.total;
        }
      }
    } else if (grouping === 'day') {
      // Daily buckets spanning the range
      const cur = new Date(start);
      while (cur <= end) {
        const dayLabel = cur.toLocaleDateString('en-GB', { day: 'numeric', month: 'short' });
        buckets.push({
          label: dayLabel,
          fullDateLabel: cur.toLocaleDateString('en-GB', { weekday: 'short', day: 'numeric', month: 'long', year: 'numeric' }),
          website: 0,
          pos: 0,
          total: 0,
        });
        cur.setDate(cur.getDate() + 1);
      }
      for (const ord of completedCurrentOrders) {
        const ordDate = new Date(ord.createdAt);
        const diffDays = Math.floor((ordDate.getTime() - start.getTime()) / (1000 * 60 * 60 * 24));
        if (diffDays >= 0 && diffDays < buckets.length) {
          if (isWebsiteOrder(ord)) {
            buckets[diffDays].website += ord.netTotal ?? ord.total;
          } else {
            buckets[diffDays].pos += ord.netTotal ?? ord.total;
          }
          buckets[diffDays].total += ord.netTotal ?? ord.total;
        }
      }
    } else {
      // Monthly buckets (Jan - Dec)
      const months = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
      for (let m = 0; m < 12; m++) {
        buckets.push({
          label: months[m],
          fullDateLabel: `${months[m]} ${start.getFullYear()}`,
          website: 0,
          pos: 0,
          total: 0,
        });
      }
      for (const ord of completedCurrentOrders) {
        const ordDate = new Date(ord.createdAt);
        const m = ordDate.getMonth();
        if (m >= 0 && m < 12) {
          if (isWebsiteOrder(ord)) {
            buckets[m].website += ord.netTotal ?? ord.total;
          } else {
            buckets[m].pos += ord.netTotal ?? ord.total;
          }
          buckets[m].total += ord.netTotal ?? ord.total;
        }
      }
    }

    if(serverSummary) for(let n=0;n<buckets.length;n++) {
      const key=grouping==='hour'?String(n).padStart(2,'0'):grouping==='month'?`${start.getFullYear()}-${String(n+1).padStart(2,'0')}`:(()=>{const date=new Date(start);date.setDate(date.getDate()+n);return `${date.getFullYear()}-${String(date.getMonth()+1).padStart(2,'0')}-${String(date.getDate()).padStart(2,'0')}`;})();
      Object.assign(buckets[n],serverSummary.series[key]||{website:0,pos:0,total:0});
    }
    const maxVal = Math.max(...buckets.map((b) => b.total), 1000);

    return {
      buckets,
      maxVal,
    };
  }, [bounds, completedCurrentOrders,serverSummary]);


  return (
    <div className="flex-1 flex flex-col h-full bg-surface-50 overflow-y-auto min-w-0">
      <div className="p-4 sm:p-6 max-w-7xl mx-auto w-full space-y-6">
        <p role="status" className="text-xs text-surface-500">
          {serverSummary ? `${remote.fresh ? 'Store totals verified' : 'Cached store totals; checking updates'} · ${new Date(serverSummary.verifiedAt).toLocaleString()}` : `Showing downloaded data${pendingCount ? ' including pending local sales' : ''}. ${historicalSyncService.isCompleted() ? 'History import complete.' : 'Full history is still syncing in the background.'}`}
          {remote.error && online ? ' Store totals could not refresh; retrying.' : ''}
        </p>
        {/* =========================================================================
            1. TOP CONTROL BAR (HEADER, DATE FILTER, RESYNC)
            ========================================================================= */}
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-3 pb-3 border-b border-surface-200">
          <div>
            <div className="flex items-center gap-2.5">
              <h1 className="text-xl sm:text-2xl font-black text-on-surface tracking-tight">
                Sales &amp; Business Dashboard
              </h1>
              <Badge variant="brand" size="sm">
                Omnichannel View
              </Badge>
            </div>
            <p className="text-xs text-surface-500 mt-0.5">
              Unified business performance tracking online WooCommerce + in-store Physical POS.
            </p>
          </div>

          <div className="flex items-center gap-2.5 flex-wrap">
            {/* Global Date Filter */}
            <div className="relative inline-flex items-center">
              <Calendar className="w-3.5 h-3.5 absolute left-3 text-surface-400 pointer-events-none" />
              <select
                value={dateRange}
                onChange={(e) => setDateRange(e.target.value as DateRangeKey)}
                className="h-9 pl-8 pr-7 bg-surface border border-outline-variant rounded-lg text-xs font-bold text-on-surface hover:border-outline focus:outline-none focus:ring-2 focus:ring-primary/20 cursor-pointer appearance-none"
              >
                <option value="today">Today</option>
                <option value="yesterday">Yesterday</option>
                <option value="this_week">This Week</option>
                <option value="last_week">Last Week</option>
                <option value="this_month">This Month</option>
                <option value="last_month">Last Month</option>
                <option value="this_year">This Year</option>
                <option value="last_year">Last Year</option>
                <option value="custom">Custom Range</option>
              </select>
              <ChevronDown className="w-3.5 h-3.5 absolute right-2 text-surface-400 pointer-events-none" />
            </div>

            {/* Custom Date Inputs when 'custom' selected */}
            {dateRange === 'custom' && (
              <div className="flex items-center gap-1.5 text-xs bg-surface border border-outline-variant rounded-lg px-2.5 h-9">
                <input
                  type="date"
                  value={customStartDate}
                  onChange={(e) => setCustomStartDate(e.target.value)}
                  className="font-medium text-on-surface focus:outline-none bg-transparent"
                />
                <span className="text-surface-400">to</span>
                <input
                  type="date"
                  value={customEndDate}
                  onChange={(e) => setCustomEndDate(e.target.value)}
                  className="font-medium text-on-surface focus:outline-none bg-transparent"
                />
              </div>
            )}

            {/* ↻ DASHBOARD SYNC BUTTON */}
            <SyncButton
              scope="dashboard"
              label="Resync"
              variant="primary"
              size="sm"
            />

            {/* Global Sync Status Flyout */}
            <GlobalSyncStatus />
          </div>
        </div>

        {/* =========================================================================
            2. CORE SUMMARY METRICS CARDS (6 CARDS)
            ========================================================================= */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-6 gap-3.5">
          {/* Card 1: TOTAL SALES (Combined) */}
          <div className="m3-card-outlined rounded-xl p-4 bg-surface flex flex-col justify-between hover:border-outline transition-colors">
            <div className="flex items-center justify-between text-surface-500">
              <span className="text-[11px] font-bold uppercase tracking-wider text-surface-500">
                Total Sales
              </span>
              <div className="w-7 h-7 rounded-lg bg-blue-50 text-[#60A5FA] flex items-center justify-center">
                <DollarSign className="w-4 h-4" />
              </div>
            </div>
            <div className="mt-3 space-y-1">
              <div className="text-xl font-black text-on-surface tracking-tight tabular-nums">
                {formatMoney(metrics.totalSales)}
              </div>
              <div className="flex items-center gap-1 text-[11px] font-semibold">
                {metrics.salesChangeSign === 'pos' ? (
                  <span className="text-success inline-flex items-center gap-0.5 font-bold">
                    <TrendingUp className="w-3 h-3" />
                    +{metrics.salesChangePct}%
                  </span>
                ) : metrics.salesChangeSign === 'neg' ? (
                  <span className="text-danger inline-flex items-center gap-0.5 font-bold">
                    <TrendingDown className="w-3 h-3" />
                    -{metrics.salesChangePct}%
                  </span>
                ) : (
                  <span className="text-surface-400">0%</span>
                )}
                <span className="text-surface-400 font-normal">vs {bounds.prevLabel}</span>
              </div>
            </div>
          </div>

          {/* Card 2: WEBSITE SALES */}
          <div className="m3-card-outlined rounded-xl p-4 bg-surface flex flex-col justify-between hover:border-outline transition-colors">
            <div className="flex items-center justify-between text-surface-500">
              <span className="text-[11px] font-bold uppercase tracking-wider text-[#071A31]">
                Website Sales
              </span>
              <div className="w-7 h-7 rounded-lg bg-slate-100 text-[#071A31] flex items-center justify-center">
                <Globe className="w-4 h-4" />
              </div>
            </div>
            <div className="mt-3 space-y-1">
              <div className="text-xl font-black text-on-surface tracking-tight tabular-nums">
                {formatMoney(metrics.websiteSales)}
              </div>
              <div className="flex items-center justify-between text-[11px] text-surface-500">
                <span className="font-semibold text-[#071A31]">{metrics.websiteSalesPct}% of Total</span>
                <span>{metrics.websiteOrdersCount} orders</span>
              </div>
            </div>
          </div>

          {/* Card 3: PHYSICAL POS SALES */}
          <div className="m3-card-outlined rounded-xl p-4 bg-surface flex flex-col justify-between hover:border-outline transition-colors">
            <div className="flex items-center justify-between text-surface-500">
              <span className="text-[11px] font-bold uppercase tracking-wider text-[#60A5FA]">
                POS Store Sales
              </span>
              <div className="w-7 h-7 rounded-lg bg-blue-50 text-[#60A5FA] flex items-center justify-center">
                <Store className="w-4 h-4" />
              </div>
            </div>
            <div className="mt-3 space-y-1">
              <div className="text-xl font-black text-on-surface tracking-tight tabular-nums">
                {formatMoney(metrics.posSales)}
              </div>
              <div className="flex items-center justify-between text-[11px] text-surface-500">
                <span className="font-semibold text-[#60A5FA]">{metrics.posSalesPct}% of Total</span>
                <span>{metrics.posOrdersCount} orders</span>
              </div>
            </div>
          </div>

          {/* Card 4: TOTAL ORDERS */}
          <div className="m3-card-outlined rounded-xl p-4 bg-surface flex flex-col justify-between hover:border-outline transition-colors">
            <div className="flex items-center justify-between text-surface-500">
              <span className="text-[11px] font-bold uppercase tracking-wider text-surface-500">
                Total Orders
              </span>
              <div className="w-7 h-7 rounded-lg bg-purple-50 dark:bg-purple-950 text-purple-600 dark:text-purple-400 flex items-center justify-center">
                <ShoppingBag className="w-4 h-4" />
              </div>
            </div>
            <div className="mt-3 space-y-1">
              <div className="text-xl font-black text-on-surface tracking-tight tabular-nums">
                {metrics.completedOrdersCount}
              </div>
              <div className="text-[11px] text-surface-500 truncate">
                <span>{metrics.itemsSold} items sold</span>
                {metrics.pendingOrdersCount > 0 && (
                  <span className="text-amber-700 dark:text-amber-400 font-semibold ml-1">
                    · {metrics.pendingOrdersCount} pending
                  </span>
                )}
              </div>
            </div>
          </div>

          {/* Card 5: AVERAGE ORDER VALUE */}
          <div className="m3-card-outlined rounded-xl p-4 bg-surface flex flex-col justify-between hover:border-outline transition-colors">
            <div className="flex items-center justify-between text-surface-500">
              <span className="text-[11px] font-bold uppercase tracking-wider text-surface-500">
                Average Value (AOV)
              </span>
              <div className="w-7 h-7 rounded-lg bg-amber-50 dark:bg-amber-950 text-amber-600 dark:text-amber-400 flex items-center justify-center">
                <DollarSign className="w-4 h-4" />
              </div>
            </div>
            <div className="mt-3 space-y-1">
              <div className="text-xl font-black text-on-surface tracking-tight tabular-nums">
                {formatMoney(metrics.aov)}
              </div>
              <div className="text-[11px] text-surface-400">
                <span>Per completed checkout</span>
              </div>
            </div>
          </div>

          {/* Card 6: CUSTOMERS */}
          <div className="m3-card-outlined rounded-xl p-4 bg-surface flex flex-col justify-between hover:border-outline transition-colors">
            <div className="flex items-center justify-between text-surface-500">
              <span className="text-[11px] font-bold uppercase tracking-wider text-surface-500">
                Customers Active
              </span>
              <div className="w-7 h-7 rounded-lg bg-indigo-50 dark:bg-indigo-950 text-indigo-600 dark:text-indigo-400 flex items-center justify-center">
                <Users className="w-4 h-4" />
              </div>
            </div>
            <div className="mt-3 space-y-1">
              <div className="text-xl font-black text-on-surface tracking-tight tabular-nums">
                {metrics.uniqueCustomersCount}
              </div>
              <div className="text-[11px] text-surface-400">
                <span>In selected timeframe</span>
              </div>
            </div>
          </div>
        </div>

        {/* =========================================================================
            2.5 INVENTORY OVERVIEW (STOCK VALUATION, HEALTH METRICS, DONUT BREAKDOWN)
            ========================================================================= */}
        <div className="m3-card-outlined rounded-2xl p-5 bg-surface space-y-4">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-3 border-b border-surface-200">
            <div>
              <div className="flex items-center gap-2">
                <Boxes className="w-4 h-4 text-primary" />
                <h2 className="text-sm sm:text-base font-bold text-on-surface tracking-tight">
                  Inventory Overview
                </h2>
                <Badge variant="brand" size="sm">
                  Real-Time
                </Badge>
              </div>
              <p className="text-xs text-surface-500 mt-0.5">
                Real-time catalog valuation and stock health monitoring across your store.
              </p>
            </div>

            <button
              type="button"
              onClick={() => navigate('/products')}
              className="inline-flex items-center gap-1.5 text-xs font-bold text-primary hover:text-primary/80 transition-colors cursor-pointer group self-start sm:self-center"
            >
              <span>View Products</span>
              <ArrowRight className="w-3.5 h-3.5 group-hover:translate-x-0.5 transition-transform" />
            </button>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-12 gap-4">
            {/* Left Column: Primary Stock Valuation & Donut Breakdown */}
            <div className="lg:col-span-5 p-4 rounded-xl border border-outline-variant bg-surface-container-lowest flex flex-col justify-between gap-4">
              <div className="space-y-1">
                <div className="flex items-center justify-between">
                  <span className="text-[11px] font-bold uppercase tracking-wider text-surface-500">
                    Current Stock Value
                  </span>
                  <div className="w-7 h-7 rounded-lg bg-emerald-50 dark:bg-emerald-950 text-emerald-600 dark:text-emerald-400 flex items-center justify-center">
                    <Boxes className="w-4 h-4" />
                  </div>
                </div>
                <div className="text-2xl sm:text-3xl font-black text-on-surface tracking-tight tabular-nums">
                  {formatMoney(inventoryMetrics.currentStockValue)}
                </div>
                <p className="text-[11px] text-surface-400 font-medium">
                  Aggregated monetary retail value of available physical stock
                </p>
              </div>

              {/* Visual Donut Breakdown & Legend */}
              <div className="pt-3 border-t border-surface-200 dark:border-surface-800 flex flex-col sm:flex-row items-center gap-4">
                <div className="relative flex items-center justify-center flex-shrink-0">
                  <svg viewBox="0 0 160 160" className="w-32 h-32 sm:w-36 sm:h-36 transform -rotate-90">
                    <circle
                      cx="80"
                      cy="80"
                      r={donutData.radius}
                      fill="transparent"
                      stroke="currentColor"
                      strokeWidth="14"
                      className="text-surface-200 dark:text-surface-800"
                    />
                    {donutData.inStockLength > 0 && (
                      <circle
                        cx="80"
                        cy="80"
                        r={donutData.radius}
                        fill="transparent"
                        stroke="#10B981"
                        strokeWidth="14"
                        strokeDasharray={`${donutData.inStockLength} ${donutData.circumference - donutData.inStockLength}`}
                        strokeDashoffset={0}
                        className="transition-all duration-500 ease-out"
                      />
                    )}
                    {donutData.lowStockLength > 0 && (
                      <circle
                        cx="80"
                        cy="80"
                        r={donutData.radius}
                        fill="transparent"
                        stroke="#F59E0B"
                        strokeWidth="14"
                        strokeDasharray={`${donutData.lowStockLength} ${donutData.circumference - donutData.lowStockLength}`}
                        strokeDashoffset={donutData.lowStockOffset}
                        className="transition-all duration-500 ease-out"
                      />
                    )}
                    {donutData.outOfStockLength > 0 && (
                      <circle
                        cx="80"
                        cy="80"
                        r={donutData.radius}
                        fill="transparent"
                        stroke="#EF4444"
                        strokeWidth="14"
                        strokeDasharray={`${donutData.outOfStockLength} ${donutData.circumference - donutData.outOfStockLength}`}
                        strokeDashoffset={donutData.outOfStockOffset}
                        className="transition-all duration-500 ease-out"
                      />
                    )}
                  </svg>
                  <div className="absolute inset-0 flex flex-col items-center justify-center text-center pointer-events-none">
                    <span className="text-[9px] font-bold uppercase tracking-wider text-surface-400">
                      Total
                    </span>
                    <span className="text-lg font-black text-on-surface tabular-nums">
                      {inventoryMetrics.totalProducts}
                    </span>
                    <span className="text-[9px] font-medium text-surface-400">
                      Items
                    </span>
                  </div>
                </div>

                {/* Donut Legend */}
                <div className="space-y-2 flex-1 w-full min-w-[130px]">
                  <div className="flex items-center justify-between text-xs">
                    <div className="flex items-center gap-1.5">
                      <span className="w-2.5 h-2.5 rounded-full bg-emerald-500 flex-shrink-0" />
                      <span className="font-semibold text-surface-700">In Stock</span>
                    </div>
                    <div className="flex items-center gap-1 font-bold tabular-nums">
                      <span className="text-on-surface">{inventoryMetrics.inStockCount}</span>
                      <span className="text-[10px] text-surface-400 font-normal">({inventoryMetrics.inStockPct}%)</span>
                    </div>
                  </div>
                  <div className="flex items-center justify-between text-xs">
                    <div className="flex items-center gap-1.5">
                      <span className="w-2.5 h-2.5 rounded-full bg-amber-500 flex-shrink-0" />
                      <span className="font-semibold text-surface-700">Low Stock</span>
                    </div>
                    <div className="flex items-center gap-1 font-bold tabular-nums">
                      <span className="text-on-surface">{inventoryMetrics.lowStockCount}</span>
                      <span className="text-[10px] text-surface-400 font-normal">({inventoryMetrics.lowStockPct}%)</span>
                    </div>
                  </div>
                  <div className="flex items-center justify-between text-xs">
                    <div className="flex items-center gap-1.5">
                      <span className="w-2.5 h-2.5 rounded-full bg-rose-500 flex-shrink-0" />
                      <span className="font-semibold text-surface-700">Out of Stock</span>
                    </div>
                    <div className="flex items-center gap-1 font-bold tabular-nums">
                      <span className="text-on-surface">{inventoryMetrics.outOfStockCount}</span>
                      <span className="text-[10px] text-surface-400 font-normal">({inventoryMetrics.outOfStockPct}%)</span>
                    </div>
                  </div>
                </div>
              </div>
            </div>

            {/* Right Column: 4 Core Health Metric Cards */}
            <div className="lg:col-span-7 grid grid-cols-1 sm:grid-cols-2 gap-3.5">
              {/* Metric 1: Total Products */}
              <div className="p-4 rounded-xl border border-outline-variant bg-surface hover:border-outline transition-colors flex flex-col justify-between">
                <div className="flex items-center justify-between">
                  <span className="text-[11px] font-bold uppercase tracking-wider text-surface-500">
                    Total Products
                  </span>
                  <div className="w-7 h-7 rounded-lg bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 flex items-center justify-center">
                    <Package className="w-4 h-4" />
                  </div>
                </div>
                <div className="mt-3 space-y-1">
                  <div className="text-2xl font-black text-on-surface tracking-tight tabular-nums">
                    {inventoryMetrics.totalProducts}
                  </div>
                  <div className="text-[11px] text-surface-400 font-medium">
                    Active catalog items tracked
                  </div>
                </div>
              </div>

              {/* Metric 2: In Stock */}
              <div className="p-4 rounded-xl border border-emerald-200/70 dark:border-emerald-900/60 bg-emerald-50/40 dark:bg-emerald-950/20 hover:border-emerald-300 transition-colors flex flex-col justify-between">
                <div className="flex items-center justify-between">
                  <span className="text-[11px] font-bold uppercase tracking-wider text-emerald-800 dark:text-emerald-300">
                    In Stock
                  </span>
                  <div className="w-7 h-7 rounded-lg bg-emerald-100 dark:bg-emerald-900 text-emerald-600 dark:text-emerald-300 flex items-center justify-center">
                    <CheckCircle2 className="w-4 h-4" />
                  </div>
                </div>
                <div className="mt-3 space-y-1">
                  <div className="flex items-baseline gap-2">
                    <div className="text-2xl font-black text-emerald-950 dark:text-emerald-100 tracking-tight tabular-nums">
                      {inventoryMetrics.inStockCount}
                    </div>
                    <span className="text-xs font-bold text-emerald-700 dark:text-emerald-400">
                      {inventoryMetrics.inStockPct}%
                    </span>
                  </div>
                  <div className="text-[11px] text-emerald-700/80 dark:text-emerald-400/80 font-medium">
                    Healthy stock levels available
                  </div>
                </div>
              </div>

              {/* Metric 3: Low Stock / Restock */}
              <div className="p-4 rounded-xl border border-amber-200/70 dark:border-amber-900/60 bg-amber-50/40 dark:bg-amber-950/20 hover:border-amber-300 transition-colors flex flex-col justify-between">
                <div className="flex items-center justify-between">
                  <span className="text-[11px] font-bold uppercase tracking-wider text-amber-800 dark:text-amber-300">
                    Low Stock / Restock
                  </span>
                  <div className="w-7 h-7 rounded-lg bg-amber-100 dark:bg-amber-900 text-amber-600 dark:text-amber-300 flex items-center justify-center">
                    <AlertTriangle className="w-4 h-4" />
                  </div>
                </div>
                <div className="mt-3 space-y-1">
                  <div className="flex items-baseline gap-2">
                    <div className="text-2xl font-black text-amber-950 dark:text-amber-100 tracking-tight tabular-nums">
                      {inventoryMetrics.lowStockCount}
                    </div>
                    <span className="text-xs font-bold text-amber-700 dark:text-amber-400">
                      {inventoryMetrics.lowStockPct}%
                    </span>
                  </div>
                  <div className="text-[11px] text-amber-700/80 dark:text-amber-400/80 font-medium">
                    At or below reorder threshold
                  </div>
                </div>
              </div>

              {/* Metric 4: Out of Stock */}
              <div className="p-4 rounded-xl border border-rose-200/70 dark:border-rose-900/60 bg-rose-50/40 dark:bg-rose-950/20 hover:border-rose-300 transition-colors flex flex-col justify-between">
                <div className="flex items-center justify-between">
                  <span className="text-[11px] font-bold uppercase tracking-wider text-rose-800 dark:text-rose-300">
                    Out of Stock
                  </span>
                  <div className="w-7 h-7 rounded-lg bg-rose-100 dark:bg-rose-900 text-rose-600 dark:text-rose-300 flex items-center justify-center">
                    <AlertCircle className="w-4 h-4" />
                  </div>
                </div>
                <div className="mt-3 space-y-1">
                  <div className="flex items-baseline gap-2">
                    <div className="text-2xl font-black text-rose-950 dark:text-rose-100 tracking-tight tabular-nums">
                      {inventoryMetrics.outOfStockCount}
                    </div>
                    <span className="text-xs font-bold text-rose-700 dark:text-rose-400">
                      {inventoryMetrics.outOfStockPct}%
                    </span>
                  </div>
                  <div className="text-[11px] text-rose-700/80 dark:text-rose-400/80 font-medium">
                    Completely depleted inventory
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* =========================================================================
            3. PRIMARY SALES OVER TIME CHART (WEBSITE vs POS vs TOTAL)
            ========================================================================= */}
        <div className="m3-card-outlined rounded-2xl p-5 bg-surface space-y-4">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
            <div>
              <div className="flex items-center gap-2">
                <h3 className="text-sm font-bold text-on-surface tracking-tight">
                  Sales Trend Over Time
                </h3>
                <span className="text-xs text-surface-400 font-medium">
                  ({bounds.label} · Grouped by {bounds.grouping})
                </span>
              </div>
              <p className="text-xs text-surface-500 mt-0.5">
                Multi-channel breakdown tracking online vs physical store revenue performance.
              </p>
            </div>

            {/* Legend & Chart View Toggle */}
            <div className="flex items-center gap-4 flex-wrap">
              <div className="flex items-center gap-3 text-xs font-semibold">
                <div className="flex items-center gap-1.5">
                  <span className="w-2.5 h-2.5 rounded-full bg-[#071A31]" />
                  <span className="text-surface-700 font-semibold">Website (Navy)</span>
                </div>
                <div className="flex items-center gap-1.5">
                  <span className="w-2.5 h-2.5 rounded-full bg-[#60A5FA]" />
                  <span className="text-surface-700 font-semibold">Physical POS (Light Blue)</span>
                </div>
                <div className="flex items-center gap-1.5">
                  <span className="w-2.5 h-2.5 rounded-full bg-surface-800" />
                  <span className="text-surface-700">Combined Total</span>
                </div>
              </div>

              {/* Toggle Line / Bar */}
              <div className="flex items-center bg-surface-container-lowest p-0.5 rounded-lg border border-outline-variant">
                <button
                  type="button"
                  onClick={() => handleSelectChartType('line')}
                  className={cn(
                    'p-1.5 rounded-md text-xs font-semibold transition-colors cursor-pointer',
                    chartType === 'line'
                      ? 'bg-surface text-on-surface shadow-xs'
                      : 'text-surface-500 hover:text-on-surface'
                  )}
                  title="Line View"
                >
                  <LineChartIcon className="w-3.5 h-3.5" />
                </button>
                <button
                  type="button"
                  onClick={() => handleSelectChartType('bar')}
                  className={cn(
                    'p-1.5 rounded-md text-xs font-semibold transition-colors cursor-pointer',
                    chartType === 'bar'
                      ? 'bg-surface text-on-surface shadow-xs'
                      : 'text-surface-500 hover:text-on-surface'
                  )}
                  title="Stacked Bar View"
                >
                  <BarChart3 className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>
          </div>

          {/* SVG Interactive Chart Component */}
          <div className="relative pt-2">
            <div className="h-64 sm:h-72 w-full flex items-end gap-1 sm:gap-2 pb-6 pt-4 border-b border-surface-200 relative">
              {/* Background Grid Lines */}
              <div className="absolute inset-0 flex flex-col justify-between pointer-events-none pb-6 text-[10px] text-surface-400 font-mono">
                <div className="border-b border-surface-100 w-full flex justify-end pr-1">
                  <span>{formatMoney(chartData.maxVal)}</span>
                </div>
                <div className="border-b border-surface-100 w-full flex justify-end pr-1">
                  <span>{formatMoney(Math.round(chartData.maxVal * 0.5))}</span>
                </div>
                <div className="border-b border-surface-100 w-full flex justify-end pr-1">
                  <span>{formatMoney(0)}</span>
                </div>
              </div>

              {/* Data Bars / Columns */}
              {chartData.buckets.map((b, idx) => {
                const totalHeightPct = chartData.maxVal > 0 ? (b.total / chartData.maxVal) * 100 : 0;
                const isHovered = hoveredDataIndex === idx;

                return (
                  <div
                    key={idx}
                    className="flex-1 h-full flex flex-col justify-end items-center relative group cursor-pointer"
                    onMouseEnter={() => setHoveredDataIndex(idx)}
                    onMouseLeave={() => setHoveredDataIndex(null)}
                  >
                    {/* Hover Floating Tooltip */}
                    {isHovered && (
                      <div className="absolute bottom-full mb-2 z-30 p-2.5 bg-surface-900 text-surface-0 rounded-xl shadow-xl text-left pointer-events-none whitespace-nowrap min-w-[150px] border border-surface-700">
                        <div className="text-[11px] font-bold border-b border-surface-700 pb-1 mb-1.5 text-surface-300">
                          {b.fullDateLabel}
                        </div>
                        <div className="space-y-1 text-xs tabular-nums">
                          <div className="flex justify-between items-center gap-3">
                            <span className="text-blue-300 flex items-center gap-1">
                              <span className="w-2 h-2 rounded-full bg-blue-400" />
                              Website:
                            </span>
                            <span className="font-bold">{formatMoney(b.website)}</span>
                          </div>
                          <div className="flex justify-between items-center gap-3">
                            <span className="text-emerald-300 flex items-center gap-1">
                              <span className="w-2 h-2 rounded-full bg-emerald-400" />
                              POS:
                            </span>
                            <span className="font-bold">{formatMoney(b.pos)}</span>
                          </div>
                          <div className="flex justify-between items-center gap-3 pt-1 border-t border-surface-700 font-black">
                            <span className="text-surface-300">Total:</span>
                            <span>{formatMoney(b.total)}</span>
                          </div>
                        </div>
                      </div>
                    )}

                    {/* Chart Element (Bar or Column) */}
                    <div className="w-full flex flex-col justify-end items-center h-full max-w-[32px]">
                      {chartType === 'bar' ? (
                        /* Stacked Bar */
                        <div
                          className={cn(
                            'w-full rounded-t-md transition-all flex flex-col justify-end overflow-hidden',
                            isHovered ? 'ring-2 ring-[#60A5FA]' : ''
                          )}
                          style={{ height: `${Math.max(totalHeightPct, 2)}%` }}
                        >
                          <div
                            className="bg-[#071A31] w-full transition-all"
                            style={{ height: b.total > 0 ? `${(b.website / b.total) * 100}%` : '0%' }}
                          />
                          <div
                            className="bg-[#60A5FA] w-full transition-all"
                            style={{ height: b.total > 0 ? `${(b.pos / b.total) * 100}%` : '0%' }}
                          />
                        </div>
                      ) : (
                        /* Modern Rounded Pillar Line */
                        <div
                          className={cn(
                            'w-1.5 sm:w-2 rounded-full transition-all',
                            b.total > 0
                              ? isHovered
                                ? 'bg-primary w-2.5'
                                : 'bg-surface-800'
                              : 'bg-surface-200'
                          )}
                          style={{ height: `${Math.max(totalHeightPct, 3)}%` }}
                        />
                      )}
                    </div>

                    {/* X-Axis Label */}
                    <span
                      className={cn(
                        'absolute top-full mt-1.5 text-[10px] truncate max-w-full font-medium transition-colors',
                        isHovered ? 'text-on-surface font-bold' : 'text-surface-400'
                      )}
                    >
                      {b.label}
                    </span>
                  </div>
                );
              })}
            </div>
          </div>
        </div>

        {/* =========================================================================
            4. SECONDARY ROW: SALES BY CHANNEL & PAYMENT METHOD BREAKDOWN
            ========================================================================= */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-5">
          {/* Card A: CHANNEL BREAKDOWN (Website vs POS) */}
          <div className="m3-card-outlined rounded-2xl p-5 bg-surface space-y-4">
            <div>
              <h3 className="text-sm font-bold text-on-surface tracking-tight">
                Sales by Channel
              </h3>
              <p className="text-xs text-surface-500 mt-0.5">
                Revenue distribution between online e-commerce and in-store till.
              </p>
            </div>

            {/* Visual Bar Comparison */}
            <div className="space-y-3 pt-1">
              <div className="w-full h-3.5 rounded-full bg-surface-container-high flex overflow-hidden p-0.5 border border-outline-variant">
                <div
                  className="bg-[#071A31] h-full rounded-l-full transition-all duration-500"
                  style={{ width: `${metrics.websiteSalesPct}%` }}
                />
                <div
                  className="bg-[#60A5FA] h-full rounded-r-full transition-all duration-500"
                  style={{ width: `${metrics.posSalesPct}%` }}
                />
              </div>

              {/* Channel Stats Tiles */}
              <div className="grid grid-cols-2 gap-3 pt-1">
                {/* Website tile (Navy) */}
                <div className="p-3.5 bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl space-y-1">
                  <div className="flex items-center gap-1.5 text-xs font-bold text-[#071A31] dark:text-slate-100">
                    <Globe className="w-3.5 h-3.5 text-[#071A31] dark:text-slate-300" />
                    <span>Website Store (Navy)</span>
                  </div>
                  <div className="text-base font-black text-[#071A31] dark:text-slate-100 tabular-nums">
                    {formatMoney(metrics.websiteSales)}
                  </div>
                  <div className="flex justify-between text-[11px] text-slate-500 dark:text-slate-400 font-medium">
                    <span>{metrics.websiteSalesPct}% share</span>
                    <span>{metrics.websiteOrdersCount} orders</span>
                  </div>
                </div>

                {/* POS tile (Light Blue) */}
                <div className="p-3.5 bg-blue-50/50 dark:bg-blue-950/30 border border-blue-100 dark:border-blue-900/50 rounded-xl space-y-1">
                  <div className="flex items-center gap-1.5 text-xs font-bold text-blue-900 dark:text-blue-300">
                    <Store className="w-3.5 h-3.5 text-[#60A5FA]" />
                    <span>Physical POS (Light Blue)</span>
                  </div>
                  <div className="text-base font-black text-blue-950 dark:text-blue-200 tabular-nums">
                    {formatMoney(metrics.posSales)}
                  </div>
                  <div className="flex justify-between text-[11px] text-blue-700 dark:text-blue-400 font-medium">
                    <span>{metrics.posSalesPct}% share</span>
                    <span>{metrics.posOrdersCount} orders</span>
                  </div>
                </div>
              </div>

              {/* Helpful business insight pill */}
              <div className="p-3 bg-surface-container-low border border-outline-variant rounded-xl text-xs text-surface-600 flex items-center justify-between">
                <span>
                  Leading channel:{' '}
                  <strong className="text-on-surface font-black">
                    {metrics.websiteSales >= metrics.posSales ? 'Online WooCommerce' : 'In-store Physical Till'}
                  </strong>
                </span>
                <span className="text-[11px] font-semibold text-surface-500">
                  Total orders: {metrics.completedOrdersCount}
                </span>
              </div>
            </div>
          </div>

          {/* Card B: PAYMENT METHODS REPORTING */}
          <div className="m3-card-outlined rounded-2xl p-5 bg-surface space-y-4">
            <div>
              <h3 className="text-sm font-bold text-on-surface tracking-tight">
                Payment Breakdown
              </h3>
              <p className="text-xs text-surface-500 mt-0.5">
                Exact breakdown of collection methods. Split payments are accurately allocated without duplicate sales.
              </p>
            </div>

            {/* List of Payment Methods */}
            <div className="space-y-2 pt-1">
              {paymentBreakdown.map((pm) => {
                const IconComponent = pm.icon;
                return (
                  <div
                    key={pm.key}
                    className="p-3 bg-surface border border-outline-variant rounded-xl flex items-center justify-between gap-3 text-xs hover:bg-surface-container-low transition-colors"
                  >
                    <div className="flex items-center gap-2.5 min-w-0">
                      <div className="w-7 h-7 rounded-lg bg-surface-container-high border border-outline-variant flex items-center justify-center flex-shrink-0 text-on-surface">
                        <IconComponent className="w-3.5 h-3.5" />
                      </div>
                      <div className="truncate">
                        <span className="font-bold text-on-surface block truncate">
                          {pm.label}
                        </span>
                        <span className="text-[10px] text-surface-500">
                          {pm.count} transaction{pm.count !== 1 ? 's' : ''} ({pm.percent}%)
                        </span>
                      </div>
                    </div>

                    <div className="text-right flex-shrink-0">
                      <span className="font-black text-on-surface tabular-nums block text-xs">
                        {formatMoney(pm.amount)}
                      </span>
                      {/* Mini visual fill */}
                      <div className="w-16 h-1.5 rounded-full bg-surface-container-high ml-auto mt-1 overflow-hidden">
                        <div
                          className="bg-primary h-full rounded-full"
                          style={{ width: `${pm.percent}%` }}
                        />
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        </div>

        {/* =========================================================================
            5. LOWER ROW: TOP SELLING PRODUCTS & RECENT ORDERS
            ========================================================================= */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-5">
          {/* Top Selling Products */}
          <div className="m3-card-outlined rounded-2xl p-5 bg-surface space-y-3">
            <div className="flex items-center justify-between">
              <div>
                <h3 className="text-sm font-bold text-on-surface tracking-tight">
                  Top Selling Products
                </h3>
                <p className="text-xs text-surface-500 mt-0.5">
                  Best performing items in selected timeframe.
                </p>
              </div>
              <span className="text-[11px] font-semibold text-surface-400 bg-surface-container-low px-2 py-0.5 rounded-md border border-outline-variant">
                By Revenue
              </span>
            </div>

            {topProducts.length === 0 ? (
              <div className="py-8 text-center text-xs text-surface-400">
                No product sales found for this period.
              </div>
            ) : (
              <div className="divide-y divide-surface-100">
                {topProducts.map((tp, idx) => (
                  <div key={idx} className="py-2.5 flex items-center justify-between gap-3 text-xs">
                    <div className="flex items-center gap-2.5 min-w-0">
                      <span className="w-5 h-5 rounded-full bg-surface-container-high flex items-center justify-center text-[10px] font-bold text-surface-600 flex-shrink-0">
                        {idx + 1}
                      </span>
                      <div className="min-w-0">
                        <span className="font-bold text-on-surface block truncate">
                          {tp.name}
                        </span>
                        <div className="flex items-center gap-1.5 text-[10px] text-surface-500 mt-0.5">
                          <span>{tp.unitsSold} units sold</span>
                          <span>·</span>
                          {/* Channel Badge */}
                          <span
                            className={cn(
                              'px-1.5 py-0.2 rounded font-bold uppercase text-[9px]',
                              tp.hasWebsite && tp.hasPOS
                                ? 'bg-purple-50 text-purple-700 border border-purple-200'
                                : tp.hasWebsite
                                ? 'bg-blue-50 text-blue-700 border border-blue-200'
                                : 'bg-emerald-50 text-emerald-700 border border-emerald-200'
                            )}
                          >
                            {tp.hasWebsite && tp.hasPOS ? 'Both Channels' : tp.hasWebsite ? 'Website' : 'POS'}
                          </span>
                        </div>
                      </div>
                    </div>

                    <div className="text-right flex-shrink-0 font-black text-on-surface tabular-nums">
                      {formatMoney(tp.revenue)}
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>

          {/* Recent Orders List with Channel Badges */}
          <div className="m3-card-outlined rounded-2xl p-5 bg-surface space-y-3 flex flex-col justify-between">
            <div>
              <div className="flex items-center justify-between">
                <div>
                  <h3 className="text-sm font-bold text-on-surface tracking-tight">
                    Recent Transactions
                  </h3>
                  <p className="text-xs text-surface-500 mt-0.5">
                    Live stream from both online WooCommerce and in-store POS.
                  </p>
                </div>
                <Badge variant="brand" size="sm">
                  {totalCachedOrders} cached orders
                </Badge>
              </div>

              {recentOrders.length === 0 ? (
                <div className="py-8 text-center text-xs text-surface-400">
                  No orders recorded yet.
                </div>
              ) : (
                <div className="divide-y divide-surface-100 pt-1">
                  {recentOrders.map((ord) => {
                    const isWeb = isWebsiteOrder(ord);
                    return (
                      <button
                        key={ord.id}
                        type="button"
                        onClick={() => setInspectOrderId(ord.id)}
                        className="w-full py-2.5 flex items-center justify-between gap-3 text-xs text-left hover:bg-surface-container-low -mx-2 px-2 rounded-xl transition-colors cursor-pointer"
                        title="Click to view full order details"
                      >
                        <div className="min-w-0 space-y-0.5">
                          <div className="flex items-center gap-2">
                            <span className="font-bold text-on-surface">
                              {ord.orderNumber}
                            </span>
                            {/* Channel Badge: WEBSITE vs POS */}
                            <ChannelBadge source={isWeb ? 'website' : 'pos'} />
                          </div>
                          <div className="text-[11px] text-surface-500 truncate">
                            <span>{ord.customerName || 'Walk-in Customer'}</span>
                            <span className="mx-1">·</span>
                            <span>{formatTime(ord.createdAt)}</span>
                          </div>
                        </div>

                        <div className="text-right flex-shrink-0 space-y-1">
                          <span className="font-black text-on-surface tabular-nums block">
                            {formatMoney(ord.total)}
                          </span>
                          <StatusPill status={ord.status} />
                        </div>
                      </button>
                    );
                  })}
                </div>
              )}
            </div>
          </div>
        </div>
      </div>

      {/* =========================================================================
          6. MODAL: INSPECT ORDER DETAILS (REUSING OrderDetailView)
          ========================================================================= */}
      {selectedInspectOrder && (
        <Modal
          open={true}
          onClose={() => setInspectOrderId(null)}
          title={`Order ${selectedInspectOrder.orderNumber}`}
          size="lg"
        >
          <div className="h-[600px] flex flex-col overflow-hidden -m-4">
            <OrderDetailView
              order={selectedInspectOrder}
              items={inspectOrderItems}
              onBack={() => setInspectOrderId(null)}
            />
          </div>
        </Modal>
      )}
    </div>
  );
}
