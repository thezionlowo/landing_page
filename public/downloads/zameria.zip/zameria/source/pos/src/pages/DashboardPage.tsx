import { SelectControl } from '@/components/ui/SelectControl';
import { PageHeader } from '@/components/layout/PageHeader';
import { useState, useMemo } from 'react';
import { useNavigate } from 'react-router';
import { useLiveQuery } from 'dexie-react-hooks';
import { db } from '@/db';
import { useAuthStore, useConnectionStore } from '@/store';
import { isOrderAccessibleToUser } from '@/services/auth/orderAccess';
import { useDashboardSummary } from '@/services/zameria/dashboardSummary';
import { syncScope } from '@/services/woocommerce/syncCoordinator';
import { historicalSyncService } from '@/services/woocommerce/historicalSyncService';
import { OrderDetailView } from '@/components/order/OrderDetailView';
import { StatusPill, Modal, Button, Badge, ChannelBadge, SyncButton } from '@/components/ui';
import { formatMoney, formatTime, cn } from '@/lib';
import {
  Globe,
  Store,
  Calendar,
  CreditCard,
  Wallet,
  Smartphone,
  BarChart3,
  LineChart as LineChartIcon,
  ArrowRight,
  Boxes,
  Package,
  CheckCircle2,
  AlertTriangle,
  AlertCircle,
} from 'lucide-react';
import type { Order, OrderItem } from '@/types';

type DateRangeKey =
  | 'today'
  | 'yesterday'
  | 'this_week'
  | 'last_week'
  | 'this_month'
  | 'last_month'
  | 'this_year'
  | 'last_year'
  | 'custom';

interface DateFilterBounds {
  start: Date;
  end: Date;
  prevStart: Date;
  prevEnd: Date;
  grouping: 'hour' | 'day' | 'month';
  label: string;
  prevLabel: string;
}

export function DashboardPage() {
  const navigate = useNavigate();
  const [dateRange, setDateRange] = useState<DateRangeKey>('this_month');
  const [customStartDate, setCustomStartDate] = useState(() => {
    const d = new Date();
    d.setDate(d.getDate() - 14);
    return d.toISOString().split('T')[0];
  });
  const [customEndDate, setCustomEndDate] = useState(() => {
    return new Date().toISOString().split('T')[0];
  });
  const [chartType, setChartType] = useState<'line' | 'bar'>(() => {
    try {
      const saved = localStorage.getItem('zameria_dashboard_chart_type');
      return saved === 'line' || saved === 'bar' ? saved : 'bar';
    } catch {
      return 'bar';
    }
  });

  const handleSelectChartType = (type: 'line' | 'bar') => {
    setChartType(type);
    try {
      localStorage.setItem('zameria_dashboard_chart_type', type);
    } catch {
      // Ignore storage errors
    }
  };
  const [hoveredDataIndex, setHoveredDataIndex] = useState<number | null>(null);

  // Order Details Modal
  const [inspectOrderId, setInspectOrderId] = useState<number | null>(null);


  // Date range bounds calculator using local business timezone
  const bounds: DateFilterBounds = useMemo(() => {
    const now = new Date();

    switch (dateRange) {
      case 'today': {
        const start = new Date(now.getFullYear(), now.getMonth(), now.getDate(), 0, 0, 0, 0);
        const end = new Date(now.getFullYear(), now.getMonth(), now.getDate(), 23, 59, 59, 999);
        const prevStart = new Date(start);
        prevStart.setDate(prevStart.getDate() - 1);
        const prevEnd = new Date(end);
        prevEnd.setDate(prevEnd.getDate() - 1);
        return {
          start,
          end,
          prevStart,
          prevEnd,
          grouping: 'hour',
          label: 'Today',
          prevLabel: 'Yesterday',
        };
      }
      case 'yesterday': {
        const start = new Date(now.getFullYear(), now.getMonth(), now.getDate() - 1, 0, 0, 0, 0);
        const end = new Date(now.getFullYear(), now.getMonth(), now.getDate() - 1, 23, 59, 59, 999);
        const prevStart = new Date(start);
        prevStart.setDate(prevStart.getDate() - 1);
        const prevEnd = new Date(end);
        prevEnd.setDate(prevEnd.getDate() - 1);
        return {
          start,
          end,
          prevStart,
          prevEnd,
          grouping: 'hour',
          label: 'Yesterday',
          prevLabel: '2 Days Ago',
        };
      }
      case 'this_week': {
        // Current week starting Monday
        const dayOfWeek = now.getDay() === 0 ? 6 : now.getDay() - 1;
        const start = new Date(now.getFullYear(), now.getMonth(), now.getDate() - dayOfWeek, 0, 0, 0, 0);
        const end = new Date(start);
        end.setDate(end.getDate() + 6);
        end.setHours(23, 59, 59, 999);
        const prevStart = new Date(start);
        prevStart.setDate(prevStart.getDate() - 7);
        const prevEnd = new Date(end);
        prevEnd.setDate(prevEnd.getDate() - 7);
        return {
          start,
          end,
          prevStart,
          prevEnd,
          grouping: 'day',
          label: 'This Week',
          prevLabel: 'Last Week',
        };
      }
      case 'last_week': {
        const dayOfWeek = now.getDay() === 0 ? 6 : now.getDay() - 1;
        const start = new Date(now.getFullYear(), now.getMonth(), now.getDate() - dayOfWeek - 7, 0, 0, 0, 0);
        const end = new Date(start);
        end.setDate(end.getDate() + 6);
        end.setHours(23, 59, 59, 999);
        const prevStart = new Date(start);
        prevStart.setDate(prevStart.getDate() - 7);
        const prevEnd = new Date(end);
        prevEnd.setDate(prevEnd.getDate() - 7);
        return {
          start,
          end,
          prevStart,
          prevEnd,
          grouping: 'day',
          label: 'Last Week',
          prevLabel: 'Prior Week',
        };
      }
      case 'this_month': {
        const start = new Date(now.getFullYear(), now.getMonth(), 1, 0, 0, 0, 0);
        const end = new Date(now.getFullYear(), now.getMonth() + 1, 0, 23, 59, 59, 999);
        const prevStart = new Date(now.getFullYear(), now.getMonth() - 1, 1, 0, 0, 0, 0);
        const prevEnd = new Date(now.getFullYear(), now.getMonth(), 0, 23, 59, 59, 999);
        return {
          start,
          end,
          prevStart,
          prevEnd,
          grouping: 'day',
          label: 'This Month',
          prevLabel: 'Last Month',
        };
      }
      case 'last_month': {
        const start = new Date(now.getFullYear(), now.getMonth() - 1, 1, 0, 0, 0, 0);
        const end = new Date(now.getFullYear(), now.getMonth(), 0, 23, 59, 59, 999);
        const prevStart = new Date(now.getFullYear(), now.getMonth() - 2, 1, 0, 0, 0, 0);
        const prevEnd = new Date(now.getFullYear(), now.getMonth() - 1, 0, 23, 59, 59, 999);
        return {
          start,
          end,
          prevStart,
          prevEnd,
          grouping: 'day',
          label: 'Last Month',
          prevLabel: 'Prior Month',
        };
      }
      case 'this_year': {
        const start = new Date(now.getFullYear(), 0, 1, 0, 0, 0, 0);
        const end = new Date(now.getFullYear(), 11, 31, 23, 59, 59, 999);
        const prevStart = new Date(now.getFullYear() - 1, 0, 1, 0, 0, 0, 0);
        const prevEnd = new Date(now.getFullYear() - 1, 11, 31, 23, 59, 59, 999);
        return {
          start,
          end,
          prevStart,
          prevEnd,
          grouping: 'month',
          label: 'This Year',
          prevLabel: 'Last Year',
        };
      }
      case 'last_year': {
        const start = new Date(now.getFullYear() - 1, 0, 1, 0, 0, 0, 0);
        const end = new Date(now.getFullYear() - 1, 11, 31, 23, 59, 59, 999);
        const prevStart = new Date(now.getFullYear() - 2, 0, 1, 0, 0, 0, 0);
        const prevEnd = new Date(now.getFullYear() - 2, 11, 31, 23, 59, 59, 999);
        return {
          start,
          end,
          prevStart,
          prevEnd,
          grouping: 'month',
          label: 'Last Year',
          prevLabel: 'Prior Year',
        };
      }
      case 'custom': {
        const start = new Date(`${customStartDate}T00:00:00`);
        const end = new Date(`${customEndDate}T23:59:59.999`);
        const durationMs = end.getTime() - start.getTime();
        const prevEnd = new Date(start.getTime() - 1);
        const prevStart = new Date(prevEnd.getTime() - durationMs);
        const daysSpan = durationMs / (1000 * 60 * 60 * 24);
        const grouping: 'hour' | 'day' | 'month' =
          daysSpan <= 2 ? 'hour' : daysSpan <= 60 ? 'day' : 'month';
        return {
          start,
          end,
          prevStart,
          prevEnd,
          grouping,
          label: 'Custom Range',
          prevLabel: 'Previous Period',
        };
      }
    }
  }, [dateRange, customStartDate, customEndDate]);

  // Channel classification helper
  // Live Dexie queries
  const user = useAuthStore(state=>state.user);
  const online = useConnectionStore(state=>state.isOnline);
  const scope=syncScope();
  const remote = useDashboardSummary(bounds,online);
  const pendingCount=useLiveQuery(()=>db.orders.where('syncStatus').anyOf('PENDING_SYNC','SYNC_ERROR','LOCAL_ONLY').filter(order=>isOrderAccessibleToUser(order,user)).count(),[scope]) || 0;
  const serverSummary = online && !pendingCount ? remote.summary : undefined;
  const recentOrders = useLiveQuery(()=>db.orders.orderBy('createdAt').reverse().filter(order=>isOrderAccessibleToUser(order,user)).limit(6).toArray(),[scope]) || [];
  const totalCachedOrders=useLiveQuery(()=>db.orders.filter(order=>isOrderAccessibleToUser(order,user)).count(),[scope]) || 0;
  const orders = useLiveQuery(async()=>{
    if(serverSummary)return [];
    const lower=new Date(Math.min(bounds.start.getTime(),bounds.prevStart.getTime())).toISOString();
    const upper=new Date(Math.max(bounds.end.getTime(),bounds.prevEnd.getTime())).toISOString();
    return db.orders.where('createdAt').between(lower,upper,true,true).filter(order=>isOrderAccessibleToUser(order,user)).toArray();
  },[bounds,scope,Boolean(serverSummary)]) || [];
  const products = useLiveQuery(() => db.products.toArray(), []) || [];

  // Canonical published products for inventory valuation & health metrics
  const publishedProducts = useMemo(() => {
    return products.filter((p) => !p.status || p.status === 'publish');
  }, [products]);

  // Aggregate Inventory Metrics (Single Source of Truth)
  const inventoryMetrics = useMemo(() => {
    let currentStockValue = 0;
    let inStockCount = 0;
    let lowStockCount = 0;
    let outOfStockCount = 0;

    for (const p of publishedProducts) {
      const lowThreshold = p.lowStockThreshold ?? 5;

      if (p.type === 'variable' && p.variations && p.variations.length > 0) {
        // Variable product: calculate stock value from variations without double-counting parent
        let varTotalStock = 0;
        let hasManagedVariations = false;
        let allVariationsOut = true;
        let anyVariationLow = false;

        for (const v of p.variations) {
          const vPrice = v.salePrice ?? v.price ?? p.price ?? 0;
          const vManage = v.manageStock;
          const vQty = v.stockQuantity;
          const vOut = v.stockStatus === 'outofstock' || (vManage && typeof vQty === 'number' && vQty <= 0);

          if (!vOut) {
            allVariationsOut = false;
          }

          if (vManage && typeof vQty === 'number') {
            hasManagedVariations = true;
            if (vQty > 0) {
              currentStockValue += vPrice * vQty;
              varTotalStock += vQty;
              if (vQty <= lowThreshold) {
                anyVariationLow = true;
              }
            }
          }
        }

        // Health classification for variable product
        if (p.stockStatus === 'outofstock' || allVariationsOut) {
          outOfStockCount++;
        } else if (anyVariationLow || (hasManagedVariations && varTotalStock <= lowThreshold)) {
          lowStockCount++;
        } else {
          inStockCount++;
        }
      } else {
        // Simple product
        const pPrice = p.salePrice ?? p.price ?? 0;
        const pManage = p.manageStock;
        const pQty = p.stockQuantity;
        const isOut = p.stockStatus === 'outofstock' || (pManage && typeof pQty === 'number' && pQty <= 0);

        if (isOut) {
          outOfStockCount++;
        } else if (pManage && typeof pQty === 'number' && pQty <= lowThreshold) {
          lowStockCount++;
          if (pQty > 0) {
            currentStockValue += pPrice * pQty;
          }
        } else {
          inStockCount++;
          if (pManage && typeof pQty === 'number' && pQty > 0) {
            currentStockValue += pPrice * pQty;
          }
        }
      }
    }

    const totalProducts = publishedProducts.length;

    return {
      totalProducts,
      currentStockValue,
      inStockCount,
      lowStockCount,
      outOfStockCount,
      inStockPct: totalProducts > 0 ? Math.round((inStockCount / totalProducts) * 100) : 0,
      lowStockPct: totalProducts > 0 ? Math.round((lowStockCount / totalProducts) * 100) : 0,
      outOfStockPct: totalProducts > 0 ? Math.round((outOfStockCount / totalProducts) * 100) : 0,
    };
  }, [publishedProducts]);

  // Items for selected inspect order
  const inspectOrderItems = useLiveQuery<OrderItem[]>(
    async () => {
      if (!inspectOrderId) return [];
      return db.orderItems.where('orderId').equals(inspectOrderId).toArray();
    },
    [inspectOrderId]
  ) || [];

  const selectedInspectOrder = useMemo(() => {
    if (!inspectOrderId) return null;
    return recentOrders.find((o) => o.id === inspectOrderId) || orders.find((o) => o.id === inspectOrderId) || null;
  }, [inspectOrderId, orders, recentOrders]);

  const isWebsiteOrder = (order: Order): boolean => {
    if (order.source === 'website') return true;
    if (order.source === 'pos') return false;
    return order.wooId !== null && order.shippingMethod !== 'in-store' && order.shippingMethod !== 'walk-in';
  };

  // Filter orders in range
  const {
    currentOrders,
    completedCurrentOrders,
    completedPreviousOrders,
  } = useMemo(() => {
    const startMs = bounds.start.getTime();
    const endMs = bounds.end.getTime();
    const prevStartMs = bounds.prevStart.getTime();
    const prevEndMs = bounds.prevEnd.getTime();

    const current: Order[] = [];
    const compCurrent: Order[] = [];
    const compPrev: Order[] = [];

    const isRevenueStatus = (status: string) => status === 'completed' || status === 'processing';

    for (const ord of orders) {
      const ordMs = new Date(ord.createdAt).getTime();
      if (ordMs >= startMs && ordMs <= endMs) {
        current.push(ord);
        if (isRevenueStatus(ord.status)) {
          compCurrent.push(ord);
        }
      } else if (ordMs >= prevStartMs && ordMs <= prevEndMs) {
        if (isRevenueStatus(ord.status)) {
          compPrev.push(ord);
        }
      }
    }

    return {
      currentOrders: current,
      completedCurrentOrders: compCurrent,
      completedPreviousOrders: compPrev,
    };
  }, [orders, bounds]);

  // Core metrics calculation
  const localMetrics = useMemo(() => {
    let totalSales = 0;
    let websiteSales = 0;
    let posSales = 0;
    let websiteOrdersCount = 0;
    let posOrdersCount = 0;
    let itemsSold = 0;

    for (const ord of completedCurrentOrders) {
      const value = ord.netTotal ?? ord.total;
      totalSales += value;
      itemsSold += ord.itemCount || 1;
      if (isWebsiteOrder(ord)) {
        websiteSales += value;
        websiteOrdersCount++;
      } else {
        posSales += value;
        posOrdersCount++;
      }
    }

    // Previous period sales
    let prevTotalSales = 0;
    for (const ord of completedPreviousOrders) {
      prevTotalSales += ord.netTotal ?? ord.total;
    }

    // Percentage change vs previous period
    let salesChangePct = 0;
    let salesChangeSign: 'pos' | 'neg' | 'neutral' = 'neutral';
    if (prevTotalSales > 0) {
      const diff = totalSales - prevTotalSales;
      salesChangePct = Math.round((diff / prevTotalSales) * 1000) / 10;
      salesChangeSign = diff >= 0 ? 'pos' : 'neg';
    } else if (totalSales > 0) {
      salesChangePct = 100;
      salesChangeSign = 'pos';
    }

    // Channel proportions
    const websiteSalesPct = totalSales > 0 ? Math.round((websiteSales / totalSales) * 1000) / 10 : 0;
    const posSalesPct = totalSales > 0 ? Math.round((posSales / totalSales) * 1000) / 10 : 0;

    // Total orders count in range (all statuses)
    const totalOrdersCount = currentOrders.length;
    const pendingOrdersCount = currentOrders.filter(
      (o) => o.status === 'on-hold' || o.status === 'pending'
    ).length;

    // AOV (Average Order Value)
    const aov = completedCurrentOrders.length > 0 ? Math.round(totalSales / completedCurrentOrders.length) : 0;

    // Unique customers in period
    const uniqueCustomerIds = new Set<string>();
    let hasWalkIn = false;
    for (const ord of currentOrders) {
      if (ord.customerId) uniqueCustomerIds.add(`id-${ord.customerId}`);
      else if (ord.wooCustomerId) uniqueCustomerIds.add(`woo-${ord.wooCustomerId}`);
      else if (ord.customerEmail && ord.customerEmail.trim()) uniqueCustomerIds.add(`email-${ord.customerEmail.trim().toLowerCase()}`);
      else hasWalkIn = true;
    }
    const uniqueCustomersCount = uniqueCustomerIds.size + (hasWalkIn ? 1 : 0);

    return {
      totalSales,
      websiteSales,
      posSales,
      websiteSalesPct,
      posSalesPct,
      websiteOrdersCount,
      posOrdersCount,
      completedOrdersCount: completedCurrentOrders.length,
      totalOrdersCount,
      pendingOrdersCount,
      itemsSold,
      aov,
      uniqueCustomersCount,
      salesChangePct: Math.abs(salesChangePct),
      salesChangeSign,
      prevTotalSales,
    };
  }, [completedCurrentOrders, completedPreviousOrders, currentOrders]);

  const metrics = serverSummary?.metrics || localMetrics;

  // Payment Methods Breakdown (Physical POS collection methods)
  const paymentBreakdown = useMemo(() => {
    const buckets: Record<string, { label: string; amount: number; count: number; icon: any }> = {
      cash: { label: 'Cash', amount: 0, count: 0, icon: Wallet },
      pos: { label: 'POS Terminal / Card', amount: 0, count: 0, icon: CreditCard },
      transfer: { label: 'Bank Transfer', amount: 0, count: 0, icon: Smartphone },
    };

    for (const ord of completedCurrentOrders) {
      if (ord.paymentSplits && ord.paymentSplits.length > 0) {
        // Attributed strictly according to each split's method and amount
        for (const split of ord.paymentSplits) {
          const m = (split.method || '').toLowerCase();
          const key = (m === 'cash' || m === 'cod') ? 'cash'
            : (m === 'transfer' || m === 'bacs' || m === 'bank_transfer') ? 'transfer'
            : (m === 'pos' || m === 'card' || m === 'terminal') ? 'pos'
            : null;
          if (key && buckets[key]) {
            buckets[key].amount += Math.round(split.amount * (ord.total > 0 ? (ord.netTotal ?? ord.total) / ord.total : 0));
            buckets[key].count++;
          }
        }
      } else {
        const m = (ord.paymentMethod || '').toLowerCase();
        let key: string | null = null;
        if (m === 'cash' || m === 'cod') key = 'cash';
        else if (m === 'transfer' || m === 'bacs' || m === 'bank_transfer') key = 'transfer';
        else if (m === 'pos' || m === 'card' || m === 'terminal') key = 'pos';
        else if (!isWebsiteOrder(ord)) key = 'pos';

        if (key && buckets[key]) {
          buckets[key].amount += ord.netTotal ?? ord.total;
          buckets[key].count++;
        }
      }
    }

    if(serverSummary) for(const [key,bucket] of Object.entries(buckets)){const remotePayment=serverSummary.payments[key];bucket.amount=remotePayment?.amount||0;bucket.count=remotePayment?.count||0;}
    const totalCollected = Object.values(buckets).reduce((sum, b) => sum + b.amount, 0);

    return Object.entries(buckets).map(([key, data]) => ({
      key,
      label: data.label,
      amount: data.amount,
      count: data.count,
      percent: totalCollected > 0 ? Math.round((data.amount / totalCollected) * 1000) / 10 : 0,
      icon: data.icon,
    }));
  }, [completedCurrentOrders,serverSummary]);

  // Every order in the selected period contributes; bounded indexed batches avoid a huge anyOf request.
  const periodOrderIdsKey = useMemo(() => {
    return completedCurrentOrders.map((o) => o.id).join(',');
  }, [completedCurrentOrders]);

  const periodOrderItems = useLiveQuery<OrderItem[]>(
    async () => {
      if (!periodOrderIdsKey) return [];
      const ids = periodOrderIdsKey.split(',').map(Number).filter(Boolean);
      const items: OrderItem[]=[];
      for(let n=0;n<ids.length;n+=100) items.push(...await db.orderItems.where('orderId').anyOf(ids.slice(n,n+100)).toArray());
      return items;
    },
    [periodOrderIdsKey]
  ) || [];

  // Top Selling Products in period
  const topProducts = useMemo(() => {
    if(serverSummary)return serverSummary.topProducts;
    const completedOrderIds = new Set(completedCurrentOrders.map((o) => o.id));
    const completedOrderMap = new Map(completedCurrentOrders.map((o) => [o.id, o]));

    const productMap = new Map<
      string,
      {
        name: string;
        sku: string;
        unitsSold: number;
        revenue: number;
        hasWebsite: boolean;
        hasPOS: boolean;
      }
    >();

    for (const item of periodOrderItems) {
      if (!completedOrderIds.has(item.orderId)) continue;
      const order = completedOrderMap.get(item.orderId);
      const isWeb = order ? isWebsiteOrder(order) : false;

      const key = item.productId > 0 ? String(item.productId) : item.name;
      const existing = productMap.get(key);

      if (existing) {
        existing.unitsSold += item.quantity;
        existing.revenue += item.total;
        if (isWeb) existing.hasWebsite = true;
        else existing.hasPOS = true;
      } else {
        productMap.set(key, {
          name: item.name,
          sku: item.sku || 'N/A',
          unitsSold: item.quantity,
          revenue: item.total,
          hasWebsite: isWeb,
          hasPOS: !isWeb,
        });
      }
    }

    return Array.from(productMap.values())
      .sort((a, b) => b.revenue - a.revenue)
      .slice(0, 6);
  }, [completedCurrentOrders, periodOrderItems,serverSummary]);

  // Primary Sales Chart Data Series
  const chartData = useMemo(() => {
    const { start, end, grouping } = bounds;

    interface Bucket {
      label: string;
      fullDateLabel: string;
      website: number;
      pos: number;
      total: number;
    }

    const buckets: Bucket[] = [];

    if (grouping === 'hour') {
      // 24 hourly buckets: 00:00 to 23:00
      for (let h = 0; h < 24; h++) {
        const label = `${h.toString().padStart(2, '0')}:00`;
        buckets.push({
          label,
          fullDateLabel: `${label} - ${h}:59`,
          website: 0,
          pos: 0,
          total: 0,
        });
      }
      for (const ord of completedCurrentOrders) {
        const d = new Date(ord.createdAt);
        const h = d.getHours();
        if (h >= 0 && h < 24) {
          if (isWebsiteOrder(ord)) {
            buckets[h].website += ord.netTotal ?? ord.total;
          } else {
            buckets[h].pos += ord.netTotal ?? ord.total;
          }
          buckets[h].total += ord.netTotal ?? ord.total;
        }
      }
    } else if (grouping === 'day') {
      // Daily buckets spanning the range
      const cur = new Date(start);
      while (cur <= end) {
        const dayLabel = cur.toLocaleDateString('en-GB', { day: 'numeric', month: 'short' });
        buckets.push({
          label: dayLabel,
          fullDateLabel: cur.toLocaleDateString('en-GB', { weekday: 'short', day: 'numeric', month: 'long', year: 'numeric' }),
          website: 0,
          pos: 0,
          total: 0,
        });
        cur.setDate(cur.getDate() + 1);
      }
      for (const ord of completedCurrentOrders) {
        const ordDate = new Date(ord.createdAt);
        const diffDays = Math.floor((ordDate.getTime() - start.getTime()) / (1000 * 60 * 60 * 24));
        if (diffDays >= 0 && diffDays < buckets.length) {
          if (isWebsiteOrder(ord)) {
            buckets[diffDays].website += ord.netTotal ?? ord.total;
          } else {
            buckets[diffDays].pos += ord.netTotal ?? ord.total;
          }
          buckets[diffDays].total += ord.netTotal ?? ord.total;
        }
      }
    } else {
      // Monthly buckets (Jan - Dec)
      const months = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
      for (let m = 0; m < 12; m++) {
        buckets.push({
          label: months[m],
          fullDateLabel: `${months[m]} ${start.getFullYear()}`,
          website: 0,
          pos: 0,
          total: 0,
        });
      }
      for (const ord of completedCurrentOrders) {
        const ordDate = new Date(ord.createdAt);
        const m = ordDate.getMonth();
        if (m >= 0 && m < 12) {
          if (isWebsiteOrder(ord)) {
            buckets[m].website += ord.netTotal ?? ord.total;
          } else {
            buckets[m].pos += ord.netTotal ?? ord.total;
          }
          buckets[m].total += ord.netTotal ?? ord.total;
        }
      }
    }

    if(serverSummary) for(let n=0;n<buckets.length;n++) {
      const key=grouping==='hour'?String(n).padStart(2,'0'):grouping==='month'?`${start.getFullYear()}-${String(n+1).padStart(2,'0')}`:(()=>{const date=new Date(start);date.setDate(date.getDate()+n);return `${date.getFullYear()}-${String(date.getMonth()+1).padStart(2,'0')}-${String(date.getDate()).padStart(2,'0')}`;})();
      Object.assign(buckets[n],serverSummary.series[key]||{website:0,pos:0,total:0});
    }
    const maxVal = Math.max(...buckets.map((b) => b.total), 1000);

    return {
      buckets,
      maxVal,
    };
  }, [bounds, completedCurrentOrders,serverSummary]);


  return (
    <div className="pos-dashboard h-full overflow-y-auto bg-surface-50">
      <PageHeader title="Dashboard" actions={<>
        <div className="pos-date-control"><Calendar className="w-4 h-4" /><SelectControl aria-label="Dashboard date range" value={dateRange} onChange={event=>setDateRange(event.target.value as DateRangeKey)}>
          <option value="today">Today</option><option value="yesterday">Yesterday</option><option value="this_week">This Week</option><option value="last_week">Last Week</option><option value="this_month">This Month</option><option value="last_month">Last Month</option><option value="this_year">This Year</option><option value="last_year">Last Year</option><option value="custom">Custom Range</option>
        </SelectControl></div>
        {dateRange==='custom' && <div className="pos-custom-dates"><input aria-label="Start date" type="date" value={customStartDate} onChange={event=>{const value=event.target.value;if(!value)return;setCustomStartDate(value);if(value>customEndDate)setCustomEndDate(value);}} /><span>to</span><input aria-label="End date" type="date" value={customEndDate} onChange={event=>{const value=event.target.value;if(!value)return;setCustomEndDate(value);if(value<customStartDate)setCustomStartDate(value);}} /></div>}
        <SyncButton scope="dashboard" label="Refresh" size="sm" variant="secondary" />
      </>} />
      <div className="pos-dashboard-content">
        <p role="status" className="pos-report-status">
          <span className={cn('pos-status-dot', remote.fresh && 'is-verified')} />
          {serverSummary ? `${remote.fresh ? 'Store totals verified' : 'Cached store totals; checking updates'} · ${new Date(serverSummary.verifiedAt).toLocaleString()}` : `Showing downloaded data${pendingCount ? ' including pending local sales' : ''}. ${historicalSyncService.isCompleted() ? 'History import complete.' : 'Full history is still syncing in the background.'}`}
          {remote.error && online ? ' Store totals could not refresh; retrying.' : ''}
        </p>
        <div className="pos-metrics-grid">
          <div className="pos-metric-card pos-metric-primary"><span className="pos-metric-label">Total sales</span><strong>{formatMoney(metrics.totalSales)}</strong><p>{metrics.salesChangeSign==='neg' ? '−' : metrics.salesChangeSign==='pos' ? '+' : ''}{metrics.salesChangePct}% <span>vs {bounds.prevLabel.toLowerCase()}</span></p></div>
          <div className="pos-metric-card"><span className="pos-metric-label">Orders</span><strong>{metrics.totalOrdersCount}</strong><p>{metrics.completedOrdersCount} paid <span>· {metrics.pendingOrdersCount} pending</span></p></div>
          <div className="pos-metric-card"><span className="pos-metric-label">Average sale</span><strong>{formatMoney(metrics.aov)}</strong><p><span>Per paid order</span></p></div>
          <div className="pos-metric-card"><span className="pos-metric-label">Customers</span><strong>{metrics.uniqueCustomersCount}</strong><p><span>In this period</span></p></div>
        </div>
        <section className="pos-inventory-card" aria-labelledby="inventory-title">
          <div className="pos-inventory-heading">
            <div><h2 id="inventory-title"><Boxes className="w-5 h-5" />Inventory Overview</h2><p>Catalogue valuation and stock health from your downloaded products.</p></div>
            {user?.permissions.canAccessProducts && <Button variant="ghost" size="sm" onClick={() => navigate('/products')}>View Products<ArrowRight className="w-4 h-4" /></Button>}
          </div>
          <div className="pos-inventory-layout">
            <div className="pos-inventory-valuation">
              <div className="pos-inventory-value"><span>Current stock value</span><strong>{formatMoney(inventoryMetrics.currentStockValue)}</strong><p>Retail value of available, quantity-tracked stock.</p></div>
              <div className="pos-inventory-distribution">
                <svg viewBox="0 0 120 120" role="img" aria-label={`${inventoryMetrics.totalProducts} products: ${inventoryMetrics.inStockCount} in stock, ${inventoryMetrics.lowStockCount} low stock, ${inventoryMetrics.outOfStockCount} out of stock`}>
                  <circle cx="60" cy="60" r="46" fill="none" stroke="var(--color-outline-variant)" strokeWidth="12" />
                  {[
                    { count: inventoryMetrics.inStockCount, offset: 0, color: '#10b981' },
                    { count: inventoryMetrics.lowStockCount, offset: inventoryMetrics.inStockCount, color: '#f59e0b' },
                    { count: inventoryMetrics.outOfStockCount, offset: inventoryMetrics.inStockCount + inventoryMetrics.lowStockCount, color: '#f43f5e' },
                  ].map(segment => <circle key={segment.color} cx="60" cy="60" r="46" fill="none" stroke={segment.color} strokeWidth="12" pathLength="100" strokeDasharray={`${inventoryMetrics.totalProducts ? segment.count / inventoryMetrics.totalProducts * 100 : 0} 100`} strokeDashoffset={inventoryMetrics.totalProducts ? -segment.offset / inventoryMetrics.totalProducts * 100 : 0} transform="rotate(-90 60 60)" />)}
                  <text x="60" y="53" textAnchor="middle" className="pos-inventory-ring-label">TOTAL</text><text x="60" y="73" textAnchor="middle" className="pos-inventory-ring-total">{inventoryMetrics.totalProducts}</text>
                </svg>
                <dl className="pos-inventory-legend">
                  {[{ label: 'In stock', count: inventoryMetrics.inStockCount, percent: inventoryMetrics.inStockPct, color: '#10b981' }, { label: 'Low stock', count: inventoryMetrics.lowStockCount, percent: inventoryMetrics.lowStockPct, color: '#f59e0b' }, { label: 'Out of stock', count: inventoryMetrics.outOfStockCount, percent: inventoryMetrics.outOfStockPct, color: '#f43f5e' }].map(item => <div key={item.label}><dt><i style={{background:item.color}} />{item.label}</dt><dd><strong>{item.count}</strong><span>{item.percent}%</span></dd></div>)}
                </dl>
              </div>
            </div>
            <div className="pos-inventory-health">
              <div className="pos-stock-card"><span>Total products<Package /></span><strong>{inventoryMetrics.totalProducts}</strong><p>Published catalogue items</p></div>
              <div className="pos-stock-card is-healthy"><span>In stock<CheckCircle2 /></span><strong>{inventoryMetrics.inStockCount}<small>{inventoryMetrics.inStockPct}%</small></strong><p>Healthy stock levels available</p></div>
              <div className="pos-stock-card is-low"><span>Low stock / Restock<AlertTriangle /></span><strong>{inventoryMetrics.lowStockCount}<small>{inventoryMetrics.lowStockPct}%</small></strong><p>At or below reorder threshold</p></div>
              <div className="pos-stock-card is-out"><span>Out of stock<AlertCircle /></span><strong>{inventoryMetrics.outOfStockCount}<small>{inventoryMetrics.outOfStockPct}%</small></strong><p>Unavailable inventory</p></div>
            </div>
          </div>
        </section>
        {/* =========================================================================
            3. PRIMARY SALES OVER TIME CHART (WEBSITE vs POS vs TOTAL)
            ========================================================================= */}
        <div className="m3-card-outlined rounded-2xl p-5 bg-surface space-y-4">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
            <div>
              <div className="flex items-center gap-2">
                <h3 className="text-sm font-bold text-on-surface tracking-tight">
                  Sales Trend Over Time
                </h3>
                <span className="text-xs text-surface-400 font-medium">
                  ({bounds.label} · Grouped by {bounds.grouping})
                </span>
              </div>
              <p className="text-xs text-surface-500 mt-0.5">
                Website and in-store sales for the selected period.
              </p>
            </div>

            {/* Legend & Chart View Toggle */}
            <div className="flex items-center gap-4 flex-wrap">
              <div className="flex items-center gap-3 text-xs font-semibold">
                <div className="flex items-center gap-1.5">
                  <span className="w-2.5 h-2.5 rounded-full bg-[#071A31]" />
                  <span className="text-surface-700 font-semibold">Website</span>
                </div>
                <div className="flex items-center gap-1.5">
                  <span className="w-2.5 h-2.5 rounded-full bg-[#60A5FA]" />
                  <span className="text-surface-700 font-semibold">In-store</span>
                </div>
                <div className="flex items-center gap-1.5">
                  <span className="w-2.5 h-2.5 rounded-full bg-surface-800" />
                  <span className="text-surface-700">Combined Total</span>
                </div>
              </div>

              {/* Toggle Line / Bar */}
              <div className="flex items-center bg-surface-container-lowest p-0.5 rounded-lg border border-outline-variant">
                <button
                  type="button"
                  onClick={() => handleSelectChartType('line')}
                  className={cn(
                    'min-h-10 min-w-10 flex items-center justify-center rounded-md text-xs font-semibold transition-colors cursor-pointer',
                    chartType === 'line'
                      ? 'bg-surface text-on-surface shadow-xs'
                      : 'text-surface-500 hover:text-on-surface'
                  )}
                  title="Column view" aria-label="Column view" aria-pressed={chartType === 'line'}
                >
                  <LineChartIcon className="w-3.5 h-3.5" />
                </button>
                <button
                  type="button"
                  onClick={() => handleSelectChartType('bar')}
                  className={cn(
                    'min-h-10 min-w-10 flex items-center justify-center rounded-md text-xs font-semibold transition-colors cursor-pointer',
                    chartType === 'bar'
                      ? 'bg-surface text-on-surface shadow-xs'
                      : 'text-surface-500 hover:text-on-surface'
                  )}
                  title="Stacked bar view" aria-label="Stacked bar view" aria-pressed={chartType === 'bar'}
                >
                  <BarChart3 className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>
          </div>

          {/* SVG Interactive Chart Component */}
          <div className="relative pt-2">
            <div className="pos-sales-chart w-full flex items-end gap-1 sm:gap-2 pb-6 pt-4 border-b border-surface-200 relative">
              {/* Background Grid Lines */}
              <div className="absolute inset-0 flex flex-col justify-between pointer-events-none pb-6 text-xs text-surface-400 font-mono">
                <div className="border-b border-surface-100 w-full flex justify-end pr-1">
                  <span>{formatMoney(chartData.maxVal)}</span>
                </div>
                <div className="border-b border-surface-100 w-full flex justify-end pr-1">
                  <span>{formatMoney(Math.round(chartData.maxVal * 0.5))}</span>
                </div>
                <div className="border-b border-surface-100 w-full flex justify-end pr-1">
                  <span>{formatMoney(0)}</span>
                </div>
              </div>

              {/* Data Bars / Columns */}
              {chartData.buckets.map((b, idx) => {
                const totalHeightPct = chartData.maxVal > 0 ? (b.total / chartData.maxVal) * 100 : 0;
                const isHovered = hoveredDataIndex === idx;

                return (
                  <div
                    key={idx}
                    className="flex-1 h-full flex flex-col justify-end items-center relative group cursor-pointer"
                    tabIndex={0}
                    role="img"
                    aria-label={`${b.fullDateLabel}: website ${formatMoney(b.website)}, in-store ${formatMoney(b.pos)}, total ${formatMoney(b.total)}`}
                    onFocus={() => setHoveredDataIndex(idx)}
                    onBlur={() => setHoveredDataIndex(null)}
                    onMouseEnter={() => setHoveredDataIndex(idx)}
                    onMouseLeave={() => setHoveredDataIndex(null)}
                  >
                    {/* Hover Floating Tooltip */}
                    {isHovered && (
                      <div className="absolute bottom-full mb-2 z-30 p-2.5 bg-surface-900 text-surface-0 rounded-xl shadow-xl text-left pointer-events-none whitespace-nowrap min-w-[150px] border border-surface-700">
                        <div className="text-xs font-bold border-b border-surface-700 pb-1 mb-1.5 text-surface-300">
                          {b.fullDateLabel}
                        </div>
                        <div className="space-y-1 text-xs tabular-nums">
                          <div className="flex justify-between items-center gap-3">
                            <span className="text-blue-300 flex items-center gap-1">
                              <span className="w-2 h-2 rounded-full bg-blue-400" />
                              Website:
                            </span>
                            <span className="font-bold">{formatMoney(b.website)}</span>
                          </div>
                          <div className="flex justify-between items-center gap-3">
                            <span className="text-emerald-300 flex items-center gap-1">
                              <span className="w-2 h-2 rounded-full bg-emerald-400" />
                              POS:
                            </span>
                            <span className="font-bold">{formatMoney(b.pos)}</span>
                          </div>
                          <div className="flex justify-between items-center gap-3 pt-1 border-t border-surface-700 font-semibold">
                            <span className="text-surface-300">Total:</span>
                            <span>{formatMoney(b.total)}</span>
                          </div>
                        </div>
                      </div>
                    )}

                    {/* Chart Element (Bar or Column) */}
                    <div className="absolute inset-0 mx-auto w-full flex flex-col justify-end items-center max-w-[32px]">
                      {chartType === 'bar' ? (
                        /* Stacked Bar */
                        <div
                          className={cn(
                            'w-full rounded-t-md transition-all flex flex-col justify-end overflow-hidden',
                            isHovered ? 'ring-2 ring-[#60A5FA]' : ''
                          )}
                          style={{ height: `${Math.max(totalHeightPct, 2)}%` }}
                        >
                          <div
                            className="bg-[#071A31] w-full transition-all"
                            style={{ height: b.total > 0 ? `${(b.website / b.total) * 100}%` : '0%' }}
                          />
                          <div
                            className="bg-[#60A5FA] w-full transition-all"
                            style={{ height: b.total > 0 ? `${(b.pos / b.total) * 100}%` : '0%' }}
                          />
                        </div>
                      ) : (
                        /* Modern Rounded Pillar Line */
                        <div
                          className={cn(
                            'w-1.5 sm:w-2 rounded-full transition-all',
                            b.total > 0
                              ? isHovered
                                ? 'bg-primary w-2.5'
                                : 'bg-surface-800'
                              : 'bg-surface-200'
                          )}
                          style={{ height: `${Math.max(totalHeightPct, 3)}%` }}
                        />
                      )}
                    </div>

                    {/* X-Axis Label */}
                    <span
                      className={cn(
                        'absolute top-full mt-1.5 text-xs whitespace-nowrap font-medium transition-colors',
                        isHovered ? 'text-on-surface font-bold' : 'text-surface-400'
                      )}
                    >
                      {idx % Math.ceil(chartData.buckets.length / 5) === 0 || idx === chartData.buckets.length - 1 ? b.label : ''}
                    </span>
                  </div>
                );
              })}
            </div>
          </div>
        </div>

        {/* =========================================================================
            4. SECONDARY ROW: SALES BY CHANNEL & PAYMENT METHOD BREAKDOWN
            ========================================================================= */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-5">
          {/* Card A: CHANNEL BREAKDOWN (Website vs POS) */}
          <div className="m3-card-outlined rounded-2xl p-5 bg-surface space-y-4">
            <div>
              <h3 className="text-sm font-bold text-on-surface tracking-tight">
                Sales by Channel
              </h3>
              <p className="text-xs text-surface-500 mt-0.5">
                Revenue distribution between online e-commerce and in-store till.
              </p>
            </div>

            {/* Visual Bar Comparison */}
            <div className="space-y-3 pt-1">
              <div className="w-full h-3.5 rounded-full bg-surface-container-high flex overflow-hidden p-0.5 border border-outline-variant">
                <div
                  className="bg-[#071A31] h-full rounded-l-full transition-all duration-500"
                  style={{ width: `${metrics.websiteSalesPct}%` }}
                />
                <div
                  className="bg-[#60A5FA] h-full rounded-r-full transition-all duration-500"
                  style={{ width: `${metrics.posSalesPct}%` }}
                />
              </div>

              {/* Channel Stats Tiles */}
              <div className="grid grid-cols-2 gap-3 pt-1">
                {/* Website tile (Navy) */}
                <div className="p-3.5 bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl space-y-1">
                  <div className="flex items-center gap-1.5 text-xs font-bold text-[#071A31] dark:text-slate-100">
                    <Globe className="w-3.5 h-3.5 text-[#071A31] dark:text-slate-300" />
                    <span>Website</span>
                  </div>
                  <div className="text-base font-semibold text-[#071A31] dark:text-slate-100 tabular-nums">
                    {formatMoney(metrics.websiteSales)}
                  </div>
                  <div className="flex justify-between text-xs text-slate-500 dark:text-slate-400 font-medium">
                    <span>{metrics.websiteSalesPct}% share</span>
                    <span>{metrics.websiteOrdersCount} orders</span>
                  </div>
                </div>

                {/* POS tile (Light Blue) */}
                <div className="p-3.5 bg-blue-50/50 dark:bg-blue-950/30 border border-blue-100 dark:border-blue-900/50 rounded-xl space-y-1">
                  <div className="flex items-center gap-1.5 text-xs font-bold text-blue-900 dark:text-blue-300">
                    <Store className="w-3.5 h-3.5 text-[#60A5FA]" />
                    <span>In-store</span>
                  </div>
                  <div className="text-base font-semibold text-blue-950 dark:text-blue-200 tabular-nums">
                    {formatMoney(metrics.posSales)}
                  </div>
                  <div className="flex justify-between text-xs text-blue-700 dark:text-blue-400 font-medium">
                    <span>{metrics.posSalesPct}% share</span>
                    <span>{metrics.posOrdersCount} orders</span>
                  </div>
                </div>
              </div>

              {/* Helpful business insight pill */}
              <div className="p-3 bg-surface-container-low border border-outline-variant rounded-xl text-xs text-surface-600 flex items-center justify-between">
                <span>
                  Leading channel:{' '}
                  <strong className="text-on-surface font-semibold">
                    {metrics.websiteSales >= metrics.posSales ? 'Online WooCommerce' : 'In-store Physical Till'}
                  </strong>
                </span>
                <span className="text-xs font-semibold text-surface-500">
                  Total orders: {metrics.completedOrdersCount}
                </span>
              </div>
            </div>
          </div>

          {/* Card B: PAYMENT METHODS REPORTING */}
          <div className="m3-card-outlined rounded-2xl p-5 bg-surface space-y-4">
            <div>
              <h3 className="text-sm font-bold text-on-surface tracking-tight">
                Payment Breakdown
              </h3>
              <p className="text-xs text-surface-500 mt-0.5">
                Exact breakdown of collection methods. Split payments are accurately allocated without duplicate sales.
              </p>
            </div>

            {/* List of Payment Methods */}
            <div className="space-y-2 pt-1">
              {paymentBreakdown.map((pm) => {
                const IconComponent = pm.icon;
                return (
                  <div
                    key={pm.key}
                    className="p-3 bg-surface border border-outline-variant rounded-xl flex items-center justify-between gap-3 text-xs hover:bg-surface-container-low transition-colors"
                  >
                    <div className="flex items-center gap-2.5 min-w-0">
                      <div className="w-7 h-7 rounded-lg bg-surface-container-high border border-outline-variant flex items-center justify-center flex-shrink-0 text-on-surface">
                        <IconComponent className="w-3.5 h-3.5" />
                      </div>
                      <div className="truncate">
                        <span className="font-bold text-on-surface block truncate">
                          {pm.label}
                        </span>
                        <span className="text-xs text-surface-500">
                          {pm.count} transaction{pm.count !== 1 ? 's' : ''} ({pm.percent}%)
                        </span>
                      </div>
                    </div>

                    <div className="text-right flex-shrink-0">
                      <span className="font-semibold text-on-surface tabular-nums block text-xs">
                        {formatMoney(pm.amount)}
                      </span>
                      {/* Mini visual fill */}
                      <div className="w-16 h-1.5 rounded-full bg-surface-container-high ml-auto mt-1 overflow-hidden">
                        <div
                          className="bg-primary h-full rounded-full"
                          style={{ width: `${pm.percent}%` }}
                        />
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        </div>

        {/* =========================================================================
            5. LOWER ROW: TOP SELLING PRODUCTS & RECENT ORDERS
            ========================================================================= */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-5">
          {/* Top Selling Products */}
          <div className="m3-card-outlined rounded-2xl p-5 bg-surface space-y-3">
            <div className="flex items-center justify-between">
              <div>
                <h3 className="text-sm font-bold text-on-surface tracking-tight">
                  Top Selling Products
                </h3>
                <p className="text-xs text-surface-500 mt-0.5">
                  Best performing items in selected timeframe.
                </p>
              </div>
              <span className="text-xs font-semibold text-surface-400 bg-surface-container-low px-2 py-0.5 rounded-md border border-outline-variant">
                By Revenue
              </span>
            </div>

            {topProducts.length === 0 ? (
              <div className="py-8 text-center text-xs text-surface-400">
                No product sales found for this period.
              </div>
            ) : (
              <div className="divide-y divide-surface-100">
                {topProducts.map((tp, idx) => (
                  <div key={idx} className="py-2.5 flex items-center justify-between gap-3 text-xs">
                    <div className="flex items-center gap-2.5 min-w-0">
                      <span className="w-5 h-5 rounded-full bg-surface-container-high flex items-center justify-center text-xs font-bold text-surface-600 flex-shrink-0">
                        {idx + 1}
                      </span>
                      <div className="min-w-0">
                        <span className="font-bold text-on-surface block truncate">
                          {tp.name}
                        </span>
                        <div className="flex items-center gap-1.5 text-xs text-surface-500 mt-0.5">
                          <span>{tp.unitsSold} units sold</span>
                          <span>·</span>
                          {/* Channel Badge */}
                          <span
                            className={cn(
                              'px-1.5 py-0.2 rounded font-bold uppercase text-[9px]',
                              tp.hasWebsite && tp.hasPOS
                                ? 'bg-purple-50 text-purple-700 border border-purple-200'
                                : tp.hasWebsite
                                ? 'bg-blue-50 text-blue-700 border border-blue-200'
                                : 'bg-emerald-50 text-emerald-700 border border-emerald-200'
                            )}
                          >
                            {tp.hasWebsite && tp.hasPOS ? 'Both Channels' : tp.hasWebsite ? 'Website' : 'POS'}
                          </span>
                        </div>
                      </div>
                    </div>

                    <div className="text-right flex-shrink-0 font-semibold text-on-surface tabular-nums">
                      {formatMoney(tp.revenue)}
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>

          {/* Recent Orders List with Channel Badges */}
          <div className="m3-card-outlined rounded-2xl p-5 bg-surface space-y-3 flex flex-col justify-between">
            <div>
              <div className="flex items-center justify-between">
                <div>
                  <h3 className="text-sm font-bold text-on-surface tracking-tight">
                    Recent Transactions
                  </h3>
                  <p className="text-xs text-surface-500 mt-0.5">
                    The newest downloaded orders across your store.
                  </p>
                </div>
                <Badge variant="brand" size="sm">
                  {totalCachedOrders} cached orders
                </Badge>
              </div>

              {recentOrders.length === 0 ? (
                <div className="py-8 text-center text-xs text-surface-400">
                  No orders recorded yet.
                </div>
              ) : (
                <div className="divide-y divide-surface-100 pt-1">
                  {recentOrders.map((ord) => {
                    const isWeb = isWebsiteOrder(ord);
                    return (
                      <button
                        key={ord.id}
                        type="button"
                        onClick={() => setInspectOrderId(ord.id)}
                        className="w-full py-2.5 flex items-center justify-between gap-3 text-xs text-left hover:bg-surface-container-low -mx-2 px-2 rounded-xl transition-colors cursor-pointer"
                        title="Click to view full order details"
                      >
                        <div className="min-w-0 space-y-0.5">
                          <div className="flex items-center gap-2">
                            <span className="font-bold text-on-surface">
                              {ord.orderNumber}
                            </span>
                            {/* Channel Badge: WEBSITE vs POS */}
                            <ChannelBadge source={isWeb ? 'website' : 'pos'} />
                          </div>
                          <div className="text-xs text-surface-500 truncate">
                            <span>{ord.customerName || 'Walk-in Customer'}</span>
                            <span className="mx-1">·</span>
                            <span>{formatTime(ord.createdAt)}</span>
                          </div>
                        </div>

                        <div className="text-right flex-shrink-0 space-y-1">
                          <span className="font-semibold text-on-surface tabular-nums block">
                            {formatMoney(ord.total)}
                          </span>
                          <StatusPill status={ord.status} />
                        </div>
                      </button>
                    );
                  })}
                </div>
              )}
            </div>
          </div>
        </div>



      </div>
      {/* =========================================================================
          6. MODAL: INSPECT ORDER DETAILS (REUSING OrderDetailView)
          ========================================================================= */}
      {selectedInspectOrder && (
        <Modal
          open={true}
          onClose={() => setInspectOrderId(null)}
          title={`Order ${selectedInspectOrder.orderNumber}`}
          size="lg"
        >
          <div className="h-[min(65dvh,600px)] flex flex-col overflow-hidden -m-4">
            <OrderDetailView
              order={selectedInspectOrder}
              items={inspectOrderItems}
              onBack={() => setInspectOrderId(null)}
            />
          </div>
        </Modal>
      )}
    </div>
  );
}
