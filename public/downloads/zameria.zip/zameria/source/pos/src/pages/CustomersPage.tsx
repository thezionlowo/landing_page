import { useState, useMemo, useEffect } from 'react';
import { useLiveQuery } from 'dexie-react-hooks';
import { db, getSetting } from '@/db';
import {
  SearchInput,
  Button,
  Input,
  EmptyState,
  SkeletonRow,
  Drawer,
  StatusPill,
  ChannelBadge,
  ReceiptModal,
  ResizableSplitView,
  SyncButton,
} from '@/components/ui';
import { queryCustomerDirectory, ordersForCustomer } from '@/services/woocommerce/customerProjection';
import { syncScope } from '@/services/woocommerce/syncCoordinator';
import { historicalSyncService } from '@/services/woocommerce/historicalSyncService';
import { OrderDetailView } from '@/components/order/OrderDetailView';
import { useConnectionStore, useAuthStore } from '@/store';
import { createCustomer, updateCustomer, syncAllCustomers, syncOrdersForCustomer } from '@/services/woocommerce';
import { toast } from 'sonner';
import { formatMoney, cn, useResponsive, useStoreCurrency, decodeHtmlEntities } from '@/lib';
import {
  Users,
  UserPlus,
  User,
  Mail,
  ChevronRight,
  Phone,
  Building,
  MapPin,
  Clock,
  Edit2,
  Filter,
  X,
  ArrowLeft,
  RefreshCw,
} from 'lucide-react';
import type { Customer, OrderItem } from '@/types';

export type CustomerSortOption =
  | 'default'
  | 'spent_desc'
  | 'spent_asc'
  | 'orders_desc'
  | 'orders_asc'
  | 'recent_purchase'
  | 'newest'
  | 'alpha_asc'
  | 'alpha_desc';

export type CustomerSegmentFilter =
  | 'all'
  | 'high_value'
  | 'regular'
  | 'one_time'
  | 'recent'
  | 'inactive';

export function CustomersPage() {
  const [search, setSearch] = useState('');
  const [selectedCustomerId, setSelectedCustomerId] = useState<number | null>(null);
  const [viewingOrderId, setViewingOrderId] = useState<number | null>(null);
  const [showCreateDrawer, setShowCreateDrawer] = useState(false);
  const [showEditDrawer, setShowEditDrawer] = useState(false);
  const [showReceiptModal, setShowReceiptModal] = useState(false);
  const { isOnline } = useConnectionStore();
  const user = useAuthStore(s => s.user);
  const { isMobile } = useResponsive();
  const currency = useStoreCurrency();

  // Filter & Sort State
  const [sortBy, setSortBy] = useState<CustomerSortOption>('default');
  const [segmentFilter, setSegmentFilter] = useState<CustomerSegmentFilter>('all');
  const [showFilters, setShowFilters] = useState(false);

  // Create Form state
  const [firstName, setFirstName] = useState('');
  const [lastName, setLastName] = useState('');
  const [email, setEmail] = useState('');
  const [phone, setPhone] = useState('');
  const [company, setCompany] = useState('');
  const [country, setCountry] = useState('NG');
  const [state, setState] = useState('LA');
  const [address1, setAddress1] = useState('');
  const [address2, setAddress2] = useState('');
  const [city, setCity] = useState('');
  const [postcode, setPostcode] = useState('');
  const [formErrors, setFormErrors] = useState<Record<string, string>>({});
  const [isSubmitting, setIsSubmitting] = useState(false);

  // Edit Form state
  const [editFirstName, setEditFirstName] = useState('');
  const [editLastName, setEditLastName] = useState('');
  const [editEmail, setEditEmail] = useState('');
  const [editPhone, setEditPhone] = useState('');
  const [editCompany, setEditCompany] = useState('');
  const [editCountry, setEditCountry] = useState('NG');
  const [editState, setEditState] = useState('LA');
  const [editAddress1, setEditAddress1] = useState('');
  const [editAddress2, setEditAddress2] = useState('');
  const [editCity, setEditCity] = useState('');
  const [editPostcode, setEditPostcode] = useState('');
  const [editFormErrors, setEditFormErrors] = useState<Record<string, string>>({});
  const [isEditingSubmitting, setIsEditingSubmitting] = useState(false);

  // Progressive rendering state for customer directory
  const [visibleCustomersCount, setVisibleCustomersCount] = useState(60);

  const scope = syncScope();
  const directory = useLiveQuery(() => queryCustomerDirectory(scope, { sort:sortBy, segment:segmentFilter, search, limit:visibleCustomersCount+1 }), [scope,sortBy,segmentFilter,search,visibleCustomersCount]);
  const customers = directory?.map(r=>r.customer);
  const customerStatsMap = new Map((directory || []).map(r=>[r.customerId,r.stats]));
  const projectionReady = useLiveQuery(()=>getSetting(`customer_projection_ready:${scope}`),[scope]);
  const totalPurchasers = useLiveQuery(() => db.customerSummaries.where('[scope+purchaseCount]').between([scope,1],[scope,Infinity],true,true).count(),[scope]) || 0;
  const selectedCustomer = useLiveQuery(() => selectedCustomerId ? db.customers.get(selectedCustomerId) : undefined,[selectedCustomerId]);
  const selectedSummary = useLiveQuery(() => selectedCustomerId ? db.customerSummaries.get([scope,selectedCustomerId]) : undefined,[scope,selectedCustomerId]);
  const orders = useLiveQuery(() => selectedCustomer && user ? ordersForCustomer(selectedCustomer,user) : [],[selectedCustomer,scope]);
  // Refresh cached profiles on entry and reconnection.
  useEffect(() => {
    async function initCustomers() {
      try {
        if (isOnline) {
          void historicalSyncService.startHistoricalSync();
          const result = await syncAllCustomers({ incremental: true });
          if (result.failedCount) toast.warning('Customer sync needs a retry.', { description: result.errors.join('; ') });
        }
      } catch (err) {
        console.warn('Customer auto-init notice:', err);
      }
    }
    void initCustomers();
  }, [isOnline]);

  const viewingOrder = useMemo(
    () => orders?.find((o) => o.id === viewingOrderId) || null,
    [orders, viewingOrderId]
  );

  const viewingOrderItems = useLiveQuery<OrderItem[]>(
    async () => {
      if (!viewingOrderId) return [];
      return db.orderItems.where('orderId').equals(viewingOrderId).toArray();
    },
    [viewingOrderId]
  ) || [];

  const activeFiltersCount = (sortBy !== 'default' ? 1 : 0) + (segmentFilter !== 'all' ? 1 : 0);

  const handleClearFilters = () => {
    setSortBy('default');
    setSegmentFilter('all');
  };

  const filteredCustomers = customers || [];

  // Reset visible count on filter/search change
  useEffect(() => {
    setVisibleCustomersCount(60);
  }, [search, segmentFilter, sortBy]);

  const displayedCustomers = useMemo(() => {
    return filteredCustomers.slice(0, visibleCustomersCount);
  }, [filteredCustomers, visibleCustomersCount]);

  const [isSyncingCustomerOrders, setIsSyncingCustomerOrders] = useState(false);

  const handleSyncCustomerOrders = async (customerToSync: Customer) => {
    if (!isOnline) {
      toast.error('Device is offline. Cannot sync WooCommerce orders.');
      return;
    }
    setIsSyncingCustomerOrders(true);
    try {
      const res = await syncOrdersForCustomer(customerToSync);
      if (res.error) {
        toast.error(res.error);
      } else {
        const count = res.importedCount + res.updatedCount;
        toast.success(count > 0 ? `Synced ${count} order(s) from WooCommerce` : 'Order history is up to date');
      }
    } catch (err: any) {
      toast.error(err?.message || 'Failed to sync customer orders');
    } finally {
      setIsSyncingCustomerOrders(false);
    }
  };

  const customerOrders = orders || [];

  // Fetch all history on selection, even when WooCommerce metrics are missing or zero.
  useEffect(() => {
    if (!selectedCustomer || !isOnline) return;
    let active = true;
    setIsSyncingCustomerOrders(true);
    void syncOrdersForCustomer(selectedCustomer).then(result => {
      if (active && result.error) toast.error(result.error);
    }).catch(err => {
      if (active) toast.error(err instanceof Error ? err.message : 'Failed to sync customer orders');
    }).finally(() => {
      if (active) setIsSyncingCustomerOrders(false);
    });
    return () => { active = false; };
  }, [selectedCustomerId, isOnline]);

  const selectedStats = selectedSummary?.stats;
  const effectiveTotalOrders = selectedStats?.orderCount || 0;
  const effectiveTotalSpent = selectedStats?.totalSpent || 0;
  const customerAvgOrderValue = selectedStats?.averageOrderValue || 0;
  const customerLastOrderDate = selectedStats?.lastOrderDate || null;

  const handleOpenEdit = () => {
    if (!selectedCustomer) return;
    setEditFirstName(selectedCustomer.firstName || '');
    setEditLastName(selectedCustomer.lastName || '');
    setEditEmail(selectedCustomer.email || '');
    setEditPhone(selectedCustomer.billing?.phone || '');
    setEditCompany(selectedCustomer.billing?.company || '');
    setEditCountry(selectedCustomer.billing?.country || 'NG');
    setEditState(selectedCustomer.billing?.state || 'LA');
    setEditAddress1(selectedCustomer.billing?.address1 || '');
    setEditAddress2(selectedCustomer.billing?.address2 || '');
    setEditCity(selectedCustomer.billing?.city || '');
    setEditPostcode(selectedCustomer.billing?.postcode || '');
    setEditFormErrors({});
    setShowEditDrawer(true);
  };

  const handleSaveCustomerEdit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedCustomer) return;

    const errors: Record<string, string> = {};
    if (!editFirstName.trim()) errors.firstName = 'First name is required';
    if (!editLastName.trim()) errors.lastName = 'Last name is required';
    if (!editEmail.trim()) errors.email = 'Email is required';
    else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(editEmail)) errors.email = 'Invalid email address';

    setEditFormErrors(errors);
    if (Object.keys(errors).length > 0) return;

    setIsEditingSubmitting(true);
    try {
      const res = await updateCustomer(selectedCustomer.id, {
        firstName: editFirstName.trim(),
        lastName: editLastName.trim(),
        email: editEmail.trim(),
        phone: editPhone.trim(),
        billing: {
          address1: editAddress1.trim(),
          address2: editAddress2.trim(),
          city: editCity.trim(),
          state: editState.trim(),
          country: editCountry.trim(),
          postcode: editPostcode.trim(),
          company: editCompany.trim(),
        },
      });

      if (res.success) {
        toast.success('Customer details updated successfully');
        setShowEditDrawer(false);
      } else {
        toast.error(res.error || 'Failed to update customer');
      }
    } catch (err: any) {
      toast.error(err?.message || 'Failed to update customer');
    } finally {
      setIsEditingSubmitting(false);
    }
  };

  const handleCreateCustomer = async (e: React.FormEvent) => {
    e.preventDefault();
    const errors: Record<string, string> = {};
    if (!firstName.trim()) errors.firstName = 'First name is required';
    if (!lastName.trim()) errors.lastName = 'Last name is required';
    if (!email.trim()) errors.email = 'Email is required';
    else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) errors.email = 'Invalid email address';

    setFormErrors(errors);
    if (Object.keys(errors).length > 0) return;

    if (!isOnline) {
      toast.error('Customer creation requires an internet connection');
      return;
    }

    setIsSubmitting(true);
    try {
      const result = await createCustomer({
        firstName: firstName.trim(), lastName: lastName.trim(),
        email: email.trim(), phone: phone.trim(),
        billing: { company: company.trim(), address1: address1.trim(), address2: address2.trim(),
          city: city.trim(), state: state.trim(), postcode: postcode.trim(), country: country.trim() },
      });
      if (!result.success || !result.customer) {
        toast.error(result.error || 'Failed to create customer');
        return;
      }
      toast.success('Customer saved. They will appear here after their first purchase.');

      // Reset form
      setFirstName('');
      setLastName('');
      setEmail('');
      setPhone('');
      setCompany('');
      setAddress1('');
      setAddress2('');
      setCity('');
      setPostcode('');
      setShowCreateDrawer(false);
      setSelectedCustomerId(null);
    } catch {
      toast.error('Failed to create customer');
    } finally {
      setIsSubmitting(false);
    }
  };

  const customerListPanel = (
    <div className="w-full flex flex-col h-full bg-surface overflow-hidden border-r border-outline-variant/60">
            {/* Header Toolbar */}
            <div className="p-3.5 border-b border-outline-variant/60 space-y-2.5 bg-surface flex-shrink-0">
              <div className="flex items-center justify-between">
                <div>
                  <h1 className="text-sm font-bold text-on-surface tracking-tight">Customers</h1>
                  <p className="text-[11px] text-on-surface-variant">
                    {customers ? `${totalPurchasers} cached customers with purchases` : 'Loading purchaser history...'}
                  </p>

                </div>
                <div className="flex items-center gap-2">
                  <SyncButton
                    scope="customers"
                    label={isMobile ? 'Sync' : 'Sync Customers'}
                    size="sm"
                    variant="tonal"
                    showLastSynced={true}
                  />
                  <Button
                    size="sm"
                    variant="primary"
                    onClick={() => setShowCreateDrawer(true)}
                    icon={<UserPlus className="w-3.5 h-3.5" />}
                  >
                    New Customer
                  </Button>
                </div>
              </div>
              <div className="flex items-center gap-2">
                <div className="flex-1">
                  <SearchInput
                    value={search}
                    onChange={setSearch}
                    placeholder="Search by name, email, or city..."
                  />
                </div>
                <Button
                  type="button"
                  variant={activeFiltersCount > 0 ? 'primary' : 'secondary'}
                  size="sm"
                  onClick={() => setShowFilters(!showFilters)}
                  className="flex items-center gap-1.5 flex-shrink-0"
                  title="Filter and sort customers"
                >
                  <Filter className="w-3.5 h-3.5" />
                  <span>Filter</span>
                  {activeFiltersCount > 0 && (
                    <span className="w-4 h-4 rounded-full bg-[#60A5FA] text-[#071A31] text-[10px] font-bold flex items-center justify-center">
                      {activeFiltersCount}
                    </span>
                  )}
                </Button>
              </div>

              {/* Collapsible Business Filter Bar */}
              {showFilters && (
                <div className="p-2.5 bg-surface-container-low border border-outline-variant rounded-xl space-y-2 text-xs">
                  <div className="flex items-center justify-between">
                    <span className="font-bold text-[11px] uppercase tracking-wider text-surface-600">
                      Customer Filters & Sorting
                    </span>
                    {activeFiltersCount > 0 && (
                      <button
                        type="button"
                        onClick={handleClearFilters}
                        className="text-[11px] text-primary hover:underline font-semibold flex items-center gap-1 cursor-pointer"
                      >
                        <X className="w-3 h-3" />
                        Clear Filters
                      </button>
                    )}
                  </div>

                  <div className="grid grid-cols-2 gap-2">
                    <div>
                      <label className="text-[10px] font-semibold text-surface-500 block mb-1">
                        Sort By
                      </label>
                      <select
                        value={sortBy}
                        onChange={(e) => setSortBy(e.target.value as CustomerSortOption)}
                        className="w-full h-8 px-2 bg-surface border border-outline-variant rounded-lg text-xs font-medium text-on-surface focus:outline-none focus:border-primary"
                      >
                        <option value="default">Default</option>
                        <option value="spent_desc">Total Spent: High → Low</option>
                        <option value="spent_asc">Total Spent: Low → High</option>
                        <option value="orders_desc">Most Orders</option>
                        <option value="orders_asc">Fewest Orders</option>
                        <option value="recent_purchase">Most Recent Purchase</option>
                        <option value="newest">Newest Customers</option>
                        <option value="alpha_asc">Alphabetical: A → Z</option>
                        <option value="alpha_desc">Alphabetical: Z → A</option>
                      </select>
                    </div>

                    <div>
                      <label className="text-[10px] font-semibold text-surface-500 block mb-1">
                        Customer Tier / Activity
                      </label>
                      <select
                        value={segmentFilter}
                        onChange={(e) => setSegmentFilter(e.target.value as CustomerSegmentFilter)}
                        className="w-full h-8 px-2 bg-surface border border-outline-variant rounded-lg text-xs font-medium text-on-surface focus:outline-none focus:border-primary"
                      >
                        <option value="all">All Customers</option>
                        <option value="high_value">High-Value Spenders ({currency.symbol}50k+)</option>
                        <option value="regular">Regular Customers (2+ orders)</option>
                        <option value="one_time">One-time Buyers (1 order)</option>
                        <option value="recent">Purchased Recently (&lt;30d)</option>
                        <option value="inactive">Hasn't Purchased Recently</option>
                      </select>
                    </div>
                  </div>
                </div>
              )}
            </div>

            {/* Customer List */}
            <div className="flex-1 overflow-y-auto">
              {(!customers || (projectionReady !== '1' && totalPurchasers === 0)) ? (
                <div className="p-3 space-y-2">
                  {Array.from({ length: 6 }).map((_, i) => (
                    <SkeletonRow key={i} />
                  ))}
                </div>
              ) : filteredCustomers.length === 0 ? (
                <EmptyState
                  icon={<Users className="w-10 h-10 text-on-surface-variant/40" />}
                  title="No customers found"
                  description={search ? `No customer found matching "${search}"` : 'Customers appear here after their first purchase. Sync to load purchase history.'}
                  action={
                    search ? (
                      <Button variant="secondary" size="sm" onClick={() => setSearch('')}>
                        Clear Search
                      </Button>
                    ) : null
                  }
                  className="py-20"
                />
              ) : (
                <div className="divide-y divide-outline-variant/40">
                  {displayedCustomers.map((c) => {
                    const isSelected = selectedCustomerId === c.id;
                    const fullName = [c.firstName, c.lastName].filter(Boolean).join(' ').trim() ||
                                     [c.billing?.firstName, c.billing?.lastName].filter(Boolean).join(' ').trim() ||
                                     c.username ||
                                     c.email ||
                                     `Customer #${c.id}`;
                    const displayName = decodeHtmlEntities(fullName);
                    const nameForInitials = (c.firstName || c.billing?.firstName || c.username || c.email || '').trim();
                    const lastNameForInitials = (c.lastName || c.billing?.lastName || '').trim();
                    const initials = (
                      (nameForInitials[0] || '') + (lastNameForInitials[0] || '')
                    ).toUpperCase() || displayName.slice(0, 2).toUpperCase();

                    return (
                      <div
                        key={c.id}
                        role="button"
                        tabIndex={0}
                        onClick={() => {
                          setSelectedCustomerId(c.id);
                          setViewingOrderId(null);
                        }}
                        onKeyDown={(e) => {
                          if (e.key === 'Enter' || e.key === ' ') {
                            e.preventDefault();
                            setSelectedCustomerId(c.id);
                            setViewingOrderId(null);
                          }
                        }}
                        className={cn(
                          'px-3.5 py-3 flex items-center gap-3 transition-colors cursor-pointer select-none',
                          isSelected
                            ? 'bg-primary-container/20 border-l-4 border-primary'
                            : 'hover:bg-surface-container-low bg-surface'
                        )}
                      >
                        {/* Initials Avatar */}
                        <div className={cn(
                          'w-9 h-9 rounded-full flex items-center justify-center text-xs font-bold flex-shrink-0 transition-colors',
                          isSelected
                            ? 'bg-[#071A31] text-white dark:bg-[#123158] dark:border dark:border-[#60A5FA]/40'
                            : 'bg-blue-50 border border-blue-200/60 text-[#071A31] dark:bg-blue-950/50 dark:border-blue-800/50 dark:text-blue-200'
                        )}>
                          {initials || <User className="w-4 h-4" />}
                        </div>

                        {/* Info */}
                        <div className="flex-1 min-w-0">
                          <p className="text-xs font-semibold text-on-surface truncate">
                            {displayName}
                          </p>
                          <p className="text-[11px] text-on-surface-variant/80 truncate mt-0.5">{c.email || '—'}</p>
                          {c.billing?.city && (
                            <span className="text-[10px] text-on-surface-variant/60 truncate block mt-0.5">
                              {decodeHtmlEntities(c.billing.city)}
                            </span>
                          )}
                        </div>

                        {/* Customer Spend & Order Count Metrics */}
                        <div className="text-right flex-shrink-0 space-y-0.5">
                          {customerStatsMap.get(c.id)?.totalSpent ? (
                            <span className="text-xs font-bold text-on-surface tabular-nums block">
                              {formatMoney(customerStatsMap.get(c.id)!.totalSpent)}
                            </span>
                          ) : null}
                          <span className="text-[10px] text-on-surface-variant block">
                            {customerStatsMap.get(c.id)?.orderCount || 0} {(customerStatsMap.get(c.id)?.orderCount || 0) === 1 ? 'order' : 'orders'}
                          </span>
                        </div>
                      </div>
                    );
                  })}
                </div>
              )}

              {/* Progressive Load More button when customer count is high */}
              {filteredCustomers.length > visibleCustomersCount && (
                <div className="p-4 text-center border-t border-outline-variant/40 bg-surface">
                  <Button
                    type="button"
                    variant="secondary"
                    size="sm"
                    onClick={() => setVisibleCustomersCount((prev) => prev + 60)}
                    className="w-full max-w-xs mx-auto text-xs font-semibold"
                  >
                    Load More Customers
                  </Button>
                </div>
              )}
            </div>
          </div>
  );

  const selectedFullName = [selectedCustomer?.firstName, selectedCustomer?.lastName].filter(Boolean).join(' ').trim() ||
                           [selectedCustomer?.billing?.firstName, selectedCustomer?.billing?.lastName].filter(Boolean).join(' ').trim() ||
                           selectedCustomer?.username ||
                           selectedCustomer?.email ||
                           (selectedCustomer ? `Customer #${selectedCustomer.id}` : '');
  const selectedDisplayName = decodeHtmlEntities(selectedFullName);
  const selectedNameForInitials = (selectedCustomer?.firstName || selectedCustomer?.billing?.firstName || selectedCustomer?.username || selectedCustomer?.email || '').trim();
  const selectedLastNameForInitials = (selectedCustomer?.lastName || selectedCustomer?.billing?.lastName || '').trim();
  const selectedInitials = (
    (selectedNameForInitials[0] || '') + (selectedLastNameForInitials[0] || '')
  ).toUpperCase() || selectedDisplayName.slice(0, 2).toUpperCase();

  const customerDetailPanel = (
    <div className="w-full flex flex-col h-full bg-surface-container-lowest overflow-hidden">
            {viewingOrder ? (
              <OrderDetailView
                order={viewingOrder}
                items={viewingOrderItems}
                onBack={() => setViewingOrderId(null)}
                onPrintReceipt={() => setShowReceiptModal(true)}
              />
            ) : !selectedCustomer ? (
              <div className="flex-1 flex flex-col items-center justify-center p-8 text-center bg-surface-container-lowest">
                <div className="w-14 h-14 rounded-2xl bg-surface-container-high flex items-center justify-center text-on-surface-variant/50 mb-3.5">
                  <User className="w-7 h-7" />
                </div>
                <h3 className="text-xs font-bold text-on-surface uppercase tracking-wider mb-1">
                  Select Customer Profile
                </h3>
                <p className="text-xs text-on-surface-variant max-w-xs leading-relaxed">
                  Choose a customer from the left directory to inspect their contact information, billing address, and omnichannel purchase history.
                </p>
              </div>
            ) : (
              <div className="flex-1 flex flex-col min-w-0 overflow-y-auto p-6 space-y-6">
                {/* Header Profile */}
                <div className="flex items-start justify-between pb-5 border-b border-outline-variant/60">
                  <div className="flex items-center gap-4">
                    <div className="w-13 h-13 rounded-full bg-blue-50 text-[#071A31] border border-blue-200/80 dark:bg-blue-950/50 dark:text-blue-200 dark:border-blue-800/60 flex items-center justify-center text-base font-black flex-shrink-0">
                      {selectedInitials || <User className="w-6 h-6" />}
                    </div>
                    <div>
                      <h2 className="text-base font-bold text-on-surface tracking-tight">
                        {selectedDisplayName}
                      </h2>
                      <p className="text-xs text-on-surface-variant mt-0.5 flex items-center gap-1.5">
                        <Mail className="w-3.5 h-3.5 text-on-surface-variant/70" />
                        {selectedCustomer.email || 'No email provided'}
                      </p>
                    </div>
                  </div>
                  <div className="flex items-center gap-2">
                    <Button
                      variant="secondary"
                      size="sm"
                      onClick={handleOpenEdit}
                      disabled={selectedCustomer.profileType === 'guest'}
                      className="flex items-center gap-1.5"
                    >
                      <Edit2 className="w-3.5 h-3.5" />
                      Edit Customer
                    </Button>
                    <StatusPill status={selectedCustomer.syncStatus} />
                  </div>
                </div>

                {/* Summary Metrics Row (4 Key Indicators) */}
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5">
                  <div className="m3-card-outlined rounded-xl p-3 bg-surface">
                    <span className="text-[10px] font-semibold text-on-surface-variant uppercase tracking-wider block truncate">
                      Total Orders
                    </span>
                    <p className="text-base font-bold text-on-surface mt-1 tabular-nums">
                      {effectiveTotalOrders}
                    </p>
                  </div>
                  <div className="m3-card-outlined rounded-xl p-3 bg-surface">
                    <span className="text-[10px] font-semibold text-on-surface-variant uppercase tracking-wider block truncate">
                      Lifetime Spend
                    </span>
                    <p className="text-base font-bold text-on-surface mt-1 tabular-nums truncate" title={formatMoney(effectiveTotalSpent)}>
                      {formatMoney(effectiveTotalSpent)}
                    </p>
                  </div>
                  <div className="m3-card-outlined rounded-xl p-3 bg-surface">
                    <span className="text-[10px] font-semibold text-on-surface-variant uppercase tracking-wider block truncate">
                      Avg. Order Value
                    </span>
                    <p className="text-base font-bold text-on-surface mt-1 tabular-nums truncate" title={formatMoney(customerAvgOrderValue)}>
                      {formatMoney(customerAvgOrderValue)}
                    </p>
                  </div>
                  <div className="m3-card-outlined rounded-xl p-3 bg-surface">
                    <span className="text-[10px] font-semibold text-on-surface-variant uppercase tracking-wider block truncate">
                      Last Purchase
                    </span>
                    <p className="text-xs font-bold text-on-surface mt-1 truncate">
                      {customerLastOrderDate ? new Date(customerLastOrderDate).toLocaleDateString() : '—'}
                    </p>
                  </div>
                </div>

                {/* Billing Address Details */}
                <div className="space-y-2.5">
                  <h3 className="text-xs font-bold text-on-surface-variant uppercase tracking-wider">
                    Billing Address & Contact
                  </h3>
                  <div className="m3-card-outlined rounded-xl p-4 bg-surface grid grid-cols-2 gap-4 text-xs">
                    <div>
                      <span className="text-[11px] text-on-surface-variant/70 block mb-0.5 flex items-center gap-1">
                        <Phone className="w-3 h-3 text-on-surface-variant/50" />
                        Phone:
                      </span>
                      <span className="font-semibold text-on-surface">
                        {selectedCustomer.billing?.phone || '—'}
                      </span>
                    </div>
                    <div>
                      <span className="text-[11px] text-on-surface-variant/70 block mb-0.5 flex items-center gap-1">
                        <Building className="w-3 h-3 text-on-surface-variant/50" />
                        Company:
                      </span>
                      <span className="font-semibold text-on-surface">
                        {decodeHtmlEntities(selectedCustomer.billing?.company) || '—'}
                      </span>
                    </div>
                    <div className="col-span-2">
                      <span className="text-[11px] text-on-surface-variant/70 block mb-0.5 flex items-center gap-1">
                        <MapPin className="w-3 h-3 text-on-surface-variant/50" />
                        Address:
                      </span>
                      <span className="font-semibold text-on-surface">
                        {decodeHtmlEntities(
                          [selectedCustomer.billing?.address1, selectedCustomer.billing?.address2].filter(Boolean).join(', ')
                        ) || '—'}
                      </span>
                    </div>
                    <div>
                      <span className="text-[11px] text-on-surface-variant/70 block mb-0.5">City / State:</span>
                      <span className="font-semibold text-on-surface">
                        {decodeHtmlEntities(
                          [selectedCustomer.billing?.city, selectedCustomer.billing?.state].filter(Boolean).join(', ')
                        ) || '—'}
                      </span>
                    </div>
                    <div>
                      <span className="text-[11px] text-on-surface-variant/70 block mb-0.5">Country / Postcode:</span>
                      <span className="font-semibold text-on-surface">
                        {[selectedCustomer.billing?.country, selectedCustomer.billing?.postcode].filter(Boolean).join(' · ') || '—'}
                      </span>
                    </div>
                  </div>
                </div>

                {/* Order History */}
                <div className="space-y-2.5">
                  <div className="flex items-center justify-between">
                    <h3 className="text-xs font-bold text-on-surface-variant uppercase tracking-wider flex items-center gap-1.5">
                      <Clock className="w-3.5 h-3.5 text-on-surface-variant/60" />
                      Order History ({customerOrders.length}{effectiveTotalOrders > customerOrders.length ? ` / ${effectiveTotalOrders} total` : ''})
                    </h3>
                    {isOnline && (
                      <Button
                        type="button"
                        variant="ghost"
                        size="sm"
                        onClick={() => handleSyncCustomerOrders(selectedCustomer)}
                        disabled={isSyncingCustomerOrders}
                        className="text-[11px] h-7 px-2 font-semibold text-primary gap-1 cursor-pointer"
                      >
                        <RefreshCw className={cn("w-3 h-3", isSyncingCustomerOrders && "animate-spin")} />
                        <span>{isSyncingCustomerOrders ? 'Syncing...' : 'Fetch Orders'}</span>
                      </Button>
                    )}
                  </div>
                  {customerOrders.length === 0 ? (
                    <div className="m3-card-outlined rounded-xl p-6 text-center bg-surface">
                      <p className="text-xs text-on-surface-variant italic">
                        {effectiveTotalOrders > 0
                          ? `${effectiveTotalOrders} order${effectiveTotalOrders === 1 ? '' : 's'} recorded in WooCommerce store (syncing historical details in background...)`
                          : 'No past transactions recorded for this customer.'}
                      </p>
                    </div>
                  ) : (
                    <div className="m3-card-outlined rounded-xl divide-y divide-outline-variant/40 bg-surface overflow-hidden">
                      {customerOrders.map((o) => (
                        <div
                          key={o.id}
                          role="button"
                          tabIndex={0}
                          onClick={() => {
                            setViewingOrderId(o.id);
                          }}
                          onKeyDown={(e) => {
                            if (e.key === 'Enter' || e.key === ' ') {
                              e.preventDefault();
                              setViewingOrderId(o.id);
                            }
                          }}
                          className="p-3 flex items-center justify-between text-xs hover:bg-surface-container-low cursor-pointer transition-colors group select-none"
                        >
                          <div className="min-w-0 flex-1">
                            <div className="flex items-center gap-2">
                              <span className="font-bold text-on-surface group-hover:text-primary transition-colors">
                                {o.orderNumber}
                              </span>
                              <ChannelBadge source={o.source || 'pos'} />
                              <span className="text-[10px] text-on-surface-variant capitalize">
                                · {(o.paymentMethodTitle || o.paymentMethod || '').replace(/^zameria_/, '')}
                              </span>
                            </div>
                            <div className="text-[10px] text-on-surface-variant mt-0.5">
                              {new Date(o.createdAt).toLocaleDateString()} · {o.itemCount} items
                            </div>
                          </div>
                          <div className="text-right flex items-center gap-3">
                            <span className="font-bold tabular-nums text-on-surface">
                              {formatMoney(o.total)}
                            </span>
                            <StatusPill status={o.status} />
                            <ChevronRight className="w-3.5 h-3.5 text-outline group-hover:text-primary transition-colors" />
                          </div>
                        </div>
                      ))}
                    </div>
                  )}
                </div>
              </div>
            )}
          </div>
  );

  return (
    <div className="flex h-full w-full overflow-hidden bg-surface relative">
      {isMobile ? (
        selectedCustomer || viewingOrder ? (
          <div className="w-full flex flex-col h-full bg-surface-container-lowest overflow-hidden">
            {/* Mobile Header with Back button */}
            <div className="h-12 px-3 border-b border-outline-variant/60 flex items-center justify-between bg-surface flex-shrink-0">
              <Button
                variant="ghost"
                size="sm"
                onClick={() => {
                  if (viewingOrder) {
                    setViewingOrderId(null);
                  } else {
                    setSelectedCustomerId(null);
                  }
                }}
                className="text-xs font-bold gap-1.5 -ml-1 text-primary hover:text-primary-focus cursor-pointer"
              >
                <ArrowLeft className="w-4 h-4" />
                <span>{viewingOrder ? 'Back to Customer' : 'Back to Customers'}</span>
              </Button>
              <span className="text-xs font-bold truncate max-w-[180px] text-on-surface">
                {viewingOrder
                  ? viewingOrder.orderNumber
                  : selectedCustomer
                  ? `${selectedCustomer.firstName} ${selectedCustomer.lastName}`
                  : ''}
              </span>
            </div>
            <div className="flex-1 overflow-hidden">
              {customerDetailPanel}
            </div>
          </div>
        ) : (
          customerListPanel
        )
      ) : (
        <ResizableSplitView
          storageKey="zameria-split-customers"
          defaultSplit={42}
          minLeftPercent={28}
          maxLeftPercent={65}
          left={customerListPanel}
          right={customerDetailPanel}
        />
      )}

      {/* RECEIPT PREVIEW MODAL FOR HISTORICAL ORDERS */}
      {viewingOrder && (
        <ReceiptModal
          open={showReceiptModal}
          onClose={() => setShowReceiptModal(false)}
          order={viewingOrder}
          items={viewingOrderItems}
        />
      )}

      {/* =====================================================================
          CREATE NEW CUSTOMER DRAWER
          ===================================================================== */}
      <Drawer
        open={showCreateDrawer}
        onClose={() => setShowCreateDrawer(false)}
        title="Create New Customer"
        width="md"
      >
        <form onSubmit={handleCreateCustomer} className="space-y-4">
          {!isOnline && (
            <div className="p-3 bg-warning/10 border border-warning/30 rounded-xl text-on-surface text-xs leading-relaxed">
              <span className="font-semibold text-warning">Offline Notice:</span> Customer creation requires an active internet connection to synchronize with WooCommerce.
            </div>
          )}

          {/* Primary Fields */}
          <div className="space-y-3">
            <h4 className="text-[11px] font-bold text-on-surface-variant uppercase tracking-wider">
              Basic Information
            </h4>
            <div className="grid grid-cols-2 gap-2.5">
              <Input
                label="First Name *"
                value={firstName}
                onChange={(e) => setFirstName(e.target.value)}
                error={formErrors.firstName}
                placeholder="John"
              />
              <Input
                label="Last Name *"
                value={lastName}
                onChange={(e) => setLastName(e.target.value)}
                error={formErrors.lastName}
                placeholder="Doe"
              />
            </div>
            <Input
              label="Email Address *"
              type="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              error={formErrors.email}
              placeholder="john.doe@example.com"
            />
            <Input
              label="Phone Number"
              type="tel"
              value={phone}
              onChange={(e) => setPhone(e.target.value)}
              placeholder="+234 800 000 0000"
            />
          </div>

          {/* Billing Address */}
          <div className="space-y-3 pt-3 border-t border-outline-variant/60">
            <h4 className="text-[11px] font-bold text-on-surface-variant uppercase tracking-wider">
              Billing Address
            </h4>
            <Input
              label="Company"
              value={company}
              onChange={(e) => setCompany(e.target.value)}
              placeholder="Company or Organization"
            />
            <Input
              label="Address Line 1"
              value={address1}
              onChange={(e) => setAddress1(e.target.value)}
              placeholder="Street address or P.O. Box"
            />
            <Input
              label="Address Line 2"
              value={address2}
              onChange={(e) => setAddress2(e.target.value)}
              placeholder="Apartment, suite, unit, etc."
            />
            <div className="grid grid-cols-2 gap-2.5">
              <Input
                label="City"
                value={city}
                onChange={(e) => setCity(e.target.value)}
                placeholder="Lagos, Abuja..."
              />
              <Input
                label="State"
                value={state}
                onChange={(e) => setState(e.target.value)}
                placeholder="Lagos State"
              />
            </div>
            <div className="grid grid-cols-2 gap-2.5">
              <Input
                label="Postcode"
                value={postcode}
                onChange={(e) => setPostcode(e.target.value)}
                placeholder="100001"
              />
              <Input
                label="Country"
                value={country}
                onChange={(e) => setCountry(e.target.value)}
                placeholder="NG"
              />
            </div>
          </div>

          {/* Actions */}
          <div className="flex items-center justify-end gap-2.5 pt-4 border-t border-outline-variant/60">
            <Button
              type="button"
              variant="secondary"
              size="sm"
              onClick={() => setShowCreateDrawer(false)}
            >
              Cancel
            </Button>
            <Button
              type="submit"
              variant="primary"
              size="sm"
              loading={isSubmitting}
            >
              Create Customer
            </Button>
          </div>
        </form>
      </Drawer>

      {/* EDIT CUSTOMER DRAWER */}
      <Drawer
        open={showEditDrawer && selectedCustomer !== null}
        onClose={() => setShowEditDrawer(false)}
        title={`Edit Customer: ${selectedCustomer?.firstName || ''} ${selectedCustomer?.lastName || ''}`}
        width="md"
      >
        <form onSubmit={handleSaveCustomerEdit} className="p-5 space-y-5 overflow-y-auto">
          {/* Primary Fields */}
          <div className="space-y-3">
            <h4 className="text-[11px] font-bold text-on-surface-variant uppercase tracking-wider">
              Basic & Contact Information
            </h4>
            <div className="grid grid-cols-2 gap-2.5">
              <Input
                label="First Name *"
                value={editFirstName}
                onChange={(e) => setEditFirstName(e.target.value)}
                error={editFormErrors.firstName}
                placeholder="First Name"
              />
              <Input
                label="Last Name *"
                value={editLastName}
                onChange={(e) => setEditLastName(e.target.value)}
                error={editFormErrors.lastName}
                placeholder="Last Name"
              />
            </div>
            <Input
              label="Email Address *"
              type="email"
              value={editEmail}
              onChange={(e) => setEditEmail(e.target.value)}
              error={editFormErrors.email}
              placeholder="customer@example.com"
            />
            <Input
              label="Phone Number"
              type="tel"
              value={editPhone}
              onChange={(e) => setEditPhone(e.target.value)}
              placeholder="+234 800 000 0000"
            />
          </div>

          {/* Billing Address */}
          <div className="space-y-3 pt-3 border-t border-outline-variant/60">
            <h4 className="text-[11px] font-bold text-on-surface-variant uppercase tracking-wider">
              Billing Address
            </h4>
            <Input
              label="Company"
              value={editCompany}
              onChange={(e) => setEditCompany(e.target.value)}
              placeholder="Company or Organization"
            />
            <Input
              label="Address Line 1"
              value={editAddress1}
              onChange={(e) => setEditAddress1(e.target.value)}
              placeholder="Street address or P.O. Box"
            />
            <Input
              label="Address Line 2"
              value={editAddress2}
              onChange={(e) => setEditAddress2(e.target.value)}
              placeholder="Apartment, suite, unit, etc."
            />
            <div className="grid grid-cols-2 gap-2.5">
              <Input
                label="City"
                value={editCity}
                onChange={(e) => setEditCity(e.target.value)}
                placeholder="City"
              />
              <Input
                label="State"
                value={editState}
                onChange={(e) => setEditState(e.target.value)}
                placeholder="State"
              />
            </div>
            <div className="grid grid-cols-2 gap-2.5">
              <Input
                label="Postcode / ZIP"
                value={editPostcode}
                onChange={(e) => setEditPostcode(e.target.value)}
                placeholder="100001"
              />
              <Input
                label="Country"
                value={editCountry}
                onChange={(e) => setEditCountry(e.target.value)}
                placeholder="NG"
              />
            </div>
          </div>

          {/* Actions */}
          <div className="flex items-center justify-end gap-2.5 pt-4 border-t border-outline-variant/60">
            <Button
              type="button"
              variant="secondary"
              size="sm"
              onClick={() => setShowEditDrawer(false)}
            >
              Cancel
            </Button>
            <Button
              type="submit"
              variant="primary"
              size="sm"
              loading={isEditingSubmitting}
            >
              Save Changes
            </Button>
          </div>
        </form>
      </Drawer>
    </div>
  );
}
