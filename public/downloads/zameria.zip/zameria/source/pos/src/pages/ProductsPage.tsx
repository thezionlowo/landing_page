import { SelectControl } from '@/components/ui/SelectControl';
import { PageHeader } from '@/components/layout/PageHeader';
import React, { useState, useMemo, useEffect } from 'react';
import { useLiveQuery } from 'dexie-react-hooks';
import { db } from '@/db';
import {
  SearchInput,
  EmptyState,
  SkeletonRow,
  Button,
  Input,
  ResizableSplitView,
  BarcodeScannerModal,
  SyncButton,
  Modal,
} from '@/components/ui';
import { AddProductModal } from '@/components/product/AddProductModal';
import { CategorySelector } from '@/components/product/CategorySelector';
import { BrandSelector } from '@/components/product/BrandSelector';
import { ProductImageUploader } from '@/components/product/ProductImageUploader';
import { formatMoney, cn, toKobo, fromKobo, timeAgo, useResponsive, useStoreCurrency } from '@/lib';
import { useUIStore, useConnectionStore, useAuthStore } from '@/store';
import {
  updateProduct,
  deleteProduct,
  buildCategoryTree,
  flattenCategoryTree,
} from '@/services/woocommerce';
import { toast } from 'sonner';
import {
  Package,
  ExternalLink,
  CheckCircle2,
  AlertCircle,
  Clock,
  RefreshCw,
  Plus,
  Shield,
  Tag,
  Boxes,
  Check,
  ScanBarcode,
  Search,
  Upload,
  Layers,
  ArrowUpDown,
  Barcode,
  Scan,
  Trash2,
  ArrowLeft,
} from 'lucide-react';
import type { Product, StockStatus } from '@/types';

export function ProductsPage() {
  const [search, setSearch] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<number | null>(null);
  const [statusFilter, setStatusFilter] = useState<'all' | 'publish' | 'draft'>('all');
  const [selectedProductId, setSelectedProductId] = useState<number | null>(null);
  const [showAddModal, setShowAddModal] = useState(false);

  // Progressive rendering state to prevent DOM exhaustion
  const [visibleProductsCount, setVisibleProductsCount] = useState(60);
  const { isMobile } = useResponsive();
  const currency = useStoreCurrency();

  // Auth & Role-based permissions from WooCommerce
  const { user, hasPermission } = useAuthStore();
  const canManageProducts = hasPermission('canCreateProduct') || hasPermission('canEditProduct');
  const canEditProductPrice = hasPermission('canEditProductPrice');
  const canEditStockManually = hasPermission('canEditStockManually');
  const canDeleteProduct = hasPermission('canDeleteProduct');

  // Form edit state for selected product
  const [name, setName] = useState('');
  const [regularPrice, setRegularPrice] = useState('');
  const [salePrice, setSalePrice] = useState('');
  const [sku, setSku] = useState('');
  const [barcode, setBarcode] = useState('');
  const [showScannerModal, setShowScannerModal] = useState(false);
  const [showDeleteModal, setShowDeleteModal] = useState(false);
  const [isDeleting, setIsDeleting] = useState(false);
  const [selectedCategoryIds, setSelectedCategoryIds] = useState<number[]>([]);
  const [selectedBrandId, setSelectedBrandId] = useState<number | null>(null);
  const [stockStatus, setStockStatus] = useState<StockStatus>('instock');
  const [stockQuantity, setStockQuantity] = useState('');
  const [lowStockThreshold, setLowStockThreshold] = useState('');
  const [manageStock, setManageStock] = useState(true);
  const [catalogStatus, setCatalogStatus] = useState<'publish' | 'draft'>('publish');
  const [newImageFile, setNewImageFile] = useState<File | null>(null);
  const [isImageRemoved, setIsImageRemoved] = useState(false);
  const [description, setDescription] = useState('');
  const [isUpdating, setIsUpdating] = useState(false);

  // Live queries from Dexie
  const products = useLiveQuery(() => db.products.toArray(), []);
  const categories = useLiveQuery(() => db.categories.toArray(), []);

  // Build hierarchical category list for filter dropdown
  const hierarchicalCategories = useMemo(() => {
    if (!categories || categories.length === 0) return [];
    const roots = buildCategoryTree(categories);
    return flattenCategoryTree(roots);
  }, [categories]);

  // Filtered product catalogue
  const filteredProducts = useMemo(() => {
    if (!products) return [];
    let list = products;

    if (search.trim()) {
      const q = search.trim().toLowerCase();
      list = list.filter(
        (p) =>
          (p.name || '').toLowerCase().includes(q) ||
          (p.sku || '').toLowerCase().includes(q) ||
          (p.barcode && p.barcode.toLowerCase().includes(q)) ||
          (p.upc && p.upc.toLowerCase().includes(q)) ||
          String(p.wooId || '').includes(q)
      );
    }

    if (selectedCategory !== null) {
      // Find category node to include subcategory matches
      const selectedNode = hierarchicalCategories.find((c) => c.id === selectedCategory);
      const matchingCatIds = new Set<number>([selectedCategory]);
      if (selectedNode) {
        for (const cat of hierarchicalCategories) {
          if (cat.parent === selectedNode.wooId || (selectedNode.wooId && cat.path.startsWith(selectedNode.path))) {
            matchingCatIds.add(cat.id);
          }
        }
      }
      list = list.filter((p) => p.categoryIds?.some((id) => matchingCatIds.has(id)));
    }

    if (statusFilter !== 'all') {
      list = list.filter((p) => (p.status || 'publish') === statusFilter);
    }

    return list;
  }, [products, search, selectedCategory, statusFilter, hierarchicalCategories]);

  // Reset progressive count on filter change
  useEffect(() => {
    setVisibleProductsCount(60);
  }, [search, selectedCategory, statusFilter]);

  const displayedProducts = useMemo(() => {
    return filteredProducts.slice(0, visibleProductsCount);
  }, [filteredProducts, visibleProductsCount]);

  const selectedProduct = useMemo(
    () => products?.find((p) => p.id === selectedProductId) || null,
    [products, selectedProductId]
  );

  // Auto-select first product if none selected (desktop dual-pane only; mobile starts on list)
  useEffect(() => {
    if (!isMobile && !selectedProductId && filteredProducts.length > 0) {
      setSelectedProductId(filteredProducts[0].id);
    }
  }, [isMobile, selectedProductId, filteredProducts]);

  // Load product data into editable form state when selected product changes
  useEffect(() => {
    if (selectedProduct) {
      setName(selectedProduct.name);
      setRegularPrice((selectedProduct.regularPrice / 100).toString());
      setSalePrice(
        selectedProduct.salePrice !== null && selectedProduct.salePrice !== undefined
          ? (selectedProduct.salePrice / 100).toString()
          : ''
      );
      setSku(selectedProduct.sku || '');
      setBarcode(selectedProduct.barcode || '');
      setSelectedCategoryIds(selectedProduct.categoryIds || []);
      const initialBrandId = selectedProduct.brandId ?? selectedProduct.wooBrandId ?? null;
      setSelectedBrandId(initialBrandId);
      setStockStatus(selectedProduct.stockStatus);
      setStockQuantity(
        selectedProduct.stockQuantity !== null && selectedProduct.stockQuantity !== undefined
          ? selectedProduct.stockQuantity.toString()
          : ''
      );
      setLowStockThreshold(
        selectedProduct.lowStockThreshold !== null && selectedProduct.lowStockThreshold !== undefined
          ? selectedProduct.lowStockThreshold.toString()
          : '5'
      );
      setManageStock(selectedProduct.manageStock);
      setCatalogStatus(selectedProduct.status === 'draft' ? 'draft' : 'publish');
      setNewImageFile(null);
      setIsImageRemoved(false);
      setDescription(selectedProduct.description || '');
    }
  }, [selectedProduct]);

  // Save product changes and sync to WooCommerce
  const handleUpdateProduct = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedProduct) return;

    if (!canManageProducts) {
      toast.error('You do not have permission to modify products.');
      return;
    }

    const regPriceNum = parseFloat(regularPrice);
    if (isNaN(regPriceNum) || regPriceNum < 0) {
      toast.error('Please enter a valid regular price');
      return;
    }

    const salePriceNum = salePrice.trim() ? parseFloat(salePrice) : null;
    if (salePriceNum !== null && (isNaN(salePriceNum) || salePriceNum < 0)) {
      toast.error('Please enter a valid sale price');
      return;
    }

    if (salePriceNum !== null && salePriceNum >= regPriceNum) {
      toast.error('Sale price should be less than regular price');
      return;
    }

    // Enforce price edit permission
    const pricesChanged =
      toKobo(regPriceNum) !== selectedProduct.regularPrice ||
      (salePriceNum !== null ? toKobo(salePriceNum) : null) !== selectedProduct.salePrice;
    if (pricesChanged && !canEditProductPrice) {
      toast.error('You do not have permission to modify product prices.');
      return;
    }

    const stockQtyNum = manageStock && stockQuantity.trim() ? parseInt(stockQuantity, 10) : null;
    const lowStockNum = lowStockThreshold.trim() ? parseInt(lowStockThreshold, 10) : null;

    // Enforce manual stock edit permission
    const stockChanged =
      stockStatus !== selectedProduct.stockStatus ||
      manageStock !== selectedProduct.manageStock ||
      stockQtyNum !== selectedProduct.stockQuantity ||
      lowStockNum !== (selectedProduct.lowStockThreshold ?? null);
    if (stockChanged && !canEditStockManually) {
      toast.error('You do not have permission to manually adjust stock levels.');
      return;
    }

    // Check if category selection changed
    const prevCatIds = selectedProduct.categoryIds || [];
    const categoriesChanged =
      selectedCategoryIds.length !== prevCatIds.length ||
      selectedCategoryIds.some((id) => !prevCatIds.includes(id));

    // Check if brand selection changed
    const currentProdBrandId = selectedProduct.brandId ?? selectedProduct.wooBrandId ?? null;
    const brandChanged = selectedBrandId !== currentProdBrandId;

    // Check if image changed or removed
    const imageChanged = Boolean(newImageFile) || isImageRemoved;

    // Check if any other fields changed
    const hasChanges =
      categoriesChanged ||
      brandChanged ||
      imageChanged ||
      name.trim() !== selectedProduct.name ||
      sku.trim() !== (selectedProduct.sku || '') ||
      barcode.trim() !== (selectedProduct.barcode || '') ||
      toKobo(regPriceNum) !== selectedProduct.regularPrice ||
      (salePriceNum !== null ? toKobo(salePriceNum) : null) !== selectedProduct.salePrice ||
      stockStatus !== selectedProduct.stockStatus ||
      manageStock !== selectedProduct.manageStock ||
      stockQtyNum !== selectedProduct.stockQuantity ||
      lowStockNum !== (selectedProduct.lowStockThreshold ?? null) ||
      catalogStatus !== (selectedProduct.status || 'publish') ||
      description.trim() !== (selectedProduct.description || '');

    if (!hasChanges) {
      toast.info('No changes detected to sync');
      return;
    }

    setIsUpdating(true);
    const targetProductId = selectedProduct.id;
    try {
      const result = await updateProduct(targetProductId, {
        name: name.trim(),
        sku: sku.trim(),
        barcode: barcode.trim() || null,
        regularPrice: toKobo(regPriceNum),
        salePrice: salePriceNum !== null ? toKobo(salePriceNum) : null,
        costPrice: selectedProduct.costPrice ?? null,
        categoryIds: selectedCategoryIds,
        brandId: selectedBrandId,
        stockStatus,
        stockQuantity: stockQtyNum,
        lowStockThreshold: lowStockNum,
        manageStock,
        status: catalogStatus,
        imageFile: newImageFile,
        removeImage: isImageRemoved,
        description: description.trim(),
      });

      // Clear pending image upload state upon successful save
      setNewImageFile(null);
      setIsImageRemoved(false);

      if (result.synced) {
        toast.success(`✓ Changes saved and synced with website`, {
          icon: <CheckCircle2 className="w-4 h-4 text-emerald-600" />,
        });
      } else {
        toast.warning('Changes saved locally, but website sync failed.', {
          description: result.error || 'Will automatically sync when connection returns.',
          icon: <AlertCircle className="w-4 h-4 text-amber-600" />,
        });
      }
    } catch (err: any) {
      toast.error(err?.message || 'Failed to update product');
    } finally {
      setIsUpdating(false);
    }
  };

  // Helper for sync status badges
  const renderSyncBadge = (prod: Product) => {
    if (prod.syncStatus === 'SYNCING') {
      return (
        <span className="inline-flex items-center gap-1 text-xs font-semibold text-info bg-info/10 px-1.5 py-0.5 rounded-md border border-info/20">
          <RefreshCw className="w-2.5 h-2.5 animate-spin" />
          Syncing
        </span>
      );
    }
    if (prod.syncStatus === 'PENDING_SYNC') {
      return (
        <span className="inline-flex items-center gap-1 text-xs font-semibold text-warning bg-warning/10 px-1.5 py-0.5 rounded-md border border-warning/30">
          <Clock className="w-2.5 h-2.5" />
          Pending
        </span>
      );
    }
    if (prod.syncStatus === 'SYNC_ERROR' || prod.syncStatus === 'SYNC_CONFLICT') {
      return (
        <span className="inline-flex items-center gap-1 text-xs font-semibold text-error bg-error/10 px-1.5 py-0.5 rounded-md border border-error/20">
          <AlertCircle className="w-2.5 h-2.5" />
          {prod.syncStatus === 'SYNC_CONFLICT' ? 'Conflict' : 'Failed'}
        </span>
      );
    }
    return (
      <span className="inline-flex items-center gap-1 text-xs font-semibold text-success bg-success/10 px-1.5 py-0.5 rounded-md border border-success/20">
        <Check className="w-2.5 h-2.5" />
        Synced
      </span>
    );
  };

  const productListPanel = (
    <div className="w-full flex flex-col h-full bg-surface overflow-hidden border-r border-outline-variant/60">
            <PageHeader title="Products" description={`${filteredProducts.length} products in your catalogue`} actions={<SyncButton scope="products" label="Sync" size="sm" variant="secondary" />} />
            {/* Header Toolbar - Standardized 48px Header matching POS Session */}
            <div className="pos-record-toolbar">
              <div className="pos-toolbar-search flex-1 min-w-0">
                <SearchInput
                  value={search}
                  onChange={setSearch}
                  placeholder="Search products by name, SKU, or barcode..."
                  className="text-xs placeholder:text-xs"
                />
              </div>

              {/* Category Filter (Compact on desktop) */}
              <SelectControl
                value={selectedCategory ?? ''}
                onChange={(e) => setSelectedCategory(e.target.value ? Number(e.target.value) : null)}
                className="pos-filter-select hidden sm:inline-block w-[110px] shrink-0 truncate"
                title="Filter by category"
              >
                <option value="">All Categories</option>
                {hierarchicalCategories.map((c) => (
                  <option key={c.id} value={c.id}>
                    {c.level > 0 ? `${'\u00A0\u00A0'.repeat(c.level)}└── ${c.name}` : c.name}
                  </option>
                ))}
              </SelectControl>

              {/* Status Filter */}
              <SelectControl
                value={statusFilter}
                onChange={(e) => setStatusFilter(e.target.value as any)}
                className="pos-filter-select hidden md:inline-block w-[95px] shrink-0 truncate"
                title="Filter by status"
              >
                <option value="all">All Status</option>
                <option value="publish">Active</option>
                <option value="draft">Draft</option>
              </SelectControl>

              {/* Barcode Scanner Button - Matching POS compact secondary button */}
              <Button
                type="button"
                variant="secondary"
                size="sm"
                onClick={() => setShowScannerModal(true)}
                className="h-8.5 px-2.5 text-xs font-medium flex items-center gap-1.5 border-outline-variant hover:border-primary/50 flex-shrink-0"
                icon={<ScanBarcode className="w-3.5 h-3.5 text-primary" />}
                title="Scan barcode with camera or enter code"
              >
                <span className="hidden sm:inline">Scan</span>
              </Button>

              {/* Result Count Badge */}
              <div className="hidden sm:flex items-center gap-1 text-xs text-surface-500 font-medium shrink-0">
                <span className="px-2 py-0.5 rounded-full bg-surface-container-high border border-outline-variant/40 font-mono text-on-surface-variant">
                  {filteredProducts.length}
                </span>
                <span className="hidden md:inline">items</span>
              </div>
            </div>

            {/* Mobile Filter Sub-Ribbon (< 768px) - Compact Ribbon matching POS Category Strip */}
            {isMobile && (
              <div className="flex items-center gap-1.5 px-3 py-1.5 border-b border-surface-200 bg-surface/50 overflow-x-auto no-scrollbar flex-shrink-0 text-xs select-none">
                <SelectControl
                  value={selectedCategory ?? ''}
                  onChange={(e) => setSelectedCategory(e.target.value ? Number(e.target.value) : null)}
                  className="pos-filter-select-sm max-w-[125px] truncate"
                  title="Filter by category"
                >
                  <option value="">All Categories</option>
                  {hierarchicalCategories.map((c) => (
                    <option key={c.id} value={c.id}>
                      {c.name}
                    </option>
                  ))}
                </SelectControl>

                <SelectControl
                  value={statusFilter}
                  onChange={(e) => setStatusFilter(e.target.value as any)}
                  className="pos-filter-select-sm max-w-[95px] truncate"
                  title="Filter by status"
                >
                  <option value="all">All Status</option>
                  <option value="publish">Active</option>
                  <option value="draft">Draft</option>
                </SelectControl>

                <div className="ml-auto flex items-center gap-1 text-xs text-surface-500 font-mono shrink-0">
                  <span>{filteredProducts.length}</span>
                  <span>items</span>
                </div>
              </div>
            )}

            {/* Product Rows */}
            <div className="flex-1 overflow-y-auto">
              {!products ? (
                <div className="p-3 space-y-2">
                  {Array.from({ length: 8 }).map((_, i) => (
                    <SkeletonRow key={i} />
                  ))}
                </div>
              ) : filteredProducts.length === 0 ? (
                <EmptyState
                  icon={<Package className="w-10 h-10 text-on-surface-variant/40" />}
                  title="No Products Found"
                  description={search ? `No product matching "${search}"` : 'No products available in the catalogue.'}
                  action={
                    search || selectedCategory !== null || statusFilter !== 'all' ? (
                      <Button
                        variant="secondary"
                        size="sm"
                        onClick={() => {
                          setSearch('');
                          setSelectedCategory(null);
                          setStatusFilter('all');
                        }}
                      >
                        Reset Filters
                      </Button>
                    ) : canManageProducts ? (
                      <Button
                        variant="primary"
                        size="sm"
                        onClick={() => setShowAddModal(true)}
                        icon={<Plus className="w-4 h-4" />}
                      >
                        Add First Product
                      </Button>
                    ) : null
                  }
                  className="py-20"
                />
              ) : (
                <div className="divide-y divide-outline-variant/40">
                  {displayedProducts.map((p) => {
                    const isSelected = selectedProductId === p.id;
                    const prodCats = categories?.filter((c) => p.categoryIds?.includes(c.id)) || [];

                    return (
                      <div
                        key={p.id}
                        role="button"
                        tabIndex={0}
                        onClick={() => setSelectedProductId(p.id)}
                        onKeyDown={(e) => {
                          if (e.key === 'Enter' || e.key === ' ') {
                            e.preventDefault();
                            setSelectedProductId(p.id);
                          }
                        }}
                        className={cn(
                          'px-3.5 py-2.5 flex items-center gap-3 transition-colors cursor-pointer select-none',
                          isSelected
                            ? 'bg-primary-container/20 border-l-4 border-primary'
                            : 'hover:bg-surface-container-low bg-surface'
                        )}
                      >
                        {/* Thumbnail */}
                        <div className="w-10 h-10 rounded-lg overflow-hidden bg-surface-container-high border border-outline-variant/60 flex-shrink-0 flex items-center justify-center">
                          {p.images?.[0]?.src ? (
                            <img
                              src={p.images[0].src}
                              alt={p.name}
                              className="w-full h-full object-cover"
                              loading="lazy"
                            />
                          ) : (
                            <Package className="w-5 h-5 text-on-surface-variant/50" />
                          )}
                        </div>

                        {/* Details */}
                        <div className="flex-1 min-w-0">
                          <div className="flex items-center gap-1.5">
                            <p className="text-xs font-semibold text-on-surface truncate">{p.name}</p>
                            {p.status === 'draft' && (
                              <span className="text-[9px] font-bold px-1.5 py-0.2 bg-warning/15 text-warning rounded-md">
                                Draft
                              </span>
                            )}
                          </div>
                          <div className="flex flex-wrap items-center gap-1.5 text-xs text-on-surface-variant font-mono mt-0.5">
                            <span>ID: {p.wooId || p.id}</span>
                            {p.sku && <span>· SKU: {p.sku}</span>}
                            {p.barcode && <span className="text-on-surface">· Barcode: {p.barcode}</span>}
                            {prodCats.length > 0 && (
                              <span className="text-on-surface-variant font-sans font-medium">
                                · {prodCats.map((c) => c.name).join(', ')}
                              </span>
                            )}
                          </div>
                        </div>

                        {/* Stock, Price & Sync Status */}
                        <div className="text-right flex-shrink-0 space-y-0.5">
                          <div className="text-xs font-bold text-on-surface tabular-nums">
                            {formatMoney(p.price)}
                            {p.onSale && p.regularPrice > p.price && (
                              <span className="ml-1 text-xs font-normal text-on-surface-variant/60 line-through">
                                {formatMoney(p.regularPrice)}
                              </span>
                            )}
                          </div>
                          <div className="flex items-center justify-end gap-1.5">
                            <span
                              className={cn(
                                'text-xs font-semibold',
                                p.stockStatus === 'instock'
                                  ? 'text-success'
                                  : p.stockStatus === 'onbackorder'
                                  ? 'text-warning'
                                  : 'text-error'
                              )}
                            >
                              {p.manageStock && p.stockQuantity !== null
                                ? `${p.stockQuantity} in stock`
                                : p.stockStatus === 'instock'
                                ? 'In stock'
                                : 'Out of stock'}
                            </span>
                            {renderSyncBadge(p)}
                          </div>
                        </div>
                      </div>
                    );
                  })}
                </div>
              )}

              {/* Progressive Load More button when product count is high */}
              {filteredProducts.length > visibleProductsCount && (
                <div className="p-4 text-center border-t border-outline-variant/40 bg-surface">
                  <Button
                    type="button"
                    variant="secondary"
                    size="sm"
                    onClick={() => setVisibleProductsCount((prev) => prev + 60)}
                    className="w-full max-w-xs mx-auto text-xs font-semibold"
                  >
                    Load More Products ({filteredProducts.length - visibleProductsCount} remaining)
                  </Button>
                </div>
              )}
            </div>
          </div>
  );

  const productDetailPanel = (
    <div className="w-full flex flex-col h-full bg-surface-container-lowest overflow-hidden">
            {!selectedProduct ? (
              <div className="flex-1 flex flex-col items-center justify-center p-8 text-center bg-surface-container-lowest">
                <div className="w-14 h-14 rounded-2xl bg-surface-container-high flex items-center justify-center text-on-surface-variant/50 mb-3.5">
                  <Package className="w-7 h-7" />
                </div>
                <h3 className="text-xs font-bold text-on-surface uppercase tracking-wider mb-1">
                  Select a Product
                </h3>
                <p className="text-xs text-on-surface-variant max-w-xs">
                  Choose a product from the catalogue to view inventory levels, adjust pricing, and synchronize changes.
                </p>
              </div>
            ) : (
              <form key={selectedProduct.id} onSubmit={handleUpdateProduct} className="flex-1 flex flex-col min-w-0 overflow-hidden">
                {/* Scrollable Form Body */}
                <div className="flex-1 overflow-y-auto p-6 space-y-5">
                  {/* Read-Only Notice for Restricted Roles */}
                  {!canManageProducts && (
                    <div className="p-3 rounded-xl bg-warning/10 border border-warning/30 flex items-center gap-2.5 text-xs text-on-surface">
                      <Shield className="w-4 h-4 text-warning flex-shrink-0" />
                      <span>
                        <strong>Restricted Access:</strong> Product editing is restricted for role: {user?.role.toUpperCase() || 'UNKNOWN'}. You can inspect catalogue details and specifications.
                      </span>
                    </div>
                  )}

                  {/* Product Header & WooCommerce Link */}
                  <div className="flex items-center justify-between pb-3 border-b border-outline-variant/60">
                    <div className="flex items-center gap-2">
                      <span className="text-xs font-bold text-on-surface-variant font-mono bg-surface-container-high px-2 py-0.5 rounded-md border border-outline-variant/40">
                        WooCommerce ID: {selectedProduct.wooId || 'Local Product'}
                      </span>
                      {selectedProduct.barcode && (
                        <span className="text-xs font-medium text-on-surface font-mono bg-surface-container-high px-2 py-0.5 rounded-md border border-outline-variant/40">
                          Barcode: {selectedProduct.barcode}
                        </span>
                      )}
                      {renderSyncBadge(selectedProduct)}
                    </div>
                    <a
                      href="#"
                      onClick={(e) => {
                        e.preventDefault();
                        toast.info(
                          selectedProduct.wooId
                            ? `WooCommerce Product ID: ${selectedProduct.wooId}`
                            : 'WooCommerce link available when product is synchronized'
                        );
                      }}
                      className="inline-flex items-center gap-1 text-xs font-semibold text-primary hover:underline"
                    >
                      <ExternalLink className="w-3.5 h-3.5" />
                      Open in WooCommerce
                    </a>
                  </div>

                  {/* Basic Information */}
                  <div className="space-y-2.5">
                    <h3 className="text-xs font-bold text-on-surface-variant uppercase tracking-wider">
                      Product Information
                    </h3>
                    <div className="m3-card-outlined rounded-xl p-4 bg-surface space-y-4">
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                        <Input
                          label="Product Name *"
                          value={name}
                          disabled={!canManageProducts}
                          onChange={(e) => setName(e.target.value)}
                          required
                        />
                        <Input
                          label="SKU"
                          value={sku}
                          disabled={!canManageProducts}
                          onChange={(e) => setSku(e.target.value)}
                          placeholder="e.g. BEV-001"
                        />
                      </div>

                      {/* Barcode Field with Scan Button */}
                      <div>
                        <label className="text-xs font-semibold text-on-surface block mb-1">
                          Barcode / Barcode Scanner
                        </label>
                        <div className="flex items-center gap-2">
                          <input
                            type="text"
                            disabled={!canManageProducts}
                            value={barcode}
                            onChange={(e) => setBarcode(e.target.value)}
                            placeholder="e.g. 8901234567890 or 5449000000996"
                            className="flex-1 h-9 px-3 border border-outline-variant/80 rounded-lg text-xs font-mono bg-surface text-on-surface focus:outline-none focus:border-primary disabled:bg-surface-container-high placeholder:font-sans placeholder:text-on-surface-variant/50"
                          />
                          {canManageProducts && (
                            <Button
                              type="button"
                              variant="secondary"
                              size="sm"
                              onClick={() => setShowScannerModal(true)}
                              className="h-9 px-3 text-xs font-medium flex items-center gap-1.5 flex-shrink-0"
                              icon={<ScanBarcode className="w-3.5 h-3.5 text-primary" />}
                            >
                              Scan Barcode
                            </Button>
                          )}
                        </div>
                        <p className="text-xs text-on-surface-variant mt-1">
                          Assigned barcode for physical retail scanning. Updates sync to WooCommerce metadata automatically.
                        </p>
                      </div>

                      {/* Hierarchical Multi-Category Selector */}
                      <CategorySelector
                        selectedCategoryIds={selectedCategoryIds}
                        onChange={setSelectedCategoryIds}
                        disabled={!canManageProducts}
                      />

                      {/* Brand Selector */}
                      <BrandSelector
                        selectedBrandId={selectedBrandId}
                        onChange={setSelectedBrandId}
                        disabled={!canManageProducts}
                      />
                    </div>
                  </div>

                  {/* Pricing Section */}
                  <div className="space-y-2.5">
                    <h3 className="text-xs font-bold text-on-surface-variant uppercase tracking-wider">
                      Pricing ({currency.symbol})
                    </h3>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-3 m3-card-outlined rounded-xl p-4 bg-surface">
                      <Input
                        label={`Regular Price (${currency.symbol}) *`}
                        type="number"
                        step="any"
                        disabled={!canEditProductPrice}
                        value={regularPrice}
                        onChange={(e) => setRegularPrice(e.target.value)}
                        required
                      />
                      <Input
                        label={`Sale Price (${currency.symbol})`}
                        type="number"
                        step="any"
                        disabled={!canEditProductPrice}
                        value={salePrice}
                        onChange={(e) => setSalePrice(e.target.value)}
                        placeholder="Leave empty if not on sale"
                      />
                    </div>
                  </div>

                  {/* Inventory & Stock Management */}
                  <div className="space-y-2.5">
                    <h3 className="text-xs font-bold text-on-surface-variant uppercase tracking-wider">
                      Inventory & Catalog Visibility
                    </h3>
                    <div className="m3-card-outlined rounded-xl p-4 bg-surface space-y-3">
                      <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
                        <div>
                          <label className="text-xs font-semibold text-on-surface block mb-1">
                            Stock Status
                          </label>
                          <SelectControl aria-label="Stock status"
                            value={stockStatus}
                            disabled={!canEditStockManually}
                            onChange={(e) => setStockStatus(e.target.value as StockStatus)}
                            className="w-full h-9 px-3 border border-outline-variant/80 rounded-lg text-xs font-medium bg-surface text-on-surface focus:outline-none focus:border-primary disabled:bg-surface-container-high cursor-pointer"
                          >
                            <option value="instock">In stock</option>
                            <option value="outofstock">Out of stock</option>
                            <option value="onbackorder">On backorder</option>
                          </SelectControl>
                        </div>

                        <div>
                          <Input
                            label="Stock Quantity"
                            type="number"
                            disabled={!canEditStockManually || !manageStock}
                            value={stockQuantity}
                            onChange={(e) => setStockQuantity(e.target.value)}
                            placeholder="Unlimited"
                          />
                        </div>

                        <div>
                          <Input
                            label="Low Stock Threshold"
                            type="number"
                            disabled={!canEditStockManually || !manageStock}
                            value={lowStockThreshold}
                            onChange={(e) => setLowStockThreshold(e.target.value)}
                            placeholder="5"
                          />
                        </div>
                      </div>

                      <div className="pt-2 flex flex-wrap items-center justify-between gap-4 border-t border-outline-variant/40">
                        <label className="flex items-center gap-2 cursor-pointer text-xs font-medium text-on-surface select-none">
                          <input
                            type="checkbox"
                            checked={manageStock}
                            disabled={!canManageProducts}
                            onChange={(e) => setManageStock(e.target.checked)}
                            className="rounded border-outline-variant/80 text-primary focus:ring-primary cursor-pointer"
                          />
                          Track inventory for this product
                        </label>

                        <div className="flex items-center gap-2">
                          <span className="text-xs font-semibold text-on-surface">Catalog Visibility:</span>
                          <div className="flex items-center rounded-lg border border-outline-variant/60 p-0.5 bg-surface-container-high">
                            <button
                              type="button"
                              disabled={!canManageProducts}
                              onClick={() => setCatalogStatus('publish')}
                              className={cn(
                                'px-2.5 py-1 text-xs font-semibold rounded cursor-pointer transition-colors',
                                catalogStatus === 'publish'
                                  ? 'bg-surface text-primary shadow-xs'
                                  : 'text-on-surface-variant hover:text-on-surface'
                              )}
                            >
                              Active
                            </button>
                            <button
                              type="button"
                              disabled={!canManageProducts}
                              onClick={() => setCatalogStatus('draft')}
                              className={cn(
                                'px-2.5 py-1 text-xs font-semibold rounded cursor-pointer transition-colors',
                                catalogStatus === 'draft'
                                  ? 'bg-surface text-warning shadow-xs'
                                  : 'text-on-surface-variant hover:text-on-surface'
                              )}
                            >
                              Draft
                            </button>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>

                  {/* Direct Image Upload */}
                  <div className="space-y-2.5">
                    <h3 className="text-xs font-bold text-on-surface-variant uppercase tracking-wider">
                      Product Media & Description
                    </h3>
                    <div className="m3-card-outlined rounded-xl p-4 bg-surface space-y-4">
                      <ProductImageUploader
                        currentImageUrl={selectedProduct.images?.[0]?.src}
                        onImageSelected={(file) => {
                          setNewImageFile(file);
                          setIsImageRemoved(false);
                        }}
                        onImageRemoved={() => {
                          setNewImageFile(null);
                          setIsImageRemoved(true);
                        }}
                        disabled={!canManageProducts}
                      />

                      <div>
                        <label className="text-xs font-semibold text-on-surface block mb-1">
                          Description
                        </label>
                        <textarea
                          rows={3}
                          disabled={!canManageProducts}
                          value={description}
                          onChange={(e) => setDescription(e.target.value)}
                          placeholder="Product description for in-store and online catalog..."
                          className="w-full px-3 py-2 border border-outline-variant/80 rounded-lg text-xs font-normal text-on-surface bg-surface focus:outline-none focus:border-primary disabled:bg-surface-container-high resize-none"
                        />
                      </div>
                    </div>
                  </div>

                  {/* Synchronization Metadata Card */}
                  <div className="m3-card-outlined rounded-xl p-4 bg-surface space-y-2 text-xs">
                    <div className="flex items-center justify-between">
                      <span className="font-semibold text-on-surface">WooCommerce Synchronization</span>
                      {renderSyncBadge(selectedProduct)}
                    </div>
                    <div className="text-xs text-on-surface-variant flex flex-wrap items-center justify-between gap-2">
                      <span>
                        {selectedProduct.lastSyncedAt
                          ? `Last confirmed sync: ${timeAgo(selectedProduct.lastSyncedAt)}`
                          : 'Not synchronized with WooCommerce yet'}
                      </span>
                      {selectedProduct.syncStatus === 'PENDING_SYNC' && (
                        <span className="text-warning font-semibold">
                          Queued for automatic sync when online
                        </span>
                      )}
                    </div>
                  </div>
                </div>

                {/* Bottom Footer Actions */}
                <div className="px-4 py-3 border-t border-outline-variant/60 bg-surface flex items-center justify-between flex-shrink-0 gap-3">
                  <div>
                    {canDeleteProduct && (
                      <Button
                        type="button"
                        variant="outline"
                        size="sm"
                        onClick={() => setShowDeleteModal(true)}
                        className="text-danger border-danger/30 hover:bg-danger/10 hover:text-danger dark:border-danger/40 dark:text-danger dark:hover:bg-danger/20 flex-shrink-0"
                        icon={<Trash2 className="w-4 h-4" />}
                      >
                        Delete
                      </Button>
                    )}
                  </div>

                  <div className="flex items-center gap-3 min-w-0 justify-end ml-auto">
                    {!canManageProducts && (
                      <span className="text-xs text-on-surface-variant/70 whitespace-nowrap text-right hidden sm:inline-block">
                        Read-only access for cashier role
                      </span>
                    )}
                    {canManageProducts && (
                      <Button
                        type="submit"
                        variant="primary"
                        size="sm"
                        loading={isUpdating}
                        className="whitespace-nowrap flex-shrink-0"
                        icon={<CheckCircle2 className="w-4 h-4" />}
                      >
                        Save & Sync to Website
                      </Button>
                    )}
                  </div>
                </div>
              </form>
            )}
          </div>
  );

  return (
    <div className="flex h-full w-full overflow-hidden bg-surface relative">
      {isMobile ? (
        selectedProduct ? (
          <div className="w-full flex flex-col h-full bg-surface-container-lowest overflow-hidden">
            {/* Mobile Header with Back button */}
            <div className="h-12 px-3 border-b border-outline-variant/60 flex items-center justify-between bg-surface flex-shrink-0">
              <Button
                variant="ghost"
                size="sm"
                onClick={() => setSelectedProductId(null)}
                className="text-xs font-bold gap-1.5 -ml-1 text-primary hover:text-primary-focus cursor-pointer"
              >
                <ArrowLeft className="w-4 h-4" />
                <span>Back to Products</span>
              </Button>
              <span className="text-xs font-bold truncate max-w-[180px] text-on-surface">
                {selectedProduct.name}
              </span>
            </div>
            <div className="flex-1 overflow-hidden">
              {productDetailPanel}
            </div>
          </div>
        ) : (
          productListPanel
        )
      ) : (
        <ResizableSplitView
          storageKey="zameria-split-products"
          defaultSplit={46}
          minLeftPercent={28}
          maxLeftPercent={65}
          left={productListPanel}
          right={productDetailPanel}
        />
      )}

      {/* Delete Product Confirmation Modal */}
      {selectedProduct && (
        <Modal
          open={showDeleteModal}
          onClose={() => !isDeleting && setShowDeleteModal(false)}
          title="Delete Product"
          size="sm"
        >
          <div className="space-y-4 py-2">
            <div className="p-3 bg-danger/10 border border-danger/20 rounded-lg flex items-start gap-3 text-sm text-danger">
              <AlertCircle className="w-5 h-5 flex-shrink-0 mt-0.5" />
              <div className="space-y-1">
                <p className="font-bold">Are you sure you want to delete this product?</p>
                <p className="text-xs text-on-surface-variant">
                  &ldquo;<strong className="text-on-surface">{selectedProduct.name}</strong>&rdquo; will be removed from the active POS sales catalogue and WooCommerce.
                </p>
              </div>
            </div>

            <p className="text-xs text-on-surface-variant">
              ✓ <strong>Historical orders safe:</strong> Any existing orders or receipts that include this product will safely retain their historical snapshot items and pricing.
            </p>

            <div className="flex items-center justify-end gap-2 pt-2 border-t border-surface-200">
              <Button
                variant="outline"
                size="sm"
                onClick={() => setShowDeleteModal(false)}
                disabled={isDeleting}
              >
                Cancel
              </Button>
              <Button
                variant="primary"
                size="sm"
                className="bg-danger hover:bg-danger-hover text-white border-danger"
                onClick={async () => {
                  if (!selectedProduct || !canDeleteProduct) return;
                  setIsDeleting(true);
                  try {
                    const result = await deleteProduct(selectedProduct.id);
                    if (result.success) {
                      toast.success(`Product "${selectedProduct.name}" deleted successfully.`);
                      setShowDeleteModal(false);
                      setSelectedProductId(null);
                    } else {
                      toast.error(result.error || 'Failed to delete product.');
                    }
                  } catch (err: any) {
                    toast.error(err?.message || 'Failed to delete product.');
                  } finally {
                    setIsDeleting(false);
                  }
                }}
                loading={isDeleting}
                icon={<Trash2 className="w-4 h-4" />}
              >
                Confirm Delete
              </Button>
            </div>
          </div>
        </Modal>
      )}

      {/* Add Product Modal */}
      <AddProductModal
        open={showAddModal}
        onClose={() => setShowAddModal(false)}
        onProductCreated={(newId) => {
          setSelectedProductId(newId);
        }}
      />

      {/* Barcode Camera Scanner Modal */}
      <BarcodeScannerModal
        open={showScannerModal}
        onClose={() => setShowScannerModal(false)}
        onScan={(code) => {
          setBarcode(code);
          toast.success(`Barcode detected: ${code}`);
        }}
        title="Scan Product Barcode"
        submitLabel="Use Barcode"
      />

      {/* Floating Add Product Button */}
      {!selectedProductId && canManageProducts && (
        <button
          type="button"
          onClick={() => setShowAddModal(true)}
          className="fixed right-4 md:right-8 bottom-20 md:bottom-8 z-30 flex items-center gap-2 px-4 py-3 rounded-full bg-primary hover:bg-primary-hover active:scale-95 text-white shadow-xl transition-all cursor-pointer border-2 border-white dark:border-slate-800 text-xs font-bold"
          title="Add New Product"
          aria-label="Add New Product"
        >
          <Plus className="w-4 h-4 text-white" />
          <span>Add Product</span>
        </button>
      )}
    </div>
  );
}
