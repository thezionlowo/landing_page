import { useState, useMemo, useEffect } from 'react';
import { useLiveQuery } from 'dexie-react-hooks';
import { useNavigate } from 'react-router';
import { db } from '@/db';
import { useCartStore, useAuthStore } from '@/store';
import { isOrderAccessibleToUser } from '@/services/auth';
import {
  SearchInput,
  StatusPill,
  EmptyState,
  SkeletonRow,
  Button,
  Badge,
  ChannelBadge,
  ReceiptModal,
  Modal,
  ResizableSplitView,
  SyncButton,
} from '@/components/ui';
import { OrderDetailView } from '@/components/order/OrderDetailView';
import { formatMoney, formatTime, getRelativeDateLabel, getDateKey, cn, useResponsive } from '@/lib';
import { cancelOrder } from '@/services/woocommerce';
import { syncScope } from '@/services/woocommerce/syncCoordinator';
import { syncLatestOrders } from '@/services/woocommerce/orderSyncService';
import { toast } from 'sonner';
import {
  ChevronDown,
  ChevronRight,
  ExternalLink,
  Printer,
  RefreshCw,
  FileText,
  Trash2,
  ArrowRight,
  ArrowLeft,
  MoreHorizontal,
} from 'lucide-react';
import type { Order, OrderItem, OrderStatus } from '@/types';

type StatusFilterOption = 'all' | 'completed' | 'processing' | 'on-hold' | 'incomplete';
type ChannelFilterOption = 'all' | 'pos' | 'website';

export function OrdersPage() {
  const [search, setSearch] = useState('');
  const [statusFilter, setStatusFilter] = useState<StatusFilterOption>('all');
  const [channelFilter, setChannelFilter] = useState<ChannelFilterOption>('all');
  const [selectedOrderId, setSelectedOrderId] = useState<number | null>(null);
  const [collapsedGroups, setCollapsedGroups] = useState<Set<string>>(new Set());
  const [detailTab, setDetailTab] = useState<'items' | 'details'>('items');

  // Modals
  const [showReceiptModal, setShowReceiptModal] = useState(false);
  const [showResumeModal, setShowResumeModal] = useState(false);

  // Progressive rendering state for high volume order history
  const [visibleOrdersCount, setVisibleOrdersCount] = useState(60);

  const cart = useCartStore();
  const navigate = useNavigate();
  const { isMobile } = useResponsive();

  const currentUser = useAuthStore((s) => s.user);

  const scope=syncScope();
  useEffect(() => { void syncLatestOrders(); }, [scope,currentUser?.token]);
  const orders = useLiveQuery(() => db.orders.orderBy('createdAt').reverse().filter(order => {
    if (!isOrderAccessibleToUser(order,currentUser)) return false;
    if (channelFilter !== 'all' && order.source !== channelFilter) return false;
    if (statusFilter === 'incomplete' && !['on-hold','pending','processing'].includes(order.status)) return false;
    if (!['all','incomplete'].includes(statusFilter) && order.status !== statusFilter) return false;
    const q=search.trim().toLowerCase();
    return !q || [order.orderNumber,order.customerName,order.customerEmail,order.localTransactionId].some(value=>String(value||'').toLowerCase().includes(q));
  }).limit(visibleOrdersCount+1).toArray(), [scope,channelFilter,statusFilter,search,visibleOrdersCount]);
  const selectedOrder = useLiveQuery(async () => {
    const order=selectedOrderId ? await db.orders.get(selectedOrderId) : undefined;
    return order && isOrderAccessibleToUser(order,currentUser) ? order : null;
  },[selectedOrderId,scope]);

  // Query order items for selected order - only if selectedOrder is authorized & loaded
  const orderItems = useLiveQuery<OrderItem[]>(
    async () => {
      if (!selectedOrderId || !selectedOrder) return [];
      return db.orderItems.where('orderId').equals(selectedOrderId).toArray();
    },
    [selectedOrderId, selectedOrder]
  ) || [];

  const filteredOrders = orders || [];

  // Reset visible orders count on filter change
  useEffect(() => {
    setVisibleOrdersCount(60);
  }, [channelFilter, statusFilter, search]);

  // Preserve strict creation-date descending order across every status.
  const groupedOrders = useMemo(() => {
    const groups: { key: string; label: string; orders: Order[] }[] = [];
    const slicedOrders = filteredOrders.slice(0, visibleOrdersCount);

    const regularOrders = slicedOrders;
    const dateMap = new Map<string, Order[]>();

    for (const o of regularOrders) {
      const key = getDateKey(o.createdAt);
      if (!dateMap.has(key)) dateMap.set(key, []);
      dateMap.get(key)!.push(o);
    }

    for (const [key, dayOrders] of dateMap) {
      const d = new Date(dayOrders[0].createdAt);
      const dayFormatted = `${String(d.getDate()).padStart(2, '0')}/${String(d.getMonth() + 1).padStart(2, '0')}/${d.getFullYear()}`;
      groups.push({
        key,
        label: dayFormatted,
        orders: dayOrders,
      });
    }

    return groups;
  }, [filteredOrders, statusFilter, visibleOrdersCount]);

  const toggleGroup = (key: string) => {
    setCollapsedGroups((prev) => {
      const next = new Set(prev);
      next.has(key) ? next.delete(key) : next.add(key);
      return next;
    });
  };

  const handleStatusChange = async (newStatus: OrderStatus) => {
    if (!selectedOrder) return;
    if (newStatus === 'cancelled') {
      try {
        const res = await cancelOrder(selectedOrder.id);
        if (res.success) {
          toast.success(`Order ${selectedOrder.orderNumber} cancelled and inventory restored.`);
        }
      } catch (err: any) {
        toast.error(err.message || 'Failed to cancel order: Unauthorized.');
      }
      return;
    }
    await db.orders.update(selectedOrder.id, {
      status: newStatus,
      updatedAt: new Date().toISOString(),
    });
    toast.success(`Order status updated to ${newStatus}`);
  };

  const [orderToResume, setOrderToResume] = useState<Order | null>(null);

  const handleResumeOrder = (order?: Order) => {
    const target = order || selectedOrder;
    if (!target) return;
    if (cart.items.length > 0) {
      setOrderToResume(target);
      setShowResumeModal(true);
    } else {
      executeResumeOrder(target);
    }
  };

  const executeResumeOrder = async (orderToExecute?: Order) => {
    const target = orderToExecute || orderToResume || selectedOrder;
    if (!target) return;
    const res = await cart.loadOrderIntoCart(target.id);
    if (res.success) {
      if (res.warnings && res.warnings.length > 0) {
        toast.warning(res.warnings.join(' '));
      }
      toast.success(`Resumed order ${target.orderNumber} into active basket`);
      navigate('/sale');
    } else {
      toast.error('Could not resume order: ' + (res.warnings?.join(' ') || 'Unknown error'));
    }
  };

  const orderListPanel = (
    <div className="w-full flex flex-col h-full bg-surface-0 overflow-hidden">
      {/* Top Filter & Search Toolbar - Standardized 48px Header matching POS Session */}
      <div className="h-12 px-3 border-b border-surface-200 bg-surface flex items-center gap-2 flex-shrink-0">
        <div className="flex-1 min-w-0">
          <SearchInput
            value={search}
            onChange={setSearch}
            placeholder="Search orders by #, customer, email, or transaction..."
            className="text-xs placeholder:text-xs"
          />
        </div>

        {/* Channel Filter (Desktop) */}
        <select
          value={channelFilter}
          onChange={(e) => setChannelFilter(e.target.value as ChannelFilterOption)}
          className="pos-filter-select hidden sm:inline-block w-[110px] shrink-0 truncate"
          title="Filter by channel"
        >
          <option value="all">All Channels</option>
          <option value="pos">🏪 POS</option>
          <option value="website">🌐 Web</option>
        </select>

        {/* Status Filter (Desktop) */}
        <select
          value={statusFilter}
          onChange={(e) => setStatusFilter(e.target.value as StatusFilterOption)}
          className="pos-filter-select hidden sm:inline-block w-[115px] shrink-0 truncate"
          title="Filter by status"
        >
          <option value="all">All Statuses</option>
          <option value="completed">✓ Completed</option>
          <option value="processing">⟳ Processing</option>
          <option value="on-hold">⏸ On-Hold</option>
          <option value="incomplete">⚠ Incomplete</option>
        </select>

        {/* Centralized Orders Sync Button */}
        <div className="flex-shrink-0">
          <SyncButton
            scope="orders"
            label="Sync"
            size="sm"
            variant="tonal"
            showLastSynced={false}
            className="h-8.5 px-2.5 text-xs"
          />
        </div>

        {/* Result Count Badge */}
        <div className="hidden sm:flex items-center gap-1 text-[11px] text-surface-500 font-medium shrink-0">
          <span className="px-2 py-0.5 rounded-full bg-surface-container-high border border-outline-variant/40 text-on-surface-variant font-mono">
            {Math.min(filteredOrders.length,visibleOrdersCount)}{filteredOrders.length>visibleOrdersCount ? '+' : ''}
          </span>
          <span className="hidden lg:inline">orders</span>
        </div>
      </div>

      {/* Mobile Filter Sub-Ribbon (< 768px) - Compact Ribbon matching POS Category Strip */}
      {isMobile && (
        <div className="flex items-center gap-1.5 px-3 py-1.5 border-b border-surface-200 bg-surface/50 text-xs overflow-x-auto no-scrollbar flex-shrink-0 select-none">
          <select
            value={channelFilter}
            onChange={(e) => setChannelFilter(e.target.value as ChannelFilterOption)}
            className="pos-filter-select-sm max-w-[115px] truncate"
            title="Filter by channel"
          >
            <option value="all">All Channels</option>
            <option value="pos">🏪 POS</option>
            <option value="website">🌐 Web</option>
          </select>
          <select
            value={statusFilter}
            onChange={(e) => setStatusFilter(e.target.value as StatusFilterOption)}
            className="pos-filter-select-sm max-w-[115px] truncate"
            title="Filter by status"
          >
            <option value="all">All Statuses</option>
            <option value="completed">✓ Completed</option>
            <option value="processing">⟳ Processing</option>
            <option value="on-hold">⏸ On-Hold</option>
            <option value="incomplete">⚠ Incomplete</option>
          </select>
          {(channelFilter !== 'all' || statusFilter !== 'all') && (
            <button
              type="button"
              onClick={() => {
                setChannelFilter('all');
                setStatusFilter('all');
              }}
              className="text-[11px] font-semibold text-primary hover:underline px-1 py-0.5 shrink-0"
            >
              Reset
            </button>
          )}
          <span className="text-[11px] text-surface-400 font-mono ml-auto">
            {Math.min(filteredOrders.length,visibleOrdersCount)}{filteredOrders.length>visibleOrdersCount ? '+' : ''} orders
          </span>
        </div>
      )}

            {/* Grouped Orders List */}
            <div className="flex-1 overflow-y-auto">
              {!orders ? (
                <div className="p-3 space-y-1">
                  {Array.from({ length: 8 }).map((_, i) => (
                    <SkeletonRow key={i} />
                  ))}
                </div>
              ) : groupedOrders.length === 0 ? (
                <EmptyState
                  icon={<FileText className="w-10 h-10 text-surface-300" />}
                  title="No Orders Found"
                  description={search ? `No orders match "${search}"` : 'No orders available'}
                  className="py-20"
                />
              ) : (
                <div>
                  {groupedOrders.map((group) => {
                    const isCollapsed = collapsedGroups.has(group.key);

                    return (
                      <div key={group.key}>
                        {/* Date / Group Header Banner (Calm M3 Tonal Surface) */}
                        <div className="px-4 py-2 flex items-center justify-between text-xs font-bold text-on-surface bg-surface-container-high border-y border-outline-variant/60 select-none">
                          <div className="flex items-center gap-2">
                            <button
                              type="button"
                              onClick={() => toggleGroup(group.key)}
                              className="p-0.5 hover:opacity-80 cursor-pointer text-surface-500"
                            >
                              {isCollapsed ? (
                                <ChevronRight className="w-3.5 h-3.5" />
                              ) : (
                                <ChevronDown className="w-3.5 h-3.5" />
                              )}
                            </button>
                            <span>{group.label}</span>
                          </div>
                          <div className="flex items-center gap-3">
                            <span className="text-[11px] font-semibold text-surface-500 bg-surface px-2 py-0.5 rounded-full border border-outline-variant/60">
                              {group.orders.length} order{group.orders.length !== 1 ? 's' : ''}
                            </span>
                            <MoreHorizontal className="w-4 h-4 text-surface-400" />
                          </div>
                        </div>

                        {/* Order Rows */}
                        {!isCollapsed && (
                          <div className="divide-y divide-surface-100 bg-surface">
                            {group.orders.map((order) => {
                              const isSelected = selectedOrderId === order.id;
                              const isIncomplete = ['on-hold', 'pending', 'processing'].includes(order.status);
                              const isWeb = order.source === 'website' || (!order.source && order.wooId !== null && order.shippingMethod !== 'in-store' && order.shippingMethod !== 'walk-in');

                              return (
                                <div
                                  key={order.id}
                                  role="button"
                                  tabIndex={0}
                                  onClick={() => setSelectedOrderId(order.id)}
                                  onKeyDown={(e) => {
                                    if (e.key === 'Enter' || e.key === ' ') {
                                      e.preventDefault();
                                      setSelectedOrderId(order.id);
                                    }
                                  }}
                                  className={cn(
                                    'px-4 py-3 flex items-center justify-between gap-3 text-left transition-colors cursor-pointer select-none',
                                    isSelected
                                      ? 'bg-primary-container/30 border-l-4 border-primary'
                                      : 'hover:bg-surface-container-low bg-surface'
                                  )}
                                >
                                  {/* Left: Order Title, Time, Status */}
                                  <div className="min-w-0 flex-1">
                                    <span className="font-bold text-xs text-on-surface truncate block leading-tight">
                                      {isIncomplete
                                        ? `Incomplete Order ${order.orderNumber}`
                                        : order.orderNumber}
                                    </span>
                                    <div className="flex items-center gap-1.5 mt-1 flex-wrap">
                                      <span className="text-[11px] text-surface-400 font-medium">
                                        {formatTime(order.createdAt)}
                                      </span>
                                      <StatusPill status={order.status} />
                                      <ChannelBadge source={isWeb ? 'website' : 'pos'} />
                                    </div>
                                  </div>

                                  {/* Middle: Items & Delivery Bubble */}
                                  <div className="hidden sm:flex flex-col items-start min-w-0 max-w-[150px]">
                                    <span className="text-xs font-semibold text-surface-700">
                                      {order.itemCount} item{order.itemCount !== 1 ? 's' : ''}
                                    </span>
                                    {order.shippingMethod && (
                                      <div className="pos-delivery-tag text-[9px] px-1.5 py-0.5 rounded truncate max-w-full mt-0.5 leading-tight">
                                        {order.shippingMethod}
                                      </div>
                                    )}
                                  </div>

                                  {/* Right: Price & Chevron */}
                                  <div className="flex items-center gap-2 flex-shrink-0 text-right">
                                    <span className="text-xs font-black text-on-surface tabular-nums">
                                      {formatMoney(order.total)}
                                    </span>
                                    <ChevronRight className="w-3.5 h-3.5 text-surface-300" />
                                  </div>
                                </div>
                              );
                            })}
                          </div>
                        )}
                      </div>
                    );
                  })}
                </div>
              )}

              {/* Progressive Load More button when order count is high */}
              {filteredOrders.length > visibleOrdersCount && (
                <div className="p-4 text-center border-t border-surface-200/50 bg-surface">
                  <Button
                    type="button"
                    variant="secondary"
                    size="sm"
                    onClick={() => setVisibleOrdersCount((prev) => prev + 60)}
                    className="w-full max-w-xs mx-auto text-xs font-semibold"
                  >
                    Load Older Orders
                  </Button>
                </div>
              )}
            </div>
          </div>
  );

  const orderDetailPanel = (
    <div className="w-full flex flex-col h-full bg-surface overflow-hidden">
      {!selectedOrder ? (
        <div className="flex-1 flex flex-col items-center justify-center p-8 text-center bg-surface-50/50">
          <div className="w-16 h-16 rounded-2xl bg-surface-container-high flex items-center justify-center text-surface-400 mb-3">
            <FileText className="w-8 h-8" />
          </div>
          <h3 className="text-xs font-bold text-surface-700 uppercase tracking-wider mb-1">
            SELECT ORDER
          </h3>
          <p className="text-xs text-surface-400 max-w-xs leading-relaxed">
            Select an order from the list to view its complete details and items
          </p>
        </div>
      ) : (
        <OrderDetailView
          order={selectedOrder}
          items={orderItems}
          onStatusChange={handleStatusChange}
          onPrintReceipt={() => setShowReceiptModal(true)}
          onContinue={
            ['on-hold', 'pending', 'processing'].includes(selectedOrder.status)
              ? () => handleResumeOrder(selectedOrder)
              : undefined
          }
        />
      )}
    </div>
  );

  return (
    <div className="flex h-full w-full overflow-hidden bg-surface-50 relative">
      {isMobile ? (
        selectedOrder ? (
          <div className="w-full flex flex-col h-full bg-surface overflow-hidden">
            {/* Mobile Back Header */}
            <div className="h-12 px-3 border-b border-surface-200 flex items-center justify-between bg-surface flex-shrink-0">
              <Button
                variant="ghost"
                size="sm"
                onClick={() => setSelectedOrderId(null)}
                className="text-xs font-bold gap-1.5 -ml-1 text-primary hover:text-primary-focus cursor-pointer"
              >
                <ArrowLeft className="w-4 h-4" />
                <span>Back to Orders</span>
              </Button>
              <span className="text-xs font-mono font-bold text-surface-600">
                {selectedOrder.orderNumber}
              </span>
            </div>
            <div className="flex-1 overflow-hidden">
              {orderDetailPanel}
            </div>
          </div>
        ) : (
          orderListPanel
        )
      ) : (
        <ResizableSplitView
          storageKey="zameria-split-orders"
          defaultSplit={50}
          minLeftPercent={30}
          maxLeftPercent={70}
          left={orderListPanel}
          right={orderDetailPanel}
        />
      )}

      {/* RECEIPT MODAL */}
      {selectedOrder && (
        <ReceiptModal
          open={showReceiptModal}
          onClose={() => setShowReceiptModal(false)}
          order={selectedOrder}
          items={orderItems}
        />
      )}

      {/* RESUME ORDER CONFIRMATION MODAL */}
      <Modal
        open={showResumeModal}
        onClose={() => {
          setShowResumeModal(false);
          setOrderToResume(null);
        }}
        title="Active Sale in Progress"
        size="sm"
      >
        <div className="space-y-4">
          <p className="text-xs text-surface-600 leading-relaxed">
            You have an active sale in progress ({cart.items.length} item{cart.items.length === 1 ? '' : 's'}). Continuing this held order will replace the current basket. Continue?
          </p>
          <div className="flex justify-end gap-2 pt-2">
            <Button
              variant="secondary"
              size="sm"
              onClick={() => {
                setShowResumeModal(false);
                setOrderToResume(null);
              }}
            >
              Cancel
            </Button>
            <Button
              variant="destructive"
              size="sm"
              onClick={async () => {
                setShowResumeModal(false);
                await executeResumeOrder();
              }}
            >
              Continue
            </Button>
          </div>
        </div>
      </Modal>
    </div>
  );
}
