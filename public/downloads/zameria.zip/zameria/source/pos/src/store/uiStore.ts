import { create } from 'zustand';
import type { Theme, ListMode } from '@/types';

interface UIState {
  // Sidebar
  sidebarCollapsed: boolean;
  toggleSidebar: () => void;
  setSidebarCollapsed: (collapsed: boolean) => void;

  // Theme
  theme: Theme;
  setTheme: (theme: Theme) => void;

  // List mode for sale screen
  listMode: ListMode;
  setListMode: (mode: ListMode) => void;

  // Cart thumbnails
  showCartThumbnails: boolean;
  setShowCartThumbnails: (show: boolean) => void;

  // Modals
  activeModal: string | null;
  modalData: unknown;
  openModal: (modal: string, data?: unknown) => void;
  closeModal: () => void;

  // Active slide-over
  activeSlideOver: string | null;
  slideOverData: unknown;
  openSlideOver: (id: string, data?: unknown) => void;
  closeSlideOver: () => void;

  // Demo mode
  isDemoMode: boolean;
  setDemoMode: (demo: boolean) => void;

  // Role permissions
  userRole: 'admin' | 'manager' | 'cashier';
  setUserRole: (role: 'admin' | 'manager' | 'cashier') => void;

  // Support Chat
  isSupportChatOpen: boolean;
  setSupportChatOpen: (open: boolean) => void;
  openSupportChat: () => void;
  closeSupportChat: () => void;
  toggleSupportChat: () => void;
}

export const useUIStore = create<UIState>((set) => ({
  sidebarCollapsed: typeof window !== 'undefined' ? window.innerWidth < 1024 : false,
  toggleSidebar: () => set((s) => ({ sidebarCollapsed: !s.sidebarCollapsed })),
  setSidebarCollapsed: (sidebarCollapsed) => set({ sidebarCollapsed }),

  theme: 'light',
  setTheme: (theme) => {
    set({ theme });
    applyTheme(theme);
  },

  listMode: 'grid',
  setListMode: (listMode) => set({ listMode }),

  showCartThumbnails: true,
  setShowCartThumbnails: (showCartThumbnails) => set({ showCartThumbnails }),

  activeModal: null,
  modalData: null,
  openModal: (activeModal, modalData = null) => set({ activeModal, modalData }),
  closeModal: () => set({ activeModal: null, modalData: null }),

  activeSlideOver: null,
  slideOverData: null,
  openSlideOver: (activeSlideOver, slideOverData = null) => set({ activeSlideOver, slideOverData }),
  closeSlideOver: () => set({ activeSlideOver: null, slideOverData: null }),

  isDemoMode: false,
  setDemoMode: (isDemoMode) => set({ isDemoMode }),

  userRole: 'admin',
  setUserRole: (userRole) => set({ userRole }),

  isSupportChatOpen: false,
  setSupportChatOpen: (isSupportChatOpen) => set({ isSupportChatOpen }),
  openSupportChat: () => set({ isSupportChatOpen: true }),
  closeSupportChat: () => set({ isSupportChatOpen: false }),
  toggleSupportChat: () => set((s) => ({ isSupportChatOpen: !s.isSupportChatOpen })),
}));

function applyTheme(theme: Theme): void {
  const root = document.documentElement;
  root.classList.remove('light', 'dark');
  
  let isDark = false;
  if (theme === 'system') {
    isDark = window.matchMedia('(prefers-color-scheme: dark)').matches;
  } else {
    isDark = theme === 'dark';
  }
  root.classList.add(isDark ? 'dark' : 'light');

  // Update meta theme-color for browser chrome / status bar
  const meta = document.querySelector('meta[name="theme-color"]');
  if (meta) {
    meta.setAttribute('content', isDark ? '#0f172a' : '#ffffff');
  }
}

// Apply theme on initial load and listen for system changes
if (typeof window !== 'undefined') {
  applyTheme(useUIStore.getState().theme);

  window.matchMedia('(prefers-color-scheme: dark)').addEventListener('change', () => {
    const { theme } = useUIStore.getState();
    if (theme === 'system') {
      applyTheme('system');
    }
  });
}
