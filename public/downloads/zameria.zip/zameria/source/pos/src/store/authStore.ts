import { create } from 'zustand';
import type { AuthUser, RolePermissions, ZameriaRole } from '@/types';
import { useUIStore } from './uiStore';
import { DEMO_USERS } from '@/services/auth/permissions';
import {
  revalidateUserSession,
  authenticateUser,
  connectWooClient,
  signOutDevice,
  type LoginCredentials,
} from '@/services/auth';
import { demoLoginEnabled, zameriaConfig } from '@/services/zameria/config';
import { useConnectionStore } from './connectionStore';

const STORAGE_KEY = 'zameria_auth_session';
const isBrowser = typeof localStorage !== 'undefined' && import.meta.env?.MODE !== 'product-preview';

interface AuthState {
  user: AuthUser | null;
  isAuthenticated: boolean;
  isLoading: boolean;
  error: string | null;

  // Actions
  login: (userOrCredentials: AuthUser | LoginCredentials) => Promise<void>;
  logout: () => void;
  hasPermission: (permission: keyof RolePermissions) => boolean;
  revalidate: () => Promise<boolean>;
  switchDemoRole: (role: ZameriaRole | 'admin' | 'manager' | 'cashier' | 'cashier_a' | 'cashier_b' | 'custom' | string) => void;
  setError: (error: string | null) => void;
}

// Initial session from localStorage
function getInitialSession(): { user: AuthUser | null; isAuthenticated: boolean } {
  if (isBrowser) {
    try {
      const raw = localStorage.getItem(STORAGE_KEY);
      if (raw) {
        const parsed = JSON.parse(raw) as AuthUser;
        // Real sessions carry a device token; token-less demo sessions only exist in dev builds.
        if (parsed && parsed.permissions && (parsed.token || demoLoginEnabled())) {
          return { user: parsed, isAuthenticated: true };
        }
      }
    } catch {}
  }

  return { user: null, isAuthenticated: false };
}

const initial = getInitialSession();
connectWooClient(initial.user);
if (initial.user) {
  useConnectionStore.getState().setConnected(
    initial.user.storeUrl || zameriaConfig.storeUrl,
    initial.user.storeName || zameriaConfig.storeName || 'Store'
  );
}

export const useAuthStore = create<AuthState>((set, get) => ({
  user: initial.user,
  isAuthenticated: initial.isAuthenticated,
  isLoading: false,
  error: null,

  setError: (error: string | null) => set({ error }),

  login: async (userOrCredentials: AuthUser | LoginCredentials) => {
    // If passed full AuthUser object
    if ('role' in userOrCredentials && 'permissions' in userOrCredentials) {
      const user = userOrCredentials as AuthUser;
      connectWooClient(user);
      if (isBrowser) {
        try {
          localStorage.setItem(STORAGE_KEY, JSON.stringify(user));
        } catch {}
      }
      set({ user, isAuthenticated: true, isLoading: false, error: null });

      // Sync UI store legacy role
      const legacyRole =
        user.role === 'administrator'
          ? 'admin'
          : user.role === 'shop_manager'
          ? 'manager'
          : 'cashier';
      useUIStore.getState().setUserRole(legacyRole);
      useConnectionStore.getState().setConnected(
        user.storeUrl || zameriaConfig.storeUrl,
        user.storeName || zameriaConfig.storeName || 'Store'
      );
      return;
    }

    // Otherwise authenticate with credentials
    set({ isLoading: true, error: null });
    try {
      const authenticatedUser = await authenticateUser(userOrCredentials as LoginCredentials);
      connectWooClient(authenticatedUser);
      if (isBrowser) {
        try {
          localStorage.setItem(STORAGE_KEY, JSON.stringify(authenticatedUser));
        } catch {}
      }
      set({ user: authenticatedUser, isAuthenticated: true, isLoading: false, error: null });

      const legacyRole =
        authenticatedUser.role === 'administrator'
          ? 'admin'
          : authenticatedUser.role === 'shop_manager'
          ? 'manager'
          : 'cashier';
      useUIStore.getState().setUserRole(legacyRole);
      useConnectionStore.getState().setConnected(
        authenticatedUser.storeUrl || zameriaConfig.storeUrl,
        authenticatedUser.storeName || zameriaConfig.storeName || 'Store'
      );
    } catch (err: any) {
      const errorMsg = err.message || 'Authentication failed.';
      set({ error: errorMsg, isLoading: false });
      throw err;
    }
  },

  logout: () => {
    // Unsynced sales stay in IndexedDB and upload after the next sign-in on this device.
    const signingOutUser = get().user;
    void signOutDevice(signingOutUser);
    connectWooClient(null);
    useConnectionStore.getState().setDisconnected();
    if (isBrowser) {
      try {
        const saved = localStorage.getItem(STORAGE_KEY);
        // Another tab may already have saved a newer login in shared storage.
        if (!saved || JSON.parse(saved)?.token === signingOutUser?.token) {
          localStorage.removeItem(STORAGE_KEY);
        }
      } catch {}
    }
    set({ user: null, isAuthenticated: false, isLoading: false, error: null });
  },

  hasPermission: (permission: keyof RolePermissions) => {
    const { user, isAuthenticated } = get();
    if (!isAuthenticated || !user) return false;
    return Boolean(user.permissions[permission]);
  },

  revalidate: async () => {
    const { user } = get();
    if (!user) return false;

    set({ isLoading: true });
    try {
      const result = await revalidateUserSession(user);
      if (get().user !== user) return false; // A late response must not replace a newer staff session.
      if (!result.valid) {
        // Access revoked on WooCommerce
        get().logout();
        set({ isLoading: false });
        return false;
      }

      if (result.updatedUser) {
        await get().login(result.updatedUser);
      }
      set({ isLoading: false });
      return true;
    } catch {
      if (get().user !== user) return false;
      set({ isLoading: false });
      return true; // Retain offline session on network failure
    }
  },

  switchDemoRole: (role: ZameriaRole | 'admin' | 'manager' | 'cashier' | 'cashier_a' | 'cashier_b' | 'custom' | string) => {
    // Role switching is a development aid; a real signed-in session can never change its own role.
    if (!demoLoginEnabled() || get().user?.token) return;
    const targetUser = DEMO_USERS[role];
    if (targetUser) {
      const user: AuthUser = {
        ...targetUser,
        lastValidatedAt: new Date().toISOString(),
      };
      if (isBrowser) {
        try {
          localStorage.setItem(STORAGE_KEY, JSON.stringify(user));
        } catch {}
      }
      set({ user, isAuthenticated: true, error: null });

      const legacyRole =
        user.role === 'administrator'
          ? 'admin'
          : user.role === 'shop_manager'
          ? 'manager'
          : 'cashier';
      useUIStore.getState().setUserRole(legacyRole);
    }
  },
}));

// Synchronize legacy UI role on init
if (initial.user) {
  const legacyRole =
    initial.user.role === 'administrator'
      ? 'admin'
      : initial.user.role === 'shop_manager'
      ? 'manager'
      : 'cashier';
  useUIStore.getState().setUserRole(legacyRole);
}
