import { create } from 'zustand';
import type {
  SyncScope,
  SyncEntity,
  SyncSummary,
  FailedSyncItem,
  SyncLogEntry,
} from '@/types';

interface SyncState {
  isSyncing: boolean;
  activeScope: SyncScope | null;
  currentEntity: string | null;
  progress: { current: number; total: number } | null;
  entityProgress: { entity: string; current: number; total: number; stage?: string } | null;
  pendingCount: number;
  conflictCount: number;
  lastSyncedAt: string | null;
  nextSyncAt: string | null;
  syncErrors: string[];
  lastSyncedByScope: Record<SyncScope, string | null>;
  lastSyncedByEntity: Record<SyncEntity, string | null>;
  lastSyncSummary: SyncSummary | null;
  salesReady: boolean;
  ordersReady: boolean;
  failedItems: FailedSyncItem[];
  syncHistory: SyncLogEntry[];

  // Actions
  setSalesReady: (ready: boolean) => void;
  setOrdersReady: (ready: boolean) => void;
  startSync: (entity: string) => void;
  startScopeSync: (scope: SyncScope, initialEntity?: string) => void;
  updateProgress: (current: number, total: number) => void;
  updateEntityProgress: (entity: string, current: number, total: number, stage?: string) => void;
  recordEntitySyncSuccess: (entity: SyncEntity, timestamp?: string) => void;
  finishSync: () => void;
  finishScopeSync: (summary: SyncSummary) => void;
  setSyncError: (error: string) => void;
  clearErrors: () => void;
  setPendingCount: (count: number) => void;
  incrementPending: () => void;
  clearPending: () => void;
  setConflictCount: (count: number) => void;
  setNextSync: (timestamp: string | null) => void;
  addFailedItem: (item: Omit<FailedSyncItem, 'id' | 'timestamp' | 'retryCount'>) => void;
  removeFailedItem: (id: string) => void;
  clearFailedItems: () => void;
}

const STORAGE_KEY_SCOPE = 'zameria_sync_last_by_scope';
const STORAGE_KEY_ENTITY = 'zameria_sync_last_by_entity';

function safeStorageGet(key: string): string | null {
  try {
    if (typeof localStorage !== 'undefined') {
      return localStorage.getItem(key);
    }
  } catch {}
  return null;
}

function safeStorageSet(key: string, value: string): void {
  try {
    if (typeof localStorage !== 'undefined') {
      localStorage.setItem(key, value);
    }
  } catch {}
}

function loadPersistedTimestamps<T extends string>(key: string, defaultKeys: T[]): Record<T, string | null> {
  const result: Record<string, string | null> = {};
  defaultKeys.forEach((k) => {
    result[k] = null;
  });
  try {
    const raw = safeStorageGet(key);
    if (raw) {
      const parsed = JSON.parse(raw);
      Object.assign(result, parsed);
    }
  } catch {}
  return result as Record<T, string | null>;
}

const initialScopes: SyncScope[] = ['full', 'products', 'inventory', 'orders', 'customers', 'coupons', 'pos', 'dashboard'];
const initialEntities: SyncEntity[] = ['products', 'categories', 'inventory', 'orders', 'customers', 'coupons'];

export const useSyncStore = create<SyncState>((set, get) => ({
  isSyncing: false,
  activeScope: null,
  currentEntity: null,
  progress: null,
  entityProgress: null,
  pendingCount: 0,
  conflictCount: 0,
  lastSyncedAt: safeStorageGet('zameria_last_synced_at') || null,
  nextSyncAt: null,
  syncErrors: [],
  lastSyncedByScope: loadPersistedTimestamps<SyncScope>(STORAGE_KEY_SCOPE, initialScopes),
  lastSyncedByEntity: loadPersistedTimestamps<SyncEntity>(STORAGE_KEY_ENTITY, initialEntities),
  lastSyncSummary: null,
  salesReady: false,
  ordersReady: false,
  failedItems: [],
  syncHistory: [],

  setSalesReady: (salesReady) => set({ salesReady }),
  setOrdersReady: (ordersReady) => set({ ordersReady }),

  startSync: (entity) =>
    set({
      isSyncing: true,
      currentEntity: entity,
      progress: { current: 0, total: 0 },
      entityProgress: { entity, current: 0, total: 0 },
    }),

  startScopeSync: (scope, initialEntity) =>
    set({
      isSyncing: true,
      activeScope: scope,
      currentEntity: initialEntity || scope,
      progress: { current: 0, total: 0 },
      entityProgress: initialEntity ? { entity: initialEntity, current: 0, total: 0 } : null,
      syncErrors: [],
    }),

  updateProgress: (current, total) => set({ progress: { current, total } }),

  updateEntityProgress: (entity, current, total, stage) =>
    set({
      currentEntity: entity,
      entityProgress: { entity, current, total, stage },
      progress: { current, total },
    }),

  recordEntitySyncSuccess: (entity, timestamp) => {
    const now = timestamp || new Date().toISOString();
    set((state) => {
      const updated = { ...state.lastSyncedByEntity, [entity]: now };
      safeStorageSet(STORAGE_KEY_ENTITY, JSON.stringify(updated));
      return { lastSyncedByEntity: updated };
    });
  },

  finishSync: () => {
    const now = new Date().toISOString();
    safeStorageSet('zameria_last_synced_at', now);
    set({
      isSyncing: false,
      activeScope: null,
      currentEntity: null,
      progress: null,
      entityProgress: null,
      lastSyncedAt: now,
    });
  },

  finishScopeSync: (summary) => {
    const now = summary.completedAt || new Date().toISOString();
    safeStorageSet('zameria_last_synced_at', now);

    set((state) => {
      const updatedScopes = { ...state.lastSyncedByScope, [summary.scope]: now };
      safeStorageSet(STORAGE_KEY_SCOPE, JSON.stringify(updatedScopes));

      const logEntry: SyncLogEntry = {
        id: `sync-log-${Date.now()}-${Math.random().toString(36).slice(2, 6)}`,
        timestamp: now,
        scope: summary.scope,
        status: summary.status,
        durationMs: summary.durationMs,
        summary: `${summary.totalImported} imported, ${summary.totalUpdated} updated, ${summary.totalFailed} failed`,
        errors: summary.error ? [summary.error] : undefined,
      };

      return {
        isSyncing: false,
        activeScope: null,
        currentEntity: null,
        progress: null,
        entityProgress: null,
        lastSyncedAt: now,
        lastSyncedByScope: updatedScopes,
        lastSyncSummary: summary,
        syncHistory: [logEntry, ...state.syncHistory].slice(0, 50),
      };
    });
  },

  setSyncError: (error) =>
    set((s) => ({
      syncErrors: [...s.syncErrors, error],
      isSyncing: false,
      activeScope: null,
      currentEntity: null,
      progress: null,
      entityProgress: null,
    })),

  clearErrors: () => set({ syncErrors: [] }),

  setPendingCount: (pendingCount) => set({ pendingCount }),
  incrementPending: () => set((s) => ({ pendingCount: s.pendingCount + 1 })),
  clearPending: () => set({ pendingCount: 0 }),
  setConflictCount: (conflictCount) => set({ conflictCount }),
  setNextSync: (nextSyncAt) => set({ nextSyncAt }),

  addFailedItem: (item) =>
    set((state) => {
      const existing = state.failedItems.find(
        (f) => f.entity === item.entity && f.entityId === item.entityId && f.operation === item.operation
      );
      if (existing) {
        return {
          failedItems: state.failedItems.map((f) =>
            f.id === existing.id
              ? { ...f, error: item.error, timestamp: new Date().toISOString(), retryCount: f.retryCount + 1 }
              : f
          ),
        };
      }
      const newItem: FailedSyncItem = {
        ...item,
        id: `fail-${Date.now()}-${Math.random().toString(36).slice(2, 6)}`,
        timestamp: new Date().toISOString(),
        retryCount: 0,
      };
      return { failedItems: [...state.failedItems, newItem] };
    }),

  removeFailedItem: (id) =>
    set((state) => ({
      failedItems: state.failedItems.filter((f) => f.id !== id),
    })),

  clearFailedItems: () => set({ failedItems: [] }),
}));
