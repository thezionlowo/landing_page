import { create } from 'zustand';
import type { ConnectionStatus } from '@/types';

interface ConnectionState {
  status: ConnectionStatus;
  isOnline: boolean;
  isConnectedToStore: boolean;
  storeUrl: string;
  storeName: string;
  lastSyncedAt: string | null;
  syncProgress: { entity: string; current: number; total: number } | null;
  error: string | null;

  // Actions
  setStatus: (status: ConnectionStatus) => void;
  setOnline: (online: boolean) => void;
  setConnected: (url: string, name: string) => void;
  setDisconnected: () => void;
  setSyncProgress: (progress: { entity: string; current: number; total: number } | null) => void;
  setLastSynced: (timestamp: string) => void;
  setError: (error: string | null) => void;
}

const getInitialOnline = (): boolean =>
  typeof navigator !== 'undefined' && typeof navigator.onLine === 'boolean' ? navigator.onLine : true;

export const useConnectionStore = create<ConnectionState>((set, get) => ({
  status: 'DISCONNECTED',
  isOnline: getInitialOnline(),
  isConnectedToStore: false,
  storeUrl: '',
  storeName: '',
  lastSyncedAt: null,
  syncProgress: null,
  error: null,

  setStatus: (status) => set({ status }),
  setOnline: (isOnline) => set({ isOnline, status: isOnline ? (get().isConnectedToStore ? 'ONLINE' : 'DISCONNECTED') : 'OFFLINE' }),
  setConnected: (storeUrl, storeName) => set({
    isConnectedToStore: true,
    storeUrl,
    storeName,
    status: get().isOnline ? 'ONLINE' : 'OFFLINE',
    error: null,
  }),
  setDisconnected: () => set({
    isConnectedToStore: false,
    storeUrl: '',
    storeName: '',
    status: 'DISCONNECTED',
    syncProgress: null,
    error: null,
  }),
  setSyncProgress: (syncProgress) => set({
    syncProgress,
    status: syncProgress ? 'SYNCING' : (get().error ? 'SYNC_ERROR' : (get().isOnline ? 'ONLINE' : 'OFFLINE')),
  }),
  setLastSynced: (lastSyncedAt) => set({ lastSyncedAt }),
  setError: (error) => set({
    error,
    status: error ? 'SYNC_ERROR' : (get().isOnline ? 'ONLINE' : 'OFFLINE'),
  }),
}));
