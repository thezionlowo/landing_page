import { create } from 'zustand';
import { db } from '@/db';
import { generateId, toISOString } from '@/lib';
import { calculateLineTotal, calculateTransactionFee } from '@/lib';
import { useConnectionStore } from './connectionStore';
import { useSyncStore } from './syncStore';
import { useAuthStore } from './authStore';
import { isOrderAccessibleToUser } from '@/services/auth';
import { validateWooCoupon, calculateCouponDiscount } from '@/services/woocommerce';
import { sessionToken } from '@/services/zameria/session';
import { nextReceiptNumber } from '@/services/zameria/sales';
import { runPosSync } from '@/services/zameria/posSync';
import { toast } from 'sonner';
import type {
  CartItem,
  Cart,
  CartTotals,
  Discount,
  Product,
  ProductVariation,
  Order,
  OrderItem,
  PaymentSplit,
  AppliedCoupon,
} from '@/types';

interface CartState {
  cartId: number | null;
  items: CartItem[];
  customerId: number | null;
  wooCustomerId?: number | null;
  customerName: string;
  customerEmail: string;
  customerPhone?: string;
  paymentMethod: string;
  paymentMethodTitle: string;
  note: string;
  appliedCoupon: AppliedCoupon | null;
  resumedOrderId: number | null;
  resumedOrderNumber: string | null;
  resumedWooId: number | null;
  resumedAttendedBy: string | null;
  resumedCreatedByUserId: number | null;
  isLoading: boolean;
  feePercentage: number;
  feeLabel: string;

  // Computed
  getTotals: () => CartTotals;

  // Actions
  initCart: () => Promise<void>;
  addItem: (product: Product, variation?: ProductVariation) => Promise<void>;
  removeItem: (itemId: number) => Promise<void>;
  updateQuantity: (itemId: number, quantity: number) => Promise<void>;
  applyDiscount: (itemId: number, discount: Discount) => Promise<void>;
  removeDiscount: (itemId: number) => Promise<void>;
  applyCoupon: (code: string) => Promise<{ success: boolean; error?: string; coupon?: AppliedCoupon }>;
  removeCoupon: () => Promise<void>;
  setCustomer: (id: number | null, name: string, email?: string, phone?: string, wooCustomerId?: number | null) => void;
  setPaymentMethod: (method: string, title: string) => void;
  setNote: (note: string) => void;
  clearCart: () => Promise<void>;
  saveAsOnHold: () => Promise<number>;
  completeCheckout: (params?: {
    paymentMethod?: string;
    paymentMethodTitle?: string;
    tenderedAmount?: number;
    paymentSplits?: PaymentSplit[];
    note?: string;
  }) => Promise<{ order: Order; items: OrderItem[] } | null>;
  loadOrderIntoCart: (orderId: number) => Promise<{ success: boolean; warnings?: string[] }>;
}

let cartMutationPromise = Promise.resolve();

/** Variation sold on a cart line, if any, plus the WooCommerce id whose stock it uses. */
async function stockIdentity(item: CartItem): Promise<{ wooVariationId: number | null; stockOwnerWooId: number | null }> {
  const product = await db.products.get(item.productId);
  const variation = item.variationId ? product?.variations?.find((v) => v.id === item.variationId) : undefined;
  if (variation) {
    return { wooVariationId: variation.wooId, stockOwnerWooId: variation.stockOwnerWooId ?? variation.wooId };
  }
  return { wooVariationId: null, stockOwnerWooId: product?.stockOwnerWooId ?? product?.wooId ?? null };
}

/**
 * Reduces stock on this till only. The store applies the real reduction when the sale uploads,
 * and the till's figure is then replaced by the store's (see services/zameria/catalog.ts).
 */
async function reduceLocalStock(item: CartItem): Promise<void> {
  const product = await db.products.get(item.productId);
  if (!product) return;
  if (item.variationId && product.variations) {
    await db.products.update(product.id, {
      variations: product.variations.map((v) => {
        if (v.id !== item.variationId || !v.manageStock || v.stockQuantity === null) return v;
        const stockQuantity = v.stockQuantity - item.quantity;
        return { ...v, stockQuantity, stockStatus: stockQuantity <= 0 ? 'outofstock' as const : v.stockStatus };
      }),
    });
  } else if (product.manageStock && product.stockQuantity !== null) {
    const stockQuantity = product.stockQuantity - item.quantity;
    await db.products.update(product.id, {
      stockQuantity,
      stockStatus: stockQuantity <= 0 ? 'outofstock' : product.stockStatus,
    });
  }
}
let isCheckingOut = false;
let isHolding = false;

export const useCartStore = create<CartState>((set, get) => ({
  cartId: null,
  items: [],
  customerId: null,
  customerName: '',
  customerEmail: '',
  paymentMethod: 'cash',
  paymentMethodTitle: 'Cash',
  note: '',
  appliedCoupon: null,
  resumedOrderId: null,
  resumedOrderNumber: null,
  resumedWooId: null,
  resumedAttendedBy: null,
  resumedCreatedByUserId: null,
  isLoading: false,
  feePercentage: 0,
  feeLabel: '',

  getTotals: () => {
    const { items, feePercentage, appliedCoupon } = get();
    const itemCount = items.reduce((sum, item) => sum + item.quantity, 0);
    const subtotal = items.reduce((sum, item) => sum + item.lineTotal, 0);
    const couponDiscount = appliedCoupon ? appliedCoupon.discountKobo : 0;
    const discountedSubtotal = Math.max(0, subtotal - couponDiscount);
    const transactionFee = feePercentage > 0 ? calculateTransactionFee(discountedSubtotal, feePercentage) : 0;
    const total = discountedSubtotal + transactionFee;
    return { itemCount, subtotal, couponDiscount, discountedSubtotal, transactionFee, total };
  },

  initCart: async () => {
    set({ isLoading: true });
    try {
      // Check for existing cart
      const existingCart = await db.cart.toCollection().first();
      if (existingCart) {
        const items = await db.cartItems.where('cartId').equals(existingCart.id).toArray();
        set({
          cartId: existingCart.id,
          items,
          customerId: existingCart.customerId,
          customerName: existingCart.customerName,
          customerEmail: existingCart.customerEmail,
          paymentMethod: existingCart.paymentMethod || 'cash',
          paymentMethodTitle: existingCart.paymentMethodTitle || 'Cash',
          note: existingCart.note || '',
          appliedCoupon: existingCart.appliedCoupon || null,
          resumedOrderId: existingCart.resumedOrderId || null,
          resumedOrderNumber: existingCart.resumedOrderNumber || null,
          resumedWooId: existingCart.resumedWooId || null,
          resumedAttendedBy: existingCart.resumedAttendedBy || null,
          resumedCreatedByUserId: existingCart.resumedCreatedByUserId || null,
          isLoading: false,
        });
      } else {
        // Create new cart
        const cartId = await db.cart.add({
          storeId: 1,
          customerId: null,
          customerName: '',
          customerEmail: '',
          paymentMethod: 'cash',
          paymentMethodTitle: 'Cash',
          note: '',
          appliedCoupon: null,
          createdAt: toISOString(),
          updatedAt: toISOString(),
        } as Cart);
        set({ cartId: cartId as number, items: [], appliedCoupon: null, isLoading: false });
      }
    } catch {
      set({ isLoading: false });
    }
  },

  addItem: async (product: Product, variation?: ProductVariation) => {
    return (cartMutationPromise = cartMutationPromise
      .then(async () => {
        const { cartId, items } = get();
        if (!cartId) return;

        // Secondary sellability check: product must be published
        if (product.status && product.status !== 'publish') {
          toast.error(`"${product.name}" is not published and cannot be sold.`);
          return;
        }

        // Stock availability & out-of-stock validation
        const targetManageStock = variation ? variation.manageStock : product.manageStock;
        const targetStockQty = variation ? variation.stockQuantity : product.stockQuantity;
        const isOutOfStock = variation
          ? variation.stockStatus === 'outofstock' || (targetManageStock && targetStockQty !== null && targetStockQty <= 0)
          : product.stockStatus === 'outofstock' || (targetManageStock && targetStockQty !== null && targetStockQty <= 0);

        const displayName = variation
          ? `${product.name}${variation.attributes?.length ? ` (${variation.attributes.map((a) => a.option).join(' / ')})` : ''}`
          : product.name;

        if (isOutOfStock) {
          toast.error(`"${displayName}" is out of stock`);
          return;
        }

        // Check if product / variation already in cart
        const existing = items.find(
          (item) =>
            item.productId === product.id &&
            (variation ? item.variationId === variation.id : !item.variationId)
        );

        const currentQtyInCart = existing ? existing.quantity : 0;
        if (targetManageStock && targetStockQty !== null && currentQtyInCart + 1 > targetStockQty) {
          toast.warning(`Cannot add more. Only ${targetStockQty} available in stock.`);
          return;
        }

        let updatedItems: CartItem[];

        if (existing) {
          // Increment quantity
          const newQuantity = existing.quantity + 1;
          const lineTotal = calculateLineTotal(existing.unitPrice, newQuantity, existing.discount);
          await db.cartItems.update(existing.id, { quantity: newQuantity, lineTotal });
          updatedItems = items.map((item) =>
            item.id === existing.id ? { ...item, quantity: newQuantity, lineTotal } : item
          );
          set({ items: updatedItems });
        } else {
          // Add new item
          const price = variation
            ? (variation.salePrice ?? variation.price)
            : (product.salePrice ?? product.price);
          const regPrice = variation ? variation.regularPrice : product.regularPrice;
          const salePrice = variation ? variation.salePrice : product.salePrice;
          const variationTitle = variation?.attributes?.map((a) => a.option).join(' / ');
          const itemName = variationTitle ? `${product.name} - ${variationTitle}` : product.name;
          const itemSku = variation?.sku || product.sku;
          const itemImage = variation?.image?.src || product.images?.[0]?.src || '';

          const newItem: Omit<CartItem, 'id'> = {
            cartId,
            productId: product.id,
            wooProductId: product.wooId,
            variationId: variation?.id,
            variationTitle,
            name: itemName,
            sku: itemSku,
            image: itemImage,
            unitPrice: price,
            regularPrice: regPrice,
            salePrice,
            quantity: 1,
            discount: null,
            lineTotal: price,
          };

          const id = await db.cartItems.add(newItem as CartItem);
          updatedItems = [...items, { ...newItem, id: id as number }];
          set({ items: updatedItems });
        }

        // Reactively recheck active WooCommerce coupon
        const { appliedCoupon } = get();
        if (appliedCoupon) {
          const res = await calculateCouponDiscount(appliedCoupon, updatedItems, get().customerEmail);
          if ('error' in res) {
            set({ appliedCoupon: null });
            await db.cart.update(cartId, { appliedCoupon: null });
            toast.warning(`Coupon "${appliedCoupon.code}" removed: ${res.error}`);
          } else if (res.discountKobo !== appliedCoupon.discountKobo) {
            const updated: AppliedCoupon = { ...appliedCoupon, discountKobo: res.discountKobo };
            set({ appliedCoupon: updated });
            await db.cart.update(cartId, { appliedCoupon: updated });
          }
        }
      })
      .catch((err) => {
        console.error('Cart mutation error:', err);
      }));
  },

  removeItem: async (itemId: number) => {
    const { items, cartId, appliedCoupon } = get();
    await db.cartItems.delete(itemId);
    const updatedItems = items.filter((item) => item.id !== itemId);
    set({ items: updatedItems });

    // Reactively recheck active WooCommerce coupon
    if (appliedCoupon && cartId) {
      if (updatedItems.length === 0) {
        set({ appliedCoupon: null });
        await db.cart.update(cartId, { appliedCoupon: null });
      } else {
        const res = await calculateCouponDiscount(appliedCoupon, updatedItems, get().customerEmail);
        if ('error' in res) {
          set({ appliedCoupon: null });
          await db.cart.update(cartId, { appliedCoupon: null });
          toast.warning(`Coupon "${appliedCoupon.code}" removed: ${res.error}`);
        } else if (res.discountKobo !== appliedCoupon.discountKobo) {
          const updated: AppliedCoupon = { ...appliedCoupon, discountKobo: res.discountKobo };
          set({ appliedCoupon: updated });
          await db.cart.update(cartId, { appliedCoupon: updated });
        }
      }
    }
  },

  updateQuantity: async (itemId: number, quantity: number) => {
    if (quantity < 1) return;
    const { items, cartId, appliedCoupon } = get();
    const item = items.find((i) => i.id === itemId);
    if (!item) return;

    // Check available stock limits
    const prod = await db.products.get(item.productId);
    if (prod && prod.manageStock && prod.stockQuantity !== null) {
      if (quantity > prod.stockQuantity) {
        toast.warning(`Quantity capped at maximum available stock (${prod.stockQuantity}).`);
        quantity = prod.stockQuantity;
      }
    }

    const lineTotal = calculateLineTotal(item.unitPrice, quantity, item.discount);
    await db.cartItems.update(itemId, { quantity, lineTotal });
    const updatedItems = items.map((i) =>
      i.id === itemId ? { ...i, quantity, lineTotal } : i
    );
    set({ items: updatedItems });

    // Reactively recheck active WooCommerce coupon
    if (appliedCoupon && cartId) {
      const res = await calculateCouponDiscount(appliedCoupon, updatedItems, get().customerEmail);
      if ('error' in res) {
        set({ appliedCoupon: null });
        await db.cart.update(cartId, { appliedCoupon: null });
        toast.warning(`Coupon "${appliedCoupon.code}" removed: ${res.error}`);
      } else if (res.discountKobo !== appliedCoupon.discountKobo) {
        const updated: AppliedCoupon = { ...appliedCoupon, discountKobo: res.discountKobo };
        set({ appliedCoupon: updated });
        await db.cart.update(cartId, { appliedCoupon: updated });
      }
    }
  },

  applyDiscount: async (itemId: number, discount: Discount) => {
    const { items, cartId, appliedCoupon } = get();
    const item = items.find((i) => i.id === itemId);
    if (!item) return;

    const lineTotal = calculateLineTotal(item.unitPrice, item.quantity, discount);
    if (lineTotal < 0) return;

    await db.cartItems.update(itemId, { discount, lineTotal });
    const updatedItems = items.map((i) =>
      i.id === itemId ? { ...i, discount, lineTotal } : i
    );
    set({ items: updatedItems });

    // Reactively recheck active WooCommerce coupon
    if (appliedCoupon && cartId) {
      const res = await calculateCouponDiscount(appliedCoupon, updatedItems, get().customerEmail);
      if ('error' in res) {
        set({ appliedCoupon: null });
        await db.cart.update(cartId, { appliedCoupon: null });
        toast.warning(`Coupon "${appliedCoupon.code}" removed: ${res.error}`);
      } else if (res.discountKobo !== appliedCoupon.discountKobo) {
        const updated: AppliedCoupon = { ...appliedCoupon, discountKobo: res.discountKobo };
        set({ appliedCoupon: updated });
        await db.cart.update(cartId, { appliedCoupon: updated });
      }
    }
  },

  removeDiscount: async (itemId: number) => {
    const { items, cartId, appliedCoupon } = get();
    const item = items.find((i) => i.id === itemId);
    if (!item) return;

    const lineTotal = calculateLineTotal(item.unitPrice, item.quantity, null);
    await db.cartItems.update(itemId, { discount: null, lineTotal });
    const updatedItems = items.map((i) =>
      i.id === itemId ? { ...i, discount: null, lineTotal } : i
    );
    set({ items: updatedItems });

    // Reactively recheck active WooCommerce coupon
    if (appliedCoupon && cartId) {
      const res = await calculateCouponDiscount(appliedCoupon, updatedItems, get().customerEmail);
      if ('error' in res) {
        set({ appliedCoupon: null });
        await db.cart.update(cartId, { appliedCoupon: null });
        toast.warning(`Coupon "${appliedCoupon.code}" removed: ${res.error}`);
      } else if (res.discountKobo !== appliedCoupon.discountKobo) {
        const updated: AppliedCoupon = { ...appliedCoupon, discountKobo: res.discountKobo };
        set({ appliedCoupon: updated });
        await db.cart.update(cartId, { appliedCoupon: updated });
      }
    }
  },

  applyCoupon: async (code: string) => {
    const { items, customerEmail, cartId } = get();
    const result = await validateWooCoupon(code, items, customerEmail);
    if (!result.valid || !result.coupon) {
      return { success: false, error: result.error || 'Failed to apply coupon.' };
    }
    set({ appliedCoupon: result.coupon });
    if (cartId) {
      await db.cart.update(cartId, { appliedCoupon: result.coupon });
    }
    return { success: true, coupon: result.coupon };
  },

  removeCoupon: async () => {
    const { cartId } = get();
    set({ appliedCoupon: null });
    if (cartId) {
      await db.cart.update(cartId, { appliedCoupon: null });
    }
  },

  setCustomer: (customerId, customerName, customerEmail = '', customerPhone = '', wooCustomerId = null) => {
    set({ customerId, wooCustomerId, customerName, customerEmail, customerPhone });
    const { cartId, appliedCoupon, items } = get();
    if (cartId) {
      db.cart.update(cartId, { customerId, customerName, customerEmail });
    }
    // If customer changed and coupon has email restrictions, recheck eligibility
    if (appliedCoupon && cartId) {
      calculateCouponDiscount(appliedCoupon, items, customerEmail).then((res) => {
        if ('error' in res) {
          set({ appliedCoupon: null });
          db.cart.update(cartId, { appliedCoupon: null });
          toast.warning(`Coupon "${appliedCoupon.code}" removed: ${res.error}`);
        }
      });
    }
  },

  setPaymentMethod: (paymentMethod, paymentMethodTitle) => {
    set({ paymentMethod, paymentMethodTitle });
    const { cartId } = get();
    if (cartId) {
      db.cart.update(cartId, { paymentMethod, paymentMethodTitle });
    }
  },

  setNote: (note) => {
    set({ note });
    const { cartId } = get();
    if (cartId) {
      db.cart.update(cartId, { note });
    }
  },

  clearCart: async () => {
    const { cartId } = get();
    if (cartId) {
      await db.cartItems.where('cartId').equals(cartId).delete();
      await db.cart.delete(cartId);
    }
    const newCartId = await db.cart.add({
      storeId: 1,
      customerId: null,
      customerName: '',
      customerEmail: '',
      paymentMethod: 'cash',
      paymentMethodTitle: 'Cash',
      note: '',
      appliedCoupon: null,
      createdAt: toISOString(),
      updatedAt: toISOString(),
    } as Cart);
    set({
      cartId: newCartId as number,
      items: [],
      customerId: null,
      customerName: '',
      customerEmail: '',
      paymentMethod: 'cash',
      paymentMethodTitle: 'Cash',
      note: '',
      appliedCoupon: null,
      resumedOrderId: null,
      resumedOrderNumber: null,
      resumedWooId: null,
      resumedAttendedBy: null,
      resumedCreatedByUserId: null,
    });
  },

  saveAsOnHold: async () => {
    if (isHolding || isCheckingOut) return -1;
    isHolding = true;
    try {
      const state = get();
      if (!state.cartId || state.items.length === 0) return -1;

      const totals = state.getTotals();
      const now = toISOString();
      const localTransactionId = generateId();

      const currentUser = useAuthStore.getState().user;
      const attendedBy = state.resumedAttendedBy || currentUser?.displayName || currentUser?.username || 'POS Staff';
      const attendedByUserId = currentUser?.id ?? null;
      const createdByUserId = state.resumedOrderId
        ? (state.resumedCreatedByUserId ?? currentUser?.id ?? null)
        : (currentUser?.id ?? null);

      let wooCustomerId: number | null = state.wooCustomerId ?? null;
      let customerPhone = state.customerPhone || '';
      if (state.customerId) {
        const cust = await db.customers.get(state.customerId);
        if (cust) {
          if (!wooCustomerId && cust.wooId) wooCustomerId = cust.wooId;
          if (!customerPhone && cust.billing?.phone) customerPhone = cust.billing.phone;
        }
      }

      // Pre-resolve stock identities for all cart items before opening atomic transaction
      const itemsWithIdentity = await Promise.all(
        state.items.map(async (item) => ({
          item,
          identity: await stockIdentity(item),
        }))
      );

      const randomSuffix = Math.floor(Math.random() * 9000 + 1000).toString();
      const holdOrderNumber = `HOLD-${Date.now().toString().slice(-6)}-${randomSuffix}`;

      let orderId!: number;
      let newCartId!: number;

      await db.transaction('rw', db.orders, db.orderItems, db.cart, db.cartItems, async () => {
        // If order was resumed, update the existing on-hold order rather than creating duplicate
        if (state.resumedOrderId) {
          orderId = state.resumedOrderId;
          await db.orders.update(orderId, {
            customerId: state.customerId,
            wooCustomerId,
            customerName: state.customerName || 'Walk-in Customer',
            customerEmail: state.customerEmail,
            customerPhone,
            subtotal: totals.subtotal,
            couponDiscount: state.appliedCoupon?.discountKobo || 0,
            couponCode: state.appliedCoupon?.code || null,
            appliedCoupon: state.appliedCoupon || null,
            transactionFee: totals.transactionFee,
            total: totals.total,
            paymentMethod: state.paymentMethod,
            paymentMethodTitle: state.paymentMethodTitle,
            itemCount: totals.itemCount,
            customerNote: state.note,
            createdByUserId,
            attendedBy,
            attendedByUserId,
            updatedAt: now,
          });
          await db.orderItems.where('orderId').equals(orderId).delete();
        } else {
          orderId = (await db.orders.add({
            wooId: null,
            localTransactionId,
            orderNumber: holdOrderNumber,
            status: 'on-hold',
            customerId: state.customerId,
            wooCustomerId,
            customerName: state.customerName || 'Walk-in Customer',
            customerEmail: state.customerEmail,
            customerPhone,
            subtotal: totals.subtotal,
            couponDiscount: state.appliedCoupon?.discountKobo || 0,
            couponCode: state.appliedCoupon?.code || null,
            appliedCoupon: state.appliedCoupon || null,
            transactionFee: totals.transactionFee,
            total: totals.total,
            paymentMethod: state.paymentMethod,
            paymentMethodTitle: state.paymentMethodTitle,
            shippingMethod: 'walk-in',
            source: 'pos',
            createdByUserId,
            attendedBy,
            attendedByUserId,
            itemCount: totals.itemCount,
            customerNote: state.note,
            syncStatus: 'LOCAL_ONLY',
            lastSyncedAt: null,
            localVersion: 1,
            remoteVersion: null,
            createdAt: now,
            updatedAt: now,
            completedAt: null,
          } as unknown as Order)) as number;
        }

        for (const { item, identity } of itemsWithIdentity) {
          await db.orderItems.add({
            orderId,
            productId: item.productId,
            wooProductId: item.wooProductId,
            ...identity,
            name: item.name,
            sku: item.sku,
            price: item.unitPrice,
            quantity: item.quantity,
            subtotal: item.unitPrice * item.quantity,
            total: item.lineTotal,
            discount: item.discount,
            image: item.image,
          } as unknown as OrderItem);
        }

        // Cleanly clear active cart items and replace cart entity in DB
        await db.cartItems.where('cartId').equals(state.cartId!).delete();
        await db.cart.delete(state.cartId!);
        newCartId = (await db.cart.add({
          storeId: 1,
          customerId: null,
          customerName: '',
          customerEmail: '',
          paymentMethod: 'cash',
          paymentMethodTitle: 'Cash',
          note: '',
          appliedCoupon: null,
          resumedOrderId: null,
          resumedOrderNumber: null,
          resumedWooId: null,
          resumedAttendedBy: null,
          resumedCreatedByUserId: null,
          createdAt: now,
          updatedAt: now,
        } as Cart)) as number;
      });

      // Synchronize in-memory Zustand state immediately
      set({
        cartId: newCartId,
        items: [],
        customerId: null,
        customerName: '',
        customerEmail: '',
        paymentMethod: 'cash',
        paymentMethodTitle: 'Cash',
        note: '',
        appliedCoupon: null,
        resumedOrderId: null,
        resumedOrderNumber: null,
        resumedWooId: null,
        resumedAttendedBy: null,
        resumedCreatedByUserId: null,
      });

      return orderId;
    } finally {
      isHolding = false;
    }
  },

  completeCheckout: async (params) => {
    if (isCheckingOut || isHolding) return null;
    isCheckingOut = true;
    try {
      const state = get();
      if (!state.cartId || state.items.length === 0) return null;

    // Secondary sellability safeguard: verify all items belong to active published products
    for (const item of state.items) {
      const prod = await db.products.get(item.productId);
      if (!prod || (prod.status && prod.status !== 'publish')) {
        toast.error(`"${item.name}" is no longer published and cannot be sold.`);
        return null;
      }
    }

    const totals = state.getTotals();
    const now = toISOString();
    const isOnline = useConnectionStore.getState().isOnline;
    const localTransactionId = generateId();

    // With a real store every sale is queued and uploaded idempotently by the sync loop, whether
    // or not we are online right now. Demo sessions have no store to upload to.
    const hasStore = sessionToken() !== null;
    const syncStatus: Order['syncStatus'] = hasStore || !isOnline ? 'PENDING_SYNC' : 'SYNCED';
    const receiptNumber = hasStore
      ? await nextReceiptNumber(useAuthStore.getState().user?.deviceId)
      : `#${Math.floor(1015000 + Math.random() * 9000)}`;

    const paymentSplits = params?.paymentSplits;
    const isSplit = paymentSplits && paymentSplits.length > 0;
    const paymentMethod = isSplit ? 'split' : (params?.paymentMethod || state.paymentMethod || 'cash');
    const paymentMethodTitle = isSplit ? 'Split Payment' : (params?.paymentMethodTitle || state.paymentMethodTitle || 'Cash');
    const note = params?.note ?? state.note;

    const couponDiscount = state.appliedCoupon?.discountKobo || 0;
    const couponCode = state.appliedCoupon?.code || null;
    const couponLines = state.appliedCoupon
      ? [{ code: state.appliedCoupon.code, discount: couponDiscount }]
      : [];

    const currentUser = useAuthStore.getState().user;
    // Retain historical creator if resumed, or attribute to authenticated staff
    const attendedBy = state.resumedAttendedBy || currentUser?.displayName || currentUser?.username || 'POS Staff';
    const attendedByUserId = currentUser?.id ?? null;
    const createdByUserId = state.resumedOrderId
      ? (state.resumedCreatedByUserId ?? currentUser?.id ?? null)
      : (currentUser?.id ?? null);

    let orderId!: number;
    let replacementCartId!: number;
    const savedItems: OrderItem[] = [];

    let wooCustomerId: number | null = state.wooCustomerId ?? null;
    let customerPhone = state.customerPhone || '';
    if (state.customerId) {
      const cust = await db.customers.get(state.customerId);
      if (cust) {
        if (!wooCustomerId && cust.wooId) wooCustomerId = cust.wooId;
        if (!customerPhone && cust.billing?.phone) customerPhone = cust.billing.phone;
      }
    }

    // A sale, its line items, local stock adjustment, and cart reset are one durable unit.
    // Without this transaction a browser crash could leave an order with no items (or stock
    // changed without its corresponding sale) in IndexedDB.
    await db.transaction('rw', db.orders, db.orderItems, db.products, db.cart, db.cartItems, async () => {
    if (state.resumedOrderId) {
      // Transition existing on-hold order to completed! No duplicate order created!
      orderId = state.resumedOrderId;
      await db.orders.update(orderId, {
        status: 'completed',
        customerId: state.customerId,
        wooCustomerId,
        customerName: state.customerName || 'Walk-in Customer',
        customerEmail: state.customerEmail,
        customerPhone,
        subtotal: totals.subtotal,
        couponDiscount,
        couponCode,
        appliedCoupon: state.appliedCoupon || null,
        ...(couponLines.length > 0 ? { couponLines } : {}),
        transactionFee: totals.transactionFee,
        total: totals.total,
        paymentMethod,
        paymentMethodTitle,
        ...(isSplit ? { paymentSplits } : {}),
        shippingMethod: 'in-store',
        source: 'pos',
        createdByUserId,
        attendedBy,
        attendedByUserId,
        itemCount: totals.itemCount,
        customerNote: note,
        orderNumber: receiptNumber,
        receiptNumber,
        syncStatus,
        lastSyncedAt: null,
        updatedAt: now,
        completedAt: now,
      });

      // Clear old order line items to be refreshed with final cart items
      await db.orderItems.where('orderId').equals(orderId).delete();
    } else {
      const orderData: Omit<Order, 'id'> = {
        wooId: null,
        localTransactionId,
        orderNumber: receiptNumber,
        receiptNumber,
        status: 'completed',
        customerId: state.customerId,
        wooCustomerId,
        customerName: state.customerName || 'Walk-in Customer',
        customerEmail: state.customerEmail,
        customerPhone,
        subtotal: totals.subtotal,
        couponDiscount,
        couponCode,
        appliedCoupon: state.appliedCoupon || null,
        ...(couponLines.length > 0 ? { couponLines } : {}),
        transactionFee: totals.transactionFee,
        total: totals.total,
        paymentMethod,
        paymentMethodTitle,
        ...(isSplit ? { paymentSplits } : {}),
        shippingMethod: 'in-store',
        source: 'pos',
        createdByUserId,
        attendedBy,
        attendedByUserId,
        itemCount: totals.itemCount,
        customerNote: note,
        syncStatus,
        lastSyncedAt: null,
        localVersion: 1,
        remoteVersion: null,
        createdAt: now,
        updatedAt: now,
        completedAt: now,
      };

      orderId = (await db.orders.add(orderData as Order)) as number;
    }

    // Save order items & reduce stock on this till.
    for (const item of state.items) {
      const orderItemData: Omit<OrderItem, 'id'> = {
        orderId,
        productId: item.productId,
        wooProductId: item.wooProductId,
        ...(await stockIdentity(item)),
        name: item.name,
        sku: item.sku,
        price: item.unitPrice,
        quantity: item.quantity,
        subtotal: item.unitPrice * item.quantity,
        total: item.lineTotal,
        discount: item.discount,
        image: item.image,
      };
      const itemId = await db.orderItems.add(orderItemData as OrderItem);
      savedItems.push({ ...orderItemData, id: itemId as number });
      await reduceLocalStock(item);
    }

    await db.cartItems.where('cartId').equals(state.cartId!).delete();
    await db.cart.delete(state.cartId!);
    replacementCartId = await db.cart.add({
      storeId: 1,
      customerId: null,
      customerName: '',
      customerEmail: '',
      paymentMethod: 'cash',
      paymentMethodTitle: 'Cash',
      note: '',
      appliedCoupon: null,
      createdAt: now,
      updatedAt: now,
    } as Cart) as number;
    });

    if (syncStatus === 'PENDING_SYNC') {
      useSyncStore.getState().incrementPending();
    }
    if (hasStore) {
      // Defer operational sync so receipt modal renders and print UI opens instantly
      setTimeout(() => {
        void runPosSync();
      }, 150);
    }

    const completedOrderRecord = await db.orders.get(orderId);
    const completedOrder: Order = completedOrderRecord || ({
      id: orderId,
      wooId: null,
      localTransactionId,
      orderNumber: receiptNumber,
      receiptNumber,
      status: 'completed',
      customerId: state.customerId,
      wooCustomerId,
      customerName: state.customerName || 'Walk-in Customer',
      customerEmail: state.customerEmail,
      subtotal: totals.subtotal,
      transactionFee: totals.transactionFee,
      total: totals.total,
      paymentMethod,
      paymentMethodTitle,
      shippingMethod: 'in-store',
      source: 'pos',
      attendedBy,
      attendedByUserId,
      itemCount: totals.itemCount,
      customerNote: note,
      syncStatus,
      lastSyncedAt: null,
      localVersion: 1,
      remoteVersion: null,
      createdAt: now,
      updatedAt: now,
      completedAt: now,
    } as Order);

    // Reflect the already-committed replacement cart in the in-memory UI.
    set({
      cartId: replacementCartId!,
      items: [],
      customerId: null,
      customerName: '',
      customerEmail: '',
      paymentMethod: 'cash',
      paymentMethodTitle: 'Cash',
      note: '',
      appliedCoupon: null,
      resumedOrderId: null,
      resumedOrderNumber: null,
      resumedWooId: null,
      resumedAttendedBy: null,
      resumedCreatedByUserId: null,
    });

    return { order: completedOrder, items: savedItems };
    } finally {
      isCheckingOut = false;
    }
  },

  loadOrderIntoCart: async (orderId: number) => {
    try {
      const order = await db.orders.get(orderId);
      if (!order) return { success: false, warnings: ['Order not found'] };

      // Enforce data-layer access control: users cannot resume or access unauthorized orders
      const currentUser = useAuthStore.getState().user;
      if (!isOrderAccessibleToUser(order, currentUser)) {
        return {
          success: false,
          warnings: ['Access denied: You are not authorized to access or resume this order.']
        };
      }

      const orderItems = await db.orderItems.where('orderId').equals(orderId).toArray();
      if (!orderItems || orderItems.length === 0) {
        return { success: false, warnings: ['Order has no items'] };
      }

      // Check current catalog for stock / changes to inform cashier
      const warnings: string[] = [];
      for (const item of orderItems) {
        const prod = await db.products.get(item.productId);
        if (!prod) {
          warnings.push(`"${item.name}" is no longer in the active catalog.`);
        } else if (prod.stockStatus === 'outofstock' || (prod.manageStock && prod.stockQuantity !== null && prod.stockQuantity <= 0)) {
          warnings.push(`"${item.name}" is currently out of stock.`);
        }
      }

      // Clear current active cart
      await get().clearCart();
      const currentCartId = get().cartId;
      if (!currentCartId) return { success: false, warnings: ['Cart initialization error'] };

      // Populate cart with order items, preserving historical prices & discounts
      const newItems: CartItem[] = [];
      for (const item of orderItems) {
        const cartItem: Omit<CartItem, 'id'> = {
          cartId: currentCartId,
          productId: item.productId,
          wooProductId: item.wooProductId,
          // Variation local ids equal WooCommerce variation ids (see services/zameria/catalog.ts).
          variationId: item.wooVariationId ?? undefined,
          name: item.name,
          sku: item.sku,
          image: item.image || '',
          unitPrice: item.price,
          regularPrice: item.price,
          salePrice: null,
          quantity: item.quantity,
          discount: item.discount,
          lineTotal: item.total,
        };
        const id = await db.cartItems.add(cartItem as CartItem);
        newItems.push({ ...cartItem, id: id as number });
      }

      // Update Dexie cart entity with resumed order tracking
      await db.cart.update(currentCartId, {
        customerId: order.customerId,
        customerName: order.customerName,
        customerEmail: order.customerEmail,
        paymentMethod: order.paymentMethod,
        paymentMethodTitle: order.paymentMethodTitle,
        note: order.customerNote || '',
        appliedCoupon: order.appliedCoupon || null,
        resumedOrderId: order.id,
        resumedOrderNumber: order.orderNumber,
        resumedWooId: order.wooId,
        resumedAttendedBy: order.attendedBy || null,
        resumedCreatedByUserId: order.createdByUserId ?? order.attendedByUserId ?? null,
      });

      // Update Zustand state with resumed order tracking
      set({
        items: newItems,
        customerId: order.customerId,
        customerName: order.customerName,
        customerEmail: order.customerEmail,
        paymentMethod: order.paymentMethod,
        paymentMethodTitle: order.paymentMethodTitle,
        note: order.customerNote || '',
        appliedCoupon: order.appliedCoupon || null,
        resumedOrderId: order.id,
        resumedOrderNumber: order.orderNumber,
        resumedWooId: order.wooId,
        resumedAttendedBy: order.attendedBy || null,
        resumedCreatedByUserId: order.createdByUserId ?? order.attendedByUserId ?? null,
      });

      // Revalidate coupon against WooCommerce rules if one was attached (with timeout protection)
      if (order.appliedCoupon || order.couponCode) {
        const couponCodeToReval = order.appliedCoupon?.code || order.couponCode!;
        try {
          // Timeout race: 2500ms max so slow or offline networks never freeze order restoration
          const timeoutPromise = new Promise<null>((resolve) => setTimeout(() => resolve(null), 2500));
          const reval = await Promise.race([
            validateWooCoupon(couponCodeToReval, newItems, order.customerEmail),
            timeoutPromise,
          ]);

          if (reval && reval.valid && reval.coupon) {
            set({ appliedCoupon: reval.coupon });
            await db.cart.update(currentCartId, { appliedCoupon: reval.coupon });
          } else if (reval && !reval.valid) {
            set({ appliedCoupon: null });
            await db.cart.update(currentCartId, { appliedCoupon: null });
            warnings.push(`Previously applied coupon "${couponCodeToReval}" is no longer valid: ${reval.error || 'Validation failed'}`);
          }
          // If timed out (reval === null), gracefully keep existing coupon without blocking
        } catch {
          // Non-fatal coupon validation error during order resume
        }
      }

      return { success: true, warnings };
    } catch {
      return { success: false, warnings: ['Failed to load order into cart'] };
    }
  },
}));
