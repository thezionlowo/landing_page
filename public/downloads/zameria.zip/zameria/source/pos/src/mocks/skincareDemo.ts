import { db } from '../db';
import { seedDemoData } from './data';

/** Seed once: every screen and workflow shares this persistent, isolated demo store. */
export async function seedSkincareDemo(assetBase: string): Promise<void> {
  if (await db.products.count()) return;
  await seedDemoData(db);
  const template = (await db.products.toArray())[0];
  const category = (await db.categories.toArray())[0];
  const catalogue = [
    ['Daily face cleanser', 'cleanser', 8500, 1],
    ['Vitamin C serum', 'vitaminc', 16500, 2],
    ['Everyday moisturiser', 'moisturizer', 12000, 3],
    ['Hydrating body lotion', 'lotion', 22500, 3],
    ['Gentle skin toner', 'toner', 14500, 1],
    ['Daily sunscreen SPF 50', 'sunscreen', 13000, 4],
    ['Hyaluronic acid serum', 'hyaluronic', 18000, 2],
    ['Niacinamide serum', 'niacinamide', 15500, 2],
    ['Restoring night cream', 'nightcream', 19000, 3],
    ['Nourishing face oil', 'oil', 17500, 2],
    ['Barrier repair cream', 'cream_jar', 21000, 3],
    ['Calming gel cleanser', 'cleanser', 9500, 1],
    ['Peptide firming serum', 'serum_bottle', 24000, 2],
    ['Rich body cream', 'cream', 16500, 3],
    ['Squalane facial oil', 'oil_dropper', 19500, 2],
    ['Brightening face serum', 'serum', 20500, 2],
    ['Hydrating sun lotion SPF 30', 'sunscreen', 15000, 4],
    ['Overnight recovery cream', 'nightcream', 23000, 3],
  ] as const;
  const now = new Date().toISOString();
  const products = catalogue.map(([name, image, price, categoryId], index) => ({
    ...template, id: index + 1, wooId: 101 + index, stockOwnerWooId: 101 + index,
    name, slug: name.toLowerCase().replace(/[^a-z0-9]+/g, '-'),
    description: `${name} — sample skincare product for the ZAMERIA demo store.`,
    shortDescription: 'Demo skincare product', sku: `SKIN-${String(index + 1).padStart(3, '0')}`,
    barcode: `200000000${String(index + 1).padStart(4, '0')}`, gtin: '', upc: '', ean: '', isbn: '',
    type: 'simple' as const, status: 'publish' as const, variations: [], attributes: [],
    price: price * 100, regularPrice: price * 100, salePrice: null, costPrice: Math.round(price * 60), onSale: false,
    categoryIds: [categoryId], wooCategoryIds: [categoryId + 9],
    brandId: 1, wooBrandId: 1, brandName: 'ZAMERIA Skincare',
    brand: { id: 1, name: 'ZAMERIA Skincare', slug: 'zameria-skincare' },
    stockStatus: 'instock' as const, stockQuantity: 24 + index * 2, manageStock: true,
    images: [{ id: index + 1, src: new URL(`products/${image}.jpg`, assetBase).href, name, alt: name }],
    updatedAt: now, lastSyncedAt: now,
  }));
  await db.transaction('rw', [db.products, db.categories, db.brands, db.orderItems, db.orders, db.customers], async () => {
    await db.products.clear();
    await db.categories.clear();
    await db.brands.clear();
    await db.products.bulkAdd(products);
    await db.categories.bulkAdd(['Cleansers & toners', 'Serums & oils', 'Moisturisers', 'Sun care'].map((name, index) => ({
      ...category, id: index + 1, wooId: index + 10, name, slug: name.toLowerCase().replace(/[^a-z0-9]+/g, '-'),
      parent: 0, description: '', image: null, count: products.filter(p => p.categoryIds[0] === index + 1).length,
    })));
    await db.brands.add({ id: 1, wooId: 1, name: 'ZAMERIA Skincare', slug: 'zameria-skincare', count: products.length, syncStatus: 'SYNCED', lastSyncedAt: now });
    const seededOrders = await db.orders.toArray();
    const seededCustomers = await db.customers.toArray();
    const orderIds = new Map(seededOrders.map((order, index) => [index + 1, order.id]));
    const customerIds = new Map(seededCustomers.map(customer => [customer.wooId, customer.id]));
    const items = await db.orderItems.toArray();
    for (const [index, item] of items.entries()) {
      const product = products[index % products.length];
      await db.orderItems.update(item.id, {
        orderId: orderIds.get(item.orderId) ?? item.orderId, productId: product.id, wooProductId: product.wooId, wooVariationId: null, stockOwnerWooId: product.wooId,
        name: product.name, sku: product.sku, image: product.images[0].src, price: product.price,
        subtotal: product.price * item.quantity, total: product.price * item.quantity, discount: null,
      });
    }
    for (const order of await db.orders.toArray()) {
      const lines = await db.orderItems.where('orderId').equals(order.id).toArray();
      const total = lines.reduce((sum, line) => sum + line.total, 0);
      const customerId = order.wooCustomerId ? customerIds.get(order.wooCustomerId) ?? null : null;
      await db.orders.update(order.id, { customerId, itemCount: lines.reduce((sum, line) => sum + line.quantity, 0), subtotal: total, total, transactionFee: 0, couponDiscount: 0, couponCode: null, appliedCoupon: null, couponLines: [], paymentSplits: undefined, customerEmail: customerId ? `buyer${customerId}@example.invalid` : '', customerPhone: '00000000000' });
    }
    for (const customer of await db.customers.toArray()) {
      const orders = await db.orders.where('customerId').equals(customer.id).toArray();
      const purchases = orders.filter(o => ['completed', 'processing', 'refunded'].includes(o.status));
      const email = `buyer${customer.id}@example.invalid`;
      await db.customers.update(customer.id, { email, avatarUrl: '', billing: { ...customer.billing, email, phone: '00000000000' }, ordersCount: orders.length, purchasesCount: purchases.length, totalSpent: purchases.reduce((sum, o) => sum + o.total, 0) });
    }
  });
}
