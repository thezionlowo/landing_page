import { supportChatClient, type SupportConversation } from '../services/supportChatClient';

/** Local demonstration only: no visitor messages are sent to support. */
export function installDemoSupport(): void {
  let conversation: SupportConversation | null = null;
  const message = async (text: string): Promise<SupportConversation> => {
    const now = new Date().toISOString();
    conversation ??= {
      id: 'demo-support', customerId: 'demo', businessName: 'Skincare Demo Store', customerName: 'Demo store owner',
      email: 'owner@example.invalid', source: 'POS', status: 'Open', assignedStaffId: null, assignedStaffName: null,
      createdAt: now, updatedAt: now, lastMessageAt: now, lastMessage: '', lastMessageSender: 'system', unreadBySupport: 0, unreadByCustomer: 0, messages: [],
    };
    const reply = 'This is a demo conversation; no message has been sent. Try adding a skincare product, holding a sale, or completing checkout. Your demo changes stay in this browser.';
    conversation.messages.push(
      { id: crypto.randomUUID(), conversationId: conversation.id, senderType: 'customer', senderName: 'Demo store owner', message: text, createdAt: now },
      { id: crypto.randomUUID(), conversationId: conversation.id, senderType: 'system', senderName: 'Demo assistant', message: reply, createdAt: now },
    );
    conversation = { ...conversation, updatedAt: now, lastMessageAt: now, lastMessage: reply, lastMessageSender: 'system' };
    return conversation;
  };
  Object.assign(supportChatClient, {
    getUnreadCount: () => 0,
    getConversation: async () => conversation,
    getOrCreateConversation: async ({ initialMessage }: { initialMessage: string }) => message(initialMessage),
    sendMessage: async (_id: string, text: string) => message(text),
    markAsReadByCustomer: async () => {},
    resolveConversation: async () => { if (conversation) conversation.status = 'Resolved'; },
  });
}
