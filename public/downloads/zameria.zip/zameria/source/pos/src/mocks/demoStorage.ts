/** Give the embedded app its own settings, printing preferences and cached logos. */
export function createDemoStorage(storage: Storage): Storage {
  const prefix = 'zameria_product_demo:';
  const keys = () => Array.from({ length: storage.length }, (_, i) => storage.key(i)).filter((key): key is string => Boolean(key?.startsWith(prefix)));
  return {
    get length() { return keys().length; },
    key: (index) => keys()[index]?.slice(prefix.length) ?? null,
    getItem: (key) => storage.getItem(prefix + key),
    setItem: (key, value) => storage.setItem(prefix + key, value),
    removeItem: (key) => storage.removeItem(prefix + key),
    clear: () => { for (const key of keys()) storage.removeItem(key); },
  };
}

if (import.meta.env.MODE === 'product-preview' && typeof window !== 'undefined') {
  try {
    Object.defineProperty(window, 'localStorage', { value: createDemoStorage(window.localStorage), configurable: true });
  } catch {
    // Browsers that disable storage can still use the app's in-memory preferences.
  }
}
