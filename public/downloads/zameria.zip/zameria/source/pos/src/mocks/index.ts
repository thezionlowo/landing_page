export { seedDemoData, mockProducts, mockCategories, mockCustomers, mockOrders, mockOrderItems } from './data';
