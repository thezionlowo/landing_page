import type { Product, Category, Customer, Order, OrderItem } from '@/types';
import { toKobo, toISOString } from '@/lib';

// ============================================================================
// CATEGORIES (5)
// ============================================================================
export const mockCategories: Omit<Category, 'id'>[] = [
  { wooId: 10, name: 'Beauty', slug: 'beauty', parent: 0, description: 'Beauty and wellness products', count: 12, image: null, syncStatus: 'SYNCED', lastSyncedAt: toISOString() },
  { wooId: 11, name: 'Skincare', slug: 'skincare', parent: 10, description: 'Cleansers, serums, and moisturizers', count: 6, image: null, syncStatus: 'SYNCED', lastSyncedAt: toISOString() },
  { wooId: 12, name: 'Makeup', slug: 'makeup', parent: 10, description: 'Lipsticks, foundations, and cosmetics', count: 4, image: null, syncStatus: 'SYNCED', lastSyncedAt: toISOString() },
  { wooId: 13, name: 'Haircare', slug: 'haircare', parent: 10, description: 'Shampoos, oils, and hair treatments', count: 2, image: null, syncStatus: 'SYNCED', lastSyncedAt: toISOString() },
  { wooId: 20, name: 'Best Sellers', slug: 'best-sellers', parent: 0, description: 'Store top trending and best sellers', count: 8, image: null, syncStatus: 'SYNCED', lastSyncedAt: toISOString() },
  { wooId: 21, name: 'New Arrivals', slug: 'new-arrivals', parent: 0, description: 'Recently added catalogue items', count: 5, image: null, syncStatus: 'SYNCED', lastSyncedAt: toISOString() },
];

// ============================================================================
// PRODUCTS (20)
// ============================================================================
const now = toISOString();
const baseProd = {
  type: 'simple' as const,
  status: 'publish' as const,
  description: '',
  shortDescription: '',
  weight: '',
  dimensions: { length: '', width: '', height: '' },
  gtin: '', upc: '', ean: '', isbn: '',
  syncStatus: 'SYNCED' as const,
  lastSyncedAt: now,
  localVersion: 1,
  remoteVersion: now,
  createdAt: now,
  updatedAt: now,
};

export const mockProducts: Omit<Product, 'id'>[] = [
  // Beverages (cat 1)
  { ...baseProd, wooId: 101, name: 'Coca-Cola 50cl', slug: 'coca-cola-50cl', sku: 'BEV-001', barcode: '5449000000996', price: toKobo(350), regularPrice: toKobo(350), salePrice: null, onSale: false, stockStatus: 'instock', stockQuantity: 48, manageStock: true, categoryIds: [1], wooCategoryIds: [10], images: [{ id: 1, src: 'https://images.unsplash.com/photo-1629203851122-3726ecdf080e?w=200', name: 'Coca-Cola', alt: 'Coca-Cola bottle' }], upc: '5449000000996' },
  { ...baseProd, wooId: 102, name: 'Fanta Orange 50cl', slug: 'fanta-orange', sku: 'BEV-002', barcode: '5449000000997', price: toKobo(300), regularPrice: toKobo(350), salePrice: toKobo(300), onSale: true, stockStatus: 'instock', stockQuantity: 36, manageStock: true, categoryIds: [1], wooCategoryIds: [10], images: [{ id: 2, src: 'https://images.unsplash.com/photo-1624517452488-04869289c4ca?w=200', name: 'Fanta', alt: 'Fanta Orange bottle' }] },
  { ...baseProd, wooId: 103, name: 'Peak Milk 400g', slug: 'peak-milk', sku: 'BEV-003', barcode: '8901234567891', price: toKobo(2500), regularPrice: toKobo(2500), salePrice: null, onSale: false, stockStatus: 'instock', stockQuantity: 20, manageStock: true, categoryIds: [1], wooCategoryIds: [10], images: [{ id: 3, src: 'https://images.unsplash.com/photo-1563636619-e9143da7973b?w=200', name: 'Milk', alt: 'Peak Milk tin' }] },
  { ...baseProd, wooId: 104, name: 'Chi Exotic Juice 1L', slug: 'chi-exotic', sku: 'BEV-004', barcode: '8901234567892', price: toKobo(1500), regularPrice: toKobo(1800), salePrice: toKobo(1500), onSale: true, stockStatus: 'instock', stockQuantity: 12, manageStock: true, categoryIds: [1], wooCategoryIds: [10], images: [{ id: 4, src: 'https://images.unsplash.com/photo-1621506289937-a8e4df240d0b?w=200', name: 'Juice', alt: 'Chi Exotic Juice' }] },
  { ...baseProd, wooId: 105, name: 'Bottled Water 75cl', slug: 'water-75cl', sku: 'BEV-005', barcode: '8901234567893', price: toKobo(200), regularPrice: toKobo(200), salePrice: null, onSale: false, stockStatus: 'instock', stockQuantity: 100, manageStock: true, categoryIds: [1], wooCategoryIds: [10], images: [{ id: 5, src: 'https://images.unsplash.com/photo-1548839140-29a749e1cf4d?w=200', name: 'Water', alt: 'Bottled water' }] },

  // Food & Snacks (cat 2)
  { ...baseProd, wooId: 201, name: 'Indomie Noodles (Carton)', slug: 'indomie-carton', sku: 'FOOD-001', barcode: '0123456789012', price: toKobo(5500), regularPrice: toKobo(6000), salePrice: toKobo(5500), onSale: true, stockStatus: 'instock', stockQuantity: 15, manageStock: true, categoryIds: [2], wooCategoryIds: [11], images: [{ id: 6, src: 'https://images.unsplash.com/photo-1612929633738-8fe44f7ec841?w=200', name: 'Noodles', alt: 'Indomie noodles carton' }], ean: '0123456789012' },
  { ...baseProd, wooId: 202, name: 'Golden Penny Spaghetti 500g', slug: 'golden-penny-spaghetti', sku: 'FOOD-002', barcode: '8901234567894', price: toKobo(800), regularPrice: toKobo(800), salePrice: null, onSale: false, stockStatus: 'instock', stockQuantity: 30, manageStock: true, categoryIds: [2], wooCategoryIds: [11], images: [{ id: 7, src: 'https://images.unsplash.com/photo-1551462147-ff29053bfc14?w=200', name: 'Spaghetti', alt: 'Golden Penny Spaghetti' }] },
  { ...baseProd, wooId: 203, name: 'Dangote Sugar 1kg', slug: 'dangote-sugar', sku: 'FOOD-003', barcode: '8901234567895', price: toKobo(1200), regularPrice: toKobo(1200), salePrice: null, onSale: false, stockStatus: 'instock', stockQuantity: 25, manageStock: true, categoryIds: [2], wooCategoryIds: [11], images: [{ id: 8, src: 'https://images.unsplash.com/photo-1558642452-9d2a7deb7f62?w=200', name: 'Sugar', alt: 'Dangote Sugar' }] },
  { ...baseProd, wooId: 204, name: 'Kings Oil 5L', slug: 'kings-oil', sku: 'FOOD-004', barcode: '8901234567896', price: toKobo(8500), regularPrice: toKobo(8500), salePrice: null, onSale: false, stockStatus: 'outofstock', stockQuantity: 0, manageStock: true, categoryIds: [2], wooCategoryIds: [11], images: [{ id: 9, src: 'https://images.unsplash.com/photo-1474979266404-7eaacbcd87c5?w=200', name: 'Oil', alt: 'Kings cooking oil' }] },
  { ...baseProd, wooId: 205, name: 'Tin Tomatoes 400g', slug: 'tin-tomatoes', sku: 'FOOD-005', barcode: '8901234567897', price: toKobo(650), regularPrice: toKobo(650), salePrice: null, onSale: false, stockStatus: 'instock', stockQuantity: null, manageStock: false, categoryIds: [2], wooCategoryIds: [11], images: [{ id: 10, src: 'https://images.unsplash.com/photo-1546554137-f86b9593a222?w=200', name: 'Tomatoes', alt: 'Tin tomatoes' }] },

  // Electronics (cat 3)
  { ...baseProd, wooId: 301, name: 'USB-C Charging Cable', slug: 'usb-c-cable', sku: 'ELEC-001', barcode: '8901234567898', price: toKobo(3500), regularPrice: toKobo(3500), salePrice: null, onSale: false, stockStatus: 'instock', stockQuantity: 40, manageStock: true, categoryIds: [3], wooCategoryIds: [12], images: [{ id: 11, src: 'https://images.unsplash.com/photo-1558618666-fcd25c85f82e?w=200', name: 'Cable', alt: 'USB-C cable' }] },
  { ...baseProd, wooId: 302, name: 'Bluetooth Earbuds', slug: 'bluetooth-earbuds', sku: 'ELEC-002', barcode: '8901234567899', price: toKobo(15000), regularPrice: toKobo(18000), salePrice: toKobo(15000), onSale: true, stockStatus: 'instock', stockQuantity: 8, manageStock: true, categoryIds: [3], wooCategoryIds: [12], images: [{ id: 12, src: 'https://images.unsplash.com/photo-1590658268037-6bf12f032f55?w=200', name: 'Earbuds', alt: 'Bluetooth earbuds' }] },
  { ...baseProd, wooId: 303, name: 'Phone Screen Protector', slug: 'screen-protector', sku: 'ELEC-003', barcode: '8901234567800', price: toKobo(2000), regularPrice: toKobo(2000), salePrice: null, onSale: false, stockStatus: 'instock', stockQuantity: 50, manageStock: true, categoryIds: [3], wooCategoryIds: [12], images: [{ id: 13, src: 'https://images.unsplash.com/photo-1601784551446-20c9e07cdbdb?w=200', name: 'Protector', alt: 'Screen protector' }] },
  { ...baseProd, wooId: 304, name: 'Power Bank 10000mAh', slug: 'power-bank', sku: 'ELEC-004', barcode: '8901234567801', price: toKobo(12000), regularPrice: toKobo(12000), salePrice: null, onSale: false, stockStatus: 'onbackorder', stockQuantity: 0, manageStock: true, categoryIds: [3], wooCategoryIds: [12], images: [{ id: 14, src: 'https://images.unsplash.com/photo-1609091839311-d5365f9ff1c5?w=200', name: 'Power Bank', alt: 'Power bank' }] },

  // Personal Care (cat 4)
  { ...baseProd, wooId: 401, name: 'Dettol Soap Pack', slug: 'dettol-soap', sku: 'CARE-001', barcode: '8901234567802', price: toKobo(1800), regularPrice: toKobo(2000), salePrice: toKobo(1800), onSale: true, stockStatus: 'instock', stockQuantity: 22, manageStock: true, categoryIds: [4], wooCategoryIds: [13], images: [{ id: 15, src: 'https://images.unsplash.com/photo-1600857062241-98e5dba7f214?w=200', name: 'Soap', alt: 'Dettol soap' }] },
  { ...baseProd, wooId: 402, name: 'Close Up Toothpaste', slug: 'close-up', sku: 'CARE-002', barcode: '8901234567803', price: toKobo(900), regularPrice: toKobo(900), salePrice: null, onSale: false, stockStatus: 'instock', stockQuantity: 18, manageStock: true, categoryIds: [4], wooCategoryIds: [13], images: [{ id: 16, src: 'https://images.unsplash.com/photo-1570172619644-dfd03ed5d881?w=200', name: 'Toothpaste', alt: 'Close Up toothpaste' }] },
  { ...baseProd, wooId: 403, name: 'Body Lotion 400ml', slug: 'body-lotion', sku: 'CARE-003', barcode: '8901234567804', price: toKobo(3200), regularPrice: toKobo(3200), salePrice: null, onSale: false, stockStatus: 'instock', stockQuantity: 14, manageStock: true, categoryIds: [4], wooCategoryIds: [13], images: [{ id: 17, src: 'https://images.unsplash.com/photo-1556228578-0d85b1a4d571?w=200', name: 'Lotion', alt: 'Body lotion' }] },

  // Home & Kitchen (cat 5)
  { ...baseProd, wooId: 501, name: 'Morning Fresh Dishwash 450ml', slug: 'morning-fresh', sku: 'HOME-001', barcode: '8901234567805', price: toKobo(1500), regularPrice: toKobo(1500), salePrice: null, onSale: false, stockStatus: 'instock', stockQuantity: 28, manageStock: true, categoryIds: [5], wooCategoryIds: [14], images: [{ id: 18, src: 'https://images.unsplash.com/photo-1585421514284-efb74c2b69ba?w=200', name: 'Dishwash', alt: 'Morning Fresh' }] },
  { ...baseProd, wooId: 502, name: 'Omo Detergent 900g', slug: 'omo-detergent', sku: 'HOME-002', barcode: '8901234567806', price: toKobo(2200), regularPrice: toKobo(2500), salePrice: toKobo(2200), onSale: true, stockStatus: 'instock', stockQuantity: 16, manageStock: true, categoryIds: [5], wooCategoryIds: [14], images: [{ id: 19, src: 'https://images.unsplash.com/photo-1582735689369-4fe89db7114c?w=200', name: 'Detergent', alt: 'Omo detergent' }] },
  { ...baseProd, wooId: 503, name: 'Harpic Toilet Cleaner', slug: 'harpic', sku: 'HOME-003', barcode: '8901234567807', price: toKobo(1800), regularPrice: toKobo(1800), salePrice: null, onSale: false, stockStatus: 'instock', stockQuantity: 10, manageStock: true, categoryIds: [5], wooCategoryIds: [14], images: [{ id: 20, src: 'https://images.unsplash.com/photo-1563453392212-326f5e854473?w=200', name: 'Cleaner', alt: 'Harpic toilet cleaner' }] },
];

// ============================================================================
// CUSTOMERS (10)
// ============================================================================
const blankBilling = { firstName: '', lastName: '', company: '', address1: '', address2: '', city: '', state: '', postcode: '', country: 'NG', email: '', phone: '' };

export const mockCustomers: Omit<Customer, 'id'>[] = [
  { wooId: 1, email: 'adunni.okafor@email.com', firstName: 'Adunni', lastName: 'Okafor', username: 'adunni.o', billing: { ...blankBilling, firstName: 'Adunni', lastName: 'Okafor', email: 'adunni.okafor@email.com', address1: '12 Admiralty Way', city: 'Lagos', state: 'LA', country: 'NG', phone: '+2348012345678' }, avatarUrl: '', syncStatus: 'SYNCED', lastSyncedAt: now, localVersion: 1, remoteVersion: now, createdAt: now, updatedAt: now },
  { wooId: 2, email: 'chidi.nwankwo@email.com', firstName: 'Chidi', lastName: 'Nwankwo', username: 'chidi.n', billing: { ...blankBilling, firstName: 'Chidi', lastName: 'Nwankwo', email: 'chidi.nwankwo@email.com', address1: '45 Allen Avenue', city: 'Ikeja', state: 'LA', country: 'NG' }, avatarUrl: '', syncStatus: 'SYNCED', lastSyncedAt: now, localVersion: 1, remoteVersion: now, createdAt: now, updatedAt: now },
  { wooId: 3, email: 'fatima.bello@email.com', firstName: 'Fatima', lastName: 'Bello', username: 'fatima.b', billing: { ...blankBilling, firstName: 'Fatima', lastName: 'Bello', email: 'fatima.bello@email.com', city: 'Abuja', state: 'FC', country: 'NG' }, avatarUrl: '', syncStatus: 'SYNCED', lastSyncedAt: now, localVersion: 1, remoteVersion: now, createdAt: now, updatedAt: now },
  { wooId: 4, email: 'emeka.obi@email.com', firstName: 'Emeka', lastName: 'Obi', username: 'emeka.o', billing: { ...blankBilling, firstName: 'Emeka', lastName: 'Obi', email: 'emeka.obi@email.com', address1: '7 Broad Street', city: 'Lagos Island', state: 'LA', country: 'NG', phone: '+2348098765432' }, avatarUrl: '', syncStatus: 'SYNCED', lastSyncedAt: now, localVersion: 1, remoteVersion: now, createdAt: now, updatedAt: now },
  { wooId: 5, email: 'ngozi.eze@email.com', firstName: 'Ngozi', lastName: 'Eze', username: 'ngozi.e', billing: { ...blankBilling, firstName: 'Ngozi', lastName: 'Eze', email: 'ngozi.eze@email.com' }, avatarUrl: '', syncStatus: 'SYNCED', lastSyncedAt: now, localVersion: 1, remoteVersion: now, createdAt: now, updatedAt: now },
  { wooId: 6, email: 'tunde.ajayi@email.com', firstName: 'Tunde', lastName: 'Ajayi', username: 'tunde.a', billing: { ...blankBilling, firstName: 'Tunde', lastName: 'Ajayi', email: 'tunde.ajayi@email.com', address1: '23 Lekki-Epe Expressway', city: 'Lekki', state: 'LA', country: 'NG' }, avatarUrl: '', syncStatus: 'SYNCED', lastSyncedAt: now, localVersion: 1, remoteVersion: now, createdAt: now, updatedAt: now },
  { wooId: 7, email: 'aisha.mohammed@email.com', firstName: 'Aisha', lastName: 'Mohammed', username: 'aisha.m', billing: { ...blankBilling, firstName: 'Aisha', lastName: 'Mohammed', email: 'aisha.mohammed@email.com', city: 'Kano', state: 'KN', country: 'NG' }, avatarUrl: '', syncStatus: 'SYNCED', lastSyncedAt: now, localVersion: 1, remoteVersion: now, createdAt: now, updatedAt: now },
  { wooId: 8, email: 'oluwaseun.adeyemi@email.com', firstName: 'Oluwaseun', lastName: 'Adeyemi', username: 'seun.a', billing: { ...blankBilling, firstName: 'Oluwaseun', lastName: 'Adeyemi', email: 'oluwaseun.adeyemi@email.com', address1: '100 Opebi Road', city: 'Ikeja', state: 'LA', country: 'NG', phone: '+2348055551234' }, avatarUrl: '', syncStatus: 'SYNCED', lastSyncedAt: now, localVersion: 1, remoteVersion: now, createdAt: now, updatedAt: now },
  // Customers without addresses
  { wooId: 9, email: 'bola.ogundimu@email.com', firstName: 'Bola', lastName: 'Ogundimu', username: 'bola.o', billing: { ...blankBilling }, avatarUrl: '', syncStatus: 'SYNCED', lastSyncedAt: now, localVersion: 1, remoteVersion: now, createdAt: now, updatedAt: now },
  { wooId: 10, email: 'kelechi.nnadi@email.com', firstName: 'Kelechi', lastName: 'Nnadi', username: 'kelechi.n', billing: { ...blankBilling }, avatarUrl: '', syncStatus: 'SYNCED', lastSyncedAt: now, localVersion: 1, remoteVersion: now, createdAt: now, updatedAt: now },
];

// ============================================================================
// ORDERS — realistic multi-period dataset for POS & WooCommerce Website
// ============================================================================
function hoursAgo(hours: number): string {
  const d = new Date();
  d.setHours(d.getHours() - hours);
  return d.toISOString();
}

function daysAgo(days: number, hour = 11, minute = 30): string {
  const d = new Date();
  d.setDate(d.getDate() - days);
  d.setHours(hour, minute, 0, 0);
  return d.toISOString();
}

const baseOrder = {
  wooCustomerId: null as number | null,
  customerNote: '',
  syncStatus: 'SYNCED' as const,
  lastSyncedAt: now,
  localVersion: 1,
  remoteVersion: now,
};

export const mockOrders: Omit<Order, 'id'>[] = [
  // --- TODAY ---
  // Order #1001: POS Sale with Split Payment (Cash ₦15,000 + POS ₦20,000 = ₦35,000)
  {
    ...baseOrder,
    wooId: null,
    localTransactionId: 'txn-001',
    orderNumber: '#1001',
    status: 'completed',
    source: 'pos',
    customerId: null,
    customerName: 'Walk-in Customer',
    customerEmail: '',
    subtotal: toKobo(35000),
    transactionFee: 0,
    total: toKobo(35000),
    paymentMethod: 'split',
    paymentMethodTitle: 'Split Payment',
    paymentSplits: [
      { id: '1', method: 'cash', methodTitle: 'Cash', amount: toKobo(15000) },
      { id: '2', method: 'pos', methodTitle: 'POS Terminal', amount: toKobo(20000) },
    ],
    shippingMethod: 'in-store',
    itemCount: 2,
    createdAt: hoursAgo(2),
    updatedAt: hoursAgo(2),
    completedAt: hoursAgo(2),
  },
  // Order #1002: Website Order (Online Payment ₦45,000)
  {
    ...baseOrder,
    wooId: 1002,
    localTransactionId: 'txn-002',
    orderNumber: '#1002',
    status: 'completed',
    source: 'website',
    customerId: 1,
    customerName: 'Adunni Okafor',
    customerEmail: 'adunni.okafor@email.com',
    subtotal: toKobo(45000),
    transactionFee: 0,
    total: toKobo(45000),
    paymentMethod: 'online',
    paymentMethodTitle: 'Online Payment',
    shippingMethod: 'delivery',
    itemCount: 3,
    createdAt: hoursAgo(4),
    updatedAt: hoursAgo(4),
    completedAt: hoursAgo(4),
  },
  // Order #1003: POS Sale (POS Terminal ₦18,500)
  {
    ...baseOrder,
    wooId: null,
    localTransactionId: 'txn-003',
    orderNumber: '#1003',
    status: 'completed',
    source: 'pos',
    customerId: 2,
    customerName: 'Chidi Nwankwo',
    customerEmail: 'chidi.nwankwo@email.com',
    subtotal: toKobo(18500),
    transactionFee: 0,
    total: toKobo(18500),
    paymentMethod: 'pos',
    paymentMethodTitle: 'POS Terminal',
    shippingMethod: 'in-store',
    itemCount: 2,
    createdAt: hoursAgo(6),
    updatedAt: hoursAgo(6),
    completedAt: hoursAgo(6),
  },

  // --- YESTERDAY ---
  // Order #1004: POS Sale (POS Terminal ₦62,000)
  {
    ...baseOrder,
    wooId: null,
    localTransactionId: 'txn-004',
    orderNumber: '#1004',
    status: 'completed',
    source: 'pos',
    customerId: 3,
    customerName: 'Fatima Bello',
    customerEmail: 'fatima.bello@email.com',
    subtotal: toKobo(62000),
    transactionFee: 0,
    total: toKobo(62000),
    paymentMethod: 'pos',
    paymentMethodTitle: 'POS Terminal',
    shippingMethod: 'in-store',
    itemCount: 3,
    createdAt: daysAgo(1, 10, 15),
    updatedAt: daysAgo(1, 10, 15),
    completedAt: daysAgo(1, 10, 15),
  },
  // Order #1005: Website Order (Online Payment ₦85,000)
  {
    ...baseOrder,
    wooId: 1005,
    localTransactionId: 'txn-005',
    orderNumber: '#1005',
    status: 'completed',
    source: 'website',
    customerId: 4,
    customerName: 'Emeka Obi',
    customerEmail: 'emeka.obi@email.com',
    subtotal: toKobo(85000),
    transactionFee: 0,
    total: toKobo(85000),
    paymentMethod: 'online',
    paymentMethodTitle: 'Online Payment',
    shippingMethod: 'delivery',
    itemCount: 4,
    createdAt: daysAgo(1, 14, 20),
    updatedAt: daysAgo(1, 14, 20),
    completedAt: daysAgo(1, 14, 20),
  },
  // Order #1006: POS Sale (Cash ₦12,500)
  {
    ...baseOrder,
    wooId: null,
    localTransactionId: 'txn-006',
    orderNumber: '#1006',
    status: 'completed',
    source: 'pos',
    customerId: null,
    customerName: 'Walk-in Customer',
    customerEmail: '',
    subtotal: toKobo(12500),
    transactionFee: 0,
    total: toKobo(12500),
    paymentMethod: 'cash',
    paymentMethodTitle: 'Cash',
    shippingMethod: 'in-store',
    itemCount: 2,
    createdAt: daysAgo(1, 16, 45),
    updatedAt: daysAgo(1, 16, 45),
    completedAt: daysAgo(1, 16, 45),
  },
  // Order #1007: Website Order (On-Hold - Should NOT inflate revenue)
  {
    ...baseOrder,
    wooId: 1007,
    localTransactionId: 'txn-007',
    orderNumber: '#1007',
    status: 'on-hold',
    source: 'website',
    customerId: 5,
    customerName: 'Ngozi Eze',
    customerEmail: 'ngozi.eze@email.com',
    subtotal: toKobo(15000),
    transactionFee: 0,
    total: toKobo(15000),
    paymentMethod: 'online',
    paymentMethodTitle: 'Online Payment',
    shippingMethod: 'delivery',
    itemCount: 1,
    createdAt: daysAgo(1, 18, 10),
    updatedAt: daysAgo(1, 18, 10),
    completedAt: null,
  },

  // --- THIS WEEK ---
  // Order #1008: POS Sale (Bank Transfer ₦42,000)
  {
    ...baseOrder,
    wooId: null,
    localTransactionId: 'txn-008',
    orderNumber: '#1008',
    status: 'completed',
    source: 'pos',
    customerId: 6,
    customerName: 'Tunde Ajayi',
    customerEmail: 'tunde.ajayi@email.com',
    subtotal: toKobo(42000),
    transactionFee: 0,
    total: toKobo(42000),
    paymentMethod: 'transfer',
    paymentMethodTitle: 'Bank Transfer',
    shippingMethod: 'in-store',
    itemCount: 3,
    createdAt: daysAgo(3, 11, 0),
    updatedAt: daysAgo(3, 11, 0),
    completedAt: daysAgo(3, 11, 0),
  },
  // Order #1009: Website Order (Online Payment ₦98,000)
  {
    ...baseOrder,
    wooId: 1009,
    localTransactionId: 'txn-009',
    orderNumber: '#1009',
    status: 'completed',
    source: 'website',
    customerId: 7,
    customerName: 'Aisha Mohammed',
    customerEmail: 'aisha.mohammed@email.com',
    subtotal: toKobo(98000),
    transactionFee: 0,
    total: toKobo(98000),
    paymentMethod: 'online',
    paymentMethodTitle: 'Online Payment',
    shippingMethod: 'shipping',
    itemCount: 4,
    createdAt: daysAgo(4, 15, 30),
    updatedAt: daysAgo(4, 15, 30),
    completedAt: daysAgo(4, 15, 30),
  },
  // Order #1010: POS Sale (POS Terminal ₦55,000)
  {
    ...baseOrder,
    wooId: null,
    localTransactionId: 'txn-010',
    orderNumber: '#1010',
    status: 'completed',
    source: 'pos',
    customerId: 8,
    customerName: 'Oluwaseun Adeyemi',
    customerEmail: 'oluwaseun.adeyemi@email.com',
    subtotal: toKobo(55000),
    transactionFee: 0,
    total: toKobo(55000),
    paymentMethod: 'pos',
    paymentMethodTitle: 'POS Terminal',
    shippingMethod: 'in-store',
    itemCount: 3,
    createdAt: daysAgo(5, 12, 10),
    updatedAt: daysAgo(5, 12, 10),
    completedAt: daysAgo(5, 12, 10),
  },

  // --- LAST WEEK ---
  // Order #1011: POS Sale (Cash ₦38,000)
  {
    ...baseOrder,
    wooId: null,
    localTransactionId: 'txn-011',
    orderNumber: '#1011',
    status: 'completed',
    source: 'pos',
    customerId: 9,
    customerName: 'Bola Ogundimu',
    customerEmail: 'bola.ogundimu@email.com',
    subtotal: toKobo(38000),
    transactionFee: 0,
    total: toKobo(38000),
    paymentMethod: 'cash',
    paymentMethodTitle: 'Cash',
    shippingMethod: 'in-store',
    itemCount: 2,
    createdAt: daysAgo(8, 14, 0),
    updatedAt: daysAgo(8, 14, 0),
    completedAt: daysAgo(8, 14, 0),
  },
  // Order #1012: Website Order (Online Payment ₦72,000)
  {
    ...baseOrder,
    wooId: 1012,
    localTransactionId: 'txn-012',
    orderNumber: '#1012',
    status: 'completed',
    source: 'website',
    customerId: 10,
    customerName: 'Kelechi Nnadi',
    customerEmail: 'kelechi.nnadi@email.com',
    subtotal: toKobo(72000),
    transactionFee: 0,
    total: toKobo(72000),
    paymentMethod: 'online',
    paymentMethodTitle: 'Online Payment',
    shippingMethod: 'delivery',
    itemCount: 3,
    createdAt: daysAgo(9, 11, 45),
    updatedAt: daysAgo(9, 11, 45),
    completedAt: daysAgo(9, 11, 45),
  },
  // Order #1013: POS Sale (POS Terminal ₦24,000)
  {
    ...baseOrder,
    wooId: null,
    localTransactionId: 'txn-013',
    orderNumber: '#1013',
    status: 'completed',
    source: 'pos',
    customerId: 1,
    customerName: 'Adunni Okafor',
    customerEmail: 'adunni.okafor@email.com',
    subtotal: toKobo(24000),
    transactionFee: 0,
    total: toKobo(24000),
    paymentMethod: 'pos',
    paymentMethodTitle: 'POS Terminal',
    shippingMethod: 'in-store',
    itemCount: 2,
    createdAt: daysAgo(11, 16, 20),
    updatedAt: daysAgo(11, 16, 20),
    completedAt: daysAgo(11, 16, 20),
  },
  // Order #1014: Website Order (Cancelled - Should NOT inflate revenue)
  {
    ...baseOrder,
    wooId: 1014,
    localTransactionId: 'txn-014',
    orderNumber: '#1014',
    status: 'cancelled',
    source: 'website',
    customerId: 2,
    customerName: 'Chidi Nwankwo',
    customerEmail: 'chidi.nwankwo@email.com',
    subtotal: toKobo(50000),
    transactionFee: 0,
    total: toKobo(50000),
    paymentMethod: 'online',
    paymentMethodTitle: 'Online Payment',
    shippingMethod: 'shipping',
    itemCount: 2,
    createdAt: daysAgo(12, 13, 0),
    updatedAt: daysAgo(12, 13, 0),
    completedAt: null,
  },

  // --- THIS MONTH (Earlier) ---
  // Order #1015: POS Sale (Cash ₦45,000)
  {
    ...baseOrder,
    wooId: null,
    localTransactionId: 'txn-015',
    orderNumber: '#1015',
    status: 'completed',
    source: 'pos',
    customerId: 3,
    customerName: 'Fatima Bello',
    customerEmail: 'fatima.bello@email.com',
    subtotal: toKobo(45000),
    transactionFee: 0,
    total: toKobo(45000),
    paymentMethod: 'cash',
    paymentMethodTitle: 'Cash',
    shippingMethod: 'in-store',
    itemCount: 3,
    createdAt: daysAgo(18, 10, 0),
    updatedAt: daysAgo(18, 10, 0),
    completedAt: daysAgo(18, 10, 0),
  },
  // Order #1016: Website Order (Online Payment ₦110,000)
  {
    ...baseOrder,
    wooId: 1016,
    localTransactionId: 'txn-016',
    orderNumber: '#1016',
    status: 'completed',
    source: 'website',
    customerId: 4,
    customerName: 'Emeka Obi',
    customerEmail: 'emeka.obi@email.com',
    subtotal: toKobo(110000),
    transactionFee: 0,
    total: toKobo(110000),
    paymentMethod: 'online',
    paymentMethodTitle: 'Online Payment',
    shippingMethod: 'delivery',
    itemCount: 5,
    createdAt: daysAgo(22, 14, 30),
    updatedAt: daysAgo(22, 14, 30),
    completedAt: daysAgo(22, 14, 30),
  },

  // --- LAST MONTH ---
  // Order #1017: POS Sale (POS Terminal ₦65,000)
  {
    ...baseOrder,
    wooId: null,
    localTransactionId: 'txn-017',
    orderNumber: '#1017',
    status: 'completed',
    source: 'pos',
    customerId: 5,
    customerName: 'Ngozi Eze',
    customerEmail: 'ngozi.eze@email.com',
    subtotal: toKobo(65000),
    transactionFee: 0,
    total: toKobo(65000),
    paymentMethod: 'pos',
    paymentMethodTitle: 'POS Terminal',
    shippingMethod: 'in-store',
    itemCount: 3,
    createdAt: daysAgo(38, 11, 0),
    updatedAt: daysAgo(38, 11, 0),
    completedAt: daysAgo(38, 11, 0),
  },
  // Order #1018: Website Order (Online Payment ₦130,000)
  {
    ...baseOrder,
    wooId: 1018,
    localTransactionId: 'txn-018',
    orderNumber: '#1018',
    status: 'completed',
    source: 'website',
    customerId: 6,
    customerName: 'Tunde Ajayi',
    customerEmail: 'tunde.ajayi@email.com',
    subtotal: toKobo(130000),
    transactionFee: 0,
    total: toKobo(130000),
    paymentMethod: 'online',
    paymentMethodTitle: 'Online Payment',
    shippingMethod: 'delivery',
    itemCount: 4,
    createdAt: daysAgo(42, 15, 0),
    updatedAt: daysAgo(42, 15, 0),
    completedAt: daysAgo(42, 15, 0),
  },
  // Order #1019: POS Sale (Cash ₦52,000)
  {
    ...baseOrder,
    wooId: null,
    localTransactionId: 'txn-019',
    orderNumber: '#1019',
    status: 'completed',
    source: 'pos',
    customerId: 7,
    customerName: 'Aisha Mohammed',
    customerEmail: 'aisha.mohammed@email.com',
    subtotal: toKobo(52000),
    transactionFee: 0,
    total: toKobo(52000),
    paymentMethod: 'cash',
    paymentMethodTitle: 'Cash',
    shippingMethod: 'in-store',
    itemCount: 2,
    createdAt: daysAgo(48, 12, 30),
    updatedAt: daysAgo(48, 12, 30),
    completedAt: daysAgo(48, 12, 30),
  },

  // --- EARLIER THIS YEAR ---
  // Order #1020: Website Order (Online Payment ₦145,000)
  {
    ...baseOrder,
    wooId: 1020,
    localTransactionId: 'txn-020',
    orderNumber: '#1020',
    status: 'completed',
    source: 'website',
    customerId: 8,
    customerName: 'Oluwaseun Adeyemi',
    customerEmail: 'oluwaseun.adeyemi@email.com',
    subtotal: toKobo(145000),
    transactionFee: 0,
    total: toKobo(145000),
    paymentMethod: 'online',
    paymentMethodTitle: 'Online Payment',
    shippingMethod: 'delivery',
    itemCount: 4,
    createdAt: daysAgo(85, 10, 0),
    updatedAt: daysAgo(85, 10, 0),
    completedAt: daysAgo(85, 10, 0),
  },
  // Order #1021: POS Sale (POS Terminal ₦80,000)
  {
    ...baseOrder,
    wooId: null,
    localTransactionId: 'txn-021',
    orderNumber: '#1021',
    status: 'completed',
    source: 'pos',
    customerId: 9,
    customerName: 'Bola Ogundimu',
    customerEmail: 'bola.ogundimu@email.com',
    subtotal: toKobo(80000),
    transactionFee: 0,
    total: toKobo(80000),
    paymentMethod: 'pos',
    paymentMethodTitle: 'POS Terminal',
    shippingMethod: 'in-store',
    itemCount: 3,
    createdAt: daysAgo(120, 14, 0),
    updatedAt: daysAgo(120, 14, 0),
    completedAt: daysAgo(120, 14, 0),
  },

  // --- LAST YEAR ---
  // Order #1022: POS Sale (Cash ₦75,000)
  {
    ...baseOrder,
    wooId: null,
    localTransactionId: 'txn-022',
    orderNumber: '#1022',
    status: 'completed',
    source: 'pos',
    customerId: 10,
    customerName: 'Kelechi Nnadi',
    customerEmail: 'kelechi.nnadi@email.com',
    subtotal: toKobo(75000),
    transactionFee: 0,
    total: toKobo(75000),
    paymentMethod: 'cash',
    paymentMethodTitle: 'Cash',
    shippingMethod: 'in-store',
    itemCount: 2,
    createdAt: daysAgo(390, 11, 0),
    updatedAt: daysAgo(390, 11, 0),
    completedAt: daysAgo(390, 11, 0),
  },
  // Order #1023: Website Order (Online Payment ₦95,000)
  {
    ...baseOrder,
    wooId: 1023,
    localTransactionId: 'txn-023',
    orderNumber: '#1023',
    status: 'completed',
    source: 'website',
    customerId: 1,
    customerName: 'Adunni Okafor',
    customerEmail: 'adunni.okafor@email.com',
    subtotal: toKobo(95000),
    transactionFee: 0,
    total: toKobo(95000),
    paymentMethod: 'online',
    paymentMethodTitle: 'Online Payment',
    shippingMethod: 'delivery',
    itemCount: 3,
    createdAt: daysAgo(420, 16, 0),
    updatedAt: daysAgo(420, 16, 0),
    completedAt: daysAgo(420, 16, 0),
  },
];

// ============================================================================
// ORDER ITEMS — populated for every order above
// ============================================================================
export const mockOrderItems: Omit<OrderItem, 'id'>[] = [
  // Order 1 (Order #1001)
  { orderId: 1, productId: 12, wooProductId: 302, name: 'Bluetooth Earbuds', sku: 'ELEC-002', price: toKobo(15000), quantity: 1, subtotal: toKobo(15000), total: toKobo(15000), discount: null, image: '' },
  { orderId: 1, productId: 11, wooProductId: 301, name: 'USB-C Fast Charger 65W', sku: 'ELEC-001', price: toKobo(20000), quantity: 1, subtotal: toKobo(20000), total: toKobo(20000), discount: null, image: '' },

  // Order 2 (Order #1002)
  { orderId: 2, productId: 13, wooProductId: 303, name: 'Power Bank 20000mAh', sku: 'ELEC-003', price: toKobo(25000), quantity: 1, subtotal: toKobo(25000), total: toKobo(25000), discount: null, image: '' },
  { orderId: 2, productId: 11, wooProductId: 301, name: 'USB-C Fast Charger 65W', sku: 'ELEC-001', price: toKobo(20000), quantity: 1, subtotal: toKobo(20000), total: toKobo(20000), discount: null, image: '' },

  // Order 3 (Order #1003)
  { orderId: 3, productId: 14, wooProductId: 304, name: 'Wireless Mouse', sku: 'ELEC-004', price: toKobo(8500), quantity: 1, subtotal: toKobo(8500), total: toKobo(8500), discount: null, image: '' },
  { orderId: 3, productId: 15, wooProductId: 305, name: 'Phone Stand Adjustable', sku: 'ELEC-005', price: toKobo(5000), quantity: 2, subtotal: toKobo(10000), total: toKobo(10000), discount: null, image: '' },

  // Order 4 (Order #1004)
  { orderId: 4, productId: 13, wooProductId: 303, name: 'Power Bank 20000mAh', sku: 'ELEC-003', price: toKobo(25000), quantity: 2, subtotal: toKobo(50000), total: toKobo(50000), discount: null, image: '' },
  { orderId: 4, productId: 12, wooProductId: 302, name: 'Bluetooth Earbuds', sku: 'ELEC-002', price: toKobo(12000), quantity: 1, subtotal: toKobo(12000), total: toKobo(12000), discount: null, image: '' },

  // Order 5 (Order #1005)
  { orderId: 5, productId: 12, wooProductId: 302, name: 'Bluetooth Earbuds', sku: 'ELEC-002', price: toKobo(15000), quantity: 3, subtotal: toKobo(45000), total: toKobo(45000), discount: null, image: '' },
  { orderId: 5, productId: 11, wooProductId: 301, name: 'USB-C Fast Charger 65W', sku: 'ELEC-001', price: toKobo(20000), quantity: 2, subtotal: toKobo(40000), total: toKobo(40000), discount: null, image: '' },

  // Order 6 (Order #1006)
  { orderId: 6, productId: 14, wooProductId: 304, name: 'Wireless Mouse', sku: 'ELEC-004', price: toKobo(8500), quantity: 1, subtotal: toKobo(8500), total: toKobo(8500), discount: null, image: '' },
  { orderId: 6, productId: 3, wooProductId: 103, name: 'Peak Milk 400g', sku: 'BEV-003', price: toKobo(2000), quantity: 2, subtotal: toKobo(4000), total: toKobo(4000), discount: null, image: '' },

  // Order 7 (Order #1007)
  { orderId: 7, productId: 12, wooProductId: 302, name: 'Bluetooth Earbuds', sku: 'ELEC-002', price: toKobo(15000), quantity: 1, subtotal: toKobo(15000), total: toKobo(15000), discount: null, image: '' },

  // Order 8 (Order #1008)
  { orderId: 8, productId: 11, wooProductId: 301, name: 'USB-C Fast Charger 65W', sku: 'ELEC-001', price: toKobo(20000), quantity: 1, subtotal: toKobo(20000), total: toKobo(20000), discount: null, image: '' },
  { orderId: 8, productId: 12, wooProductId: 302, name: 'Bluetooth Earbuds', sku: 'ELEC-002', price: toKobo(15000), quantity: 1, subtotal: toKobo(15000), total: toKobo(15000), discount: null, image: '' },
  { orderId: 8, productId: 14, wooProductId: 304, name: 'Wireless Mouse', sku: 'ELEC-004', price: toKobo(7000), quantity: 1, subtotal: toKobo(7000), total: toKobo(7000), discount: null, image: '' },

  // Order 9 (Order #1009)
  { orderId: 9, productId: 13, wooProductId: 303, name: 'Power Bank 20000mAh', sku: 'ELEC-003', price: toKobo(25000), quantity: 2, subtotal: toKobo(50000), total: toKobo(50000), discount: null, image: '' },
  { orderId: 9, productId: 11, wooProductId: 301, name: 'USB-C Fast Charger 65W', sku: 'ELEC-001', price: toKobo(20000), quantity: 2, subtotal: toKobo(40000), total: toKobo(40000), discount: null, image: '' },
  { orderId: 9, productId: 14, wooProductId: 304, name: 'Wireless Mouse', sku: 'ELEC-004', price: toKobo(8000), quantity: 1, subtotal: toKobo(8000), total: toKobo(8000), discount: null, image: '' },

  // Order 10 (Order #1010)
  { orderId: 10, productId: 12, wooProductId: 302, name: 'Bluetooth Earbuds', sku: 'ELEC-002', price: toKobo(15000), quantity: 2, subtotal: toKobo(30000), total: toKobo(30000), discount: null, image: '' },
  { orderId: 10, productId: 13, wooProductId: 303, name: 'Power Bank 20000mAh', sku: 'ELEC-003', price: toKobo(25000), quantity: 1, subtotal: toKobo(25000), total: toKobo(25000), discount: null, image: '' },

  // Order 11 (Order #1011)
  { orderId: 11, productId: 11, wooProductId: 301, name: 'USB-C Fast Charger 65W', sku: 'ELEC-001', price: toKobo(20000), quantity: 1, subtotal: toKobo(20000), total: toKobo(20000), discount: null, image: '' },
  { orderId: 11, productId: 14, wooProductId: 304, name: 'Wireless Mouse', sku: 'ELEC-004', price: toKobo(9000), quantity: 2, subtotal: toKobo(18000), total: toKobo(18000), discount: null, image: '' },

  // Order 12 (Order #1012)
  { orderId: 12, productId: 13, wooProductId: 303, name: 'Power Bank 20000mAh', sku: 'ELEC-003', price: toKobo(25000), quantity: 2, subtotal: toKobo(50000), total: toKobo(50000), discount: null, image: '' },
  { orderId: 12, productId: 15, wooProductId: 305, name: 'Phone Stand Adjustable', sku: 'ELEC-005', price: toKobo(11000), quantity: 2, subtotal: toKobo(22000), total: toKobo(22000), discount: null, image: '' },

  // Order 13 (Order #1013)
  { orderId: 13, productId: 12, wooProductId: 302, name: 'Bluetooth Earbuds', sku: 'ELEC-002', price: toKobo(12000), quantity: 2, subtotal: toKobo(24000), total: toKobo(24000), discount: null, image: '' },

  // Order 14 (Order #1014 - Cancelled)
  { orderId: 14, productId: 13, wooProductId: 303, name: 'Power Bank 20000mAh', sku: 'ELEC-003', price: toKobo(25000), quantity: 2, subtotal: toKobo(50000), total: toKobo(50000), discount: null, image: '' },

  // Order 15 (Order #1015)
  { orderId: 15, productId: 11, wooProductId: 301, name: 'USB-C Fast Charger 65W', sku: 'ELEC-001', price: toKobo(20000), quantity: 1, subtotal: toKobo(20000), total: toKobo(20000), discount: null, image: '' },
  { orderId: 15, productId: 13, wooProductId: 303, name: 'Power Bank 20000mAh', sku: 'ELEC-003', price: toKobo(25000), quantity: 1, subtotal: toKobo(25000), total: toKobo(25000), discount: null, image: '' },

  // Order 16 (Order #1016)
  { orderId: 16, productId: 12, wooProductId: 302, name: 'Bluetooth Earbuds', sku: 'ELEC-002', price: toKobo(15000), quantity: 4, subtotal: toKobo(60000), total: toKobo(60000), discount: null, image: '' },
  { orderId: 16, productId: 13, wooProductId: 303, name: 'Power Bank 20000mAh', sku: 'ELEC-003', price: toKobo(25000), quantity: 2, subtotal: toKobo(50000), total: toKobo(50000), discount: null, image: '' },

  // Order 17 (Order #1017)
  { orderId: 17, productId: 11, wooProductId: 301, name: 'USB-C Fast Charger 65W', sku: 'ELEC-001', price: toKobo(20000), quantity: 2, subtotal: toKobo(40000), total: toKobo(40000), discount: null, image: '' },
  { orderId: 17, productId: 13, wooProductId: 303, name: 'Power Bank 20000mAh', sku: 'ELEC-003', price: toKobo(25000), quantity: 1, subtotal: toKobo(25000), total: toKobo(25000), discount: null, image: '' },

  // Order 18 (Order #1018)
  { orderId: 18, productId: 12, wooProductId: 302, name: 'Bluetooth Earbuds', sku: 'ELEC-002', price: toKobo(15000), quantity: 4, subtotal: toKobo(60000), total: toKobo(60000), discount: null, image: '' },
  { orderId: 18, productId: 11, wooProductId: 301, name: 'USB-C Fast Charger 65W', sku: 'ELEC-001', price: toKobo(20000), quantity: 2, subtotal: toKobo(40000), total: toKobo(40000), discount: null, image: '' },
  { orderId: 18, productId: 12, wooProductId: 302, name: 'Bluetooth Earbuds', sku: 'ELEC-002', price: toKobo(15000), quantity: 2, subtotal: toKobo(30000), total: toKobo(30000), discount: null, image: '' },

  // Order 19 (Order #1019)
  { orderId: 19, productId: 14, wooProductId: 304, name: 'Wireless Mouse', sku: 'ELEC-004', price: toKobo(8500), quantity: 2, subtotal: toKobo(17000), total: toKobo(17000), discount: null, image: '' },
  { orderId: 19, productId: 12, wooProductId: 302, name: 'Bluetooth Earbuds', sku: 'ELEC-002', price: toKobo(15000), quantity: 1, subtotal: toKobo(15000), total: toKobo(15000), discount: null, image: '' },
  { orderId: 19, productId: 11, wooProductId: 301, name: 'USB-C Fast Charger 65W', sku: 'ELEC-001', price: toKobo(20000), quantity: 1, subtotal: toKobo(20000), total: toKobo(20000), discount: null, image: '' },

  // Order 20 (Order #1020)
  { orderId: 20, productId: 13, wooProductId: 303, name: 'Power Bank 20000mAh', sku: 'ELEC-003', price: toKobo(25000), quantity: 4, subtotal: toKobo(100000), total: toKobo(100000), discount: null, image: '' },
  { orderId: 20, productId: 12, wooProductId: 302, name: 'Bluetooth Earbuds', sku: 'ELEC-002', price: toKobo(15000), quantity: 3, subtotal: toKobo(45000), total: toKobo(45000), discount: null, image: '' },

  // Order 21 (Order #1021)
  { orderId: 21, productId: 11, wooProductId: 301, name: 'USB-C Fast Charger 65W', sku: 'ELEC-001', price: toKobo(20000), quantity: 4, subtotal: toKobo(80000), total: toKobo(80000), discount: null, image: '' },

  // Order 22 (Order #1022)
  { orderId: 22, productId: 13, wooProductId: 303, name: 'Power Bank 20000mAh', sku: 'ELEC-003', price: toKobo(25000), quantity: 3, subtotal: toKobo(75000), total: toKobo(75000), discount: null, image: '' },

  // Order 23 (Order #1023)
  { orderId: 23, productId: 12, wooProductId: 302, name: 'Bluetooth Earbuds', sku: 'ELEC-002', price: toKobo(15000), quantity: 3, subtotal: toKobo(45000), total: toKobo(45000), discount: null, image: '' },
  { orderId: 23, productId: 13, wooProductId: 303, name: 'Power Bank 20000mAh', sku: 'ELEC-003', price: toKobo(25000), quantity: 2, subtotal: toKobo(50000), total: toKobo(50000), discount: null, image: '' },
];

// ============================================================================
// SEED DATABASE
// ============================================================================
export async function seedDemoData(database: import('dexie').Dexie): Promise<void> {
  const db = database as import('@/db').ZameriaDatabase;

  // Clear existing data first
  await db.transaction('rw',
    [db.categories, db.products, db.customers, db.orders, db.orderItems],
    async () => {
      await db.categories.clear();
      await db.products.clear();
      await db.customers.clear();
      await db.orders.clear();
      await db.orderItems.clear();

      // Seed categories
      await db.categories.bulkAdd(mockCategories as Category[]);

      // Seed products
      await db.products.bulkAdd(mockProducts as Product[]);

      // Seed customers
      await db.customers.bulkAdd(mockCustomers as Customer[]);

      // Seed orders
      await db.orders.bulkAdd(mockOrders as Order[]);

      // Seed order items
      await db.orderItems.bulkAdd(mockOrderItems as OrderItem[]);
    }
  );
}
