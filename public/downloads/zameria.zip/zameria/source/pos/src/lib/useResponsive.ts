import { useState, useEffect } from 'react';

export type DeviceType = 'mobile' | 'tablet' | 'desktop';

export interface ResponsiveLayout {
  isMobile: boolean;    // < 768px (Phones)
  isTablet: boolean;    // >= 768px and < 1024px (Tablets)
  isDesktop: boolean;   // >= 1024px (Desktops / Laptops)
  isPortrait: boolean;
  isLandscape: boolean;
  deviceType: DeviceType;
  width: number;
  height: number;
}

function getLayoutState(): ResponsiveLayout {
  if (typeof window === 'undefined') {
    return {
      isMobile: false,
      isTablet: false,
      isDesktop: true,
      isPortrait: false,
      isLandscape: true,
      deviceType: 'desktop',
      width: 1280,
      height: 800,
    };
  }

  const width = window.innerWidth;
  const height = window.innerHeight;
  const isMobile = width < 768;
  const isTablet = width >= 768 && width < 1024;
  const isDesktop = width >= 1024;
  const isPortrait = height > width;
  const isLandscape = !isPortrait;

  const deviceType: DeviceType = isMobile ? 'mobile' : isTablet ? 'tablet' : 'desktop';

  return {
    isMobile,
    isTablet,
    isDesktop,
    isPortrait,
    isLandscape,
    deviceType,
    width,
    height,
  };
}

export function useResponsive(): ResponsiveLayout {
  const [layout, setLayout] = useState<ResponsiveLayout>(getLayoutState);

  useEffect(() => {
    let timeoutId: any = null;

    const handleResize = () => {
      // Debounce slightly to handle rapid orientation changes cleanly
      clearTimeout(timeoutId);
      timeoutId = setTimeout(() => {
        setLayout(getLayoutState());
      }, 50);
    };

    window.addEventListener('resize', handleResize);
    window.addEventListener('orientationchange', handleResize);

    return () => {
      clearTimeout(timeoutId);
      window.removeEventListener('resize', handleResize);
      window.removeEventListener('orientationchange', handleResize);
    };
  }, []);

  return layout;
}
