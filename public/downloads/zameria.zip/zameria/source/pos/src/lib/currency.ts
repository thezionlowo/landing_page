import { useState, useEffect } from 'react';
import type { MoneyKobo } from '@/types';

/**
 * ZAMERIA POS Store Currency Architecture
 * 
 * Source of Truth: The connected WooCommerce store.
 * 
 * WooCommerce dictates:
 * - Currency code (e.g. "NGN", "USD", "EUR", "GBP")
 * - Currency symbol (e.g. "₦", "$", "€", "£")
 * - Currency position ("left", "right", "left_space", "right_space")
 * - Decimal precision and separators
 * 
 * IMPORTANT ARCHITECTURAL SEPARATION:
 * - ZAMERIA SaaS billing currency (Nigeria = NGN, Outside = USD) is completely independent.
 * - POS store currency is NEVER determined by merchant geolocation and NEVER converted.
 */

export interface StoreCurrency {
  code: string;
  symbol: string;
  position: 'left' | 'right' | 'left_space' | 'right_space';
  decimals: number;
  decimalSeparator: string;
  thousandSeparator: string;
}

export const DEFAULT_STORE_CURRENCY: StoreCurrency = {
  code: 'NGN',
  symbol: '₦',
  position: 'left',
  decimals: 2,
  decimalSeparator: '.',
  thousandSeparator: ',',
};

export const KNOWN_CURRENCY_SYMBOLS: Record<string, string> = {
  NGN: '₦',
  USD: '$',
  EUR: '€',
  GBP: '£',
  CAD: '$',
  AUD: '$',
  KES: 'KSh',
  GHS: 'GH₵',
  ZAR: 'R',
  JPY: '¥',
  INR: '₹',
  CHF: 'CHF',
};

const CURRENCY_STORAGE_KEY = 'zameria_store_currency';

export function decodeCurrencySymbol(rawSymbol: string | undefined | null, code: string): string {
  if (!rawSymbol || typeof rawSymbol !== 'string' || !rawSymbol.trim()) {
    return KNOWN_CURRENCY_SYMBOLS[code.toUpperCase()] || code;
  }
  let s = rawSymbol.trim();
  if (s.includes('&')) {
    if (s === '&#36;' || s === '&dollar;') return '$';
    if (s === '&euro;' || s === '&#8364;') return '€';
    if (s === '&pound;' || s === '&#163;') return '£';
    if (s === '&#8358;') return '₦';
    if (s === '&#165;') return '¥';
    if (typeof document !== 'undefined') {
      try {
        const txt = document.createElement('textarea');
        txt.innerHTML = s;
        s = txt.value;
      } catch {}
    }
  }
  return s || KNOWN_CURRENCY_SYMBOLS[code.toUpperCase()] || code;
}

function loadInitialCurrency(): StoreCurrency {
  if (typeof localStorage !== 'undefined') {
    try {
      const raw = localStorage.getItem(CURRENCY_STORAGE_KEY);
      if (raw) {
        const parsed = JSON.parse(raw);
        if (parsed && typeof parsed.code === 'string') {
          return {
            code: parsed.code.toUpperCase(),
            symbol: decodeCurrencySymbol(parsed.symbol, parsed.code),
            position: (parsed.position as any) || 'left',
            decimals: typeof parsed.decimals === 'number' ? parsed.decimals : 2,
            decimalSeparator: parsed.decimalSeparator || parsed.decimal_separator || '.',
            thousandSeparator: parsed.thousandSeparator || parsed.thousand_separator || ',',
          };
        }
      }
    } catch {}
  }
  return DEFAULT_STORE_CURRENCY;
}

let activeStoreCurrency: StoreCurrency = loadInitialCurrency();
const currencyListeners = new Set<(c: StoreCurrency) => void>();

export function getStoreCurrency(): StoreCurrency {
  return activeStoreCurrency;
}

export function setStoreCurrency(update: Partial<StoreCurrency> | Record<string, any> | undefined | null): void {
  if (!update || typeof update !== 'object') return;
  const rawUpdate = update as Record<string, any>;
  const rawCode = (rawUpdate.code || activeStoreCurrency.code || 'NGN').toUpperCase();
  const rawSymbol = rawUpdate.symbol !== undefined ? rawUpdate.symbol : activeStoreCurrency.symbol;
  const symbol = decodeCurrencySymbol(rawSymbol, rawCode);
  const position = (rawUpdate.position as any) || activeStoreCurrency.position || 'left';
  const decimals = typeof rawUpdate.decimals === 'number' ? rawUpdate.decimals : activeStoreCurrency.decimals;
  const decimalSeparator = rawUpdate.decimal_separator || rawUpdate.decimalSeparator || activeStoreCurrency.decimalSeparator || '.';
  const thousandSeparator = rawUpdate.thousand_separator || rawUpdate.thousandSeparator || activeStoreCurrency.thousandSeparator || ',';

  activeStoreCurrency = {
    code: rawCode,
    symbol,
    position,
    decimals,
    decimalSeparator,
    thousandSeparator,
  };

  if (typeof localStorage !== 'undefined') {
    try {
      localStorage.setItem(CURRENCY_STORAGE_KEY, JSON.stringify(activeStoreCurrency));
    } catch {}
  }

  currencyListeners.forEach((fn) => {
    try {
      fn(activeStoreCurrency);
    } catch {}
  });
}

export function subscribeStoreCurrency(listener: (currency: StoreCurrency) => void): () => void {
  currencyListeners.add(listener);
  return () => {
    currencyListeners.delete(listener);
  };
}

/**
 * React Hook for reactive store currency updates across screens
 */
export function useStoreCurrency(): StoreCurrency {
  const [currency, setCurrency] = useState<StoreCurrency>(activeStoreCurrency);
  useEffect(() => {
    return subscribeStoreCurrency(setCurrency);
  }, []);
  return currency;
}

// Convert major currency unit (e.g., 25.50) to minor subunits (e.g. 2550 kobo/cents)
export function toKobo(amount: number): MoneyKobo {
  if (typeof amount !== 'number' || isNaN(amount) || !isFinite(amount)) return 0;
  return Math.round(amount * 100);
}

// Convert minor subunits (e.g. 2550 kobo/cents) to major display number (e.g. 25.50)
export function fromKobo(kobo: MoneyKobo): number {
  if (typeof kobo !== 'number' || isNaN(kobo) || !isFinite(kobo)) return 0;
  return kobo / 100;
}

/**
 * Formats minor subunits (kobo/cents) into the connected WooCommerce store's currency format.
 * Respects WooCommerce store currency, symbol, position, decimals and separators.
 */
export function formatMoney(kobo: MoneyKobo, customSymbol?: string, hideDecimals?: boolean): string {
  const curr = activeStoreCurrency;
  const symbol = customSymbol !== undefined ? customSymbol : curr.symbol;

  if (kobo == null || typeof kobo !== 'number' || isNaN(kobo) || !isFinite(kobo)) {
    return formatCurrencyAmount(0, symbol, curr, hideDecimals);
  }

  const major = fromKobo(kobo);
  return formatCurrencyAmount(major, symbol, curr, hideDecimals);
}

function formatCurrencyAmount(amount: number, symbol: string, curr: StoreCurrency, hideDecimals?: boolean): string {
  const decimals = hideDecimals ? 0 : Math.max(0, curr.decimals ?? 2);
  const isNegative = amount < 0;
  const absAmount = Math.abs(amount);
  
  const parts = absAmount.toFixed(decimals).split('.');
  const intPart = parts[0].replace(/\B(?=(\d{3})+(?!\d))/g, curr.thousandSeparator || ',');
  const decPart = parts[1];
  
  const formattedNumber = decimals > 0 && decPart !== undefined
    ? `${intPart}${curr.decimalSeparator || '.'}${decPart}`
    : intPart;

  let formatted = '';
  switch (curr.position) {
    case 'right':
      formatted = `${formattedNumber}${symbol}`;
      break;
    case 'right_space':
      formatted = `${formattedNumber} ${symbol}`;
      break;
    case 'left_space':
      formatted = `${symbol} ${formattedNumber}`;
      break;
    case 'left':
    default:
      formatted = `${symbol}${formattedNumber}`;
      break;
  }

  return isNegative ? `-${formatted}` : formatted;
}

// Calculate line total for a cart item with discount
export function calculateLineTotal(
  unitPrice: MoneyKobo,
  quantity: number,
  discount: { type: string; value: number } | null
): MoneyKobo {
  const safeUnitPrice = typeof unitPrice === 'number' && !isNaN(unitPrice) && isFinite(unitPrice) ? Math.max(0, unitPrice) : 0;
  const safeQuantity = typeof quantity === 'number' && !isNaN(quantity) && isFinite(quantity) ? Math.max(0, quantity) : 0;
  const gross = safeUnitPrice * safeQuantity;
  if (!discount || typeof discount.value !== 'number' || isNaN(discount.value) || !isFinite(discount.value)) {
    return gross;
  }

  switch (discount.type) {
    case 'price_override':
      // Value is the new unit price in kobo/cents
      const overridePrice = Math.max(0, discount.value);
      return overridePrice * safeQuantity;
    case 'fixed_amount':
      // Value is the fixed discount amount in kobo/cents (per line)
      return Math.max(0, gross - Math.max(0, discount.value));
    case 'percentage':
      // Value is the percentage (e.g., 10 for 10%)
      const pct = Math.min(100, Math.max(0, discount.value));
      const discountAmount = Math.round(gross * (pct / 100));
      return Math.max(0, gross - discountAmount);
    default:
      return gross;
  }
}

// Calculate transaction fee
export function calculateTransactionFee(
  subtotal: MoneyKobo,
  feePercentage: number
): MoneyKobo {
  if (
    typeof subtotal !== 'number' || isNaN(subtotal) || !isFinite(subtotal) || subtotal <= 0 ||
    typeof feePercentage !== 'number' || isNaN(feePercentage) || !isFinite(feePercentage) || feePercentage <= 0
  ) {
    return 0;
  }
  return Math.round(subtotal * (feePercentage / 100));
}

// Safe rounding for currency operations
export function roundMoney(kobo: MoneyKobo): MoneyKobo {
  return Math.round(kobo);
}
