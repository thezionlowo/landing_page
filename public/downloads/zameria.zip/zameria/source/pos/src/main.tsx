import React, { Component, type ErrorInfo, type ReactNode } from 'react';
import ReactDOM from 'react-dom/client';
import { BrowserRouter } from 'react-router';
import { Toaster } from 'sonner';
import App from './App';
import { AppUpdateNotice } from './components/common/AppUpdateNotice';
import { useUIStore } from './store';
import './index.css';

// In development, ensure any stale service worker from previous dev runs is unregistered
if (import.meta.env.DEV && typeof navigator !== 'undefined' && 'serviceWorker' in navigator) {
  navigator.serviceWorker.getRegistrations().then((registrations) => {
    for (const registration of registrations) {
      registration.unregister();
    }
  });
}

interface ErrorBoundaryProps {
  children: ReactNode;
}

interface ErrorBoundaryState {
  hasError: boolean;
  error: Error | null;
}

class RootErrorBoundary extends Component<ErrorBoundaryProps, ErrorBoundaryState> {
  constructor(props: ErrorBoundaryProps) {
    super(props);
    this.state = { hasError: false, error: null };
  }

  static getDerivedStateFromError(error: Error): ErrorBoundaryState {
    return { hasError: true, error };
  }

  componentDidCatch(error: Error, errorInfo: ErrorInfo) {
    console.error('ZAMERIA POS Uncaught Render Error:', error, errorInfo);
  }

  handleReset = () => {
    try {
      localStorage.removeItem('zameria_auth_session');
    } catch {}
    window.location.href = '/login';
  };

  render() {
    if (this.state.hasError) {
      return (
        <div className="min-h-screen flex items-center justify-center p-6 bg-[#F8FAFC] dark:bg-[#071A31] text-[#071A31] dark:text-white font-sans">
          <div className="max-w-md w-full bg-white dark:bg-[#0C2340] border border-rose-200 dark:border-rose-900/60 rounded-2xl p-6 shadow-sm space-y-4">
            <h2 className="text-lg font-bold text-rose-600 dark:text-rose-400">Something went wrong</h2>
            <p className="text-xs text-slate-600 dark:text-slate-300">
              {this.state.error?.message || 'An unexpected error occurred while rendering the Sales Dashboard.'}
            </p>
            <div className="flex gap-2">
              <button
                onClick={() => window.location.reload()}
                className="px-4 py-2 text-xs font-semibold bg-[#071A31] text-white rounded-lg cursor-pointer"
              >
                Reload
              </button>
              <button
                onClick={this.handleReset}
                className="px-4 py-2 text-xs font-semibold border border-slate-300 rounded-lg cursor-pointer"
              >
                Reset Session
              </button>
            </div>
          </div>
        </div>
      );
    }
    return this.props.children;
  }
}

function ThemedToaster() {
  const theme = useUIStore(s => s.theme);
  const resolved = theme === 'system'
    ? (window.matchMedia('(prefers-color-scheme: dark)').matches ? 'dark' : 'light')
    : theme;

  return (
    <Toaster
      position="top-right"
      theme={resolved}
      toastOptions={{
        style: {
          background: 'var(--color-surface-100)',
          border: '1px solid var(--color-surface-300)',
          color: 'var(--color-surface-900)',
        },
      }}
    />
  );
}

// The plugin serves the app under /pos/ and sets <base href="/pos/">; routes live below it.
const routerBase = new URL(document.baseURI).pathname.replace(/\/$/, '') || '/';

ReactDOM.createRoot(document.getElementById('root')!).render(
  <React.StrictMode>
    <RootErrorBoundary>
      <BrowserRouter basename={routerBase}>
        <App />
        <AppUpdateNotice />
        <ThemedToaster />
      </BrowserRouter>
    </RootErrorBoundary>
  </React.StrictMode>
);
