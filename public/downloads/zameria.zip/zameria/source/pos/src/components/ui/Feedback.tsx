import React from 'react';
import { cn } from '@/lib';

export interface EmptyStateProps {
  icon: React.ReactNode;
  title: string;
  description?: string;
  action?: React.ReactNode;
  className?: string;
}

export function EmptyState({ icon, title, description, action, className }: EmptyStateProps) {
  return (
    <div className={cn('flex flex-col items-center justify-center py-12 px-4 text-center select-none', className)}>
      <div className="text-surface-400 mb-3 flex items-center justify-center">{icon}</div>
      <h3 className="text-xs font-bold text-surface-700 tracking-wider uppercase mb-1">{title}</h3>
      {description && <p className="text-xs text-surface-400 max-w-xs mb-4 leading-relaxed">{description}</p>}
      {action}
    </div>
  );
}

export function LoadingState({ text = 'Loading...' }: { text?: string }) {
  return (
    <div className="flex flex-col items-center justify-center py-16 gap-2.5">
      <div className="w-6 h-6 border-2 border-surface-300 border-t-[#60A5FA] rounded-full animate-spin" />
      <p className="text-xs text-surface-500 font-medium">{text}</p>
    </div>
  );
}

export function SkeletonCard() {
  return (
    <div className="pos-card p-3 space-y-2.5">
      <div className="skeleton h-24 w-full rounded" />
      <div className="skeleton h-3.5 w-3/4 rounded" />
      <div className="flex items-center justify-between pt-1">
        <div className="skeleton h-4 w-16 rounded" />
        <div className="skeleton h-3 w-12 rounded" />
      </div>
    </div>
  );
}

export function SkeletonRow() {
  return (
    <div className="flex items-center gap-3 p-3 border-b border-surface-200">
      <div className="skeleton h-9 w-9 rounded flex-shrink-0" />
      <div className="flex-1 space-y-1.5 min-w-0">
        <div className="skeleton h-3.5 w-1/3 rounded" />
        <div className="skeleton h-2.5 w-1/4 rounded" />
      </div>
      <div className="skeleton h-3.5 w-16 rounded" />
    </div>
  );
}

export interface ErrorStateProps {
  message: string;
  onRetry?: () => void;
}

export function ErrorState({ message, onRetry }: ErrorStateProps) {
  return (
    <div className="flex flex-col items-center justify-center py-12 px-4 text-center">
      <div className="w-10 h-10 rounded-full bg-danger-500/10 text-danger-500 flex items-center justify-center mb-3">
        <span className="font-bold text-base">!</span>
      </div>
      <p className="text-xs text-surface-700 font-medium mb-3">{message}</p>
      {onRetry && (
        <button
          type="button"
          onClick={onRetry}
          className="px-3.5 py-1.5 text-xs font-semibold text-white bg-[#071A31] hover:bg-[#0C2340] rounded-lg shadow-xs transition-colors cursor-pointer"
        >
          Try Again
        </button>
      )}
    </div>
  );
}
