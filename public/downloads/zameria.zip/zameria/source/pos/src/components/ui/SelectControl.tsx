import React, { useEffect, useId, useLayoutEffect, useRef, useState } from 'react';
import { createPortal } from 'react-dom';
import { Check, ChevronDown } from 'lucide-react';
import { cn } from '@/lib';

type Option = { value: string; label: React.ReactNode; text: string; disabled: boolean };
function readOptions(children: React.ReactNode, disabled = false): Option[] {
  return React.Children.toArray(children).flatMap(child => {
    if (!React.isValidElement<{ value?: string | number; children?: React.ReactNode; disabled?: boolean }>(child)) return [];
    if (child.type === 'option') {
      const text = React.Children.toArray(child.props.children).join('');
      return [{ value: String(child.props.value ?? text), label: child.props.children, text, disabled: disabled || !!child.props.disabled }];
    }
    return readOptions(child.props.children, disabled || !!child.props.disabled);
  });
}

/** Opaque, keyboard-operated select. The native element retains form and change-event semantics. */
export const SelectControl = React.forwardRef<HTMLSelectElement, React.SelectHTMLAttributes<HTMLSelectElement>>(
  ({ children, value, defaultValue, onChange, className, id, disabled, title, ...props }, forwardedRef) => {
    const generatedId = useId();
    const controlId = id || generatedId;
    const native = useRef<HTMLSelectElement | null>(null);
    const trigger = useRef<HTMLButtonElement>(null);
    const menu = useRef<HTMLDivElement>(null);
    const options = readOptions(children);
    const [internal, setInternal] = useState(String(defaultValue ?? options[0]?.value ?? ''));
    const selected = options.findIndex(option => option.value === String(value ?? internal));
    const [open, setOpen] = useState(false);
    const [active, setActive] = useState(0);
    const [position, setPosition] = useState<React.CSSProperties>({});
    const search = useRef({ text: '', time: 0 });
    const choose = (index: number) => {
      const option = options[index];
      if (!option || option.disabled || disabled) return;
      if (native.current) {
        native.current.value = option.value;
        native.current.dispatchEvent(new Event('change', { bubbles: true }));
      }
      setOpen(false);
    };
    const show = () => { if (!disabled) { setActive(Math.max(0, selected)); setOpen(true); } };
    useLayoutEffect(() => {
      if (!open) return;
      const place = () => {
        const rect = trigger.current?.getBoundingClientRect();
        if (!rect) return;
        if (rect.bottom < 0 || rect.top > window.innerHeight) { setOpen(false); return; }
        const width = Math.min(Math.max(rect.width, 200), window.innerWidth - 16);
        const below = window.innerHeight - rect.bottom - 12;
        const above = rect.top - 12;
        const upward = below < Math.min(240, options.length * 40 + 8) && above > below;
        const maxHeight = Math.min(280, Math.max(80, upward ? above : below));
        setPosition({ position: 'fixed', width, maxHeight, left: Math.max(8, Math.min(rect.left, window.innerWidth - width - 8)), ...(upward ? { bottom: window.innerHeight - rect.top + 4 } : { top: rect.bottom + 4 }) });
      };
      place();
      window.addEventListener('resize', place);
      // Keep the menu anchored through browser auto-scrolling and responsive layout changes.
      const scroll = (event: Event) => { if (!menu.current?.contains(event.target as Node)) place(); };
      document.addEventListener('scroll', scroll, true);
      const observer = new ResizeObserver(place);
      if (trigger.current) observer.observe(trigger.current);
      return () => { observer.disconnect(); window.removeEventListener('resize', place); document.removeEventListener('scroll', scroll, true); };
    }, [open, options.length]);
    useEffect(() => {
      if (!open) return;
      const outside = (event: PointerEvent) => {
        if (!trigger.current?.contains(event.target as Node) && !menu.current?.contains(event.target as Node)) setOpen(false);
      };
      // Capture before a parent dialog so Escape closes only this menu first.
      const escape = (event: KeyboardEvent) => { if (event.key === 'Escape') { event.preventDefault(); event.stopImmediatePropagation(); setOpen(false); } };
      document.addEventListener('pointerdown', outside);
      window.addEventListener('keydown', escape, true);
      return () => { document.removeEventListener('pointerdown', outside); window.removeEventListener('keydown', escape, true); };
    }, [open]);
    useEffect(() => { if (disabled) setOpen(false); }, [disabled]);
    useEffect(() => {
      const list = menu.current;
      const option = list?.querySelector<HTMLElement>(`[data-option-index="${active}"]`);
      if (!open || !list || !option) return;
      // Scroll only the menu; scrollIntoView can also move the workspace behind it.
      if (option.offsetTop < list.scrollTop) list.scrollTop = option.offsetTop;
      else if (option.offsetTop + option.offsetHeight > list.scrollTop + list.clientHeight) list.scrollTop = option.offsetTop + option.offsetHeight - list.clientHeight;
    }, [open, active]);
    const move = (direction: number) => {
      let next = active;
      for (let count = 0; count < options.length; count++) {
        next = (next + direction + options.length) % options.length;
        if (!options[next].disabled) { setActive(next); break; }
      }
    };
    return <>
      <select {...props} ref={element => { native.current = element; if (typeof forwardedRef === 'function') forwardedRef(element); else if (forwardedRef) forwardedRef.current = element; }} hidden style={{display:'none'}} aria-hidden="true" aria-label={undefined} aria-labelledby={undefined} tabIndex={-1} disabled={disabled} value={value} defaultValue={defaultValue} onChange={event => { setInternal(event.target.value); onChange?.(event); }}>{children}</select>
      <button type="button" ref={trigger} id={controlId} disabled={disabled} title={title}
        role="combobox" aria-haspopup="listbox" aria-expanded={open} aria-controls={open ? `${controlId}-options` : undefined}
        aria-activedescendant={open ? `${controlId}-option-${active}` : undefined}
        aria-label={props['aria-label'] || title} aria-labelledby={props['aria-labelledby']} aria-describedby={props['aria-describedby']} aria-invalid={props['aria-invalid']} aria-required={props.required || undefined}
        className={cn('pos-select-control', className)} onClick={() => open ? setOpen(false) : show()} onBlur={() => setOpen(false)}
        onKeyDown={event => {
          if (event.key === 'Tab') { setOpen(false); return; }
          if (event.key === 'ArrowDown' || event.key === 'ArrowUp') { event.preventDefault(); if (!open) show(); else move(event.key === 'ArrowDown' ? 1 : -1); }
          else if (event.key === 'Enter' || event.key === ' ') { event.preventDefault(); if (open) choose(active); else show(); }
          else if (event.key === 'Home' || event.key === 'End') { event.preventDefault(); const indices = options.map((_, index) => index).filter(index => !options[index].disabled); if (!open) setOpen(true); setActive((event.key === 'Home' ? indices[0] : indices.at(-1)) ?? 0); }
          else if (event.key.length === 1 && !event.ctrlKey && !event.metaKey && !event.altKey) {
            const now = Date.now(); search.current = { text: (now - search.current.time < 600 ? search.current.text : '') + event.key.toLowerCase(), time: now };
            const index = options.findIndex(option => !option.disabled && option.text.toLowerCase().startsWith(search.current.text));
            if (index >= 0) { event.preventDefault(); if (open) setActive(index); else choose(index); }
          }
        }}>
        <span className="pos-select-value">{options[selected]?.label ?? options[0]?.label ?? 'Select…'}</span><ChevronDown aria-hidden="true" className="pos-select-chevron" />
      </button>
      {open && createPortal(<div ref={menu} id={`${controlId}-options`} role="listbox" aria-label={props['aria-label'] || title} aria-labelledby={props['aria-labelledby']} className="pos-select-menu" style={position} onMouseDown={event => event.preventDefault()}>
        {options.map((option, index) => <div key={`${option.value}-${index}`} id={`${controlId}-option-${index}`} role="option" aria-selected={index === selected} aria-disabled={option.disabled || undefined} data-option-index={index} className={cn('pos-select-option', active === index && 'is-active', option.disabled && 'is-disabled')} onMouseMove={() => !option.disabled && setActive(index)} onClick={() => choose(index)}>
          <span>{option.label}</span>{index === selected && <Check aria-hidden="true" className="w-4 h-4 shrink-0" />}
        </div>)}
      </div>, trigger.current?.closest('[role="dialog"]') ?? document.body)}
    </>;
  }
);
SelectControl.displayName = 'SelectControl';
