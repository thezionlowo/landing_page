import React, { useState, useEffect, useLayoutEffect, useRef, useCallback } from 'react';
import { cn } from '@/lib';

export interface ResizableSplitViewProps {
  left: React.ReactNode;
  right: React.ReactNode;
  storageKey: string;
  defaultSplit?: number; // Left panel percentage (0 - 100), default 60
  minLeftPercent?: number; // Minimum left width %, default 25
  maxLeftPercent?: number; // Maximum left width %, default 75
  minRightPixels?: number; // Minimum right panel width in pixels, default 0
  className?: string;
  leftClassName?: string;
  rightClassName?: string;
  isRightVisible?: boolean;
}

export function ResizableSplitView({
  left,
  right,
  storageKey,
  defaultSplit = 60,
  minLeftPercent = 25,
  maxLeftPercent = 75,
  minRightPixels = 0,
  className,
  leftClassName,
  rightClassName,
  isRightVisible = true,
}: ResizableSplitViewProps) {
  const containerRef = useRef<HTMLDivElement>(null);
  const [splitPercent, setSplitPercent] = useState<number>(() => {
    try {
      const saved = localStorage.getItem(storageKey);
      if (saved) {
        const parsed = parseFloat(saved);
        if (!isNaN(parsed) && parsed >= minLeftPercent && parsed <= maxLeftPercent) {
          return parsed;
        }
      }
    } catch {
      // Fallback
    }
    return defaultSplit;
  });

  const [isDragging, setIsDragging] = useState(false);

  // Clamp left percentage to respect both min/max percentages and minimum right panel pixels
  const getClampedPercent = useCallback(
    (targetPercent: number) => {
      let maxAllowedLeft = maxLeftPercent;
      if (containerRef.current && minRightPixels && minRightPixels > 0) {
        const containerWidth = containerRef.current.getBoundingClientRect().width;
        if (containerWidth > minRightPixels + 100) {
          const maxLeftByPixels = ((containerWidth - minRightPixels - 4) / containerWidth) * 100;
          maxAllowedLeft = Math.min(maxLeftPercent, Math.max(minLeftPercent, maxLeftByPixels));
        } else if (containerWidth > 0) {
          maxAllowedLeft = Math.min(maxLeftPercent, 50);
        }
      }
      return Math.min(Math.max(targetPercent, minLeftPercent), maxAllowedLeft);
    },
    [minLeftPercent, maxLeftPercent, minRightPixels]
  );

  // Dynamically adapt split when window / container resizes or rotates (orientation change)
  useLayoutEffect(() => {
    const handleResize = () => {
      setSplitPercent((current) => {
        const clamped = getClampedPercent(current);
        return Math.abs(clamped - current) > 0.1 ? clamped : current;
      });
    };

    const container = containerRef.current;
    if (!container || !isRightVisible) return;
    const observer = new ResizeObserver(handleResize);
    observer.observe(container);
    // Resolve the panel widths before paint, including after a sidebar resize.
    handleResize();
    return () => observer.disconnect();
  }, [getClampedPercent, isRightVisible]);

  // Save to localStorage when split changes (debounced or on release)
  const saveSplit = useCallback(
    (val: number) => {
      try {
        localStorage.setItem(storageKey, val.toFixed(1));
      } catch {
        // Ignore localStorage quota errors
      }
    },
    [storageKey]
  );

  const handleMouseDown = useCallback((e: React.MouseEvent) => {
    e.preventDefault();
    setIsDragging(true);
  }, []);

  useEffect(() => {
    if (!isDragging) return;

    const handleMouseMove = (e: MouseEvent) => {
      if (!containerRef.current) return;
      const rect = containerRef.current.getBoundingClientRect();
      const containerWidth = rect.width;
      if (containerWidth <= 0) return;

      const offsetX = e.clientX - rect.left;
      const newPercent = (offsetX / containerWidth) * 100;

      const clamped = getClampedPercent(newPercent);
      setSplitPercent(clamped);
    };

    const handleMouseUp = () => {
      setIsDragging(false);
      setSplitPercent((latest) => {
        saveSplit(latest);
        return latest;
      });
    };

    const handleTouchMove = (e: TouchEvent) => {
      if (!containerRef.current || !e.touches[0]) return;
      const rect = containerRef.current.getBoundingClientRect();
      const containerWidth = rect.width;
      if (containerWidth <= 0) return;

      const offsetX = e.touches[0].clientX - rect.left;
      const newPercent = (offsetX / containerWidth) * 100;

      const clamped = getClampedPercent(newPercent);
      setSplitPercent(clamped);
    };

    const handleTouchEnd = () => {
      setIsDragging(false);
      setSplitPercent((latest) => {
        saveSplit(latest);
        return latest;
      });
    };

    window.addEventListener('mousemove', handleMouseMove);
    window.addEventListener('mouseup', handleMouseUp);
    window.addEventListener('touchmove', handleTouchMove, { passive: true });
    window.addEventListener('touchend', handleTouchEnd);

    // Prevent text selection during drag
    document.body.style.userSelect = 'none';
    document.body.style.cursor = 'col-resize';

    return () => {
      window.removeEventListener('mousemove', handleMouseMove);
      window.removeEventListener('mouseup', handleMouseUp);
      window.removeEventListener('touchmove', handleTouchMove);
      window.removeEventListener('touchend', handleTouchEnd);
      document.body.style.userSelect = '';
      document.body.style.cursor = '';
    };
  }, [isDragging, getClampedPercent, saveSplit]);

  // If right panel is toggled off (e.g. on mobile or full view)
  if (!isRightVisible) {
    return (
      <div className={cn('flex h-full w-full overflow-hidden bg-surface-50', className)}>
        <div className={cn('w-full h-full flex flex-col min-w-0 overflow-hidden', leftClassName)}>
          {left}
        </div>
      </div>
    );
  }

  return (
    <div
      ref={containerRef}
      className={cn('flex h-full w-full overflow-hidden bg-surface-50 relative', className)}
    >
      {/* Left Panel */}
      <div
        style={{ width: `${splitPercent}%` }}
        className={cn(
          'flex flex-col min-w-0 h-full overflow-hidden flex-shrink-0',
          isDragging && 'pointer-events-none',
          leftClassName
        )}
      >
        {left}
      </div>

      {/* Draggable Divider Handle */}
      <div
        role="separator"
        aria-orientation="vertical"
        aria-label="Resize panels"
        tabIndex={0}
        onMouseDown={handleMouseDown}
        onTouchStart={() => setIsDragging(true)}
        onKeyDown={(e) => {
          if (e.key === 'ArrowLeft') {
            const next = getClampedPercent(splitPercent - 2);
            setSplitPercent(next);
            saveSplit(next);
          } else if (e.key === 'ArrowRight') {
            const next = getClampedPercent(splitPercent + 2);
            setSplitPercent(next);
            saveSplit(next);
          }
        }}
        className={cn(
          'relative w-1 flex-shrink-0 cursor-col-resize group z-20 flex items-center justify-center select-none',
          isDragging
            ? 'bg-[#60A5FA]'
            : 'bg-surface-200 hover:bg-[#93C5FD]'
        )}
        title="Drag to resize panels"
      >
        {/* Subtle Grip Indicator */}
        <div
          className={cn(
            'w-0.5 h-6 rounded-full transition-colors',
            isDragging
              ? 'bg-white'
              : 'bg-surface-400 group-hover:bg-white'
          )}
        />
      </div>

      {/* Right Panel */}
      <div
        style={{ flex: 1 }}
        className={cn(
          'flex flex-col min-w-0 h-full overflow-hidden',
          isDragging && 'pointer-events-none',
          rightClassName
        )}
      >
        {right}
      </div>
    </div>
  );
}
