import React, { useState, useEffect, useRef } from 'react';
import { Modal } from './Modal';
import { Button } from './Button';
import { Camera, Keyboard, AlertCircle, RefreshCw } from 'lucide-react';
import type { Html5Qrcode } from 'html5-qrcode';

export interface BarcodeScannerModalProps {
  open: boolean;
  onClose: () => void;
  onScan: (barcode: string) => void;
  title?: string;
  submitLabel?: string;
}

export function BarcodeScannerModal({
  open,
  onClose,
  onScan,
  title = 'Scan Barcode',
  submitLabel = 'Confirm Barcode',
}: BarcodeScannerModalProps) {
  const [activeTab, setActiveTab] = useState<'camera' | 'manual'>('camera');
  const [manualCode, setManualCode] = useState('');
  const [cameraError, setCameraError] = useState<string | null>(null);
  const [isScanning, setIsScanning] = useState(false);
  const [retryCount, setRetryCount] = useState(0);
  const scannerRef = useRef<Html5Qrcode | null>(null);
  const isStartingRef = useRef(false);

  // Helper to safely stop and clear an Html5Qrcode instance
  const safeStopScanner = async (scanner: Html5Qrcode | null) => {
    if (!scanner) return;
    try {
      if (scanner.isScanning) {
        await scanner.stop();
      }
    } catch (err) {
      console.warn('BarcodeScannerModal: Safe scanner stop handled:', err);
    }
    try {
      scanner.clear();
    } catch (err) {
      console.warn('BarcodeScannerModal: Safe scanner clear handled:', err);
    }
  };

  // Initialize camera scanner when tab is camera
  useEffect(() => {
    if (!open || activeTab !== 'camera') {
      if (scannerRef.current) {
        const current = scannerRef.current;
        scannerRef.current = null;
        setIsScanning(false);
        safeStopScanner(current);
      }
      return;
    }

    // Check device / browser mediaDevices support
    const hasMedia = typeof navigator !== 'undefined' && Boolean(
      (navigator.mediaDevices && typeof navigator.mediaDevices.getUserMedia === 'function') ||
      typeof (navigator as any).getUserMedia === 'function' ||
      typeof (navigator as any).webkitGetUserMedia === 'function' ||
      typeof (navigator as any).mozGetUserMedia === 'function'
    );

    if (!hasMedia) {
      const isSecure = typeof window !== 'undefined' && window.isSecureContext;
      const errorMsg = !isSecure
        ? 'In web browsers, camera access is disabled over plain HTTP. In the installed ZAMERIA native app on Android, iOS, or Windows (or over HTTPS/localhost), camera scanning works natively. Switch to Manual tab below to test barcodes directly.'
        : 'Camera access is not supported by this browser or environment. Please use manual or hardware scanner entry.';
      setCameraError(errorMsg);
      return;
    }

    let isMounted = true;
    const scannerId = 'zameria-barcode-reader';

    const startScanner = async () => {
      const targetElement = document.getElementById(scannerId);
      if (!targetElement) return;

      try {
        setCameraError(null);
        setIsScanning(true);
        isStartingRef.current = true;

        // Clean up previous instance if any
        if (scannerRef.current) {
          await safeStopScanner(scannerRef.current);
          scannerRef.current = null;
        }

        const { Html5Qrcode, Html5QrcodeSupportedFormats } = await import('html5-qrcode');
        if (!isMounted) return;
        const formatsToSupport = [
          Html5QrcodeSupportedFormats.EAN_13,
          Html5QrcodeSupportedFormats.EAN_8,
          Html5QrcodeSupportedFormats.UPC_A,
          Html5QrcodeSupportedFormats.UPC_E,
          Html5QrcodeSupportedFormats.CODE_128,
          Html5QrcodeSupportedFormats.CODE_39,
          Html5QrcodeSupportedFormats.CODE_93,
          Html5QrcodeSupportedFormats.ITF,
          Html5QrcodeSupportedFormats.QR_CODE,
          Html5QrcodeSupportedFormats.DATA_MATRIX,
        ];

        const html5QrCode = new Html5Qrcode(scannerId, {
          formatsToSupport,
          verbose: false,
        });
        scannerRef.current = html5QrCode;

        // Determine best camera source
        let cameraSource: any = { facingMode: 'environment' };
        try {
          const devices = await Html5Qrcode.getCameras();
          if (devices && devices.length > 0) {
            const backCam = devices.find((d) =>
              /back|rear|environment|posterior|reverse/i.test(d.label)
            );
            cameraSource = backCam ? backCam.id : devices[0].id;
          }
        } catch {
          // Camera enumeration may be restricted before permission grant; fallback to constraints
          cameraSource = { facingMode: 'environment' };
        }

        if (!isMounted) { await safeStopScanner(html5QrCode); return; }
        const scannerConfig = {
          fps: 15,
          qrbox: (viewfinderWidth: number, viewfinderHeight: number) => {
            const minEdge = Math.min(viewfinderWidth, viewfinderHeight);
            const width = Math.max(180, Math.floor(viewfinderWidth * 0.82));
            const height = Math.max(110, Math.floor(minEdge * 0.65));
            return { width, height };
          },
          experimentalFeatures: {
            useBarCodeDetectorIfSupported: true,
          },
        };

        const handleSuccess = (decodedText: string) => {
          if (isMounted) {
            if (typeof navigator !== 'undefined' && 'vibrate' in navigator) {
              try {
                navigator.vibrate([40, 30, 40]);
              } catch {}
            }
            onScan(decodedText.trim());
            onClose();
          }
        };

        try {
          await html5QrCode.start(
            cameraSource,
            scannerConfig,
            handleSuccess,
            () => {} // Frame parse errors are normal while scanning
          );
        } catch (firstErr) {
          // If environment/specific camera failed, attempt generic fallback
          console.warn('BarcodeScannerModal: Primary camera failed, trying fallback:', firstErr);
          if (!isMounted) return;
          await html5QrCode.start(
            { facingMode: 'user' },
            scannerConfig,
            handleSuccess,
            () => {}
          );
        }

        isStartingRef.current = false;
        if (!isMounted) {
          safeStopScanner(html5QrCode);
        }
      } catch (err: any) {
        isStartingRef.current = false;
        if (isMounted) {
          const errStr = String(err?.message || err || '').toLowerCase();
          let friendlyError = 'Camera unavailable or access failed. You can retry or enter the code manually.';

          if (errStr.includes('permission') || errStr.includes('notallowederror') || err?.name === 'NotAllowedError') {
            friendlyError = 'Camera permission was denied. Please allow camera permissions in your browser or device settings.';
          } else if (errStr.includes('notfound') || err?.name === 'NotFoundError') {
            friendlyError = 'No camera device found on this system.';
          } else if (errStr.includes('notreadable') || err?.name === 'NotReadableError') {
            friendlyError = 'Camera is currently in use by another application. Please close other camera tabs and retry.';
          } else if (errStr.includes('overconstrained') || err?.name === 'OverconstrainedError') {
            friendlyError = 'Camera resolution or constraint not supported by your camera hardware.';
          }

          setCameraError(friendlyError);
        }
      } finally {
        if (isMounted) setIsScanning(false);
      }
    };

    // Small delay to ensure modal DOM is mounted
    const timer = setTimeout(() => {
      if (isMounted) {
        startScanner();
      }
    }, 150);

    return () => {
      isMounted = false;
      clearTimeout(timer);
      if (scannerRef.current) {
        const current = scannerRef.current;
        scannerRef.current = null;
        setIsScanning(false);
        safeStopScanner(current);
      }
    };
  }, [open, activeTab, retryCount, onScan, onClose]);

  const handleManualSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!manualCode.trim()) return;
    onScan(manualCode.trim());
    setManualCode('');
    onClose();
  };

  return (
    <Modal open={open} onClose={onClose} size="sm" title={title}>
      <div className="space-y-4">
        {/* Mode Tabs */}
        <div className="flex border-b border-outline-variant/60">
          <button
            type="button"
            onClick={() => setActiveTab('camera')}
            className={`flex-1 flex items-center justify-center gap-2 py-2.5 text-xs font-semibold border-b-2 cursor-pointer transition-colors ${
              activeTab === 'camera'
                ? 'border-primary text-primary font-bold'
                : 'border-transparent text-on-surface-variant hover:text-on-surface'
            }`}
          >
            <Camera className="w-3.5 h-3.5" />
            Camera Scanner
          </button>
          <button
            type="button"
            onClick={() => setActiveTab('manual')}
            className={`flex-1 flex items-center justify-center gap-2 py-2.5 text-xs font-semibold border-b-2 cursor-pointer transition-colors ${
              activeTab === 'manual'
                ? 'border-primary text-primary font-bold'
                : 'border-transparent text-on-surface-variant hover:text-on-surface'
            }`}
          >
            <Keyboard className="w-3.5 h-3.5" />
            Manual / Hardware
          </button>
        </div>

        {/* Camera View */}
        {activeTab === 'camera' && (
          <div className="space-y-3">
            <div className="relative w-full h-64 bg-surface-container-lowest rounded-xl overflow-hidden flex items-center justify-center border border-outline-variant/40">
              <div id="zameria-barcode-reader" className="w-full h-full" />

              {isScanning && (
                <div className="absolute inset-0 flex items-center justify-center bg-black/60 text-white text-xs gap-2 z-10">
                  <div className="w-4 h-4 border-2 border-white/20 border-t-white rounded-full animate-spin" />
                  Accessing camera...
                </div>
              )}

              {/* Viewfinder Overlay Guide */}
              {!cameraError && (
                <div className="absolute inset-0 pointer-events-none flex flex-col items-center justify-center z-10">
                  <div className="w-60 h-36 border-2 border-primary rounded-xl shadow-sm relative flex flex-col items-center justify-between p-2 bg-primary/10">
                    <div className="w-full h-0.5 bg-primary animate-pulse my-auto shadow-sm" />
                    <span className="text-[10px] font-semibold text-white bg-black/70 px-2 py-0.5 rounded backdrop-blur-xs">
                      Align barcode within frame
                    </span>
                  </div>
                </div>
              )}
            </div>

            {cameraError && (
              <div className="p-3 bg-warning/10 text-on-surface border border-warning/30 rounded-xl text-xs space-y-2">
                <div className="flex items-start gap-2">
                  <AlertCircle className="w-4 h-4 flex-shrink-0 text-warning mt-0.5" />
                  <span className="flex-1">{cameraError}</span>
                </div>
                <div className="flex items-center gap-2 pt-1">
                  <button
                    type="button"
                    onClick={() => {
                      setCameraError(null);
                      setRetryCount((c) => c + 1);
                    }}
                    className="inline-flex items-center gap-1.5 px-3 py-1.5 bg-primary text-white rounded-lg text-xs font-semibold hover:bg-primary-hover active:scale-95 transition-all cursor-pointer"
                  >
                    <RefreshCw className="w-3.5 h-3.5" />
                    Retry Camera
                  </button>
                  <button
                    type="button"
                    onClick={() => setActiveTab('manual')}
                    className="px-3 py-1.5 border border-outline-variant bg-surface text-on-surface rounded-lg text-xs font-semibold hover:bg-surface-container-low transition-all cursor-pointer"
                  >
                    Switch to Manual
                  </button>
                </div>
              </div>
            )}

            <p className="text-[11px] text-on-surface-variant text-center">
              Point camera directly at the barcode (UPC, EAN, Code 128, QR).
            </p>

            <div className="flex justify-end pt-2 border-t border-outline-variant/60">
              <Button type="button" variant="secondary" size="sm" onClick={onClose}>
                Cancel
              </Button>
            </div>
          </div>
        )}

        {/* Manual Input */}
        {activeTab === 'manual' && (
          <form onSubmit={handleManualSubmit} className="space-y-3">
            <div>
              <label className="text-xs font-semibold text-on-surface block mb-1">
                Barcode Number / SKU
              </label>
              <input
                type="text"
                autoFocus
                value={manualCode}
                onChange={(e) => setManualCode(e.target.value)}
                placeholder="e.g. 8901234567890 or 5449000000996"
                className="w-full h-10 px-3 border border-outline-variant/80 rounded-lg text-xs bg-surface text-on-surface focus:outline-none focus:border-primary font-mono placeholder:font-sans placeholder:text-on-surface-variant/50"
              />
              {/* Quick Test Barcodes (Dev only) */}
              {Boolean(import.meta.env.DEV) && (
                <div className="mt-2 space-y-1">
                  <span className="text-[11px] font-medium text-surface-500">Quick Test Barcodes (Dev):</span>
                  <div className="flex flex-wrap gap-1.5">
                    {[
                      { label: 'Indomie (6154000011111)', code: '6154000011111' },
                      { label: 'Ankara Shirt (6154000022222)', code: '6154000022222' },
                      { label: 'Kings Oil (6154000044444)', code: '6154000044444' },
                    ].map((sample) => (
                      <button
                        key={sample.code}
                        type="button"
                        onClick={() => setManualCode(sample.code)}
                        className="px-2 py-1 text-[11px] font-mono bg-surface-100 hover:bg-surface-200 text-surface-700 rounded-md border border-surface-200 transition-colors cursor-pointer"
                      >
                        {sample.label}
                      </button>
                    ))}
                  </div>
                </div>
              )}
            </div>
            <p className="text-[11px] text-on-surface-variant">
              Compatible with USB and Bluetooth handheld barcode scanners typing directly into input.
            </p>
            <div className="flex justify-end gap-2.5 pt-2 border-t border-outline-variant/60">
              <Button type="button" variant="secondary" size="sm" onClick={onClose}>
                Cancel
              </Button>
              <Button type="submit" variant="primary" size="sm">
                {submitLabel}
              </Button>
            </div>
          </form>
        )}
      </div>
    </Modal>
  );
}
