import { useState } from 'react';
import { useSyncStore } from '@/store/syncStore';
import { syncEngine } from '@/services/woocommerce/syncEngine';
import { timeAgo, cn } from '@/lib';
import { RefreshCw, Check, AlertCircle } from 'lucide-react';
import { toast } from 'sonner';
import type { SyncScope, SyncSummary } from '@/types';

export interface SyncButtonProps {
  scope: SyncScope;
  label?: string;
  showLastSynced?: boolean;
  size?: 'sm' | 'md' | 'lg';
  variant?: 'primary' | 'secondary' | 'outline' | 'ghost' | 'tonal';
  className?: string;
  onSuccess?: (summary: SyncSummary) => void;
  onError?: (err: Error) => void;
}

export function SyncButton({
  scope,
  label = 'Sync',
  showLastSynced = false,
  size = 'sm',
  variant = 'outline',
  className,
  onSuccess,
  onError,
}: SyncButtonProps) {
  const isSyncing = useSyncStore((s) => s.isSyncing);
  const activeScope = useSyncStore((s) => s.activeScope);
  const lastSyncedAt = useSyncStore((s) => s.lastSyncedByScope[scope]);
  const [justSynced, setJustSynced] = useState(false);
  const [hasError, setHasError] = useState(false);

  const isCurrentScopeSyncing = isSyncing && (activeScope === scope || activeScope === 'full');

  const handleSyncClick = async (e: React.MouseEvent) => {
    e.stopPropagation();
    if (isSyncing) return;
    setHasError(false);

    try {
      const summary = await syncEngine.sync({ scope });
      setJustSynced(true);
      setTimeout(() => setJustSynced(false), 2400);

      const count = summary.totalImported + summary.totalUpdated;
      if (summary.status === 'success') {
        toast.success(
          `${label || 'Sync'} completed (${count} ${count === 1 ? 'record' : 'records'} synchronized)`,
          {
            icon: <Check className="w-4 h-4 text-emerald-600" />,
          }
        );
      } else if (summary.status === 'partial') {
        toast.warning(`Sync completed with ${summary.totalFailed} issues`, {
          description: summary.error || 'Some records failed to synchronize.',
          icon: <AlertCircle className="w-4 h-4 text-amber-600" />,
        });
      }

      onSuccess?.(summary);
    } catch (err: any) {
      setHasError(true);
      setTimeout(() => setHasError(false), 4000);
      const msg = err?.message || 'Sync failed. Please check network connection.';
      toast.error(msg, {
        icon: <AlertCircle className="w-4 h-4 text-error" />,
      });
      onError?.(err);
    }
  };

  // State-specific styling
  const stateClasses = hasError
    ? 'bg-rose-50 dark:bg-rose-950/60 border-rose-300 dark:border-rose-700 text-rose-700 dark:text-rose-300 ring-1 ring-rose-500/20'
    : justSynced
    ? 'bg-emerald-50 dark:bg-emerald-950/60 border-emerald-300 dark:border-emerald-700 text-emerald-700 dark:text-emerald-300 ring-1 ring-emerald-500/20'
    : isCurrentScopeSyncing
    ? 'bg-blue-50/90 dark:bg-blue-950/60 border-primary/40 dark:border-blue-500/50 text-primary dark:text-blue-200 ring-2 ring-primary/20'
    : variant === 'tonal'
    ? 'bg-blue-50/90 hover:bg-blue-100/90 dark:bg-blue-950/50 dark:hover:bg-blue-900/60 text-primary dark:text-blue-200 border border-blue-200/90 dark:border-blue-800/80 shadow-2xs'
    : variant === 'ghost'
    ? 'bg-surface hover:bg-slate-100/80 dark:bg-slate-800/60 dark:hover:bg-slate-800 text-slate-700 dark:text-slate-200 border border-slate-300/80 dark:border-slate-600'
    : 'bg-surface hover:bg-slate-50/90 dark:bg-surface-container dark:hover:bg-slate-800/60 text-slate-800 dark:text-slate-100 border border-slate-300 dark:border-slate-600 shadow-2xs';

  const sizeClass =
    size === 'lg'
      ? 'h-11 px-4 text-sm gap-2 rounded-xl'
      : size === 'md'
      ? 'h-9.5 px-3 text-xs gap-2 rounded-lg'
      : 'h-8.5 px-2.5 text-xs gap-1.5 rounded-lg';

  const hasVisibleLabel = Boolean(label);

  return (
    <div className="inline-flex items-center gap-1.5 flex-shrink-0">
      {showLastSynced && lastSyncedAt && !isCurrentScopeSyncing && (
        <span className="hidden md:inline-flex text-[11px] font-medium text-on-surface-variant/70 tabular-nums">
          Synced {timeAgo(lastSyncedAt)}
        </span>
      )}

      <button
        type="button"
        onClick={handleSyncClick}
        disabled={isSyncing}
        className={cn(
          'group inline-flex items-center justify-center font-semibold cursor-pointer select-none transition-all duration-150',
          'active:scale-[0.98] disabled:opacity-60 disabled:cursor-not-allowed',
          sizeClass,
          stateClasses,
          !hasVisibleLabel && 'min-w-[34px] px-2 justify-center',
          className
        )}
        title={
          hasError
            ? `Sync failed. Tap to retry ${scope} sync`
            : justSynced
            ? `${scope} successfully synchronized`
            : isCurrentScopeSyncing
            ? `Synchronizing ${scope}...`
            : `Synchronize ${scope} with WooCommerce store`
        }
        aria-label={`Sync ${scope}`}
      >
        {hasError ? (
          <AlertCircle className="w-4 h-4 text-rose-600 dark:text-rose-400 flex-shrink-0" />
        ) : justSynced ? (
          <Check className="w-4 h-4 text-emerald-600 dark:text-emerald-400 flex-shrink-0 animate-in zoom-in-75 duration-150" />
        ) : (
          <RefreshCw
            className={cn(
              'w-4 h-4 flex-shrink-0 transition-transform duration-200',
              isCurrentScopeSyncing
                ? 'animate-spin text-primary dark:text-[#60A5FA]'
                : 'text-primary dark:text-[#60A5FA] group-hover:rotate-45'
            )}
          />
        )}

        {hasVisibleLabel && (
          <span className="truncate">
            {isCurrentScopeSyncing
              ? 'Syncing...'
              : justSynced
              ? 'Synced'
              : hasError
              ? 'Retry'
              : label}
          </span>
        )}
      </button>
    </div>
  );
}

