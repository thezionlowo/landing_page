import React from 'react';
import { cn } from '@/lib';

export interface InputProps extends React.InputHTMLAttributes<HTMLInputElement> {
  label?: string;
  error?: string;
  helperText?: string;
  icon?: React.ReactNode;
  suffix?: React.ReactNode;
}

export const Input = React.forwardRef<HTMLInputElement, InputProps>(
  ({ label, error, helperText, icon, suffix, className, id, disabled, ...props }, ref) => {
    const generatedId = React.useId();
    const inputId = id || generatedId;
    return (
      <div className="flex flex-col gap-1.5 w-full">
        {label && (
          <label
            htmlFor={inputId}
            className="text-xs font-semibold text-surface-700 dark:text-surface-600 tracking-wide select-none"
          >
            {label}
          </label>
        )}
        <div className="relative flex items-center">
          {icon && (
            <div className="absolute left-3 top-1/2 -translate-y-1/2 text-surface-400 pointer-events-none flex items-center justify-center">
              {icon}
            </div>
          )}
          <input
            ref={ref}
            id={inputId}
            aria-invalid={Boolean(error) || undefined}
            aria-describedby={error || helperText ? `${inputId}-help` : undefined}
            disabled={disabled}
            className={cn(
              'pos-field w-full min-h-11 rounded-xl border border-surface-300 dark:border-surface-300/50 bg-surface-0 dark:bg-surface-100 text-surface-900 dark:text-surface-800',
              'px-3.5 py-2 text-sm placeholder:text-surface-400 dark:placeholder:text-surface-500',
              'focus:outline-none focus:border-[#60A5FA] focus:ring-2 focus:ring-[#60A5FA]/20',
              'transition-all duration-120',
              'disabled:bg-surface-100 dark:disabled:bg-surface-200/50 disabled:text-surface-400 disabled:cursor-not-allowed',
              icon ? 'pl-9.5' : '',
              suffix ? 'pr-9.5' : '',
              error
                ? 'border-danger-500 focus:border-danger-500 focus:ring-danger-500/20 text-danger-900'
                : '',
              className
            )}
            {...props}
          />
          {suffix && (
            <div className="absolute right-3 top-1/2 -translate-y-1/2 text-surface-400 flex items-center justify-center">
              {suffix}
            </div>
          )}
        </div>
        {error ? (
          <p id={`${inputId}-help`} className="text-xs text-danger-600 dark:text-danger-400 font-medium">{error}</p>
        ) : helperText ? (
          <p id={`${inputId}-help`} className="text-xs text-surface-500 font-normal">{helperText}</p>
        ) : null}
      </div>
    );
  }
);

Input.displayName = 'Input';
