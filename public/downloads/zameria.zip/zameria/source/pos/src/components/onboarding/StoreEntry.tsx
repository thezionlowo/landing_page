import { BRAND_HEADLINE } from '../../lib/brandMessaging';
import React from 'react';
export type StoreEntryMode = 'choose' | 'owner' | 'staff';
interface Props { mode: StoreEntryMode; native: boolean; onChoose: (mode: StoreEntryMode) => void }
/** Owner setup guidance never substitutes for plugin discovery, staff authentication or entitlement checks. */
export function StoreEntry({ mode, native, onChoose }: Props) {
  const button = 'w-full rounded-xl border border-slate-200 dark:border-slate-700 p-4 text-left hover:border-blue-400 focus-visible:ring-2 focus-visible:ring-blue-400';
  return <section aria-label="Get started with ZAMERIA" className="space-y-4 text-sm">
    {mode === 'choose' ? <>
      <h1 className="text-xl font-bold">{BRAND_HEADLINE}</h1>
      <p className="text-slate-500">Choose how you want to get started.</p>
      <button type="button" className={button} onClick={() => onChoose('owner')}><strong className="block">Set up my store</strong><span className="text-xs text-slate-500">I own or manage a WooCommerce store.</span></button>
      <button type="button" className={button} onClick={() => onChoose('staff')}><strong className="block">Join an existing store</strong><span className="text-xs text-slate-500">My store already uses ZAMERIA.</span></button>
    </> : <>
      <button type="button" className="text-xs text-blue-600 dark:text-blue-400 underline" onClick={() => onChoose('choose')}>Back to getting started</button>
      <h1 className="text-xl font-bold">{mode === 'owner' ? 'Set up your store' : 'Sign in to your store'}</h1>
      {mode === 'owner' ? <>
        <ol className="list-decimal pl-5 space-y-3 text-slate-600 dark:text-slate-300">
          <li>Create your ZAMERIA account on zameria.co, or use your existing account.</li>
          <li>On your computer, open your account’s setup checklist. Download and install the ZAMERIA plugin in WordPress, then connect it using that same ZAMERIA account.</li>
          <li>Return here, enter your store address and authorised WordPress staff credentials, then wait for the first catalogue sync.</li>
        </ol>
        <p className="text-xs text-slate-500">Continue setup on your computer at <strong>zameria.co/account</strong>. Your account’s checklist shows the store connection once confirmed by the server.</p>
        {!native && <a className="block text-blue-600 dark:text-blue-400 underline" href="https://zameria.co/account" target="_blank" rel="noopener noreferrer">Open account setup</a>}
        <button type="button" className={button} onClick={() => onChoose('staff')}>My plugin is connected — sign in to POS</button>
      </> : <p className="text-xs leading-relaxed text-slate-500">Enter the store address and WordPress username/password provided by your administrator. Your ZAMERIA subscription login is used in the plugin. Staff do not need a separate ZAMERIA subscription account.</p>}
    </>}
  </section>;
}
