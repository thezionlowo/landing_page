import React, { useState } from 'react';
import { Sidebar } from './Sidebar';
import { MobileBottomNav } from './MobileBottomNav';
import { useConnectionStore, useUIStore } from '@/store';
import { useAuthStore } from '@/store/authStore';
import { useSyncStore } from '@/store/syncStore';
import { WifiOff, X, Sparkles, RefreshCw, AlertTriangle, ExternalLink } from 'lucide-react';
import { cn } from '@/lib';
import { GlobalSyncStatus } from './GlobalSyncStatus';
import { Store } from 'lucide-react';
import { ZameriaSupportChatWidget } from '@/components/common/ZameriaSupportChatWidget';

interface AppShellProps {
  children: React.ReactNode;
}

export function AppShell({ children }: AppShellProps) {
  const { isOnline, status } = useConnectionStore();
  const pendingCount = useSyncStore((s) => s.pendingCount);
  const isSyncing = useSyncStore((s) => s.isSyncing) || status === 'SYNCING';
  const { isDemoMode } = useUIStore();
  const [dismissDemoBanner, setDismissDemoBanner] = useState(false);
  const user = useAuthStore((s) => s.user);

  const entitlement = user?.entitlement;
  const isTrialExpired = entitlement ? !entitlement.is_licensed : false;

  // Determine if the offline / sync banner should be displayed.
  const showOfflineBanner = !isOnline;
  const showPendingSyncBanner = isOnline && pendingCount > 0;

  return (
    <div className="pos-workspace flex h-screen h-[100dvh] max-h-[100dvh] w-screen overflow-hidden bg-surface-50">
      <a className="pos-skip-link" href="#pos-main">Skip to workspace</a>
      <Sidebar />
      <main tabIndex={-1} id="pos-main" className="pos-main flex-1 flex flex-col min-w-0 overflow-hidden bg-surface-50 relative">
        <header className="pos-workspace-header">
          <div className="flex items-center gap-3 min-w-0"><div className="pos-store-icon"><Store className="w-5 h-5" /></div><div className="min-w-0"><p className="text-sm font-semibold text-on-surface truncate">{user?.storeName || 'ZAMERIA POS'}</p></div></div>
          <div className="flex items-center gap-3 shrink-0"><GlobalSyncStatus /><span className="hidden lg:block text-xs text-on-surface-variant">{user?.deviceName || user?.displayName || 'Point of sale'}</span></div>
        </header>
        {/* Cloud Sync Status Banner */}
        {isTrialExpired && (
          <div className="bg-amber-500/10 border-b border-amber-500/20 px-4 py-2 flex items-center justify-between text-amber-800 dark:text-amber-300 no-print flex-shrink-0 animate-in fade-in">
            <div className="flex items-center gap-2">
              <AlertTriangle className="w-4 h-4 text-amber-600 flex-shrink-0" />
              <span className="text-xs font-semibold">
                Store access needs attention. Your saved work remains on this device. Ask the store owner to check the plan.
              </span>
            </div>
            <a
              href="https://zameria.co/pricing"
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center gap-1.5 px-3 py-1 text-xs font-semibold rounded-md bg-amber-600 text-white hover:bg-amber-700 transition-colors shadow-sm cursor-pointer"
            >
              View plans
              <ExternalLink className="w-3 h-3" />
            </a>
          </div>
        )}

        {/* Genuine Device Offline Banner */}
        {showOfflineBanner && (
          <div className="bg-amber-500/10 border-b border-amber-500/20 px-4 py-1.5 flex items-center justify-center gap-2 text-amber-700 dark:text-amber-400 no-print flex-shrink-0 animate-in fade-in">
            <WifiOff className="w-3.5 h-3.5" />
            <span className="text-xs font-semibold">
              {pendingCount > 0
                ? `Offline — ${pendingCount} sale${pendingCount > 1 ? 's' : ''} stored safely on device. Will sync when connection returns.`
                : 'Offline — Sales will be saved locally and sync when connection returns.'}
            </span>
          </div>
        )}

        {/* Online Pending Sales Re-syncing Banner */}
        {showPendingSyncBanner && (
          <div className="bg-blue-500/10 border-b border-blue-500/20 px-4 py-1.5 flex items-center justify-center gap-2 text-blue-700 dark:text-blue-400 no-print flex-shrink-0 animate-in fade-in">
            <RefreshCw className={cn('w-3.5 h-3.5', isSyncing && 'animate-spin text-[#60A5FA]')} />
            <span className="text-xs font-semibold">
              {isSyncing
                ? `Syncing ${pendingCount} offline sale${pendingCount > 1 ? 's' : ''} to WooCommerce...`
                : `${pendingCount} offline sale${pendingCount > 1 ? 's' : ''} queued — Syncing automatically with store.`}
            </span>
          </div>
        )}

        {/* Demo Mode Notice (Dismissible) */}
        {import.meta.env.MODE !== 'product-preview' && isDemoMode && !dismissDemoBanner && (
          <div className="bg-surface-0 border-b border-surface-200 px-4 py-1.5 flex items-center justify-between text-surface-600 text-xs no-print flex-shrink-0">
            <div className="flex items-center gap-2">
              <Sparkles className="w-3.5 h-3.5 text-[#60A5FA]" />
              <span>
                <strong className="text-surface-900 font-semibold">Demo Mode:</strong> Loaded with sample products and orders. Connect your WooCommerce store anytime in Settings.
              </span>
            </div>
            <button
              type="button"
              onClick={() => setDismissDemoBanner(true)}
              className="p-1 rounded text-surface-400 hover:text-surface-600 cursor-pointer"
              aria-label="Dismiss demo notice"
            >
              <X className="w-3 h-3" />
            </button>
          </div>
        )}

        {/* Main Content Area */}
        <div className="pos-screen flex-1 min-w-0 min-h-0 overflow-hidden relative">
          {children}
        </div>
      </main>

      {/* Mobile Bottom Navigation Bar (< 768px) */}
      <MobileBottomNav />

      {/* Unified ZAMERIA Customer Support Chat Widget */}
      <ZameriaSupportChatWidget source="POS" />
    </div>
  );
}
export default AppShell;

