import React, { useState, useMemo, useEffect, useRef, useId } from 'react';
import { useLiveQuery } from 'dexie-react-hooks';
import { db } from '@/db';
import { Search, Check, Tag, ChevronDown } from 'lucide-react';
import { cn } from '@/lib';

interface BrandSelectorProps {
  selectedBrandId: number | null;
  onChange: (brandId: number | null) => void;
  disabled?: boolean;
}

export function BrandSelector({
  selectedBrandId,
  onChange,
  disabled = false,
}: BrandSelectorProps) {
  const [isOpen, setIsOpen] = useState(false);
  const [search, setSearch] = useState('');
  const controlId = useId();
  const container = useRef<HTMLDivElement>(null);
  const trigger = useRef<HTMLButtonElement>(null);
  useEffect(() => {
    if (!isOpen) return;
    const outside = (event: PointerEvent) => { if (!container.current?.contains(event.target as Node)) setIsOpen(false); };
    const escape = (event: KeyboardEvent) => { if (event.key === 'Escape') { event.preventDefault(); event.stopImmediatePropagation(); setIsOpen(false); trigger.current?.focus(); } };
    document.addEventListener('pointerdown', outside);
    window.addEventListener('keydown', escape, true);
    return () => { document.removeEventListener('pointerdown', outside); window.removeEventListener('keydown', escape, true); };
  }, [isOpen]);
  const brands = useLiveQuery(() => db.brands.toArray(), []);

  // Filter based on search input
  const filteredBrands = useMemo(() => {
    if (!brands) return [];
    if (!search.trim()) return brands;
    const q = search.trim().toLowerCase();
    return brands.filter((b) => b.name.toLowerCase().includes(q));
  }, [brands, search]);

  const selectedBrand = useMemo(() => {
    if (!brands || selectedBrandId === null) return null;
    return brands.find((b) => b.id === selectedBrandId || b.wooId === selectedBrandId) || null;
  }, [brands, selectedBrandId]);

  return (
    <div className="space-y-1.5">
      <div className="flex items-center justify-between">
        <span id={controlId} className="text-xs font-semibold text-on-surface flex items-center gap-1.5">
          <Tag className="w-3.5 h-3.5 text-primary" />
          Brand (Website Taxonomy)
        </span>
        {selectedBrand && !disabled && (
          <button
            type="button"
            onClick={() => onChange(null)}
            className="text-[11px] text-error hover:underline cursor-pointer"
          >
            Clear brand
          </button>
        )}
      </div>

      {/* Selected Brand Pill or Dropdown trigger */}
      <div className="relative" ref={container}>
        <button ref={trigger} type="button" disabled={disabled} aria-expanded={isOpen} aria-controls={isOpen ? `${controlId}-choices` : undefined} aria-labelledby={controlId}
          onClick={() => setIsOpen(!isOpen)}
          className={cn('pos-select-control w-full flex items-center min-h-11', isOpen && 'border-primary')}
        >
          <span className="pos-select-value">{selectedBrand ? selectedBrand.name : 'Select a brand (optional)'}</span>
          <ChevronDown aria-hidden="true" className="pos-select-chevron" />
        </button>

        {/* Dropdown Popover */}
        {isOpen && !disabled && (
          <div id={`${controlId}-choices`} role="region" aria-labelledby={controlId} className="absolute top-full left-0 right-0 mt-1 z-30 bg-surface border border-outline-variant rounded-xl shadow-lg p-2 space-y-2 max-h-60 flex flex-col">
            {/* Search Input */}
            <div className="relative">
              <Search className="w-3.5 h-3.5 absolute left-2.5 top-1/2 -translate-y-1/2 text-on-surface-variant/60" />
              <input
                type="text"
                aria-label="Search brands" placeholder="Search brands..."
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                autoFocus
                className="w-full h-8 pl-8 pr-3 text-xs bg-surface-container-low border border-outline-variant/60 rounded-lg focus:outline-none focus:border-primary"
              />
            </div>

            {/* Brand Options List */}
            <div className="flex-1 overflow-y-auto space-y-0.5 max-h-44">
              <button
                type="button"
                onClick={() => {
                  onChange(null);
                  setIsOpen(false);
                }}
                className={cn(
                  'w-full text-left px-2.5 py-1.5 rounded-lg text-xs flex items-center justify-between transition-colors',
                  selectedBrandId === null
                    ? 'bg-primary-container text-on-primary-container font-semibold'
                    : 'text-on-surface hover:bg-surface-container-low'
                )}
              >
                <span>No Brand (None)</span>
                {selectedBrandId === null && <Check className="w-3.5 h-3.5" />}
              </button>

              {filteredBrands.map((b) => {
                const isSelected = selectedBrandId === b.id || selectedBrandId === b.wooId;
                return (
                  <button
                    key={b.id}
                    type="button"
                    onClick={() => {
                      onChange(b.id);
                      setIsOpen(false);
                    }}
                    className={cn(
                      'w-full text-left px-2.5 py-1.5 rounded-lg text-xs flex items-center justify-between transition-colors',
                      isSelected
                        ? 'bg-primary-container text-on-primary-container font-semibold'
                        : 'text-on-surface hover:bg-surface-container-low'
                    )}
                  >
                    <div className="flex items-center gap-1.5 truncate">
                      <span className="truncate">{b.name}</span>
                      {b.count !== undefined && (
                        <span className="text-[10px] text-on-surface-variant opacity-70">
                          ({b.count})
                        </span>
                      )}
                    </div>
                    {isSelected && <Check className="w-3.5 h-3.5 flex-shrink-0" />}
                  </button>
                );
              })}

              {filteredBrands.length === 0 && (
                <div className="text-center py-3 text-xs text-on-surface-variant">
                  No brands found
                </div>
              )}
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
