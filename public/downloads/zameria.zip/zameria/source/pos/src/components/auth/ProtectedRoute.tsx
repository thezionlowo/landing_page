import React from 'react';
import { Navigate, useLocation } from 'react-router';
import { useAuthStore } from '@/store/authStore';
import type { RolePermissions } from '@/types/auth';
import { activeStoreAccess } from '@/services/auth/authService';

interface ProtectedRouteProps {
  children: React.ReactNode;
  requiredPermission?: keyof RolePermissions;
  redirectTo?: string;
}

export const ProtectedRoute: React.FC<ProtectedRouteProps> = ({
  children,
  requiredPermission,
  redirectTo,
}) => {
  const location = useLocation();
  const { isAuthenticated, hasPermission, user } = useAuthStore();

  // If user is not logged in at all, redirect to login page (preserving query parameters like ?store_url=...)
  if (!isAuthenticated || !user) {
    return <Navigate to={{ pathname: '/login', search: location.search }} replace state={{ from: location }} />;
  }

  // Enforce POS Access Control: Only Cashier, Shop Manager, and Admin may access Zameria POS
  if (!hasPermission('canAccessPOS')) {
    return (
      <Navigate
        to="/login"
        replace
        state={{
          accessDenied: true,
          message: `Access Denied: Role '${user.roleLabel || user.role}' has zero POS access. Only Cashier, Shop Manager, and Administrator accounts can access Zameria POS.`,
        }}
      />
    );
  }

  // If a specific permission is required and user lacks it
  if (user.token && !activeStoreAccess(user.entitlement)) {
    return <main className="p-8 text-slate-800 dark:text-slate-100"><h1 className="text-2xl font-bold">Store access needs attention</h1><p className="mt-3">Connect to the internet and check access again. If access is still unavailable, ask your store owner to verify the ZAMERIA connection and plan in WordPress. Saved sales remain on this device and eligible queued sales can still synchronize.</p><button className="mt-4 underline" onClick={() => void useAuthStore.getState().revalidate()}>Check access again</button></main>;
  }
  if (requiredPermission && !hasPermission(requiredPermission)) {
    // Default redirect for authenticated users lacking permission is POS Sale
    const fallbackPath = redirectTo || (hasPermission('canAccessSale') ? '/sale' : '/orders');
    return <Navigate to={fallbackPath} replace state={{ deniedPermission: requiredPermission }} />;
  }

  return <>{children}</>;
};
