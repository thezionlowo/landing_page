import React, { useRef, useEffect } from 'react';
import { Search, X } from 'lucide-react';
import { cn } from '@/lib';

export interface SearchInputProps extends Omit<React.InputHTMLAttributes<HTMLInputElement>, 'onChange'> {
  value: string;
  onChange: (value: string) => void;
  onClear?: () => void;
  enableShortcut?: boolean;
  containerClassName?: string;
}

export function SearchInput({
  value,
  onChange,
  onClear,
  enableShortcut = true,
  className,
  containerClassName,
  placeholder = 'Search...',
  ...props
}: SearchInputProps) {
  const inputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    if (!enableShortcut) return;
    const handleKeyDown = (e: KeyboardEvent) => {
      if (document.querySelector('[role="dialog"]') && !inputRef.current?.closest('[role="dialog"]')) return;
      // If user presses '/' outside of an active input, focus the search
      if (
        e.key === '/' &&
        document.activeElement?.tagName !== 'INPUT' &&
        document.activeElement?.tagName !== 'TEXTAREA'
      ) {
        e.preventDefault();
        inputRef.current?.focus();
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [enableShortcut]);

  return (
    <div className={cn('relative flex-1 flex items-center min-w-0', containerClassName)}>
      <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-surface-400 pointer-events-none" />
      <input
        ref={inputRef}
        type="search"
        aria-label={props['aria-label'] || placeholder}
        value={value}
        onChange={(e) => onChange(e.target.value)}
        placeholder={placeholder}
        className={cn(
          'pos-field w-full min-h-9 rounded-md border border-surface-300 dark:border-surface-300/50 bg-surface-0 dark:bg-surface-100 text-surface-900 dark:text-surface-800',
          'pl-9 pr-12 py-1.5 text-sm placeholder:text-surface-400 dark:placeholder:text-surface-500',
          'focus:outline-none focus:border-[#60A5FA] focus:ring-2 focus:ring-[#60A5FA]/20',
          'transition-all duration-120',
          className
        )}
        {...props}
      />
      <div className="absolute right-2.5 top-1/2 -translate-y-1/2 flex items-center gap-1">
        {value ? (
          <button
            type="button"
            onClick={() => {
              onChange('');
              onClear?.();
              inputRef.current?.focus();
            }}
            className="w-9 h-9 flex items-center justify-center rounded-lg text-surface-500 hover:text-surface-600 hover:bg-surface-100 cursor-pointer"
            aria-label="Clear search"
          >
            <X className="w-3.5 h-3.5" />
          </button>
        ) : enableShortcut ? (
          <kbd className="hidden sm:inline-flex items-center justify-center px-1.5 py-0.5 text-[10px] font-medium text-surface-400 bg-surface-100 border border-surface-200 rounded">
            /
          </kbd>
        ) : null}
      </div>
    </div>
  );
}
