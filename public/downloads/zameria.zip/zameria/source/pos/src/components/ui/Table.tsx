import React from 'react';
import { cn } from '@/lib';

export interface TableProps extends React.TableHTMLAttributes<HTMLTableElement> {
  children: React.ReactNode;
}

export function Table({ className, children, ...props }: TableProps) {
  return (
    <div className="w-full overflow-x-auto">
      <table className={cn('w-full caption-bottom text-xs text-left', className)} {...props}>
        {children}
      </table>
    </div>
  );
}

export function TableHeader({ className, children, ...props }: React.HTMLAttributes<HTMLTableSectionElement>) {
  return (
    <thead
      className={cn(
        'bg-surface-50 dark:bg-surface-200/40 border-b border-surface-200 dark:border-surface-200/50 text-[11px] font-bold text-surface-500 uppercase tracking-wider select-none sticky top-0 z-10',
        className
      )}
      {...props}
    >
      {children}
    </thead>
  );
}

export function TableBody({ className, children, ...props }: React.HTMLAttributes<HTMLTableSectionElement>) {
  return (
    <tbody className={cn('divide-y divide-surface-100 dark:divide-surface-200/40', className)} {...props}>
      {children}
    </tbody>
  );
}

export function TableRow({ className, children, ...props }: React.HTMLAttributes<HTMLTableRowElement>) {
  return (
    <tr
      className={cn(
        'hover:bg-surface-50/70 dark:hover:bg-surface-200/30 transition-colors cursor-pointer data-[selected=true]:bg-blue-50/40',
        className
      )}
      {...props}
    >
      {children}
    </tr>
  );
}

export function TableHead({ className, children, ...props }: React.ThHTMLAttributes<HTMLTableCellElement>) {
  return (
    <th className={cn('h-9 px-3.5 text-left align-middle font-bold text-surface-600 dark:text-surface-500', className)} {...props}>
      {children}
    </th>
  );
}

export function TableCell({ className, children, ...props }: React.TdHTMLAttributes<HTMLTableCellElement>) {
  return (
    <td className={cn('p-3.5 align-middle text-surface-900 dark:text-surface-800 text-xs', className)} {...props}>
      {children}
    </td>
  );
}
