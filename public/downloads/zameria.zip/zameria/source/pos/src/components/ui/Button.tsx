import React from 'react';
import { cn } from '@/lib';
import { Loader2 } from 'lucide-react';

export type ButtonVariant =
  | 'primary'
  | 'filled'
  | 'tonal'
  | 'secondary'
  | 'outline'
  | 'outlined'
  | 'ghost'
  | 'text'
  | 'destructive';

export type ButtonSize = 'sm' | 'md' | 'lg';

export interface ButtonProps extends React.ButtonHTMLAttributes<HTMLButtonElement> {
  variant?: ButtonVariant;
  size?: ButtonSize;
  loading?: boolean;
  icon?: React.ReactNode;
  children?: React.ReactNode;
}

const variantClasses: Record<ButtonVariant, string> = {
  primary:
    'bg-[#071A31] hover:bg-[#0C2340]/90 active:bg-[#040E1B] text-white border border-transparent shadow-xs transition-all duration-200 dark:bg-[#123158] dark:hover:bg-[#1a4275] dark:border-[#60A5FA]/30 dark:text-white dark:shadow-md',
  filled:
    'bg-[#071A31] hover:bg-[#0C2340]/90 active:bg-[#040E1B] text-white border border-transparent shadow-xs transition-all duration-200 dark:bg-[#123158] dark:hover:bg-[#1a4275] dark:border-[#60A5FA]/30 dark:text-white dark:shadow-md',
  tonal:
    'bg-blue-50/80 text-[#071A31] hover:bg-blue-100/70 active:bg-blue-200 border border-blue-200/50 transition-all duration-200 dark:bg-blue-950/60 dark:text-blue-200 dark:border-blue-800/60 dark:hover:bg-blue-900/60 dark:active:bg-blue-800/80',
  secondary:
    'bg-surface hover:bg-slate-50/80 active:bg-slate-100 text-slate-800 border border-slate-200 shadow-xs transition-all duration-200 dark:bg-[#0c2340] dark:text-slate-100 dark:border-slate-700/80 dark:hover:bg-[#123158] dark:hover:text-white dark:active:bg-[#1a4275]',
  outline:
    'border border-slate-200 hover:border-slate-300/80 bg-surface/60 hover:bg-slate-50/60 text-slate-800 transition-all duration-200 dark:border-slate-700/90 dark:text-slate-200 dark:bg-transparent dark:hover:bg-white/[0.06] dark:hover:border-slate-600 dark:hover:text-white dark:active:bg-white/[0.1]',
  outlined:
    'border border-slate-200 hover:border-slate-300/80 bg-surface/60 hover:bg-slate-50/60 text-slate-800 transition-all duration-200 dark:border-slate-700/90 dark:text-slate-200 dark:bg-transparent dark:hover:bg-white/[0.06] dark:hover:border-slate-600 dark:hover:text-white dark:active:bg-white/[0.1]',
  ghost:
    'bg-transparent hover:bg-slate-100/70 text-slate-600 hover:text-slate-900 transition-colors duration-200 dark:text-slate-300 dark:hover:text-white dark:hover:bg-white/[0.06] dark:active:bg-white/[0.1]',
  text:
    'bg-transparent hover:bg-slate-100/70 text-slate-600 hover:text-slate-900 transition-colors duration-200 dark:text-slate-300 dark:hover:text-white dark:hover:bg-white/[0.06] dark:active:bg-white/[0.1]',
  destructive:
    'bg-danger-600 hover:bg-danger-700/90 active:bg-danger-800 text-white border border-transparent shadow-xs transition-all duration-200 dark:bg-rose-600 dark:hover:bg-rose-700 dark:active:bg-rose-800 dark:text-white dark:border-transparent',
};

const sizeClasses: Record<ButtonSize, string> = {
  sm: 'h-8 px-3 text-xs gap-1.5 rounded-md font-medium',
  md: 'h-9.5 px-4 text-xs font-semibold gap-2 rounded-lg',
  lg: 'h-11 px-5 text-sm font-semibold gap-2.5 rounded-lg',
};

export function Button({
  variant = 'primary',
  size = 'md',
  loading = false,
  icon,
  children,
  className,
  disabled,
  ...props
}: ButtonProps) {
  return (
    <button
      className={cn(
        'inline-flex items-center justify-center select-none cursor-pointer font-sans',
        'focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#60A5FA] focus-visible:ring-offset-1',
        'disabled:opacity-40 disabled:cursor-not-allowed disabled:pointer-events-none',
        variantClasses[variant],
        sizeClasses[size],
        className
      )}
      disabled={disabled || loading}
      {...props}
    >
      {loading ? <Loader2 className="w-3.5 h-3.5 animate-spin flex-shrink-0" /> : icon}
      {children}
    </button>
  );
}
