import { useEffect, useRef, useState } from 'react';
import { registerSW } from 'virtual:pwa-register';
import { useCartStore } from '@/store/cartStore';
import { useSyncStore } from '@/store/syncStore';
import { canApplyAppUpdate, startAppUpdates } from '@/services/appUpdates';
import { toast } from 'sonner';

export function AppUpdateNotice() {
  const [available, setAvailable] = useState(false);
  const [applying, setApplying] = useState(false);
  const updates = useRef<ReturnType<typeof startAppUpdates> | null>(null);
  const cartItems = useCartStore(s => s.items.length);
  const cartBusy = useCartStore(s => s.isLoading);
  const syncing = useSyncStore(s => s.isSyncing);
  useEffect(() => {
    if (import.meta.env.DEV || import.meta.env.MODE === 'product-preview') return;
    const watcher = startAppUpdates(registerSW, () => setAvailable(true), error => console.warn('App update check will retry:', error));
    updates.current = watcher;
    return () => { watcher.dispose(); updates.current = null; };
  }, []);
  if (!available) return null;
  const safe = canApplyAppUpdate(cartItems, cartBusy, syncing, false);
  const apply = async () => {
    // Drawers/forms may hold unsaved values even when the cart is empty.
    const formOpen = Boolean(document.querySelector('[role="dialog"], [aria-modal="true"]'));
    if (!canApplyAppUpdate(useCartStore.getState().items.length, useCartStore.getState().isLoading, useSyncStore.getState().isSyncing, formOpen)) {
      toast.info('Finish your current sale and close any open form before updating.'); return;
    }
    setApplying(true);
    try { await updates.current?.apply(); }
    catch { setApplying(false); toast.error('Update could not be applied. Please try again.'); }
  };
  return (
    <div role="status" className="fixed bottom-20 left-1/2 -translate-x-1/2 z-[100] max-w-sm w-[calc(100%-2rem)] rounded-xl border border-blue-300 bg-white p-4 shadow-lg dark:bg-slate-900 dark:text-white">
      <p className="text-sm font-semibold">A new version of Zameria is ready.</p>
      <p className="mt-1 text-xs opacity-75">{safe ? 'Update when you are ready. Your sign-in and saved sales stay on this device.' : 'Finish your current sale before updating.'}</p>
      <button className="mt-3 rounded-lg bg-blue-700 px-4 py-2 text-xs font-semibold text-white disabled:opacity-50" disabled={!safe || applying} onClick={() => void apply()}>
        {applying ? 'Updating…' : 'Update Zameria'}
      </button>
    </div>
  );
}
