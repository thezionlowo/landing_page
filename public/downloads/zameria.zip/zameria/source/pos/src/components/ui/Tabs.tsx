import React from 'react';
import { cn } from '@/lib';

export interface TabItem {
  id: string;
  label: string;
  icon?: React.ReactNode;
  badge?: number | string;
}

export interface TabsProps {
  items: TabItem[];
  value: string;
  onChange: (id: string) => void;
  variant?: 'segmented' | 'underline';
  size?: 'sm' | 'md';
  className?: string;
}

export function Tabs({
  items,
  value,
  onChange,
  variant = 'segmented',
  size = 'md',
  className,
}: TabsProps) {
  if (variant === 'underline') {
    return (
      <div className={cn('flex items-center gap-4 border-b border-surface-200 dark:border-surface-200/40', className)}>
        {items.map((item) => {
          const isActive = item.id === value;
          return (
            <button
              key={item.id}
              type="button"
              onClick={() => onChange(item.id)}
              className={cn(
                'relative flex items-center gap-1.5 pb-2 text-xs font-semibold select-none cursor-pointer transition-colors',
                isActive
                  ? 'text-primary dark:text-[#60A5FA]'
                  : 'text-surface-500 hover:text-surface-800 dark:hover:text-white'
              )}
            >
              {item.icon && <span className="flex-shrink-0">{item.icon}</span>}
              <span>{item.label}</span>
              {item.badge !== undefined && (
                <span
                  className={cn(
                    'px-1.5 py-0.2 rounded-full text-[10px] font-bold',
                    isActive
                      ? 'bg-blue-100 text-[#071A31] dark:bg-[#0C2340] dark:text-[#60A5FA]'
                      : 'bg-surface-200 text-surface-600 dark:bg-surface-200 dark:text-surface-400'
                  )}
                >
                  {item.badge}
                </span>
              )}
              {isActive && (
                <span className="absolute bottom-0 left-0 right-0 h-0.5 bg-[#60A5FA] rounded-full" />
              )}
            </button>
          );
        })}
      </div>
    );
  }

  return (
    <div
      className={cn(
        'inline-flex items-center p-1 rounded-lg bg-surface-100 dark:bg-surface-200/50 border border-surface-200/60 dark:border-surface-300/30 select-none',
        className
      )}
    >
      {items.map((item) => {
        const isActive = item.id === value;
        return (
          <button
            key={item.id}
            type="button"
            onClick={() => onChange(item.id)}
            className={cn(
              'flex items-center justify-center gap-1.5 rounded-md font-semibold select-none cursor-pointer transition-all duration-120',
              size === 'sm' ? 'px-2.5 py-1 text-[11px]' : 'px-3.5 py-1.5 text-xs',
              isActive
                ? 'bg-surface-0 dark:bg-surface-100 text-surface-900 dark:text-surface-800 shadow-xs'
                : 'text-surface-600 dark:text-surface-500 hover:text-surface-900 dark:hover:text-white'
            )}
          >
            {item.icon && <span className="flex-shrink-0">{item.icon}</span>}
            <span>{item.label}</span>
            {item.badge !== undefined && (
              <span
                className={cn(
                  'px-1.5 py-0.2 rounded-full text-[10px] font-bold',
                  isActive
                    ? 'bg-blue-50 text-[#071A31] dark:bg-[#0C2340] dark:text-[#60A5FA]'
                    : 'bg-surface-200 text-surface-600 dark:bg-surface-200 dark:text-surface-400'
                )}
              >
                {item.badge}
              </span>
            )}
          </button>
        );
      })}
    </div>
  );
}
