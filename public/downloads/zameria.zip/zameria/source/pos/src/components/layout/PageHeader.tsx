import type { ReactNode } from 'react';
import { cn } from '@/lib';
export function PageHeader({ title, description, actions, className }: { title: string; description?: ReactNode; actions?: ReactNode; className?: string }) {
  return <header className={cn('pos-page-header', className)}>
    <div className="min-w-0"><h1 className="pos-page-title">{title}</h1>{description && <p className="pos-page-description">{description}</p>}</div>
    {actions && <div className="pos-page-actions">{actions}</div>}
  </header>;
}
