import React, { useId } from 'react';
import { createPortal } from 'react-dom';
import { X } from 'lucide-react';
import { cn } from '@/lib';
import { useDialogFocus } from './useDialogFocus';

export interface ModalProps {
  open: boolean;
  onClose: () => void;
  title?: React.ReactNode;
  children: React.ReactNode;
  footer?: React.ReactNode;
  size?: 'sm' | 'md' | 'lg' | 'xl';
  showCloseButton?: boolean;
}
export function Modal({ open, onClose, title, children, footer, size = 'md', showCloseButton = true }: ModalProps) {
  const titleId = useId();
  const ref = useDialogFocus(open, onClose);
  if (!open) return null;
  const sizes = { sm: 'max-w-md', md: 'max-w-lg', lg: 'max-w-2xl', xl: 'max-w-4xl' };
  return createPortal(
    <div className="pos-dialog-layer">
      <div className="pos-dialog-backdrop" onClick={onClose} aria-hidden="true" />
      <div ref={ref} tabIndex={-1} role="dialog" aria-modal="true" aria-labelledby={title ? titleId : undefined} aria-label={title ? undefined : 'Dialog'} className={cn('pos-dialog', sizes[size])}>
        {(title || showCloseButton) && <div className="pos-dialog-heading">
          <div role="heading" aria-level={2} id={titleId} className="min-w-0 flex-1 text-base font-semibold text-on-surface">{title}</div>
          {showCloseButton && <button type="button" onClick={onClose} className="pos-icon-button" aria-label="Close dialog"><X className="w-5 h-5" /></button>}
        </div>}
        <div className="pos-dialog-body">{children}</div>
        {footer && <div className="pos-dialog-footer">{footer}</div>}
      </div>
    </div>, document.body
  );
}
