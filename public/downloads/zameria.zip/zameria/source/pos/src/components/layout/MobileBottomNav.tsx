import React, { useState, useEffect } from 'react';
import { NavLink, useLocation, useNavigate } from 'react-router';
import {
  ShoppingCart,
  FileText,
  Package,
  MoreHorizontal,
  LayoutDashboard,
  Users,
  Settings,
  Headphones,
  LogOut,
  RefreshCw,
  ShieldCheck,
  Briefcase,
  Wifi,
  WifiOff,
  ChevronRight,
  Store,
} from 'lucide-react';
import { useUIStore, useSyncStore, useConnectionStore, useAuthStore } from '@/store';
import { useLiveQuery } from 'dexie-react-hooks';
import { db } from '@/db';
import { isOrderAccessibleToUser } from '@/services/auth/orderAccess';
import { supportChatClient } from '@/services/supportChatClient';
import { cn } from '@/lib';
import { Drawer, Button } from '@/components/ui';
import { toast } from 'sonner';

export function MobileBottomNav() {
  const navigate = useNavigate();
  const location = useLocation();
  const [showMoreSheet, setShowMoreSheet] = useState(false);
  const [isRevalidating, setIsRevalidating] = useState(false);

  const { pendingCount } = useSyncStore();
  const { isOnline } = useConnectionStore();
  const { user, hasPermission, logout, revalidate } = useAuthStore();
  const { toggleSupportChat } = useUIStore();

  const [unreadSupportCount, setUnreadSupportCount] = useState(() => supportChatClient.getUnreadCount());

  useEffect(() => {
    const updateUnread = () => {
      setUnreadSupportCount(supportChatClient.getUnreadCount());
    };
    window.addEventListener('zameria_support_update', updateUnread);
    return () => window.removeEventListener('zameria_support_update', updateUnread);
  }, []);

  const incompleteCount =
    useLiveQuery(
      async () => {
        const orders = await db.orders.where('status').anyOf('on-hold', 'pending').toArray();
        return orders.filter((o) => isOrderAccessibleToUser(o, user)).length;
      },
      [user]
    ) || 0;

  const totalOrdersBadge = pendingCount + incompleteCount;

  // Auto-open more sheet when requested via query param (e.g. Back from secondary full-screen page)
  useEffect(() => {
    const params = new URLSearchParams(location.search);
    if (params.get('openMore') === 'true') {
      setShowMoreSheet(true);
      navigate(location.pathname, { replace: true });
    }
  }, [location.search, location.pathname, navigate]);

  const handleLogout = () => {
    setShowMoreSheet(false);
    logout();
    toast.info('Signed out of POS.');
    navigate('/login');
  };

  const handleRevalidate = async () => {
    setIsRevalidating(true);
    try {
      await revalidate();
      toast.success('Permissions revalidated with WooCommerce!');
    } catch (err: any) {
      toast.error(err.message || 'Failed to revalidate session.');
    } finally {
      setIsRevalidating(false);
    }
  };

  const mainTabs = [
    { path: '/sale', label: 'Sale', icon: ShoppingCart, permission: 'canAccessSale' as const },
    { path: '/orders', label: 'Orders', icon: FileText, badge: totalOrdersBadge, permission: 'canAccessOrders' as const },
    { path: '/customers', label: 'Customers', icon: Users, permission: 'canAccessCustomers' as const },
  ];

  const userRole = user?.role || 'cashier';
  const roleBadge = userRole === 'administrator' ? 'Admin' : userRole === 'shop_manager' ? 'Manager' : 'Cashier';


  return (
    <>
      {/* Mobile Bottom Navigation Bar (< 768px) */}
      <nav
        aria-label="Mobile Navigation"
        className="pos-mobile-navigation md:hidden"
      >
        <div className="flex items-center justify-around max-w-lg mx-auto">
          {mainTabs.filter(tab=>hasPermission(tab.permission)).map((tab) => {
            const Icon = tab.icon;
            const isActive = location.pathname.startsWith(tab.path);
            return (
              <NavLink
                key={tab.path}
                aria-label={tab.label}
                to={tab.path}
                className={cn(
                  'pos-mobile-nav-item',
                  isActive
                    ? 'text-primary font-bold'
                    : 'text-surface-500 hover:text-surface-900 active:scale-95'
                )}
              >
                <div className="relative">
                  <Icon className={cn('w-5 h-5 transition-transform', isActive && 'scale-110')} />
                  {Boolean(tab.badge && tab.badge > 0) && (
                    <span className="absolute -top-1.5 -right-2 bg-amber-500 text-white text-[10px] font-extrabold px-1.5 py-0.2 rounded-full min-w-[16px] text-center shadow-xs">
                      {tab.badge}
                    </span>
                  )}
                </div>
                <span className="text-xs tracking-tight mt-1">{tab.label}</span>
              </NavLink>
            );
          })}

          {/* More Tab */}
          <button
            type="button"
            onClick={() => setShowMoreSheet(true)}
            className={cn(
              'pos-mobile-nav-item',
              showMoreSheet || location.pathname.match(/\/(products|settings|dashboard)/)
                ? 'text-primary font-bold'
                : 'text-surface-500 hover:text-surface-900 active:scale-95'
            )}
          >
            <div className="relative">
              <MoreHorizontal className="w-5 h-5" />
              {unreadSupportCount > 0 && (
                <span className="absolute -top-1.5 -right-2 bg-blue-600 text-white text-[10px] font-extrabold px-1.5 py-0.2 rounded-full min-w-[16px] text-center">
                  {unreadSupportCount}
                </span>
              )}
            </div>
            <span className="text-xs tracking-tight mt-1">More</span>
          </button>
        </div>
      </nav>

      {/* More Bottom Sheet Drawer */}
      <Drawer
        open={showMoreSheet}
        onClose={() => setShowMoreSheet(false)}
        title="Your workspace"
        width="md"
      >
        <div className="space-y-4 pb-6">
          {/* Active User Card */}
          {user && (
            <div className="p-3.5 rounded-2xl bg-surface-50 border border-surface-200 flex items-center justify-between">
              <div className="flex items-center gap-3 min-w-0">
                <div className="w-10 h-10 rounded-xl bg-primary/10 border border-primary/20 flex items-center justify-center text-primary font-bold">
                  {user.role === 'administrator' ? (
                    <ShieldCheck className="w-5 h-5 text-emerald-600" />
                  ) : (
                    <Briefcase className="w-5 h-5 text-blue-600" />
                  )}
                </div>
                <div className="min-w-0 flex-1">
                  <div className="flex items-center gap-2">
                    <h4 className="text-sm font-bold text-surface-900 truncate">{user.displayName}</h4>
                    <span className="px-1.5 py-0.5 rounded text-[10px] font-bold bg-surface-200 text-surface-700 uppercase">
                      {roleBadge}
                    </span>
                  </div>
                  <p className="text-xs text-surface-500 truncate flex items-center gap-1 mt-0.5">
                    <Store className="w-3 h-3" />
                    <span>{user.storeName || 'Connected Store'}</span>
                    {user.deviceName && <span>• {user.deviceName}</span>}
                  </p>
                </div>
              </div>
            </div>
          )}

          {/* Quick Links Menu */}
          <div className="divide-y divide-surface-100 rounded-2xl border border-surface-200 bg-surface overflow-hidden">
            {hasPermission('canAccessDashboard') && (
              <button
                type="button"
                onClick={() => {
                  setShowMoreSheet(false);
                  navigate('/dashboard');
                }}
                className="w-full flex items-center justify-between p-3.5 hover:bg-surface-50 transition-colors text-left"
              >
                <div className="flex items-center gap-3">
                  <div className="p-2 rounded-lg bg-surface-100 text-surface-700">
                    <LayoutDashboard className="w-4 h-4" />
                  </div>
                  <div>
                    <span className="text-sm font-semibold text-surface-900 block">Dashboard</span>
                    <span className="text-xs text-surface-500">Sales metrics, analytics & trends</span>
                  </div>
                </div>
                <ChevronRight className="w-4 h-4 text-surface-400" />
              </button>
            )}

            {hasPermission('canAccessProducts') && <button type="button" onClick={()=>{setShowMoreSheet(false);navigate('/products');}} className="w-full flex items-center justify-between p-3.5 hover:bg-surface-50 text-left"><div className="flex items-center gap-3"><div className="p-2 rounded-lg bg-surface-100 text-surface-700"><Package className="w-4 h-4" /></div><div><span className="text-sm font-semibold text-surface-900 block">Products</span><span className="text-xs text-surface-500">Catalogue, prices and stock</span></div></div><ChevronRight className="w-4 h-4 text-surface-400" /></button>}

            {hasPermission('canAccessSettings') && (
              <button
                type="button"
                onClick={() => {
                  setShowMoreSheet(false);
                  navigate('/settings');
                }}
                className="w-full flex items-center justify-between p-3.5 hover:bg-surface-50 transition-colors text-left"
              >
                <div className="flex items-center gap-3">
                  <div className="p-2 rounded-lg bg-surface-100 text-surface-700">
                    <Settings className="w-4 h-4" />
                  </div>
                  <div>
                    <span className="text-sm font-semibold text-surface-900 block">Settings</span>
                    <span className="text-xs text-surface-500">Printer, hardware & store connection</span>
                  </div>
                </div>
                <ChevronRight className="w-4 h-4 text-surface-400" />
              </button>
            )}

            {/* Support Chat */}
            <button
              type="button"
              onClick={() => {
                setShowMoreSheet(false);
                toggleSupportChat();
              }}
              className="w-full flex items-center justify-between p-3.5 hover:bg-surface-50 transition-colors text-left"
            >
              <div className="flex items-center gap-3">
                <div className="p-2 rounded-lg bg-blue-50 text-blue-600">
                  <Headphones className="w-4 h-4" />
                </div>
                <div>
                  <div className="flex items-center gap-2">
                    <span className="text-sm font-semibold text-surface-900">ZAMERIA Support</span>
                    {unreadSupportCount > 0 && (
                      <span className="px-1.5 py-0.2 rounded-full bg-blue-600 text-white text-[10px] font-bold">
                        {unreadSupportCount} new
                      </span>
                    )}
                  </div>
                  <span className="text-xs text-surface-500">Direct assistance with POS & orders</span>
                </div>
              </div>
              <ChevronRight className="w-4 h-4 text-surface-400" />
            </button>
          </div>

          {/* Network & Device Status Bar */}
          <div className="p-3 rounded-xl bg-surface-50 border border-surface-200 flex items-center justify-between text-xs">
            <div className="flex items-center gap-2">
              {isOnline ? (
                <>
                  <Wifi className="w-3.5 h-3.5 text-emerald-500" />
                  <span className="text-emerald-700 font-semibold">Store Online</span>
                </>
              ) : (
                <>
                  <WifiOff className="w-3.5 h-3.5 text-amber-500" />
                  <span className="text-amber-700 font-semibold">Device Offline</span>
                </>
              )}
            </div>
            {pendingCount > 0 && (
              <span className="text-[11px] text-blue-600 font-medium bg-blue-50 px-2 py-0.5 rounded-full">
                {pendingCount} sale{pendingCount > 1 ? 's' : ''} queued
              </span>
            )}
          </div>

          {/* Action Buttons: Revalidate & Logout */}
          <div className="space-y-2 pt-2">
            <Button
              type="button"
              variant="outline"
              size="md"
              className="w-full justify-center text-xs"
              onClick={handleRevalidate}
              loading={isRevalidating}
              icon={<RefreshCw className="w-3.5 h-3.5" />}
            >
              Revalidate WooCommerce Session
            </Button>

            <Button
              type="button"
              variant="destructive"
              size="md"
              className="w-full justify-center text-xs"
              onClick={handleLogout}
              icon={<LogOut className="w-3.5 h-3.5" />}
            >
              Sign Out of POS
            </Button>
          </div>
        </div>
      </Drawer>
    </>
  );
}
export default MobileBottomNav;
