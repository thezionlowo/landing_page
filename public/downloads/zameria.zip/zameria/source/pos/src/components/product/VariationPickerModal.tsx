import { Modal } from '@/components/ui';
import { cn, formatMoney } from '@/lib';
import type { Product, ProductVariation } from '@/types';

interface VariationPickerModalProps {
  product: Product | null;
  onClose: () => void;
  onSelect: (product: Product, variation: ProductVariation) => void;
}

function isUnavailable(v: ProductVariation): boolean {
  return v.stockStatus === 'outofstock' || (v.manageStock && v.stockQuantity !== null && v.stockQuantity <= 0);
}

/** Lets the cashier pick a size/colour when a variable product is tapped. */
export function VariationPickerModal({ product, onClose, onSelect }: VariationPickerModalProps) {
  const variations = product?.variations ?? [];

  return (
    <Modal open={product !== null} onClose={onClose} title={product ? `Choose ${product.name}` : ''} size="md">
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
        {variations.map((v) => {
          const label = v.attributes.map((a) => a.option).filter(Boolean).join(' / ') || v.sku || `#${v.wooId}`;
          const unavailable = isUnavailable(v);
          return (
            <button
              key={v.id}
              type="button"
              disabled={unavailable}
              onClick={() => product && onSelect(product, v)}
              className={cn(
                'text-left p-3 rounded-xl border transition-colors',
                unavailable
                  ? 'opacity-50 cursor-not-allowed border-outline-variant/60'
                  : 'cursor-pointer border-outline-variant/80 hover:border-primary hover:bg-primary-container/20'
              )}
            >
              <div className="font-semibold text-sm text-on-surface">{label}</div>
              <div className="flex items-center justify-between mt-1 text-xs">
                <span className="font-bold text-on-surface">{formatMoney(v.salePrice ?? v.price)}</span>
                <span className={cn('text-on-surface-variant', unavailable && 'text-error font-semibold')}>
                  {unavailable
                    ? 'Out of stock'
                    : v.manageStock && v.stockQuantity !== null
                      ? `${v.stockQuantity} left`
                      : 'In stock'}
                </span>
              </div>
            </button>
          );
        })}
        {variations.length === 0 && (
          <p className="text-xs text-on-surface-variant col-span-full">This product has no variations available to sell.</p>
        )}
      </div>
    </Modal>
  );
}
