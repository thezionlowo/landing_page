import React from 'react';
import { Modal } from './Modal';
import { Button } from './Button';
import { Printer } from 'lucide-react';
import { formatMoney } from '@/lib';
import { getStoreLogo } from '@/services/storeLogoService';
import {
  printThermalReceipt,
  getReceiptPaperWidth,
  setReceiptPaperWidth,
  RECEIPT_CONFIGS,
  type ThermalPaperWidth,
} from '@/services/printService';
import type { Order, OrderItem } from '@/types';
import { useAuthStore } from '@/store/authStore';

export interface ReceiptModalProps {
  open: boolean;
  onClose: () => void;
  order: Order | null;
  items: OrderItem[];
  storeName?: string;
  storeUrl?: string;
  autoPrint?: boolean;
}

export function ReceiptModal({
  open,
  onClose,
  order,
  items,
  storeName: storeNameProp,
  storeUrl: storeUrlProp,
  autoPrint: autoPrintProp,
}: ReceiptModalProps) {
  // Store session context
  const sessionUser = useAuthStore((s) => s.user);
  const storeName = storeNameProp ?? sessionUser?.storeName ?? 'ZAMERIA Store';
  const storeUrl = storeUrlProp ?? sessionUser?.storeUrl ?? 'demo.zameria.co';
  const storeAddress = sessionUser?.storeAddress;
  const storeFooter = sessionUser?.storeFooter;

  // Paper width state (80mm default, 58mm compact)
  const [paperWidth, setPaperWidthState] = React.useState<ThermalPaperWidth>(() => getReceiptPaperWidth());

  const handlePaperWidthChange = React.useCallback((width: ThermalPaperWidth) => {
    setPaperWidthState(width);
    setReceiptPaperWidth(width);
  }, []);

  const handlePrint = React.useCallback(() => {
    const el = document.getElementById('printable-receipt');
    if (el) {
      void printThermalReceipt(el, { paperWidth });
    } else {
      window.print();
    }
  }, [paperWidth]);

  React.useEffect(() => {
    if (!open || !order) return;
    const isAutoPrint = autoPrintProp ?? (typeof window !== 'undefined' && localStorage.getItem('zameria_auto_print') === 'true');
    if (isAutoPrint) {
      const timer = setTimeout(() => {
        handlePrint();
      }, 150);
      return () => clearTimeout(timer);
    }
  }, [open, order?.id, autoPrintProp, handlePrint]);

  if (!order) return null;

  const formattedDate = new Date(order.createdAt).toLocaleDateString('en-GB', {
    day: '2-digit',
    month: '2-digit',
    year: 'numeric',
  });
  const formattedTime = new Date(order.createdAt).toLocaleTimeString([], {
    hour: '2-digit',
    minute: '2-digit',
  });

  const isWeb = order.source === 'website' || (!order.source && order.wooId !== null && order.shippingMethod !== 'in-store' && order.shippingMethod !== 'walk-in');
  const attendee = order.attendedBy || (isWeb ? 'Website Order' : 'Attendant');
  const storeLogo = getStoreLogo(storeUrl || storeName);
  const config = RECEIPT_CONFIGS[paperWidth] || RECEIPT_CONFIGS['80mm'];
  const cleanStoreUrl = storeUrl.replace(/^https?:\/\//, '').replace(/\/$/, '');

  return (
    <Modal open={open} onClose={onClose} size="sm" title="Receipt Preview">
      <div className="space-y-3.5">
        {/* Paper format selector (80mm Default vs 58mm Compact) */}
        <div className="flex items-center justify-between no-print border-b border-outline-variant/40 pb-2">
          <div className="flex items-center gap-1.5 text-xs text-on-surface-variant font-medium">
            <Printer className="w-3.5 h-3.5 text-primary" />
            <span>Format:</span>
          </div>
          <div className="flex items-center gap-1 bg-surface-100 p-0.5 rounded-lg border border-outline-variant/60">
            <button
              type="button"
              onClick={() => handlePaperWidthChange('80mm')}
              className={`px-2.5 py-0.5 text-xs rounded-md font-medium transition-all ${
                paperWidth === '80mm'
                  ? 'bg-primary text-on-primary shadow-xs'
                  : 'text-on-surface-variant hover:text-on-surface'
              }`}
            >
              80mm (Default)
            </button>
            <button
              type="button"
              onClick={() => handlePaperWidthChange('58mm')}
              className={`px-2.5 py-0.5 text-xs rounded-md font-medium transition-all ${
                paperWidth === '58mm'
                  ? 'bg-primary text-on-primary shadow-xs'
                  : 'text-on-surface-variant hover:text-on-surface'
              }`}
            >
              58mm
            </button>
          </div>
        </div>

        {/* Realistic Thermal Receipt Paper Container */}
        <div className="flex justify-center bg-surface-50 p-2 rounded-xl border border-outline-variant/30 max-h-[65vh] overflow-y-auto">
          <div
            id="printable-receipt"
            style={{
              width: paperWidth === '58mm' ? '58mm' : '80mm',
              maxWidth: '100%',
              fontSize: config.fontSize,
              lineHeight: config.lineHeight,
            }}
            className="receipt-container bg-white p-3 border border-outline-variant/80 rounded-md text-black space-y-2.5 font-mono shadow-xs print:m-0 print:border-none print:shadow-none print:p-0 print:rounded-none"
          >
            {/* 1. Header (Logo, Store Name, Address/Tagline, URL) */}
            <div className="text-center space-y-1 pb-2 border-b border-dashed border-black">
              <div className="flex justify-center mb-1">
                {storeLogo ? (
                  <img
                    src={storeLogo}
                    alt={storeName}
                    style={{
                      width: `${config.logoWidthMm}mm`,
                      maxWidth: `${config.logoMaxWidthMm}mm`,
                      height: 'auto',
                    }}
                    className="object-contain block mx-auto thermal-receipt-logo"
                    onError={(e) => {
                      (e.currentTarget as HTMLImageElement).src = 'zameria-logo.png';
                    }}
                  />
                ) : (
                  <img
                    src="zameria-logo.png"
                    alt="ZAMERIA"
                    style={{
                      width: `${config.logoWidthMm}mm`,
                      maxWidth: `${config.logoMaxWidthMm}mm`,
                      height: 'auto',
                    }}
                    className="object-contain block mx-auto thermal-receipt-logo"
                  />
                )}
              </div>
              <div className="font-bold text-xs sm:text-sm tracking-wider uppercase text-black">
                {storeName}
              </div>
              {storeAddress && (
                <div className="text-[10px] leading-tight text-black px-1 break-words">
                  {storeAddress}
                </div>
              )}
              <div className="text-[10px] text-black/80">
                {cleanStoreUrl}
              </div>
            </div>

            {/* 2. Order Information */}
            <div className="space-y-0.5 text-[10.5px] py-2 border-b border-dashed border-black">
              <div className="flex justify-between">
                <span className="text-black/70">Order:</span>
                <span className="font-bold text-black">#{order.orderNumber}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-black/70">Date:</span>
                <span className="text-black">{formattedDate} {formattedTime}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-black/70">Cashier:</span>
                <span className="font-semibold text-black">{attendee}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-black/70">Customer:</span>
                <span className="break-words text-right max-w-[150px] text-black">
                  {order.customerName || (isWeb ? 'Website Customer' : 'Walk-in Customer')}
                </span>
              </div>
              <div className="flex justify-between">
                <span className="text-black/70">Payment:</span>
                <span className="capitalize font-medium text-black">
                  {order.paymentMethodTitle || order.paymentMethod}
                </span>
              </div>
            </div>

            {/* Website Order Delivery Details (if applicable) */}
            {isWeb && (order.customerPhone || order.formattedDeliveryAddress || order.deliveryAddress) && (
              <div className="space-y-0.5 text-[10.5px] py-2 border-b border-dashed border-black">
                <div className="font-bold text-[9.5px] uppercase tracking-wider text-black">Delivery Details:</div>
                {order.customerPhone && (
                  <div className="flex justify-between">
                    <span className="text-black/70">Phone:</span>
                    <span className="font-semibold text-black">{order.customerPhone}</span>
                  </div>
                )}
                {order.formattedDeliveryAddress ? (
                  <div className="pt-0.5">
                    <span className="block text-[10px] break-words text-left leading-relaxed text-black">
                      {order.formattedDeliveryAddress}
                    </span>
                  </div>
                ) : null}
              </div>
            )}

            {/* 3. Items List (Left aligned with natural text wrap, right aligned total) */}
            <div className="space-y-1.5 pb-2.5 border-b border-dashed border-black">
              <div className="flex justify-between font-bold text-[10px] uppercase text-black/80 pb-0.5 border-b border-black/30">
                <span>ITEM</span>
                <span>TOTAL</span>
              </div>
              {items.map((item, index) => (
                <div key={item.id || index} className="space-y-0.5 thermal-avoid-break" data-avoid-break="true">
                  <div className="flex items-start justify-between gap-1.5">
                    <span className="font-medium text-left break-words flex-1 leading-snug text-black">
                      {item.name}
                    </span>
                    <span className="tabular-nums font-semibold text-right shrink-0 text-black">
                      {formatMoney(item.total)}
                    </span>
                  </div>
                  <div className="text-[10px] text-black/70">
                    {item.quantity} × {formatMoney(item.price)}
                    {item.discount ? <span className="font-semibold ml-1 text-black">(Discounted)</span> : null}
                  </div>
                </div>
              ))}
            </div>

            {/* 4. Totals Block */}
            <div className="space-y-1 pt-1 thermal-avoid-break" data-avoid-break="true">
              <div className="flex justify-between text-[11px] text-black">
                <span>Subtotal:</span>
                <span className="tabular-nums">{formatMoney(order.subtotal)}</span>
              </div>
              {order.couponDiscount && order.couponDiscount > 0 ? (
                <div className="flex justify-between text-[11px] font-medium text-black">
                  <span>Coupon ({order.couponCode || 'Discount'}):</span>
                  <span className="tabular-nums">-{formatMoney(order.couponDiscount)}</span>
                </div>
              ) : null}
              {order.transactionFee > 0 && (
                <div className="flex justify-between text-[11px] text-black">
                  <span>Transaction Fee (1.5%):</span>
                  <span className="tabular-nums">{formatMoney(order.transactionFee)}</span>
                </div>
              )}
              {/* Bold Prominent TOTAL Row */}
              <div className="flex justify-between font-bold text-xs sm:text-sm py-1 border-t-2 border-b border-black my-1 text-black">
                <span>TOTAL:</span>
                <span className="tabular-nums">{formatMoney(order.total)}</span>
              </div>

              {/* Payment Splits (if applicable) */}
              {order.paymentSplits && order.paymentSplits.length > 0 && (
                <div className="pt-1 text-[10px] space-y-0.5 thermal-avoid-break" data-avoid-break="true">
                  <div className="font-bold uppercase tracking-wider text-black">Payment Breakdown:</div>
                  {order.paymentSplits.map((s, idx) => (
                    <div key={s.id || idx} className="flex justify-between text-black">
                      <span>{s.methodTitle}:</span>
                      <span className="tabular-nums font-semibold">{formatMoney(s.amount)}</span>
                    </div>
                  ))}
                </div>
              )}
            </div>

            {/* 5. Compact Footer */}
            <div className="text-center pt-2 border-t border-dashed border-black text-[10px] text-black space-y-1 thermal-avoid-break" data-avoid-break="true">
              <p className="font-medium">{storeFooter || 'Thank you for shopping with us!'}</p>
              <p className="font-mono text-[9px] text-black/70">
                Ref: #{order.orderNumber} • ID: {order.localTransactionId || order.id}
              </p>
            </div>
          </div>
        </div>

        {/* Modal Actions */}
        <div className="flex items-center justify-end gap-2.5 pt-1 no-print">
          <Button variant="secondary" size="sm" onClick={onClose}>
            Close
          </Button>
          <Button variant="primary" size="sm" onClick={handlePrint} icon={<Printer className="w-3.5 h-3.5" />}>
            Print Receipt ({paperWidth})
          </Button>
        </div>
      </div>
    </Modal>
  );
}
