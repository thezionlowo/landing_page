import { Minus, Plus } from 'lucide-react';
import { cn } from '@/lib';

export interface QuantityStepperProps {
  value: number;
  onChange: (value: number) => void;
  min?: number;
  max?: number;
  size?: 'sm' | 'md';
}

export function QuantityStepper({
  value,
  onChange,
  min = 1,
  max = 999,
  size = 'sm',
}: QuantityStepperProps) {
  const decrement = (e: React.MouseEvent) => {
    e.stopPropagation();
    if (value > min) onChange(value - 1);
  };

  const increment = (e: React.MouseEvent) => {
    e.stopPropagation();
    if (value < max) onChange(value + 1);
  };

  const btnClass = cn(
    'flex items-center justify-center rounded border border-surface-300 transition-colors cursor-pointer select-none',
    'bg-surface-0 hover:bg-surface-100 active:bg-surface-200 text-surface-700',
    'disabled:opacity-30 disabled:cursor-not-allowed',
    size === 'sm' ? 'w-6 h-6' : 'w-7 h-7'
  );

  const iconSize = size === 'sm' ? 12 : 14;

  return (
    <div
      className={cn(
        'inline-flex items-center justify-between flex-shrink-0 select-none',
        size === 'sm' ? 'w-[80px]' : 'w-[92px]'
      )}
      onClick={(e) => e.stopPropagation()}
    >
      <button
        type="button"
        className={btnClass}
        onClick={decrement}
        disabled={value <= min}
        aria-label="Decrease quantity"
      >
        <Minus size={iconSize} />
      </button>
      <span
        className={cn(
          'font-semibold tabular-nums text-surface-900 text-center select-none truncate',
          size === 'sm' ? 'w-7 text-xs' : 'w-8 text-sm'
        )}
      >
        {value}
      </span>
      <button
        type="button"
        className={btnClass}
        onClick={increment}
        disabled={value >= max}
        aria-label="Increase quantity"
      >
        <Plus size={iconSize} />
      </button>
    </div>
  );
}
