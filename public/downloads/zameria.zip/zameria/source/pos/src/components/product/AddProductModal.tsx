import React, { useState, useEffect } from 'react';
import { Modal, Button, Input } from '@/components/ui';
import { BarcodeScannerModal } from '@/components/ui/BarcodeScannerModal';
import { toKobo, useStoreCurrency } from '@/lib';
import { createProduct } from '@/services/woocommerce';
import { CategorySelector } from './CategorySelector';
import { BrandSelector } from './BrandSelector';
import { ProductImageUploader } from './ProductImageUploader';
import { toast } from 'sonner';
import { PackagePlus, CheckCircle2, AlertCircle, ScanBarcode } from 'lucide-react';
import type { StockStatus } from '@/types';

interface AddProductModalProps {
  open: boolean;
  onClose: () => void;
  onProductCreated?: (productId: number) => void;
  initialBarcode?: string;
}

export function AddProductModal({
  open,
  onClose,
  onProductCreated,
  initialBarcode = '',
}: AddProductModalProps) {
  const currency = useStoreCurrency();
  // Form State
  const [name, setName] = useState('');
  const [sku, setSku] = useState('');
  const [barcode, setBarcode] = useState(initialBarcode);
  const [showScannerModal, setShowScannerModal] = useState(false);
  const [selectedCategoryIds, setSelectedCategoryIds] = useState<number[]>([]);
  const [selectedBrandId, setSelectedBrandId] = useState<number | null>(null);
  const [regularPrice, setRegularPrice] = useState('');
  const [salePrice, setSalePrice] = useState('');
  const [manageStock, setManageStock] = useState(true);
  const [stockQuantity, setStockQuantity] = useState('');
  const [lowStockThreshold, setLowStockThreshold] = useState('5');
  const [stockStatus, setStockStatus] = useState<StockStatus>('instock');
  const [status, setStatus] = useState<'publish' | 'draft'>('publish');
  const [description, setDescription] = useState('');
  const [selectedImageFile, setSelectedImageFile] = useState<File | null>(null);
  const [isSubmitting, setIsSubmitting] = useState(false);

  useEffect(() => {
    if (open && initialBarcode) {
      setBarcode(initialBarcode);
    }
  }, [open, initialBarcode]);

  const resetForm = () => {
    setName('');
    setSku('');
    setBarcode('');
    setSelectedCategoryIds([]);
    setSelectedBrandId(null);
    setRegularPrice('');
    setSalePrice('');
    setManageStock(true);
    setStockQuantity('');
    setLowStockThreshold('5');
    setStockStatus('instock');
    setStatus('publish');
    setDescription('');
    setSelectedImageFile(null);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    const trimmedName = name.trim();
    if (!trimmedName) {
      toast.error('Product name is required');
      return;
    }

    const trimmedSku = sku.trim();

    const regPriceNum = parseFloat(regularPrice);
    if (isNaN(regPriceNum) || regPriceNum <= 0) {
      toast.error('Please enter a valid regular price greater than 0');
      return;
    }

    const salePriceNum = salePrice.trim() ? parseFloat(salePrice) : null;
    if (salePriceNum !== null && (isNaN(salePriceNum) || salePriceNum < 0)) {
      toast.error('Sale price must be a valid positive number');
      return;
    }

    if (salePriceNum !== null && salePriceNum >= regPriceNum) {
      toast.error('Sale price should be less than regular price');
      return;
    }

    const stockQtyNum = stockQuantity.trim() ? parseInt(stockQuantity, 10) : (manageStock ? 0 : null);
    const lowStockNum = lowStockThreshold.trim() ? parseInt(lowStockThreshold, 10) : null;

    setIsSubmitting(true);

    try {
      const result = await createProduct({
        name: trimmedName,
        sku: trimmedSku || undefined,
        barcode: barcode.trim() || undefined,
        regularPrice: toKobo(regPriceNum),
        salePrice: salePriceNum !== null ? toKobo(salePriceNum) : null,
        categoryIds: selectedCategoryIds,
        brandId: selectedBrandId,
        manageStock,
        stockQuantity: stockQtyNum,
        lowStockThreshold: lowStockNum,
        stockStatus,
        status,
        description: description.trim(),
        imageFile: selectedImageFile,
      });

      if (result.synced) {
        toast.success(`✓ Product "${trimmedName}" created and synced with website`, {
          icon: <CheckCircle2 className="w-4 h-4 text-emerald-600" />,
        });
      } else {
        toast.warning('Product saved locally, but website sync failed.', {
          description: result.error || 'Will automatically sync when back online.',
          icon: <AlertCircle className="w-4 h-4 text-amber-600" />,
        });
      }

      resetForm();
      onClose();
      if (onProductCreated && result.product.id) {
        onProductCreated(result.product.id);
      }
    } catch (err: any) {
      toast.error(err?.message || 'Failed to create product');
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <Modal
      open={open}
      onClose={() => {
        if (!isSubmitting) onClose();
      }}
      title={
        <div className="flex items-center gap-2">
          <PackagePlus className="w-4 h-4 text-primary" />
          <span>Add New Product</span>
        </div>
      }
      size="lg"
    >
      <form onSubmit={handleSubmit} className="space-y-5">
        {/* Basic Information */}
        <div className="space-y-3">
          <h4 className="text-[11px] font-bold text-on-surface-variant uppercase tracking-wider">
            Product Information
          </h4>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
            <div>
              <Input
                label="Product Name *"
                placeholder="e.g. Vitamin C Brightening Serum"
                value={name}
                onChange={(e) => setName(e.target.value)}
                required
              />
            </div>
            <div>
              <Input
                label="SKU (Optional)"
                placeholder="e.g. VCS-001"
                value={sku}
                onChange={(e) => setSku(e.target.value)}
              />
            </div>
          </div>

          {/* Barcode Field with Scan Button */}
          <div>
            <label className="text-xs font-semibold text-on-surface block mb-1">
              Barcode / Barcode Scanner (Optional)
            </label>
            <div className="flex items-center gap-2">
              <input
                type="text"
                placeholder="e.g. 8901234567890 or 5449000000996"
                value={barcode}
                onChange={(e) => setBarcode(e.target.value)}
                className="flex-1 h-9 px-3 border border-outline-variant/80 rounded-lg text-xs font-mono bg-surface text-on-surface focus:outline-none focus:border-primary placeholder:font-sans placeholder:text-on-surface-variant/50"
              />
              <Button
                type="button"
                variant="secondary"
                size="sm"
                onClick={() => setShowScannerModal(true)}
                className="h-9 px-3 text-xs font-medium flex items-center gap-1.5 flex-shrink-0"
                icon={<ScanBarcode className="w-3.5 h-3.5 text-primary" />}
              >
                Scan Barcode
              </Button>
            </div>
            <p className="text-[10px] text-on-surface-variant mt-1">
              Used for instant checkout scanning at the POS. Supports camera or USB/Bluetooth hardware scanners.
            </p>
          </div>

          {/* Hierarchical Multi-Select Categories */}
          <CategorySelector
            selectedCategoryIds={selectedCategoryIds}
            onChange={setSelectedCategoryIds}
          />

          {/* Website Brand Selection */}
          <BrandSelector
            selectedBrandId={selectedBrandId}
            onChange={setSelectedBrandId}
          />
        </div>

        {/* Pricing */}
        <div className="space-y-3">
          <h4 className="text-[11px] font-bold text-on-surface-variant uppercase tracking-wider">
            Pricing ({currency.symbol})
          </h4>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
            <Input
              label={`Regular Price (${currency.symbol}) *`}
              type="number"
              step="any"
              placeholder="e.g. 15000"
              value={regularPrice}
              onChange={(e) => setRegularPrice(e.target.value)}
              required
            />
            <Input
              label={`Sale Price (${currency.symbol})`}
              type="number"
              step="any"
              placeholder="e.g. 12500"
              value={salePrice}
              onChange={(e) => setSalePrice(e.target.value)}
            />
          </div>
        </div>

        {/* Inventory & Status */}
        <div className="space-y-3">
          <h4 className="text-[11px] font-bold text-on-surface-variant uppercase tracking-wider">
            Inventory & Catalog Visibility
          </h4>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
            <div>
              <label className="text-xs font-semibold text-on-surface block mb-1">
                Stock Status
              </label>
              <select
                value={stockStatus}
                onChange={(e) => setStockStatus(e.target.value as StockStatus)}
                className="w-full h-9 px-3 border border-outline-variant/80 rounded-lg text-xs font-medium bg-surface text-on-surface focus:outline-none focus:border-primary cursor-pointer"
              >
                <option value="instock">In stock</option>
                <option value="outofstock">Out of stock</option>
                <option value="onbackorder">On backorder</option>
              </select>
            </div>
            <div>
              <Input
                label="Stock Quantity"
                type="number"
                disabled={!manageStock}
                placeholder="20"
                value={stockQuantity}
                onChange={(e) => setStockQuantity(e.target.value)}
              />
            </div>
            <div>
              <Input
                label="Low Stock Alert Threshold"
                type="number"
                disabled={!manageStock}
                placeholder="5"
                value={lowStockThreshold}
                onChange={(e) => setLowStockThreshold(e.target.value)}
              />
            </div>
          </div>

          <div className="flex flex-wrap items-center gap-6 pt-1">
            <label className="flex items-center gap-2 cursor-pointer text-xs font-medium text-on-surface select-none">
              <input
                type="checkbox"
                checked={manageStock}
                onChange={(e) => setManageStock(e.target.checked)}
                className="rounded border-outline-variant/80 text-primary focus:ring-primary cursor-pointer"
              />
              Track inventory for this product
            </label>

            <div className="flex items-center gap-2 ml-auto">
              <span className="text-xs font-semibold text-on-surface">Catalog Visibility:</span>
              <div className="flex items-center rounded-lg border border-outline-variant/60 p-0.5 bg-surface-container-high">
                <button
                  type="button"
                  onClick={() => setStatus('publish')}
                  className={`px-2.5 py-1 text-xs font-semibold rounded cursor-pointer transition-colors ${
                    status === 'publish'
                      ? 'bg-surface text-primary shadow-xs'
                      : 'text-on-surface-variant hover:text-on-surface'
                  }`}
                >
                  Active (Published)
                </button>
                <button
                  type="button"
                  onClick={() => setStatus('draft')}
                  className={`px-2.5 py-1 text-xs font-semibold rounded cursor-pointer transition-colors ${
                    status === 'draft'
                      ? 'bg-surface text-warning shadow-xs'
                      : 'text-on-surface-variant hover:text-on-surface'
                  }`}
                >
                  Draft
                </button>
              </div>
            </div>
          </div>
        </div>

        {/* Direct Image Upload */}
        <div className="space-y-3">
          <h4 className="text-[11px] font-bold text-on-surface-variant uppercase tracking-wider">
            Media & Description
          </h4>
          <ProductImageUploader
            onImageSelected={setSelectedImageFile}
            onImageRemoved={() => setSelectedImageFile(null)}
          />

          <div>
            <label className="text-xs font-semibold text-on-surface block mb-1">
              Description
            </label>
            <textarea
              rows={3}
              placeholder="Product description for in-store catalogue and website..."
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              className="w-full px-3 py-2 border border-outline-variant/80 rounded-lg text-xs font-normal text-on-surface bg-surface focus:outline-none focus:border-primary resize-none"
            />
          </div>
        </div>

        {/* Modal Actions */}
        <div className="flex items-center justify-end gap-2.5 pt-4 border-t border-outline-variant/60">
          <Button
            type="button"
            variant="secondary"
            size="sm"
            onClick={onClose}
            disabled={isSubmitting}
          >
            Cancel
          </Button>
          <Button
            type="submit"
            variant="primary"
            size="sm"
            loading={isSubmitting}
            icon={<CheckCircle2 className="w-4 h-4" />}
          >
            Create Product
          </Button>
        </div>
      </form>

      {/* Barcode Camera Scanner Modal */}
      <BarcodeScannerModal
        open={showScannerModal}
        onClose={() => setShowScannerModal(false)}
        onScan={(code) => {
          setBarcode(code);
          toast.success(`Barcode detected: ${code}`);
        }}
        title="Scan Product Barcode"
        submitLabel="Use Barcode"
      />
    </Modal>
  );
}
