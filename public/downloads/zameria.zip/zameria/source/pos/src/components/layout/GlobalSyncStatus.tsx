import { useState, useRef, useEffect } from 'react';
import { useSyncStore } from '@/store/syncStore';
import { useConnectionStore } from '@/store/connectionStore';
import { useAuthStore } from '@/store/authStore';
import { syncEngine } from '@/services/woocommerce/syncEngine';
import { historicalSyncService } from '@/services/woocommerce/historicalSyncService';
import { timeAgo, cn } from '@/lib';
import {
  RefreshCw,
  CheckCircle2,
  AlertTriangle,
  WifiOff,
  Package,
  Layers,
  FileText,
  Users,
  Tag,
  Boxes,
  RotateCcw,
  ExternalLink,
} from 'lucide-react';
import { toast } from 'sonner';
import type { SyncEntity } from '@/types';

export function GlobalSyncStatus() {
  const [isOpen, setIsOpen] = useState(false);
  const containerRef = useRef<HTMLDivElement>(null);

  const isSyncing = useSyncStore((s) => s.isSyncing);
  const activeScope = useSyncStore((s) => s.activeScope);
  const currentEntity = useSyncStore((s) => s.currentEntity);
  const lastSyncedAt = useSyncStore((s) => s.lastSyncedAt);
  const lastSyncedByEntity = useSyncStore((s) => s.lastSyncedByEntity);
  const salesReady = useSyncStore((s) => s.salesReady);
  const ordersFreshAt=useSyncStore(s=>s.ordersFreshAt);
  const orderRefreshError=useSyncStore(s=>s.orderRefreshError);
  const ordersReady = useSyncStore((s) => s.ordersReady);
  const failedItems = useSyncStore((s) => s.failedItems);
  const clearFailedItems = useSyncStore((s) => s.clearFailedItems);
  const isOnline = useConnectionStore((s) => s.isOnline);
  const storeName = useConnectionStore((s) => s.storeName);
  const storeUrl = useConnectionStore((s) => s.storeUrl);
  const user = useAuthStore((s) => s.user);

  const [historicalCp, setHistoricalCp] = useState(() => historicalSyncService.getCheckpoint());

  useEffect(() => {
    const interval = setInterval(() => {
      setHistoricalCp(historicalSyncService.getCheckpoint());
    }, 2000);
    return () => clearInterval(interval);
  }, []);

  // Close popover on outside click
  useEffect(() => {
    function handleClickOutside(event: MouseEvent) {
      if (containerRef.current && !containerRef.current.contains(event.target as Node)) {
        setIsOpen(false);
      }
    }
    if (isOpen) {
      document.addEventListener('mousedown', handleClickOutside);
    }
    return () => {
      document.removeEventListener('mousedown', handleClickOutside);
    };
  }, [isOpen]);

  const handleResumeHistoricalSync = async () => {
    try {
      toast.info('Resuming historical data synchronization in background...');
      void historicalSyncService.startHistoricalSync();
      setHistoricalCp(historicalSyncService.getCheckpoint());
    } catch (err: any) {
      toast.error(err?.message || 'Failed to resume historical sync');
    }
  };

  const handleSyncAll = async () => {
    if (isSyncing) return;
    try {
      toast.info('Starting full store synchronization...');
      await syncEngine.sync({ scope: 'full' });
      toast.success('Store fully synchronized with WooCommerce!');
    } catch (err: any) {
      toast.error(err?.message || 'Sync failed');
    }
  };

  const handleRetryFailed = async () => {
    if (isSyncing) return;
    try {
      toast.info('Retrying failed synchronization items...');
      await syncEngine.retryFailed();
      clearFailedItems();
      toast.success('Failed items synchronized successfully!');
    } catch (err: any) {
      toast.error(err?.message || 'Retry failed');
    }
  };

  const entityIcons: Record<SyncEntity, React.ComponentType<{ className?: string }>> = {
    products: Package,
    categories: Layers,
    inventory: Boxes,
    orders: FileText,
    customers: Users,
    coupons: Tag,
  };

  const entityLabels: Record<SyncEntity, string> = {
    products: 'Products',
    categories: 'Categories',
    inventory: 'Inventory Stock',
    orders: 'Orders',
    customers: 'Customers',
    coupons: 'Coupons & Rules',
  };

  const hasIssues = failedItems.length > 0;

  return (
    <div ref={containerRef} className="relative select-none">
      {/* Global Status Chip Button */}
      <button
        type="button"
        onClick={() => setIsOpen(!isOpen)}
        className={cn(
          'h-8 px-2.5 rounded-lg flex items-center gap-1.5 text-xs font-semibold transition-all border cursor-pointer',
          !isOnline
            ? 'bg-amber-500/10 text-amber-700 dark:text-amber-400 border-amber-500/30'
            : isSyncing
            ? 'bg-blue-50 text-blue-700 border-blue-200 shadow-xs'
            : hasIssues
            ? 'bg-warning/10 text-warning border-warning/30 hover:bg-warning/20'
            : 'bg-surface text-on-surface border-outline-variant/60 hover:bg-surface-container-low hover:border-outline'
        )}
        title="View WooCommerce synchronization status"
      >
        {!isOnline ? (
          <>
            <WifiOff className="w-3.5 h-3.5 text-amber-600" />
            <span className="hidden sm:inline">Offline</span>
          </>
        ) : isSyncing ? (
          <>
            <RefreshCw className="w-3.5 h-3.5 animate-spin text-[#60A5FA]" />
            <span className="truncate max-w-[120px]">
              {currentEntity ? `Syncing ${currentEntity}...` : 'Syncing...'}
            </span>
          </>
        ) : hasIssues ? (
          <>
            <AlertTriangle className="w-3.5 h-3.5 text-warning" />
            <span>Sync Issues ({failedItems.length})</span>
          </>
        ) : (
          <>
            <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
            <span className="tabular-nums">
              {lastSyncedAt ? `Synced ${timeAgo(lastSyncedAt)}` : 'Synced'}
            </span>
            <RefreshCw className="w-3 h-3 text-on-surface-variant/60 hover:text-on-surface transition-colors ml-0.5" />
          </>
        )}
      </button>

      {/* Flyout Popover */}
      {isOpen && (
        <div className="absolute right-0 mt-2 w-84 bg-surface border border-outline-variant/80 rounded-2xl shadow-xl z-50 p-4 space-y-3.5 animate-in fade-in slide-in-from-top-1 duration-150">
          {/* Header */}
          <div className="flex items-center justify-between pb-2 border-b border-outline-variant/60">
            <div>
              <h3 className="font-bold text-xs text-on-surface">Store Synchronization</h3>
              <p className="text-[10px] text-on-surface-variant">
                WooCommerce Authoritative Status
              </p>
            </div>
            <span
              className={cn(
                'text-[10px] font-bold px-2 py-0.5 rounded-full border',
                !isOnline
                  ? 'bg-amber-500/10 text-amber-700 border-amber-500/30'
                  : isSyncing
                  ? 'bg-blue-50 text-blue-700 border-blue-200'
                  : 'bg-emerald-50 text-emerald-700 border-emerald-200'
              )}
            >
              {!isOnline ? 'OFFLINE' : isSyncing ? 'SYNCING' : 'HEALTHY'}
            </span>
          </div>

          {/* Sync Progress Banner (when active) */}
          {isSyncing && (
            <div className="p-2.5 rounded-xl bg-blue-50/60 border border-blue-200/60 space-y-1">
              <div className="flex items-center justify-between text-xs font-semibold text-blue-900">
                <span className="flex items-center gap-1.5">
                  <RefreshCw className="w-3 h-3 animate-spin text-[#60A5FA]" />
                  Synchronizing {activeScope || 'store'}...
                </span>
              </div>
              <p className="text-[10px] text-on-surface-variant">
                Communicating with WooCommerce REST API.
              </p>
            </div>
          )}

          {/* Staged POS Readiness & Background Sync Card */}
          <div className="p-2.5 rounded-xl bg-surface-container-low border border-outline-variant/60 space-y-2 text-xs">
            <div className="flex items-center justify-between font-semibold">
              <span className="flex items-center gap-1.5 text-on-surface">
                <CheckCircle2 className={cn('w-3.5 h-3.5', salesReady ? 'text-emerald-500' : 'text-amber-500')} />
                POS Sales Status:
              </span>
              <span className={cn('text-[11px] font-bold', salesReady ? 'text-emerald-600 dark:text-emerald-400' : 'text-amber-600 dark:text-amber-400')}>
                {salesReady ? 'Ready to Sell' : 'Loading Products...'}
              </span>
            </div>

            <div className="flex items-center justify-between font-semibold">
              <span className="flex items-center gap-1.5 text-on-surface">
                <CheckCircle2 className={cn('w-3.5 h-3.5', ordersReady ? 'text-emerald-500' : 'text-blue-500')} />
                Recent Orders:
              </span>
              <span className={cn('text-[11px] font-bold', ordersReady ? 'text-emerald-600 dark:text-emerald-400' : 'text-blue-600 dark:text-blue-400')}>
                {orderRefreshError ? 'Refresh needs retry' : ordersFreshAt ? 'Latest orders checked' : ordersReady ? 'Cached orders available' : 'Loading latest orders…'}
              </span>
            </div>
            
            <div className="pt-1.5 border-t border-outline-variant/40 space-y-1">
              <div className="flex items-center justify-between text-[11px]">
                <span className="text-on-surface-variant">Store History Sync:</span>
                <span className={cn(
                  'font-semibold px-1.5 py-0.5 rounded text-[10px]',
                  historicalCp.status === 'completed'
                    ? 'bg-emerald-500/10 text-emerald-600 dark:text-emerald-400'
                    : historicalCp.status === 'in_progress'
                    ? 'bg-blue-500/10 text-blue-600 dark:text-blue-400'
                    : historicalCp.status === 'error'
                    ? 'bg-rose-500/10 text-rose-600 dark:text-rose-400'
                    : 'bg-surface-container text-on-surface-variant'
                )}>
                  {historicalCp.status === 'completed'
                    ? 'Store fully synced'
                    : historicalCp.status === 'in_progress'
                    ? 'Historical sync in progress'
                    : historicalCp.status === 'error'
                    ? 'Historical sync paused'
                    : 'Recent data ready'}
                </span>
              </div>

              {historicalCp.status === 'in_progress' && (
                <div className="text-[10px] text-on-surface-variant flex items-center justify-between">
                  <span>Streaming orders (Page {historicalCp.lastOrderPage}/{historicalCp.totalOrderPages}):</span>
                  <span className="font-mono">{historicalCp.totalOrdersImported} orders</span>
                </div>
              )}

              {historicalCp.status === 'error' && (
                <div className="flex items-center justify-between pt-1">
                  <span className="text-[10px] text-rose-500 truncate max-w-[170px]">{historicalCp.error || 'Connection paused'}</span>
                  <button
                    type="button"
                    onClick={handleResumeHistoricalSync}
                    className="text-[10px] font-bold text-primary underline cursor-pointer hover:opacity-80"
                  >
                    Resume History
                  </button>
                </div>
              )}
            </div>
          </div>

          {/* Per-Entity Status Breakdown */}
          <div className="space-y-1.5">
            <div className="text-[10px] uppercase font-bold tracking-wider text-on-surface-variant/70 px-1">
              Entity Sync Status
            </div>

            {(['products', 'inventory', 'orders', 'customers', 'coupons', 'categories'] as SyncEntity[]).map((ent) => {
              const Icon = entityIcons[ent];
              const lastSynced = lastSyncedByEntity[ent];

              return (
                <div
                  key={ent}
                  className="flex items-center justify-between p-1.5 px-2 rounded-lg bg-surface-container-low hover:bg-surface-container transition-colors"
                >
                  <div className="flex items-center gap-2">
                    <Icon className="w-3.5 h-3.5 text-on-surface-variant" />
                    <span className="font-semibold text-on-surface">{entityLabels[ent]}</span>
                  </div>

                  <div className="flex items-center gap-1.5 text-[11px] tabular-nums">
                    {lastSynced ? (
                      <span className="text-on-surface-variant/70">{timeAgo(lastSynced)}</span>
                    ) : (
                      <span className="text-on-surface-variant/40">Never</span>
                    )}
                    <CheckCircle2 className="w-3.5 h-3.5 text-success flex-shrink-0" />
                  </div>
                </div>
              );
            })}
          </div>

          {/* Failed Items Warning Section */}
          {hasIssues && (
            <div className="p-2.5 rounded-xl bg-warning/10 border border-warning/30 space-y-2">
              <div className="flex items-center justify-between text-warning font-semibold text-xs">
                <span className="flex items-center gap-1.5">
                  <AlertTriangle className="w-3.5 h-3.5" />
                  {failedItems.length} Sync {failedItems.length === 1 ? 'Issue' : 'Issues'}
                </span>
                <button
                  type="button"
                  onClick={handleRetryFailed}
                  disabled={isSyncing}
                  className="text-[10px] uppercase font-bold underline cursor-pointer hover:text-on-surface"
                >
                  Retry All
                </button>
              </div>

              <div className="max-h-24 overflow-y-auto space-y-1 text-[11px] text-on-surface-variant">
                {failedItems.map((f) => (
                  <div key={f.id} className="truncate">
                    &bull; <strong className="text-on-surface capitalize">{f.entity}:</strong> {f.error}
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Footer Actions */}
          <div className="pt-2 border-t border-outline-variant/60 flex items-center justify-between gap-2">
            <div className="text-[10px] text-on-surface-variant/70">
              Last Full Sync: {lastSyncedAt ? timeAgo(lastSyncedAt) : 'None'}
            </div>

            <button
              type="button"
              onClick={handleSyncAll}
              disabled={isSyncing || !isOnline}
              className={cn(
                'h-8 px-3 rounded-lg text-xs font-semibold flex items-center gap-1.5 cursor-pointer transition-colors shadow-xs',
                'bg-[#071A31] text-white hover:bg-[#0C2340] active:bg-[#040E1B] disabled:opacity-50'
              )}
            >
              <RefreshCw className={cn('w-3.5 h-3.5', isSyncing && 'animate-spin')} />
              <span>Sync All</span>
            </button>
          </div>
        </div>
      )}
    </div>
  );
}
