import React from 'react';
import { cn } from '@/lib';
import { Globe, Store, Check, Clock, AlertCircle, XCircle } from 'lucide-react';

export type BadgeVariant =
  | 'neutral'
  | 'brand'
  | 'primary'
  | 'success'
  | 'warning'
  | 'danger'
  | 'info'
  | 'completed'
  | 'processing'
  | 'on-hold'
  | 'cancelled'
  | 'refunded'
  | 'failed'
  | 'pending'
  | 'synced'
  | 'offline';

export interface BadgeProps extends React.HTMLAttributes<HTMLSpanElement> {
  variant?: BadgeVariant;
  size?: 'sm' | 'md';
  dot?: boolean;
  icon?: React.ReactNode;
  children: React.ReactNode;
}

const variantStyles: Record<BadgeVariant, string> = {
  neutral:
    'bg-surface-200 dark:bg-surface-200 text-surface-700 dark:text-surface-600 border border-surface-300/60 dark:border-surface-300/40',
  brand:
    'bg-blue-50 dark:bg-[#0C2340] text-[#071A31] dark:text-[#60A5FA] border border-blue-200/80 dark:border-blue-900/60',
  primary:
    'bg-primary-container text-on-primary-container border border-primary/20',
  success:
    'bg-emerald-50 dark:bg-emerald-950/40 text-emerald-700 dark:text-emerald-300 border border-emerald-200/80 dark:border-emerald-900/60',
  warning:
    'bg-amber-50 dark:bg-amber-950/40 text-amber-800 dark:text-amber-300 border border-amber-200/80 dark:border-amber-900/60',
  danger:
    'bg-rose-50 dark:bg-rose-950/40 text-rose-700 dark:text-rose-300 border border-rose-200/80 dark:border-rose-900/60',
  info:
    'bg-sky-50 dark:bg-sky-950/40 text-sky-700 dark:text-sky-300 border border-sky-200/80 dark:border-sky-900/60',
  completed:
    'bg-emerald-50 dark:bg-emerald-950/40 text-emerald-700 dark:text-emerald-300 border border-emerald-200/80 dark:border-emerald-900/60',
  processing:
    'bg-blue-50 dark:bg-blue-950/40 text-blue-700 dark:text-blue-300 border border-blue-200/80 dark:border-blue-900/60',
  'on-hold':
    'bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 border border-slate-200 dark:border-slate-700',
  cancelled:
    'bg-rose-50 dark:bg-rose-950/40 text-rose-700 dark:text-rose-300 border border-rose-200/80 dark:border-rose-900/60',
  refunded:
    'bg-purple-50 dark:bg-purple-950/40 text-purple-700 dark:text-purple-300 border border-purple-200/80 dark:border-purple-900/60',
  failed:
    'bg-rose-50 dark:bg-rose-950/40 text-rose-700 dark:text-rose-300 border border-rose-200/80 dark:border-rose-900/60',
  pending:
    'bg-surface-100 dark:bg-surface-200/60 text-surface-600 dark:text-surface-500 border border-surface-200 dark:border-surface-300/40',
  synced:
    'bg-emerald-50 dark:bg-emerald-950/40 text-emerald-700 dark:text-emerald-300 border border-emerald-200/80 dark:border-emerald-900/60',
  offline:
    'bg-amber-50 dark:bg-amber-950/40 text-amber-800 dark:text-amber-300 border border-amber-200/80 dark:border-amber-900/60',
};

const dotColors: Record<BadgeVariant, string> = {
  neutral: 'bg-surface-400',
  brand: 'bg-[#60A5FA]',
  primary: 'bg-primary',
  success: 'bg-emerald-500',
  warning: 'bg-amber-500',
  danger: 'bg-rose-500',
  info: 'bg-sky-500',
  completed: 'bg-emerald-500',
  processing: 'bg-blue-500',
  'on-hold': 'bg-amber-500',
  cancelled: 'bg-rose-500',
  refunded: 'bg-purple-500',
  failed: 'bg-rose-500',
  pending: 'bg-surface-400',
  synced: 'bg-emerald-500',
  offline: 'bg-amber-500',
};

export function Badge({
  variant = 'neutral',
  size = 'sm',
  dot = false,
  icon,
  className,
  children,
  ...props
}: BadgeProps) {
  return (
    <span
      className={cn(
        'inline-flex items-center gap-1.5 font-semibold rounded-full select-none uppercase tracking-wider',
        size === 'sm' ? 'px-2 py-0.5 text-[10px]' : 'px-2.5 py-1 text-xs',
        variantStyles[variant],
        className
      )}
      {...props}
    >
      {dot && <span className={cn('w-1.5 h-1.5 rounded-full flex-shrink-0', dotColors[variant])} />}
      {icon && <span className="flex-shrink-0">{icon}</span>}
      <span>{children}</span>
    </span>
  );
}

export function ChannelBadge({ source, className }: { source: 'website' | 'pos' | string; className?: string }) {
  const isWeb = source === 'website';
  return (
    <span
      className={cn(
        'inline-flex items-center gap-1 px-2 py-0.5 rounded text-[10px] font-bold tracking-wider uppercase select-none border',
        isWeb
          ? 'bg-slate-100 dark:bg-slate-800 text-[#071A31] dark:text-slate-100 border-slate-200 dark:border-slate-700'
          : 'bg-blue-50 dark:bg-[#0C2340] text-[#071A31] dark:text-[#60A5FA] border-blue-200/80 dark:border-blue-900/60',
        className
      )}
    >
      {isWeb ? <Globe className="w-3 h-3 flex-shrink-0" /> : <Store className="w-3 h-3 flex-shrink-0" />}
      <span>{isWeb ? 'Website' : 'Physical POS'}</span>
    </span>
  );
}
