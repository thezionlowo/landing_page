import React, { useRef, useState, useEffect } from 'react';
import { UploadCloud, RefreshCw, Trash2, Image as ImageIcon, AlertCircle } from 'lucide-react';
import { toast } from 'sonner';
import { cn } from '@/lib';

interface ProductImageUploaderProps {
  currentImageUrl?: string | null;
  onImageSelected: (file: File | null) => void;
  onImageRemoved: () => void;
  disabled?: boolean;
}

const ALLOWED_TYPES = ['image/jpeg', 'image/png', 'image/webp', 'image/jpg'];
const MAX_FILE_SIZE_BYTES = 5 * 1024 * 1024; // 5MB

export function ProductImageUploader({
  currentImageUrl,
  onImageSelected,
  onImageRemoved,
  disabled = false,
}: ProductImageUploaderProps) {
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [previewUrl, setPreviewUrl] = useState<string | null>(currentImageUrl || null);
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const [isDragOver, setIsDragOver] = useState(false);

  // Clean up object URLs on unmount or before new preview creation
  useEffect(() => {
    return () => {
      if (previewUrl && previewUrl.startsWith('blob:')) {
        URL.revokeObjectURL(previewUrl);
      }
    };
  }, [previewUrl]);

  // Sync preview whenever currentImageUrl changes externally or on product change
  useEffect(() => {
    if (previewUrl && previewUrl.startsWith('blob:')) {
      URL.revokeObjectURL(previewUrl);
    }
    setSelectedFile(null);
    setPreviewUrl(currentImageUrl || null);
    if (fileInputRef.current) {
      fileInputRef.current.value = '';
    }
  }, [currentImageUrl]);

  const validateAndProcessFile = (file: File) => {
    if (!ALLOWED_TYPES.includes(file.type.toLowerCase())) {
      toast.error('Unsupported image format. Please select a JPG, PNG, or WEBP image.');
      return;
    }

    if (file.size > MAX_FILE_SIZE_BYTES) {
      toast.error(`Image is too large (${(file.size / (1024 * 1024)).toFixed(1)}MB). Maximum allowed size is 5MB.`);
      return;
    }

    // Clean up previous blob preview if any
    if (previewUrl && previewUrl.startsWith('blob:')) {
      URL.revokeObjectURL(previewUrl);
    }

    const objectUrl = URL.createObjectURL(file);
    setSelectedFile(file);
    setPreviewUrl(objectUrl);
    onImageSelected(file);
    toast.success(`Image "${file.name}" ready for upload`);
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      validateAndProcessFile(file);
    }
    // Reset file input so re-selecting same file triggers change
    if (fileInputRef.current) {
      fileInputRef.current.value = '';
    }
  };

  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault();
    if (!disabled) setIsDragOver(true);
  };

  const handleDragLeave = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragOver(false);
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragOver(false);
    if (disabled) return;

    const file = e.dataTransfer.files?.[0];
    if (file) {
      validateAndProcessFile(file);
    }
  };

  const handleRemove = () => {
    if (previewUrl && previewUrl.startsWith('blob:')) {
      URL.revokeObjectURL(previewUrl);
    }
    setSelectedFile(null);
    setPreviewUrl(null);
    onImageSelected(null);
    onImageRemoved();
    if (fileInputRef.current) {
      fileInputRef.current.value = '';
    }
    toast.info('Product image removed');
  };

  return (
    <div className="space-y-2">
      <label className="text-xs font-semibold text-on-surface block">
        Product Image
      </label>

      <input
        ref={fileInputRef}
        type="file"
        accept="image/jpeg,image/png,image/webp,image/jpg"
        disabled={disabled}
        onChange={handleFileChange}
        className="hidden"
      />

      {!previewUrl ? (
        /* Empty Upload Dropzone */
        <div
          role="button"
          tabIndex={disabled ? -1 : 0}
          onClick={() => !disabled && fileInputRef.current?.click()}
          onKeyDown={(e) => {
            if (!disabled && (e.key === 'Enter' || e.key === ' ')) {
              e.preventDefault();
              fileInputRef.current?.click();
            }
          }}
          onDragOver={handleDragOver}
          onDragLeave={handleDragLeave}
          onDrop={handleDrop}
          className={cn(
            'border-2 border-dashed rounded-2xl p-6 text-center transition-all flex flex-col items-center justify-center gap-2 select-none group',
            disabled
              ? 'bg-surface-container-high border-outline-variant/40 cursor-not-allowed opacity-50'
              : isDragOver
              ? 'border-primary bg-primary-container/20 cursor-pointer scale-[0.99]'
              : 'border-outline-variant/80 hover:border-primary bg-surface-container-low/50 hover:bg-primary-container/10 cursor-pointer'
          )}
        >
          <div className="w-12 h-12 rounded-full bg-surface-container-high group-hover:bg-primary-container flex items-center justify-center text-on-surface-variant group-hover:text-primary transition-colors">
            <UploadCloud className="w-6 h-6" />
          </div>
          <div>
            <p className="text-xs font-bold text-on-surface group-hover:text-primary transition-colors">
              + Upload Product Image
            </p>
            <p className="text-[11px] text-on-surface-variant mt-0.5">
              Select image from device or drag and drop
            </p>
          </div>
          <span className="text-[10px] font-semibold text-on-surface-variant uppercase tracking-wider bg-surface-container-high px-2 py-0.5 rounded-md border border-outline-variant/40">
            JPG, PNG, WEBP (Max 5MB)
          </span>
        </div>
      ) : (
        /* Image Preview with Change/Remove Actions */
        <div className="m3-card-outlined rounded-xl bg-surface p-3.5 flex items-center gap-4">
          <div className="w-20 h-20 rounded-lg overflow-hidden border border-outline-variant/60 bg-surface-container-high flex-shrink-0 flex items-center justify-center relative shadow-2xs">
            <img
              src={previewUrl}
              alt="Product Preview"
              className="w-full h-full object-cover"
              onError={() => {
                setPreviewUrl(null);
                toast.error('Unable to display image preview');
              }}
            />
          </div>

          <div className="flex-1 min-w-0 space-y-1">
            <div className="flex items-center gap-2">
              <span className="text-xs font-bold text-on-surface truncate">
                {selectedFile ? selectedFile.name : 'Current Product Image'}
              </span>
              {selectedFile && (
                <span className="text-[9px] font-bold px-1.5 py-0.5 bg-success/15 text-success rounded-md">
                  New
                </span>
              )}
            </div>

            <p className="text-[11px] text-on-surface-variant">
              {selectedFile
                ? `${(selectedFile.size / 1024).toFixed(1)} KB · Ready to sync with website`
                : 'Synchronized with WooCommerce'}
            </p>

            {!disabled && (
              <div className="flex items-center gap-3 pt-1.5">
                <button
                  type="button"
                  onClick={() => fileInputRef.current?.click()}
                  className="inline-flex items-center gap-1 text-xs font-semibold text-primary hover:underline cursor-pointer transition-colors"
                >
                  <RefreshCw className="w-3 h-3" />
                  Change Image
                </button>
                <span className="text-outline-variant">·</span>
                <button
                  type="button"
                  onClick={handleRemove}
                  className="inline-flex items-center gap-1 text-xs font-semibold text-error hover:underline cursor-pointer transition-colors"
                >
                  <Trash2 className="w-3 h-3" />
                  Remove
                </button>
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );
}
