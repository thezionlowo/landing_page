import { useState, useEffect } from 'react';
import { NavLink, useLocation, useNavigate } from 'react-router';
import { useUIStore, useSyncStore, useConnectionStore, useCartStore, useAuthStore } from '@/store';
import { useLiveQuery } from 'dexie-react-hooks';
import { db } from '@/db';
import { cn } from '@/lib';
import { Modal, Button } from '@/components/ui';
import type { RolePermissions, ZameriaRole } from '@/types/auth';
import { isOrderAccessibleToUser } from '@/services/auth/orderAccess';
import { supportChatClient } from '@/services/supportChatClient';
import {
  Plus,
  LayoutDashboard,
  ShoppingCart,
  FileText,
  Users,
  Package,
  Settings,
  Headphones,
  ChevronLeft,
  ChevronRight,
  Wifi,
  WifiOff,
  ShieldCheck,
  Briefcase,
  Receipt,
  Lock,
  LogOut,
  RefreshCw,
  CheckCircle2,
  XCircle,
} from 'lucide-react';
import { toast } from 'sonner';

export function Sidebar() {
  const navigate = useNavigate();
  const location = useLocation();

  const { sidebarCollapsed, toggleSidebar } = useUIStore();
  const { pendingCount } = useSyncStore();
  const { isOnline } = useConnectionStore();
  const cart = useCartStore();

  const { user, hasPermission, logout, revalidate } = useAuthStore();

  const [showSaveModal, setShowSaveModal] = useState(false);
  const [showUserModal, setShowUserModal] = useState(false);
  const [isRevalidating, setIsRevalidating] = useState(false);

  // Live query for incomplete / on-hold orders accessible to this user
  const incompleteCount =
    useLiveQuery(
      async () => {
        const orders = await db.orders.where('status').anyOf('on-hold', 'pending').toArray();
        return orders.filter((o) => isOrderAccessibleToUser(o, user)).length;
      },
      [user]
    ) || 0;

  const totalOrdersBadge = pendingCount + incompleteCount;

  const handleNewOrderClick = () => {
    if (cart.items.length > 0) {
      setShowSaveModal(true);
    } else {
      navigate('/sale');
    }
  };

  const handleSaveAndNew = async () => {
    await cart.saveAsOnHold();
    setShowSaveModal(false);
    navigate('/sale');
  };

  const handleDiscardAndNew = async () => {
    await cart.clearCart();
    setShowSaveModal(false);
    navigate('/sale');
  };

  const handleRevalidateSession = async () => {
    setIsRevalidating(true);
    try {
      await revalidate();
      toast.success('WooCommerce permissions revalidated successfully!', {
        description: 'Role and capabilities are up-to-date with your store.',
      });
    } catch (err: any) {
      toast.error(err.message || 'Failed to revalidate session with WooCommerce.');
    } finally {
      setIsRevalidating(false);
    }
  };

  const handleLogout = () => {
    logout();
    setShowUserModal(false);
    toast.info('Signed out of POS.');
    navigate('/login');
  };

  const { isSupportChatOpen, toggleSupportChat } = useUIStore();
  const [unreadSupportCount, setUnreadSupportCount] = useState(() => supportChatClient.getUnreadCount());

  useEffect(() => {
    const updateUnread = () => {
      setUnreadSupportCount(supportChatClient.getUnreadCount());
    };
    updateUnread();
    window.addEventListener('zameria_support_update', updateUnread);
    return () => window.removeEventListener('zameria_support_update', updateUnread);
  }, []);

  interface NavItem {
    path?: string;
    label: string;
    icon: React.ComponentType<{ className?: string }>;
    permission?: keyof RolePermissions;
    badge?: number;
    action?: () => void;
  }

  const navItems: NavItem[] = [
    { path: '/dashboard', label: 'Dashboard', icon: LayoutDashboard, permission: 'canAccessDashboard' },
    { path: '/sale', label: 'Sale', icon: ShoppingCart, permission: 'canAccessSale' },
    { path: '/orders', label: 'Orders', icon: FileText, badge: totalOrdersBadge, permission: 'canAccessOrders' },
    { path: '/customers', label: 'Customers', icon: Users, permission: 'canAccessCustomers' },
    { path: '/products', label: 'Products', icon: Package, permission: 'canAccessProducts' },
    { path: '/settings', label: 'Settings', icon: Settings, permission: 'canAccessSettings' },
    {
      label: 'Support',
      icon: Headphones,
      action: () => toggleSupportChat(),
      badge: unreadSupportCount > 0 ? unreadSupportCount : undefined,
    },
  ];

  // Dynamically filter navigation tiles by resolved WooCommerce permissions (zero POS access for non-POS roles)
  const allowedNavItems = hasPermission('canAccessPOS')
    ? navItems.filter((item) => !item.permission || hasPermission(item.permission))
    : [];

  const roleStyles: Record<ZameriaRole, { bg: string; text: string; border: string; icon: any }> = {
    administrator: {
      bg: 'bg-emerald-500/10',
      text: 'text-emerald-700 dark:text-emerald-400',
      border: 'border-emerald-500/30',
      icon: ShieldCheck,
    },
    shop_manager: {
      bg: 'bg-blue-500/10',
      text: 'text-blue-700 dark:text-blue-400',
      border: 'border-blue-500/30',
      icon: Briefcase,
    },
    cashier: {
      bg: 'bg-amber-500/10',
      text: 'text-amber-700 dark:text-amber-400',
      border: 'border-amber-500/30',
      icon: Receipt,
    },
    restricted: {
      bg: 'bg-purple-500/10',
      text: 'text-purple-700 dark:text-purple-400',
      border: 'border-purple-500/30',
      icon: Lock,
    },
  };

  const userRole: ZameriaRole = user?.role || 'restricted';
  const roleStyle = roleStyles[userRole];
  const RoleIcon = roleStyle.icon;
  const canStartSale = hasPermission('canAccessPOS') && hasPermission('canAccessSale');

  return (
    <>
      <aside className="pos-sidebar hidden md:flex" data-collapsed={sidebarCollapsed} aria-label="Workspace sidebar">
        <div className="pos-sidebar-brand"><img src="zameria-logo.png" alt="ZAMERIA" /><div className="pos-sidebar-copy"><strong>ZAMERIA</strong><span>Point of sale</span></div></div>
        {canStartSale && <div className="pos-sidebar-new"><button type="button" onClick={handleNewOrderClick} title="New Order" className="pos-new-sale"><Plus className="w-5 h-5" /><span className="pos-sidebar-copy">New sale</span></button></div>}
        <nav className="pos-sidebar-navigation" aria-label="Main navigation">
          {allowedNavItems.map(item => {
            const Icon = item.icon;
            const active = item.path ? location.pathname === item.path || (item.path === '/sale' && location.pathname === '/') : isSupportChatOpen;
            const content = <><Icon className="w-5 h-5 shrink-0" /><span className="pos-sidebar-copy">{item.label}</span>{Boolean(item.badge && item.badge > 0) && <span className="pos-nav-count">{item.badge! > 99 ? '99+' : item.badge}</span>}</>;
            return item.action ? <button key={item.label} type="button" onClick={item.action} title={item.label} aria-pressed={active} className={cn('pos-nav-item',active && 'is-active')}>{content}</button> : <NavLink key={item.path} to={item.path!} title={item.label} aria-label={item.label} className={cn('pos-nav-item',active && 'is-active')}>{content}</NavLink>;
          })}
        </nav>
        <div className="pos-sidebar-footer">
          <div className="pos-sidebar-connection">{isOnline ? <Wifi className="w-4 h-4" /> : <WifiOff className="w-4 h-4" />}<span className="pos-sidebar-copy">{isOnline ? 'Store connected' : 'Working offline'}</span></div>
          {user && <button type="button" onClick={()=>setShowUserModal(true)} title={`${user.displayName} · Staff account`} aria-label="Open staff account" className="pos-sidebar-account"><div className="pos-account-avatar">{user.displayName?.slice(0,1) || 'Z'}</div><div className="pos-sidebar-copy min-w-0 text-left"><strong className="block truncate">{user.displayName}</strong><span>{userRole === 'shop_manager' ? 'Manager' : userRole === 'administrator' ? 'Administrator' : userRole}</span></div></button>}
          <button type="button" onClick={toggleSidebar} className="pos-sidebar-collapse" title={sidebarCollapsed ? 'Expand sidebar' : 'Collapse sidebar'} aria-label={sidebarCollapsed ? 'Expand sidebar' : 'Collapse sidebar'}>{sidebarCollapsed ? <ChevronRight className="w-4 h-4" /> : <ChevronLeft className="w-4 h-4" />}<span className="pos-sidebar-copy">Collapse sidebar</span></button>
        </div>
      </aside>

      {/* USER & WOOCOMMERCE ROLE DETAILS MODAL */}
      <Modal
        open={showUserModal}
        onClose={() => setShowUserModal(false)}
        title="WOOCOMMERCE STAFF ACCOUNT"
        size="md"
      >
        {user && (
          <div className="space-y-4">
            {/* User Profile Header */}
            <div className="flex items-start gap-3 p-3.5 rounded-xl bg-surface-50 border border-surface-200">
              <div
                className={cn(
                  'w-12 h-12 rounded-xl flex items-center justify-center border text-lg font-bold flex-shrink-0 shadow-sm',
                  roleStyle.bg,
                  roleStyle.text,
                  roleStyle.border
                )}
              >
                <RoleIcon className="w-6 h-6" />
              </div>
              <div className="flex-1 min-w-0">
                <div className="flex items-center justify-between gap-2">
                  <h3 className="text-sm font-bold text-surface-900 truncate">{user.displayName}</h3>
                  <span
                    className={cn(
                      'text-[10px] uppercase font-bold tracking-wider px-2 py-0.5 rounded border',
                      roleStyle.bg,
                      roleStyle.text,
                      roleStyle.border
                    )}
                  >
                    {userRole.replace('_', ' ').toUpperCase()}
                  </span>
                </div>
                <p className="text-xs text-surface-500 font-mono mt-0.5">@{user.username} &bull; {user.email}</p>
                <div className="flex items-center gap-1.5 mt-2 text-[11px] text-surface-600">
                  <span className="w-2 h-2 rounded-full bg-emerald-500" />
                  <span>Store: <strong className="text-surface-800">{user.storeName}</strong></span>
                </div>
              </div>
            </div>

            {/* Permissions Matrix Overview */}
            <div>
              <h4 className="text-xs font-semibold text-surface-700 uppercase tracking-wider mb-2">
                Resolved Store Capabilities
              </h4>
              <div className="grid grid-cols-2 gap-2 text-xs">
                <div className="p-2.5 rounded-lg bg-surface-50 border border-surface-200 flex items-center gap-2">
                  {hasPermission('canAccessSale') ? (
                    <CheckCircle2 className="w-4 h-4 text-emerald-600 flex-shrink-0" />
                  ) : (
                    <XCircle className="w-4 h-4 text-red-500 flex-shrink-0" />
                  )}
                  <span className="truncate">POS Sale &amp; Barcode</span>
                </div>

                <div className="p-2.5 rounded-lg bg-surface-50 border border-surface-200 flex items-center gap-2">
                  {hasPermission('canCreateProduct') ? (
                    <CheckCircle2 className="w-4 h-4 text-emerald-600 flex-shrink-0" />
                  ) : (
                    <XCircle className="w-4 h-4 text-red-500 flex-shrink-0" />
                  )}
                  <span className="truncate">Create Products</span>
                </div>

                <div className="p-2.5 rounded-lg bg-surface-50 border border-surface-200 flex items-center gap-2">
                  {hasPermission('canEditProductPrice') ? (
                    <CheckCircle2 className="w-4 h-4 text-emerald-600 flex-shrink-0" />
                  ) : (
                    <XCircle className="w-4 h-4 text-red-500 flex-shrink-0" />
                  )}
                  <span className="truncate">Modify Prices</span>
                </div>

                <div className="p-2.5 rounded-lg bg-surface-50 border border-surface-200 flex items-center gap-2">
                  {hasPermission('canEditStockManually') ? (
                    <CheckCircle2 className="w-4 h-4 text-emerald-600 flex-shrink-0" />
                  ) : (
                    <XCircle className="w-4 h-4 text-red-500 flex-shrink-0" />
                  )}
                  <span className="truncate">Manual Stock Edit</span>
                </div>

                <div className="p-2.5 rounded-lg bg-surface-50 border border-surface-200 flex items-center gap-2">
                  {hasPermission('canManageWooConnection') ? (
                    <CheckCircle2 className="w-4 h-4 text-emerald-600 flex-shrink-0" />
                  ) : (
                    <XCircle className="w-4 h-4 text-red-500 flex-shrink-0" />
                  )}
                  <span className="truncate">Store API Settings</span>
                </div>

                <div className="p-2.5 rounded-lg bg-surface-50 border border-surface-200 flex items-center gap-2">
                  {hasPermission('canManageStaff') ? (
                    <CheckCircle2 className="w-4 h-4 text-emerald-600 flex-shrink-0" />
                  ) : (
                    <XCircle className="w-4 h-4 text-red-500 flex-shrink-0" />
                  )}
                  <span className="truncate">Staff Management</span>
                </div>
              </div>
            </div>

            {/* Session Revalidation & Sign Out Actions */}
            <div className="pt-2 border-t border-surface-200 flex flex-col sm:flex-row gap-2 justify-between items-center">
              <Button
                variant="secondary"
                size="sm"
                onClick={handleRevalidateSession}
                disabled={isRevalidating}
                className="w-full sm:w-auto flex items-center gap-1.5 text-xs"
              >
                <RefreshCw className={cn('w-3.5 h-3.5', isRevalidating && 'animate-spin')} />
                Revalidate WooCommerce Session
              </Button>

              <div className="flex items-center gap-2 w-full sm:w-auto justify-end">
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={() => setShowUserModal(false)}
                  className="text-xs"
                >
                  Close
                </Button>
                <Button
                  variant="destructive"
                  size="sm"
                  onClick={handleLogout}
                  className="text-xs flex items-center gap-1.5"
                >
                  <LogOut className="w-3.5 h-3.5" />
                  Sign Out
                </Button>
              </div>
            </div>
          </div>
        )}
      </Modal>

      {/* SAVE ACTIVE ORDER Modal (Screenshot 3 Pattern) */}
      <Modal
        open={showSaveModal}
        onClose={() => setShowSaveModal(false)}
        title="SAVE ACTIVE ORDER"
        size="sm"
      >
        <div className="space-y-4">
          <p className="text-xs text-surface-600 leading-relaxed">
            Do you want to save the active order before continuing with this order?
          </p>
          <div className="flex justify-end gap-2 pt-2">
            <Button variant="ghost" size="sm" onClick={() => setShowSaveModal(false)}>
              Cancel
            </Button>
            <Button variant="secondary" size="sm" onClick={handleDiscardAndNew}>
              No
            </Button>
            <Button variant="primary" size="sm" onClick={handleSaveAndNew}>
              Yes
            </Button>
          </div>
        </div>
      </Modal>
    </>
  );
}
