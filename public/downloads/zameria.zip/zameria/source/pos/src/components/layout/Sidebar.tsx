import { useState, useEffect } from 'react';
import { NavLink, useLocation, useNavigate } from 'react-router';
import { useUIStore, useSyncStore, useConnectionStore, useCartStore, useAuthStore } from '@/store';
import { useLiveQuery } from 'dexie-react-hooks';
import { db } from '@/db';
import { cn } from '@/lib';
import { Modal, Button } from '@/components/ui';
import type { RolePermissions, ZameriaRole } from '@/types/auth';
import { isOrderAccessibleToUser } from '@/services/auth/orderAccess';
import { supportChatClient } from '@/services/supportChatClient';
import {
  Plus,
  LayoutDashboard,
  ShoppingCart,
  FileText,
  Users,
  Package,
  Settings,
  Headphones,
  ChevronLeft,
  ChevronRight,
  Wifi,
  WifiOff,
  Loader2,
  ShieldCheck,
  Briefcase,
  Receipt,
  Lock,
  LogOut,
  RefreshCw,
  CheckCircle2,
  XCircle,
} from 'lucide-react';
import { toast } from 'sonner';

export function Sidebar() {
  const navigate = useNavigate();
  const location = useLocation();

  const { sidebarCollapsed, toggleSidebar } = useUIStore();
  const { pendingCount } = useSyncStore();
  const { isOnline } = useConnectionStore();
  const cart = useCartStore();

  const { user, hasPermission, logout, revalidate } = useAuthStore();

  const [showSaveModal, setShowSaveModal] = useState(false);
  const [showUserModal, setShowUserModal] = useState(false);
  const [isRevalidating, setIsRevalidating] = useState(false);

  // Live query for incomplete / on-hold orders accessible to this user
  const incompleteCount =
    useLiveQuery(
      async () => {
        const orders = await db.orders.where('status').anyOf('on-hold', 'pending').toArray();
        return orders.filter((o) => isOrderAccessibleToUser(o, user)).length;
      },
      [user]
    ) || 0;

  const totalOrdersBadge = pendingCount + incompleteCount;

  const handleNewOrderClick = () => {
    if (cart.items.length > 0) {
      setShowSaveModal(true);
    } else {
      navigate('/sale');
    }
  };

  const handleSaveAndNew = async () => {
    await cart.saveAsOnHold();
    setShowSaveModal(false);
    navigate('/sale');
  };

  const handleDiscardAndNew = async () => {
    await cart.clearCart();
    setShowSaveModal(false);
    navigate('/sale');
  };

  const handleRevalidateSession = async () => {
    setIsRevalidating(true);
    try {
      await revalidate();
      toast.success('WooCommerce permissions revalidated successfully!', {
        description: 'Role and capabilities are up-to-date with your store.',
      });
    } catch (err: any) {
      toast.error(err.message || 'Failed to revalidate session with WooCommerce.');
    } finally {
      setIsRevalidating(false);
    }
  };

  const handleLogout = () => {
    logout();
    setShowUserModal(false);
    toast.info('Signed out of POS.');
    navigate('/login');
  };

  const { isSupportChatOpen, toggleSupportChat } = useUIStore();
  const [unreadSupportCount, setUnreadSupportCount] = useState(() => supportChatClient.getUnreadCount());

  useEffect(() => {
    const updateUnread = () => {
      setUnreadSupportCount(supportChatClient.getUnreadCount());
    };
    updateUnread();
    window.addEventListener('zameria_support_update', updateUnread);
    return () => window.removeEventListener('zameria_support_update', updateUnread);
  }, []);

  interface NavItem {
    path?: string;
    label: string;
    icon: React.ComponentType<{ className?: string }>;
    permission?: keyof RolePermissions;
    badge?: number;
    action?: () => void;
  }

  const navItems: NavItem[] = [
    { path: '/dashboard', label: 'Dashboard', icon: LayoutDashboard, permission: 'canAccessDashboard' },
    { path: '/sale', label: 'Sale', icon: ShoppingCart, permission: 'canAccessSale' },
    { path: '/orders', label: 'Orders', icon: FileText, badge: totalOrdersBadge, permission: 'canAccessOrders' },
    { path: '/customers', label: 'Customers', icon: Users, permission: 'canAccessCustomers' },
    { path: '/products', label: 'Products', icon: Package, permission: 'canAccessProducts' },
    { path: '/settings', label: 'Settings', icon: Settings, permission: 'canAccessSettings' },
    {
      label: 'Support',
      icon: Headphones,
      action: () => toggleSupportChat(),
      badge: unreadSupportCount > 0 ? unreadSupportCount : undefined,
    },
  ];

  // Dynamically filter navigation tiles by resolved WooCommerce permissions (zero POS access for non-POS roles)
  const allowedNavItems = hasPermission('canAccessPOS')
    ? navItems.filter((item) => !item.permission || hasPermission(item.permission))
    : [];

  const roleStyles: Record<ZameriaRole, { bg: string; text: string; border: string; icon: any }> = {
    administrator: {
      bg: 'bg-emerald-500/10',
      text: 'text-emerald-700 dark:text-emerald-400',
      border: 'border-emerald-500/30',
      icon: ShieldCheck,
    },
    shop_manager: {
      bg: 'bg-blue-500/10',
      text: 'text-blue-700 dark:text-blue-400',
      border: 'border-blue-500/30',
      icon: Briefcase,
    },
    cashier: {
      bg: 'bg-amber-500/10',
      text: 'text-amber-700 dark:text-amber-400',
      border: 'border-amber-500/30',
      icon: Receipt,
    },
    restricted: {
      bg: 'bg-purple-500/10',
      text: 'text-purple-700 dark:text-purple-400',
      border: 'border-purple-500/30',
      icon: Lock,
    },
  };

  const userRole: ZameriaRole = user?.role || 'restricted';
  const roleStyle = roleStyles[userRole];
  const RoleIcon = roleStyle.icon;
  const canAccessPOS = hasPermission('canAccessPOS');

  return (
    <>
      <aside
        className={cn(
          'hidden md:flex flex-col h-screen h-[100dvh] max-h-[100dvh] bg-[#071A31] border-r border-[#0C2340] transition-all duration-150 no-print flex-shrink-0 z-20 select-none shadow-sm',
          sidebarCollapsed ? 'w-14' : 'w-20'
        )}
      >
        {/* Brand Logo Square Header */}
        <div className="flex items-center justify-center h-14 border-b border-[#0C2340] bg-[#071A31] px-2 flex-shrink-0">
          <img
            src="zameria-logo.png"
            alt="ZAMERIA"
            className="h-7 w-auto object-contain transition-transform hover:scale-105 brightness-105"
          />
        </div>

        {/* Primary Action Tile: + New Order (Only for POS-authorized users) */}
        {canAccessPOS && (
          <div className="border-b border-[#0C2340] flex-shrink-0">
            <button
              type="button"
              onClick={handleNewOrderClick}
              title="New Order"
              className={cn(
                'w-full flex flex-col items-center justify-center transition-colors cursor-pointer',
                'bg-[#0C2340] hover:bg-[#123158] active:bg-[#040E1B] text-white',
                sidebarCollapsed ? 'h-14 py-2' : 'h-16 py-2.5 gap-1'
              )}
            >
              <Plus className={cn('flex-shrink-0 text-[#60A5FA]', sidebarCollapsed ? 'w-5 h-5' : 'w-5 h-5')} />
              {!sidebarCollapsed && (
                <span className="text-[10px] font-semibold tracking-tight text-white leading-none">
                  New Order
                </span>
              )}
            </button>
          </div>
        )}

        {/* Navigation Tiles: Icon on Top, Label Below */}
        <nav className="flex-1 flex flex-col overflow-y-auto divide-y divide-[#0C2340]/60">
          {allowedNavItems.map((item) => {
            const Icon = item.icon;
            const isActive = item.path
              ? location.pathname === item.path ||
                (item.path === '/sale' && location.pathname === '/')
              : isSupportChatOpen;

            const tileContent = (
              <>
                {/* Active M3 Icon Pill */}
                <div
                  className={cn(
                    'flex items-center justify-center rounded-full transition-all duration-200',
                    sidebarCollapsed ? 'w-8 h-8' : 'px-3 py-0.5',
                    isActive
                      ? 'bg-[#60A5FA]/15 text-[#60A5FA]'
                      : 'text-slate-400 group-hover:text-slate-200'
                  )}
                >
                  <Icon className="w-4.5 h-4.5 flex-shrink-0" />
                </div>
                {!sidebarCollapsed && (
                  <span
                    className={cn(
                      'text-[10px] tracking-tight leading-none transition-colors',
                      isActive
                        ? 'font-bold text-[#60A5FA]'
                        : 'font-medium text-slate-400 group-hover:text-slate-200'
                    )}
                  >
                    {item.label}
                  </span>
                )}

                {/* Badge (e.g. Orders pending count or Support unread) */}
                {item.badge && item.badge > 0 ? (
                  <span className="absolute top-2 right-2 flex items-center justify-center min-w-[16px] h-4 rounded-full bg-[#60A5FA] text-[#071A31] text-[9px] font-black px-1 tabular-nums shadow-xs">
                    {item.badge}
                  </span>
                ) : null}
              </>
            );

            const tileClasses = cn(
              'flex flex-col items-center justify-center transition-all duration-200 relative cursor-pointer group w-full',
              sidebarCollapsed ? 'h-14 py-2' : 'h-16 py-2 gap-1',
              isActive
                ? 'bg-[#0C2340] text-white shadow-xs'
                : 'text-slate-400 hover:text-white hover:bg-white/[0.06]'
            );

            if (item.action) {
              return (
                <button
                  key={item.label}
                  type="button"
                  onClick={item.action}
                  title={item.label}
                  className={tileClasses}
                >
                  {tileContent}
                </button>
              );
            }

            return (
              <NavLink
                key={item.path}
                to={item.path!}
                title={item.label}
                className={tileClasses}
              >
                {tileContent}
              </NavLink>
            );
          })}
        </nav>

        {/* User Account / WooCommerce Role Badge Tile */}
        {user && (
          <div className="border-t border-[#0C2340] flex-shrink-0">
            <button
              type="button"
              onClick={() => setShowUserModal(true)}
              title={`${user.displayName} (${userRole.replace('_', ' ').toUpperCase()})`}
              className={cn(
                'w-full flex flex-col items-center justify-center transition-colors cursor-pointer group',
                'hover:bg-[#0C2340]/70',
                sidebarCollapsed ? 'h-14 py-2' : 'h-16 py-2 gap-1'
              )}
            >
              <div
                className={cn(
                  'w-7 h-7 rounded-full flex items-center justify-center border font-bold text-[11px] transition-transform group-hover:scale-105',
                  roleStyle.bg,
                  roleStyle.text,
                  roleStyle.border
                )}
              >
                <RoleIcon className="w-4 h-4" />
              </div>
              {!sidebarCollapsed && (
                <div className="flex flex-col items-center leading-none">
                  <span className="text-[10px] font-semibold text-slate-200 truncate max-w-[68px]">
                    {user.displayName.split(' ')[0]}
                  </span>
                  <span
                    className={cn(
                      'text-[8px] font-bold uppercase tracking-tight mt-0.5 px-1 py-0.2 rounded',
                      roleStyle.bg,
                      roleStyle.text
                    )}
                  >
                    {userRole === 'shop_manager' ? 'Manager' : userRole === 'administrator' ? 'Admin' : userRole}
                  </span>
                </div>
              )}
            </button>
          </div>
        )}

        {/* Network / Offline Indicator */}
        <div className="py-2 flex items-center justify-center border-t border-[#0C2340] bg-[#040E1B] flex-shrink-0">
          <div
            className={cn(
              'flex items-center justify-center text-xs',
              !isOnline ? 'text-amber-400' : status === 'SYNCING' ? 'text-[#60A5FA]' : 'text-emerald-400'
            )}
            title={!isOnline ? 'Offline' : status === 'SYNCING' ? 'Syncing...' : 'Online'}
          >
            {status === 'SYNCING' ? (
              <Loader2 className="w-3.5 h-3.5 animate-spin" />
            ) : isOnline ? (
              <Wifi className="w-3.5 h-3.5" />
            ) : (
              <WifiOff className="w-3.5 h-3.5" />
            )}
          </div>
        </div>

        {/* Collapse Toggle Footer */}
        <button
          type="button"
          onClick={toggleSidebar}
          className="flex items-center justify-center h-10 border-t border-[#0C2340] text-slate-400 hover:text-white hover:bg-[#0C2340]/60 transition-colors cursor-pointer flex-shrink-0"
          title={sidebarCollapsed ? 'Expand sidebar' : 'Collapse sidebar'}
        >
          {sidebarCollapsed ? (
            <ChevronRight className="w-4 h-4" />
          ) : (
            <div className="flex items-center gap-1 text-[11px] font-medium text-surface-500">
              <ChevronLeft className="w-3.5 h-3.5" />
              <span>Collapse</span>
            </div>
          )}
        </button>
      </aside>

      {/* USER & WOOCOMMERCE ROLE DETAILS MODAL */}
      <Modal
        open={showUserModal}
        onClose={() => setShowUserModal(false)}
        title="WOOCOMMERCE STAFF ACCOUNT"
        size="md"
      >
        {user && (
          <div className="space-y-4">
            {/* User Profile Header */}
            <div className="flex items-start gap-3 p-3.5 rounded-xl bg-surface-50 border border-surface-200">
              <div
                className={cn(
                  'w-12 h-12 rounded-xl flex items-center justify-center border text-lg font-bold flex-shrink-0 shadow-sm',
                  roleStyle.bg,
                  roleStyle.text,
                  roleStyle.border
                )}
              >
                <RoleIcon className="w-6 h-6" />
              </div>
              <div className="flex-1 min-w-0">
                <div className="flex items-center justify-between gap-2">
                  <h3 className="text-sm font-bold text-surface-900 truncate">{user.displayName}</h3>
                  <span
                    className={cn(
                      'text-[10px] uppercase font-bold tracking-wider px-2 py-0.5 rounded border',
                      roleStyle.bg,
                      roleStyle.text,
                      roleStyle.border
                    )}
                  >
                    {userRole.replace('_', ' ').toUpperCase()}
                  </span>
                </div>
                <p className="text-xs text-surface-500 font-mono mt-0.5">@{user.username} &bull; {user.email}</p>
                <div className="flex items-center gap-1.5 mt-2 text-[11px] text-surface-600">
                  <span className="w-2 h-2 rounded-full bg-emerald-500" />
                  <span>Store: <strong className="text-surface-800">{user.storeName}</strong></span>
                </div>
              </div>
            </div>

            {/* Permissions Matrix Overview */}
            <div>
              <h4 className="text-xs font-semibold text-surface-700 uppercase tracking-wider mb-2">
                Resolved Store Capabilities
              </h4>
              <div className="grid grid-cols-2 gap-2 text-xs">
                <div className="p-2.5 rounded-lg bg-surface-50 border border-surface-200 flex items-center gap-2">
                  {hasPermission('canAccessSale') ? (
                    <CheckCircle2 className="w-4 h-4 text-emerald-600 flex-shrink-0" />
                  ) : (
                    <XCircle className="w-4 h-4 text-red-500 flex-shrink-0" />
                  )}
                  <span className="truncate">POS Sale &amp; Barcode</span>
                </div>

                <div className="p-2.5 rounded-lg bg-surface-50 border border-surface-200 flex items-center gap-2">
                  {hasPermission('canCreateProduct') ? (
                    <CheckCircle2 className="w-4 h-4 text-emerald-600 flex-shrink-0" />
                  ) : (
                    <XCircle className="w-4 h-4 text-red-500 flex-shrink-0" />
                  )}
                  <span className="truncate">Create Products</span>
                </div>

                <div className="p-2.5 rounded-lg bg-surface-50 border border-surface-200 flex items-center gap-2">
                  {hasPermission('canEditProductPrice') ? (
                    <CheckCircle2 className="w-4 h-4 text-emerald-600 flex-shrink-0" />
                  ) : (
                    <XCircle className="w-4 h-4 text-red-500 flex-shrink-0" />
                  )}
                  <span className="truncate">Modify Prices</span>
                </div>

                <div className="p-2.5 rounded-lg bg-surface-50 border border-surface-200 flex items-center gap-2">
                  {hasPermission('canEditStockManually') ? (
                    <CheckCircle2 className="w-4 h-4 text-emerald-600 flex-shrink-0" />
                  ) : (
                    <XCircle className="w-4 h-4 text-red-500 flex-shrink-0" />
                  )}
                  <span className="truncate">Manual Stock Edit</span>
                </div>

                <div className="p-2.5 rounded-lg bg-surface-50 border border-surface-200 flex items-center gap-2">
                  {hasPermission('canManageWooConnection') ? (
                    <CheckCircle2 className="w-4 h-4 text-emerald-600 flex-shrink-0" />
                  ) : (
                    <XCircle className="w-4 h-4 text-red-500 flex-shrink-0" />
                  )}
                  <span className="truncate">Store API Settings</span>
                </div>

                <div className="p-2.5 rounded-lg bg-surface-50 border border-surface-200 flex items-center gap-2">
                  {hasPermission('canManageStaff') ? (
                    <CheckCircle2 className="w-4 h-4 text-emerald-600 flex-shrink-0" />
                  ) : (
                    <XCircle className="w-4 h-4 text-red-500 flex-shrink-0" />
                  )}
                  <span className="truncate">Staff Management</span>
                </div>
              </div>
            </div>

            {/* Session Revalidation & Sign Out Actions */}
            <div className="pt-2 border-t border-surface-200 flex flex-col sm:flex-row gap-2 justify-between items-center">
              <Button
                variant="secondary"
                size="sm"
                onClick={handleRevalidateSession}
                disabled={isRevalidating}
                className="w-full sm:w-auto flex items-center gap-1.5 text-xs"
              >
                <RefreshCw className={cn('w-3.5 h-3.5', isRevalidating && 'animate-spin')} />
                Revalidate WooCommerce Session
              </Button>

              <div className="flex items-center gap-2 w-full sm:w-auto justify-end">
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={() => setShowUserModal(false)}
                  className="text-xs"
                >
                  Close
                </Button>
                <Button
                  variant="destructive"
                  size="sm"
                  onClick={handleLogout}
                  className="text-xs flex items-center gap-1.5"
                >
                  <LogOut className="w-3.5 h-3.5" />
                  Sign Out
                </Button>
              </div>
            </div>
          </div>
        )}
      </Modal>

      {/* SAVE ACTIVE ORDER Modal (Screenshot 3 Pattern) */}
      <Modal
        open={showSaveModal}
        onClose={() => setShowSaveModal(false)}
        title="SAVE ACTIVE ORDER"
        size="sm"
      >
        <div className="space-y-4">
          <p className="text-xs text-surface-600 leading-relaxed">
            Do you want to save the active order before continuing with this order?
          </p>
          <div className="flex justify-end gap-2 pt-2">
            <Button variant="ghost" size="sm" onClick={() => setShowSaveModal(false)}>
              Cancel
            </Button>
            <Button variant="secondary" size="sm" onClick={handleDiscardAndNew}>
              No
            </Button>
            <Button variant="primary" size="sm" onClick={handleSaveAndNew}>
              Yes
            </Button>
          </div>
        </div>
      </Modal>
    </>
  );
}
