import { SelectControl } from '@/components/ui/SelectControl';
import React, { useState, useEffect, useRef } from 'react';
import { StatusPill, Button, Badge, ChannelBadge } from '@/components/ui';
import { formatMoney, formatTime, cn, decodeHtmlEntities } from '@/lib';
import { useAuthStore } from '@/store/authStore';
import { upsertOrderBatch } from '@/services/woocommerce/orderSyncService';
import { getWooClient } from '@/services/woocommerce/client';
import { toast } from 'sonner';
import {
  ExternalLink,
  Printer,
  Trash2,
  ArrowRight,
  ArrowLeft,
  CreditCard,
  Tag,
  RefreshCw,
} from 'lucide-react';
import type { Order, OrderItem, OrderStatus } from '@/types';

export interface OrderDetailViewProps {
  order: Order;
  items: OrderItem[];
  onBack?: () => void;
  onContinue?: () => void;
  onPrintReceipt?: () => void;
  onStatusChange?: (newStatus: OrderStatus) => void;
  className?: string;
}

export function OrderDetailView({
  order,
  items,
  onBack,
  onContinue,
  onPrintReceipt,
  onStatusChange,
  className,
}: OrderDetailViewProps) {
  const [activeTab, setActiveTab] = useState<'items' | 'details'>('items');
  const [isFetchingItems, setIsFetchingItems] = useState(false);
  const fetchedRef = useRef<number | null>(null);
  const hasPermission = useAuthStore((s) => s.hasPermission);
  const canCancel = hasPermission('canCancelOrder');

  const formattedDate = new Date(order.createdAt).toLocaleDateString('en-GB', {
    weekday: 'short',
    day: '2-digit',
    month: 'short',
    year: 'numeric',
  });
  const formattedTime = formatTime(order.createdAt);
  const isWeb = order.source === 'website' || (!order.source && order.wooId !== null && order.shippingMethod !== 'in-store' && order.shippingMethod !== 'walk-in');
  const rawAttendee = order.attendedBy || (isWeb ? 'Website Order' : '—');
  const attendee = decodeHtmlEntities(rawAttendee);
  const customerDisplayName = decodeHtmlEntities(order.customerName || 'Walk-in / Guest Customer');
  const customerNoteDecoded = order.customerNote ? decodeHtmlEntities(order.customerNote) : null;

  const handleFetchItems = async () => {
    if (!order.wooId || isFetchingItems) return;
    setIsFetchingItems(true);
    try {
      const client = getWooClient();
      if (!client) {
        toast.error('Store connection not configured');
        return;
      }
      const res = await client.get<any>(`/orders/${order.wooId}`);
      if (res.data?.line_items && Array.isArray(res.data.line_items) && res.data.line_items.length > 0) {
        await upsertOrderBatch([res.data]);
        toast.success(`Loaded ${res.data.line_items.length} order items`);
      } else {
        toast.info('No line items recorded on store');
      }
    } catch (err: any) {
      console.error('Failed to fetch order items:', err);
      toast.error('Could not fetch items from store');
    } finally {
      setIsFetchingItems(false);
    }
  };

  useEffect(() => {
    if (items.length === 0 && order.wooId && fetchedRef.current !== order.id) {
      fetchedRef.current = order.id;
      handleFetchItems();
    }
  }, [items.length, order.wooId]);

  return (
    <div className={cn('pos-order-detail flex-1 flex flex-col min-w-0 bg-surface h-full overflow-hidden', className)}>
      {/* Top Header Card */}
      <div className="pos-order-heading p-4 sm:p-5 border-b border-surface-200 bg-surface flex-shrink-0 space-y-2.5">
        {onBack && (
          <button
            type="button"
            onClick={onBack}
            className="inline-flex items-center gap-1.5 text-xs font-bold text-surface-600 hover:text-on-surface transition-colors cursor-pointer mb-1"
          >
            <ArrowLeft className="w-3.5 h-3.5" />
            Back to Customer Profile
          </button>
        )}

        <div className="flex items-center justify-between gap-3 flex-wrap">
          <div className="flex items-center gap-2.5">
            <h2 className="text-base font-semibold text-on-surface tracking-tight">
              {order.status === 'on-hold'
                ? `Incomplete Order ${order.orderNumber}`
                : `Order ${order.orderNumber}`}
            </h2>
            <StatusPill status={order.remoteStatus || order.status} />
            <ChannelBadge source={isWeb ? 'website' : 'pos'} />
          </div>

          <div className="flex items-center gap-2">
            {onPrintReceipt && (
              <Button
                variant="secondary"
                size="sm"
                onClick={onPrintReceipt}
                icon={<Printer className="w-3.5 h-3.5" />}
              >
                Print Receipt
              </Button>
            )}
          </div>
        </div>

        <div className="text-xs text-surface-600 space-y-0.5">
          <p className="font-semibold text-on-surface">
            {customerDisplayName}
          </p>
          <div className="flex items-center gap-2 text-surface-400 text-xs flex-wrap">
            <span>{formattedDate} {formattedTime}</span>
            <span>·</span>
            <span className="font-medium text-surface-600">
              Attended By: <strong className="text-on-surface">{attendee}</strong>
            </span>
            <span>·</span>
            <span className="font-medium text-surface-600 capitalize">
              {order.paymentMethodTitle || order.paymentMethod}
            </span>
            {order.paymentSplits && order.paymentSplits.length > 0 && (
              <Badge variant="brand" size="sm">
                {order.paymentSplits.length} Splits
              </Badge>
            )}
          </div>
        </div>
      </div>

      {/* Segmented Tabs: [X] items | Order Details */}
      <div className="pos-order-tabs flex border-b border-surface-200 bg-surface-container-lowest px-5 flex-shrink-0">
        <button
          type="button"
          onClick={() => setActiveTab('items')}
          className={cn(
            'py-2.5 px-4 text-xs font-bold border-b-2 transition-colors cursor-pointer',
            activeTab === 'items'
              ? 'border-primary text-primary bg-surface'
              : 'border-transparent text-surface-500 hover:text-on-surface'
          )}
        >
          {items.length || order.itemCount} items
        </button>
        <button
          type="button"
          onClick={() => setActiveTab('details')}
          className={cn(
            'py-2.5 px-4 text-xs font-bold border-b-2 transition-colors cursor-pointer',
            activeTab === 'details'
              ? 'border-primary text-primary bg-surface'
              : 'border-transparent text-surface-500 hover:text-on-surface'
          )}
        >
          Order Details
        </button>
      </div>

      {/* Tab Contents */}
      <div className="pos-order-content flex-1 overflow-y-auto p-4 sm:p-5">
        {activeTab === 'items' ? (
          /* Historical Items List with Stored Prices */
          <div className="divide-y divide-surface-100">
            {items.length === 0 ? (
              <div className="py-12 text-center text-xs text-surface-400 space-y-3">
                <p>No items recorded locally for this order.</p>
                {order.wooId && (
                  <div className="flex justify-center">
                    <Button
                      variant="secondary"
                      size="sm"
                      loading={isFetchingItems}
                      onClick={handleFetchItems}
                      icon={<RefreshCw className={`w-3.5 h-3.5 ${isFetchingItems ? 'animate-spin' : ''}`} />}
                    >
                      {isFetchingItems ? 'Loading items...' : 'Fetch Order Items from WooCommerce'}
                    </Button>
                  </div>
                )}
              </div>
            ) : (
              items.map((item, idx) => (
                <div
                  key={item.id || idx}
                  className="py-3 flex items-center justify-between gap-4 hover:bg-surface-50/60 rounded px-2 -mx-2 transition-colors"
                >
                  <div className="min-w-0 flex-1">
                    <p className="text-xs font-bold text-surface-900 truncate">
                      {decodeHtmlEntities(item.name)}
                    </p>
                    <div className="flex items-center gap-2 mt-0.5 text-xs text-surface-500">
                      <span className="tabular-nums font-medium text-surface-700">
                        {formatMoney(item.price)}
                      </span>
                      <span>×</span>
                      <span className="font-semibold text-surface-900">{item.quantity}</span>
                      {item.discount && (
                        <span className="text-xs font-semibold text-blue-700 bg-blue-50 border border-blue-200/60 px-1.5 py-0.5 rounded">
                          {item.discount.type === 'percentage'
                            ? `${item.discount.value}% off`
                            : `${formatMoney(item.discount.value)} off`}
                        </span>
                      )}
                      <span className="text-xs text-surface-400 font-mono ml-1">
                        ID: {item.wooProductId || item.productId}
                      </span>
                    </div>
                  </div>

                  <div className="text-right">
                    <span className="text-xs font-black text-surface-900 tabular-nums block">
                      {formatMoney(item.total)}
                    </span>
                  </div>
                </div>
              ))
            )}
          </div>
        ) : (
          /* Order Details Tab */
          <div className="space-y-4 text-xs">
            <div>
              <h4 className="font-bold text-surface-500 uppercase tracking-wider text-xs mb-2">
                Customer & Fulfillment
              </h4>
              <div className="pos-card p-3 space-y-1.5 text-surface-700">
                <div className="flex justify-between">
                  <span className="text-surface-400">Attended By:</span>
                  <span className="font-semibold text-on-surface">{attendee}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-surface-400">Customer:</span>
                  <span className="font-medium text-on-surface">{customerDisplayName}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-surface-400">Email:</span>
                  <span className="font-medium text-on-surface">{order.customerEmail || '—'}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-surface-400">Shipping / Mode:</span>
                  <span className="font-medium capitalize text-on-surface">{order.shippingMethod || 'In-store'}</span>
                </div>
                {customerNoteDecoded && (
                  <div className="pt-2 border-t border-outline-variant/60">
                    <span className="text-surface-400 block mb-0.5">Order Note:</span>
                    <p className="text-on-surface italic bg-surface-container-low p-2.5 rounded-lg border border-outline-variant/60">
                      {customerNoteDecoded}
                    </p>
                  </div>
                )}
              </div>
            </div>

            {/* Split Payment Details (if applicable) */}
            {order.paymentSplits && order.paymentSplits.length > 0 && (
              <div>
                <h4 className="font-bold text-surface-500 uppercase tracking-wider text-xs mb-2">
                  Split Payment Breakdown
                </h4>
                <div className="m3-card-outlined rounded-xl p-3.5 space-y-2 bg-surface">
                  {order.paymentSplits.map((split, i) => (
                    <div key={split.id || i} className="flex justify-between items-center text-xs">
                      <span className="font-medium flex items-center gap-1.5 text-on-surface">
                        <CreditCard className="w-3.5 h-3.5 text-surface-400" />
                        {split.methodTitle || split.method}
                      </span>
                      <span className="font-bold tabular-nums text-on-surface">
                        {formatMoney(split.amount)}
                      </span>
                    </div>
                  ))}
                  <div className="pt-2 border-t border-outline-variant/60 flex justify-between font-black text-xs text-on-surface">
                    <span>Total Paid:</span>
                    <span className="tabular-nums">
                      {formatMoney(order.paymentSplits.reduce((sum, s) => sum + s.amount, 0))}
                    </span>
                  </div>
                </div>
              </div>
            )}

            <div>
              <h4 className="font-bold text-surface-500 uppercase tracking-wider text-xs mb-2">
                Order Management
              </h4>
              <div className="m3-card-outlined rounded-xl p-3.5 space-y-2.5 bg-surface">
                <div className="flex items-center justify-between">
                  <span className="text-surface-500">Status:</span>
                  {onStatusChange ? (
                    <SelectControl aria-label="Order status"
                      value={order.status}
                      onChange={(e) => onStatusChange(e.target.value as OrderStatus)}
                      className="h-9 px-2.5 border border-outline-variant rounded-lg text-xs font-semibold bg-surface text-on-surface focus:outline-none focus:border-primary cursor-pointer"
                    >
                      <option value="completed">Completed</option>
                      <option value="on-hold">On hold</option>
                      <option value="processing">Processing</option>
                      <option value="pending">Pending</option>
                      {canCancel && <option value="cancelled">Cancelled</option>}
                      <option value="refunded">Refunded</option>
                    </SelectControl>
                  ) : (
                    <StatusPill status={order.remoteStatus || order.status} />
                  )}
                </div>

                <div className="pt-2 border-t border-outline-variant/60 flex items-center justify-between">
                  <span className="text-surface-500">Sync Status:</span>
                  <StatusPill status={order.syncStatus} />
                </div>
              </div>
            </div>

            <div className="pt-2">
              <a
                href="#"
                onClick={(e) => {
                  e.preventDefault();
                }}
                className="inline-flex items-center gap-1.5 text-xs font-semibold text-primary hover:text-primary-hover"
              >
                <ExternalLink className="w-3.5 h-3.5" />
                Local Order ID: {order.localTransactionId}
              </a>
            </div>
          </div>
        )}
      </div>

      {/* Bottom Financial Breakdown & Action Bar */}
      <div className="pos-order-totals border-t border-surface-200 bg-surface-container-lowest p-4 space-y-3 flex-shrink-0">
        <div className="space-y-1 text-xs">
          <div className="flex justify-between text-surface-600">
            <span>Subtotal</span>
            <div className="flex items-center gap-3">
              <span className="text-surface-400">{items.length || order.itemCount} items</span>
              <span className="tabular-nums font-semibold text-on-surface">
                {formatMoney(order.subtotal)}
              </span>
            </div>
          </div>
          {order.couponDiscount && order.couponDiscount > 0 ? (
            <div className="flex justify-between text-success font-medium">
              <span className="flex items-center gap-1">
                <Tag className="w-3 h-3" />
                Coupon Discount {order.couponCode ? `(${order.couponCode})` : ''}
              </span>
              <span className="tabular-nums font-bold">
                -{formatMoney(order.couponDiscount)}
              </span>
            </div>
          ) : null}
          {order.transactionFee > 0 && (
            <div className="flex justify-between text-surface-500">
              <span>Paystack Fee (1.5%)</span>
              <span className="tabular-nums font-semibold text-on-surface">
                {formatMoney(order.transactionFee)}
              </span>
            </div>
          )}
          <div className="flex justify-between items-baseline pt-2 border-t border-surface-200 text-on-surface">
            <span className="text-xs font-bold uppercase tracking-wider text-surface-600">Total</span>
            <span className="text-2xl font-black text-on-surface tabular-nums">
              {formatMoney(order.total)}
            </span>
          </div>
        </div>

        {/* Action Bar (Cancel / Continue) */}
        {(onContinue || onStatusChange) && (
          <div className="flex items-center justify-between gap-2 pt-2 border-t border-surface-200">
            <div>
              {canCancel && onStatusChange && order.status !== 'cancelled' && (
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={() => onStatusChange('cancelled')}
                  className="text-danger hover:bg-danger-container hover:text-danger flex items-center gap-1"
                >
                  <Trash2 className="w-3.5 h-3.5" />
                  Cancel Order
                </Button>
              )}
            </div>

            <div className="flex items-center gap-2">
              {onContinue && ['on-hold', 'pending', 'processing'].includes(order.status) && (
                <Button
                  variant="primary"
                  size="sm"
                  onClick={onContinue}
                  icon={<ArrowRight className="w-3.5 h-3.5" />}
                  className="font-bold shadow-xs"
                >
                  Continue Sale
                </Button>
              )}
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
