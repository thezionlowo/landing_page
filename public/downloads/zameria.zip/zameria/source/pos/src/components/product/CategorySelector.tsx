import React, { useState, useMemo } from 'react';
import { useLiveQuery } from 'dexie-react-hooks';
import { db } from '@/db';
import { buildCategoryTree, flattenCategoryTree, type CategoryTreeNode } from '@/services/woocommerce/categoryService';
import { Search, X, Check, Folder, ChevronRight, CornerDownRight } from 'lucide-react';
import { cn } from '@/lib';
import type { Category } from '@/types';

interface CategorySelectorProps {
  selectedCategoryIds: number[];
  onChange: (categoryIds: number[]) => void;
  disabled?: boolean;
}

export function CategorySelector({
  selectedCategoryIds,
  onChange,
  disabled = false,
}: CategorySelectorProps) {
  const [search, setSearch] = useState('');
  const categories = useLiveQuery(() => db.categories.toArray(), []);

  // Build hierarchical category tree
  const treeRoots = useMemo(() => {
    if (!categories || categories.length === 0) return [];
    return buildCategoryTree(categories);
  }, [categories]);

  // Flattened tree with level guides
  const flattenedCategories = useMemo(() => {
    return flattenCategoryTree(treeRoots);
  }, [treeRoots]);

  // Filter based on search input
  const filteredCategories = useMemo(() => {
    if (!search.trim()) return flattenedCategories;
    const q = search.trim().toLowerCase();
    return flattenedCategories.filter(
      (c) => c.name.toLowerCase().includes(q) || c.path.toLowerCase().includes(q)
    );
  }, [flattenedCategories, search]);

  // Selected category entities
  const selectedCategoryEntities = useMemo(() => {
    if (!categories) return [];
    return categories.filter((c) => selectedCategoryIds.includes(c.id));
  }, [categories, selectedCategoryIds]);

  const toggleCategory = (catId: number) => {
    if (disabled) return;
    if (selectedCategoryIds.includes(catId)) {
      onChange(selectedCategoryIds.filter((id) => id !== catId));
    } else {
      onChange([...selectedCategoryIds, catId]);
    }
  };

  const removeCategory = (catId: number) => {
    if (disabled) return;
    onChange(selectedCategoryIds.filter((id) => id !== catId));
  };

  const clearAll = () => {
    if (disabled) return;
    onChange([]);
  };

  return (
    <div className="space-y-2.5">
      <div className="flex items-center justify-between">
        <label className="text-xs font-semibold text-on-surface block">
          Categories (Multi-Select)
        </label>
        {selectedCategoryIds.length > 0 && !disabled && (
          <button
            type="button"
            onClick={clearAll}
            className="text-[11px] text-on-surface-variant hover:text-error transition-colors cursor-pointer"
          >
            Clear selection
          </button>
        )}
      </div>

      {/* Selected Category Badges / Pills */}
      {selectedCategoryEntities.length > 0 && (
        <div className="flex flex-wrap items-center gap-1.5 p-2 bg-surface-container-low rounded-xl border border-outline-variant/60">
          <span className="text-[11px] font-bold text-on-surface-variant mr-1">
            Selected ({selectedCategoryEntities.length}):
          </span>
          {selectedCategoryEntities.map((cat) => (
            <span
              key={cat.id}
              className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-lg text-xs font-semibold bg-primary-container text-on-primary-container border border-primary/20 transition-all"
            >
              <span>{cat.name}</span>
              {!disabled && (
                <button
                  type="button"
                  onClick={() => removeCategory(cat.id)}
                  className="hover:text-primary rounded p-0.5 hover:bg-primary/10 transition-colors cursor-pointer"
                  title={`Remove ${cat.name}`}
                >
                  <X className="w-3 h-3" />
                </button>
              )}
            </span>
          ))}
        </div>
      )}

      {/* Search Categories */}
      <div className="relative">
        <Search className="w-3.5 h-3.5 absolute left-3 top-1/2 -translate-y-1/2 text-on-surface-variant/60 pointer-events-none" />
        <input
          type="text"
          value={search}
          disabled={disabled}
          onChange={(e) => setSearch(e.target.value)}
          placeholder="Search categories (e.g. Skincare, Beauty)..."
          className="w-full h-9 pl-9 pr-8 text-xs bg-surface border border-outline-variant/80 rounded-lg text-on-surface focus:outline-none focus:border-primary disabled:bg-surface-container-high placeholder:text-on-surface-variant/50"
        />
        {search && (
          <button
            type="button"
            onClick={() => setSearch('')}
            className="absolute right-2.5 top-1/2 -translate-y-1/2 text-on-surface-variant hover:text-on-surface cursor-pointer p-0.5"
          >
            <X className="w-3 h-3" />
          </button>
        )}
      </div>

      {/* Available Categories Hierarchy List */}
      <div className="border border-outline-variant/60 rounded-xl max-h-52 overflow-y-auto bg-surface divide-y divide-outline-variant/30">
        {!categories || categories.length === 0 ? (
          <div className="p-4 text-center text-xs text-on-surface-variant">
            No categories synchronized yet. Run Sync to pull categories from WooCommerce.
          </div>
        ) : filteredCategories.length === 0 ? (
          <div className="p-4 text-center text-xs text-on-surface-variant">
            No category matching "{search}"
          </div>
        ) : (
          filteredCategories.map((cat) => {
            const isSelected = selectedCategoryIds.includes(cat.id);
            const isChild = cat.level > 0;

            return (
              <div
                key={cat.id}
                role="button"
                tabIndex={0}
                onClick={() => toggleCategory(cat.id)}
                onKeyDown={(e) => {
                  if (e.key === 'Enter' || e.key === ' ') {
                    e.preventDefault();
                    toggleCategory(cat.id);
                  }
                }}
                style={{ paddingLeft: `${Math.max(12, cat.level * 24 + 12)}px` }}
                className={cn(
                  'pr-3.5 py-2 flex items-center justify-between text-xs transition-colors select-none cursor-pointer',
                  disabled ? 'opacity-50 cursor-not-allowed' : 'hover:bg-surface-container-low',
                  isSelected ? 'bg-primary-container/20 text-on-surface font-semibold' : 'text-on-surface'
                )}
              >
                <div className="flex items-center gap-2.5 min-w-0">
                  {/* Custom Checkbox */}
                  <div
                    className={cn(
                      'w-4 h-4 rounded border flex items-center justify-center transition-colors flex-shrink-0',
                      isSelected
                        ? 'bg-primary border-primary text-on-primary'
                        : 'border-outline-variant/80 bg-surface'
                    )}
                  >
                    {isSelected && <Check className="w-3 h-3 stroke-[3]" />}
                  </div>

                  {/* Hierarchy Indication */}
                  {isChild && (
                    <CornerDownRight className="w-3.5 h-3.5 text-on-surface-variant/50 flex-shrink-0" />
                  )}

                  {/* Name and path */}
                  <div className="flex items-center gap-1.5 min-w-0">
                    <span className={cn('truncate', !isChild && 'font-bold text-on-surface')}>
                      {cat.name}
                    </span>
                    {search && isChild && (
                      <span className="text-[10px] text-on-surface-variant/70 truncate">
                        ({cat.path})
                      </span>
                    )}
                  </div>
                </div>

                <div className="flex items-center gap-2 flex-shrink-0 ml-2">
                  {cat.count > 0 && (
                    <span className="text-[10px] text-on-surface-variant font-mono">
                      {cat.count} {cat.count === 1 ? 'item' : 'items'}
                    </span>
                  )}
                  {cat.wooId && (
                    <span className="text-[9px] font-mono text-on-surface-variant/80 px-1.5 py-0.5 bg-surface-container-high rounded border border-outline-variant/40">
                      ID: {cat.wooId}
                    </span>
                  )}
                </div>
              </div>
            );
          })
        )}
      </div>
    </div>
  );
}
