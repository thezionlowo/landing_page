import { useEffect, useRef } from 'react';

const layers: HTMLElement[] = [];
let previousOverflow = '';

/** Keeps nested dialogs usable without moving keyboard focus into the background. */
export function useDialogFocus(open: boolean, onClose: () => void) {
  const ref = useRef<HTMLDivElement>(null);
  const close = useRef(onClose);
  close.current = onClose;
  useEffect(() => {
    const panel = ref.current;
    if (!open || !panel) return;
    const previousFocus = document.activeElement instanceof HTMLElement ? document.activeElement : null;
    if (!layers.length) previousOverflow = document.body.style.overflow;
    layers.push(panel);
    document.body.style.overflow = 'hidden';
    const isTop = () => layers[layers.length - 1] === panel;
    const controls = () => [...panel.querySelectorAll<HTMLElement>('button:not([disabled]), a[href], input:not([disabled]), select:not([disabled]), textarea:not([disabled]), [tabindex]:not([tabindex="-1"])')]
      .filter(element => element.getClientRects().length && !element.closest('[inert]'));
    if (!panel.contains(document.activeElement)) panel.focus();
    const keydown = (event: KeyboardEvent) => {
      if (!isTop() || event.defaultPrevented) return;
      if (event.key === 'Escape') { event.preventDefault(); event.stopImmediatePropagation(); close.current(); return; }
      if (event.key !== 'Tab') return;
      const items = controls(), first = items[0], last = items[items.length - 1];
      if (!first) { event.preventDefault(); panel.focus(); return; }
      if (event.shiftKey && (document.activeElement === first || document.activeElement === panel)) { event.preventDefault(); last.focus(); }
      else if (!event.shiftKey && (document.activeElement === last || !panel.contains(document.activeElement))) { event.preventDefault(); first.focus(); }
    };
    const focusin = (event: FocusEvent) => { if (isTop() && !panel.contains(event.target as Node)) panel.focus(); };
    document.addEventListener('keydown', keydown, true);
    document.addEventListener('focusin', focusin);
    return () => {
      document.removeEventListener('keydown', keydown, true);
      document.removeEventListener('focusin', focusin);
      const index = layers.indexOf(panel); if (index >= 0) layers.splice(index, 1);
      if (!layers.length) document.body.style.overflow = previousOverflow;
      if (previousFocus?.isConnected && (!layers.length || layers[layers.length - 1].contains(previousFocus))) previousFocus.focus();
    };
  }, [open]);
  return ref;
}
