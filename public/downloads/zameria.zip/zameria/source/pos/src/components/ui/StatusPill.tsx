import { cn } from '@/lib';
import type { OrderStatus, SyncStatus } from '@/types';

export type PillVariant = OrderStatus | SyncStatus | 'online' | 'offline' | 'syncing';

export interface StatusPillProps {
  status: PillVariant | string;
  label?: string;
  className?: string;
}

const statusConfig: Record<string, { className: string; defaultLabel: string }> = {
  // Orders
  completed: { className: 'pill-completed', defaultLabel: 'Completed' },
  processing: { className: 'pill-processing', defaultLabel: 'Processing' },
  'on-hold': { className: 'pill-on-hold', defaultLabel: 'On Hold' },
  cancelled: { className: 'pill-cancelled', defaultLabel: 'Cancelled' },
  refunded: { className: 'pill-refunded', defaultLabel: 'Refunded' },
  pending: { className: 'pill-pending', defaultLabel: 'Pending' },
  failed: { className: 'pill-failed', defaultLabel: 'Failed' },
  trash: { className: 'pill-cancelled', defaultLabel: 'Trash' },

  // Sync
  SYNCED: { className: 'pill-synced', defaultLabel: 'Synced' },
  PENDING_SYNC: { className: 'pill-offline', defaultLabel: 'Pending Sync' },
  SYNC_CONFLICT: { className: 'pill-conflict', defaultLabel: 'Stock Conflict' },
  SYNC_ERROR: { className: 'pill-failed', defaultLabel: 'Sync Error' },
  LOCAL_ONLY: { className: 'pill-pending', defaultLabel: 'Local Only' },
  SYNCING: { className: 'pill-processing', defaultLabel: 'Syncing' },

  // Network
  online: { className: 'pill-synced', defaultLabel: 'Online' },
  offline: { className: 'pill-offline', defaultLabel: 'Offline' },
  syncing: { className: 'pill-processing', defaultLabel: 'Syncing' },
};

export function StatusPill({ status, label, className }: StatusPillProps) {
  const config = statusConfig[status] || {
    className: 'pill-pending',
    defaultLabel: status,
  };

  return (
    <span className={cn('pill', config.className, className)}>
      {label || config.defaultLabel}
    </span>
  );
}
