import React, { useId } from 'react';
import { createPortal } from 'react-dom';
import { X } from 'lucide-react';
import { cn } from '@/lib';
import { useDialogFocus } from './useDialogFocus';
export interface DrawerProps {
  open: boolean; onClose: () => void; title?: React.ReactNode; children: React.ReactNode;
  width?: 'sm' | 'md' | 'lg'; footer?: React.ReactNode; bodyClassName?: string;
}
export function Drawer({ open, onClose, title, children, width = 'md', footer, bodyClassName }: DrawerProps) {
  const titleId = useId();
  const ref = useDialogFocus(open, onClose);
  if (!open) return null;
  const sizes = { sm: 'sm:max-w-sm', md: 'sm:max-w-md', lg: 'sm:max-w-lg' };
  return createPortal(
    <div className="pos-dialog-layer pos-drawer-layer">
      <div className="pos-dialog-backdrop" onClick={onClose} aria-hidden="true" />
      <div ref={ref} tabIndex={-1} role="dialog" aria-modal="true" aria-labelledby={title ? titleId : undefined} aria-label={title ? undefined : 'Details'} className={cn('pos-drawer', sizes[width])}>
        <div className="pos-dialog-heading"><div role="heading" aria-level={2} id={titleId} className="min-w-0 flex-1 text-base font-semibold text-on-surface">{title}</div><button type="button" onClick={onClose} className="pos-icon-button" aria-label="Close panel"><X className="w-5 h-5" /></button></div>
        <div className={cn('pos-drawer-body', bodyClassName)}>{children}</div>
        {footer && <div className="pos-dialog-footer">{footer}</div>}
      </div>
    </div>, document.body
  );
}
