import React, { useState, useEffect, useRef } from 'react';
import {
  MessageSquare,
  X,
  Send,
  Headphones,
  CheckCircle2,
  Clock,
  RotateCcw,
  Sparkles
} from 'lucide-react';
import {
  supportChatClient,
  SupportConversation,
  SupportSource
} from '@/services/supportChatClient';
import { useAuthStore, useUIStore, useConnectionStore } from '@/store';

interface ZameriaSupportChatWidgetProps {
  source?: SupportSource;
  customPosition?: { bottom?: number; right?: number };
}

export const ZameriaSupportChatWidget: React.FC<ZameriaSupportChatWidgetProps> = ({
  source = 'POS',
}) => {
  const { user } = useAuthStore();
  const { storeUrl: connStoreUrl, storeName: connStoreName } = useConnectionStore();
  const isSupportChatOpen = useUIStore((s) => s.isSupportChatOpen);
  const closeSupportChat = useUIStore((s) => s.closeSupportChat);
  const [conversation, setConversation] = useState<SupportConversation | null>(null);
  const [messageText, setMessageText] = useState('');
  const [unreadCount, setUnreadCount] = useState(0);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  // Auto-resolve customer identification from session/auth store and connection store
  const activeStoreName = user?.storeName || connStoreName || 'ZAMERIA Store';
  const customerName = user?.displayName || user?.username || activeStoreName;
  const customerEmail = user?.email || (user?.username?.includes('@') ? user.username : 'pos@store.local');
  const businessName = activeStoreName;
  const activeStoreUrl = user?.storeUrl || connStoreUrl || (typeof window !== 'undefined' ? window.location.origin : '');
  const customerId = user?.id ? `cust_${user.id}` : (activeStoreUrl ? `store_${activeStoreUrl.replace(/[^a-zA-Z0-9]/g, '_')}` : 'cust_pos');

  const [sending,setSending]=useState(false);
  const [deliveryError,setDeliveryError]=useState('');
  useEffect(() => {
    setConversation(null);setDeliveryError('');
  },[user?.id,user?.token,activeStoreUrl]);
  useEffect(() => {
    if(!user?.token)return;
    let active=true;let inFlight=false;
    const refresh=async()=>{if(inFlight)return;inFlight=true;try{
      const value=await supportChatClient.getConversation();
      if(active){setConversation(value);setUnreadCount(value?.unreadByCustomer || 0);}
    }catch(e){if(active)setDeliveryError(e instanceof Error?e.message:'Could not load support replies');}finally{inFlight=false}};
    void refresh();const timer=setInterval(refresh,isSupportChatOpen?6000:15000);return()=>{active=false;clearInterval(timer)};
  },[isSupportChatOpen,user?.token,activeStoreUrl]);
  useEffect(()=>{
    if(isSupportChatOpen){messagesEndRef.current?.scrollIntoView({behavior:'smooth'});if(conversation?.unreadByCustomer)void supportChatClient.markAsReadByCustomer(conversation.id).catch(()=>{});}
  },[isSupportChatOpen,conversation?.messages.length]);
  const handleSendMessage=async(e:React.FormEvent)=>{
    e.preventDefault();if(!messageText.trim()||sending)return;
    const text=messageText.trim();setSending(true);setDeliveryError('');
    try{const value=conversation?await supportChatClient.sendMessage(conversation.id,text):await supportChatClient.getOrCreateConversation({initialMessage:text});
      if(!value)throw Error('Support did not confirm delivery');setConversation(value);setMessageText('');
    }catch(e){setDeliveryError(e instanceof Error?e.message:'Message was not delivered. Please retry.');}finally{setSending(false)}
  };
  const handleResolve=async()=>{if(!conversation||sending)return;setSending(true);try{await supportChatClient.resolveConversation(conversation.id);setConversation(await supportChatClient.getConversation());}catch(e){setDeliveryError(e instanceof Error?e.message:'Could not close conversation')}finally{setSending(false)}};

  if (!isSupportChatOpen) {
    return null;
  }

  return (
    <>
      {/* Floating Chat Modal */}
      <div
          style={{
            position: 'fixed',
            bottom: '24px',
            right: '24px',
            width: '380px',
            maxWidth: 'calc(100vw - 32px)',
            height: '520px',
            maxHeight: 'calc(100vh - 48px)',
            background: '#ffffff',
            borderRadius: '16px',
            boxShadow: '0 12px 40px rgba(0, 0, 0, 0.22)',
            border: '1px solid #e2e8f0',
            zIndex: 10000,
            display: 'flex',
            flexDirection: 'column',
            overflow: 'hidden',
            fontFamily: 'inherit',
          }}
        >
          {/* Header */}
          <div
            style={{
              background: '#071a31',
              color: '#ffffff',
              padding: '14px 16px',
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'space-between',
            }}
          >
            <div style={{ display: 'flex', alignItems: 'center', gap: '10px' }}>
              <div
                style={{
                  width: '32px',
                  height: '32px',
                  borderRadius: '50%',
                  background: 'rgba(255, 255, 255, 0.15)',
                  display: 'flex',
                  alignItems: 'center',
                  justifyContent: 'center',
                }}
              >
                <Headphones size={18} />
              </div>
              <div>
                <div style={{ fontSize: '14px', fontWeight: 700, display: 'flex', alignItems: 'center', gap: '6px' }}>
                  ZAMERIA Support
                  <span
                    style={{
                      fontSize: '10px',
                      background: 'rgba(34, 197, 94, 0.2)',
                      color: '#4ade80',
                      padding: '1px 6px',
                      borderRadius: '8px',
                      fontWeight: 600,
                    }}
                  >
                    Online
                  </span>
                </div>
                <div style={{ fontSize: '11px', opacity: 0.8 }}>
                  Connected via {source}
                </div>
              </div>
            </div>

            <div style={{ display: 'flex', alignItems: 'center', gap: '6px' }}>
              {conversation?.status === 'Resolved' ? (
                <span
                  style={{
                    fontSize: '11px',
                    background: 'rgba(16, 185, 129, 0.2)',
                    color: '#6ee7b7',
                    padding: '2px 8px',
                    borderRadius: '10px',
                  }}
                >
                  Resolved
                </span>
              ) : (
                <button
                  onClick={handleResolve}
                  title="Mark as resolved"
                  style={{
                    background: 'transparent',
                    border: '1px solid rgba(255, 255, 255, 0.25)',
                    color: '#e2e8f0',
                    fontSize: '11px',
                    padding: '3px 8px',
                    borderRadius: '6px',
                    cursor: 'pointer',
                  }}
                >
                  Resolve
                </button>
              )}

              <button
                onClick={() => closeSupportChat()}
                style={{
                  background: 'transparent',
                  border: 'none',
                  color: '#ffffff',
                  cursor: 'pointer',
                  padding: '4px',
                  display: 'flex',
                }}
              >
                <X size={18} />
              </button>
            </div>
          </div>

          {/* Context Banner */}
          <div
            style={{
              padding: '8px 14px',
              background: '#f8fafc',
              borderBottom: '1px solid #e2e8f0',
              fontSize: '11px',
              color: '#64748b',
              display: 'flex',
              justifyContent: 'space-between',
              alignItems: 'center',
            }}
          >
            <span>
              Account: <strong style={{ color: '#0f172a' }}>{businessName}</strong>
            </span>
            <span style={{ color: conversation?.status === 'Resolved' ? '#10b981' : '#2563eb', fontWeight: 600 }}>
              Status: {conversation?.status || 'Open'}
            </span>
          </div>

          {/* Messages Stream */}
          <div
            style={{
              flex: 1,
              overflowY: 'auto',
              padding: '14px',
              background: '#f1f5f9',
              display: 'flex',
              flexDirection: 'column',
              gap: '10px',
            }}
          >
            {!conversation?.messages.length ? (
              <div style={{ textAlign: 'center', padding: '30px 10px', color: '#94a3b8', fontSize: '13px' }}>
                <Headphones size={28} style={{ margin: '0 auto 8px', opacity: 0.5 }} />
                <p style={{ margin: 0, fontWeight: 600, color: '#475569' }}>How can we help you today?</p>
                <p style={{ margin: '4px 0 0', fontSize: '12px' }}>
                  Our team sees your store diagnostic context automatically.
                </p>
              </div>
            ) : (
              conversation?.messages.map((msg) => {
                const isCustomer = msg.senderType === 'customer';
                return (
                  <div
                    key={msg.id}
                    style={{
                      display: 'flex',
                      flexDirection: 'column',
                      alignItems: isCustomer ? 'flex-end' : 'flex-start',
                      gap: '2px',
                    }}
                  >
                    <span style={{ fontSize: '10px', color: '#94a3b8', margin: '0 4px' }}>
                      {isCustomer ? 'You' : msg.senderName || 'ZAMERIA Support'} •{' '}
                      {new Date(msg.createdAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                    </span>
                    <div
                      style={{
                        maxWidth: '82%',
                        padding: '9px 13px',
                        borderRadius: isCustomer ? '14px 14px 2px 14px' : '14px 14px 14px 2px',
                        background: isCustomer ? '#071a31' : '#ffffff',
                        color: isCustomer ? '#ffffff' : '#0f172a',
                        border: isCustomer ? 'none' : '1px solid #cbd5e1',
                        fontSize: '13px',
                        lineHeight: '1.4',
                        boxShadow: '0 1px 3px rgba(0,0,0,0.06)',
                        wordBreak: 'break-word',
                        whiteSpace: 'pre-wrap',
                      }}
                    >
                      {msg.message}
                    </div>
                  </div>
                );
              })
            )}
            <div ref={messagesEndRef} />
          </div>

          {deliveryError && <p role="alert" style={{color:'#b91c1c',padding:'8px 12px',margin:0}}>{deliveryError}</p>}
          {/* Compose Form */}
          <form
            onSubmit={handleSendMessage}
            style={{
              padding: '10px',
              borderTop: '1px solid #e2e8f0',
              background: '#ffffff',
              display: 'flex',
              gap: '8px',
              alignItems: 'center',
            }}
          >
            <input
              type="text"
              placeholder={
                conversation?.status === 'Resolved'
                  ? 'Type to reopen conversation...'
                  : 'Type your message...'
              }
              style={{
                flex: 1,
                border: '1px solid #cbd5e1',
                borderRadius: '20px',
                padding: '8px 14px',
                fontSize: '13px',
                outline: 'none',
              }}
              value={messageText}
              onChange={(e) => setMessageText(e.target.value)}
            />
            <button
              type="submit"
              disabled={!messageText.trim() || sending}
              style={{
                background: '#071a31',
                color: '#ffffff',
                border: 'none',
                borderRadius: '50%',
                width: '36px',
                height: '36px',
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
                cursor: messageText.trim() ? 'pointer' : 'default',
                opacity: messageText.trim() ? 1 : 0.5,
              }}
            >
              <Send size={15} />
            </button>
          </form>
        </div>
    </>
  );
};
