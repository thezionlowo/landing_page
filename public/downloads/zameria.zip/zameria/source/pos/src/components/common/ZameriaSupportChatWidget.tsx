import React, { useState, useEffect, useRef } from 'react';
import { Drawer, Button } from '@/components/ui';
import { Send, Headphones } from 'lucide-react';
import {
  supportChatClient,
  SupportConversation,
  SupportSource
} from '@/services/supportChatClient';
import { useAuthStore, useUIStore, useConnectionStore } from '@/store';

interface ZameriaSupportChatWidgetProps {
  source?: SupportSource;
  customPosition?: { bottom?: number; right?: number };
}

export const ZameriaSupportChatWidget: React.FC<ZameriaSupportChatWidgetProps> = ({
  source = 'POS',
}) => {
  const { user } = useAuthStore();
  const { storeUrl: connStoreUrl, storeName: connStoreName } = useConnectionStore();
  const isSupportChatOpen = useUIStore((s) => s.isSupportChatOpen);
  const closeSupportChat = useUIStore((s) => s.closeSupportChat);
  const [conversation, setConversation] = useState<SupportConversation | null>(null);
  const [messageText, setMessageText] = useState('');
  const messagesEndRef = useRef<HTMLDivElement>(null);

  // Auto-resolve customer identification from session/auth store and connection store
  const activeStoreName = user?.storeName || connStoreName || 'ZAMERIA Store';
  const businessName = activeStoreName;
  const activeStoreUrl = user?.storeUrl || connStoreUrl || (typeof window !== 'undefined' ? window.location.origin : '');

  const [sending,setSending]=useState(false);
  const [deliveryError,setDeliveryError]=useState('');
  useEffect(() => {
    setConversation(null);setDeliveryError('');
  },[user?.id,user?.token,activeStoreUrl]);
  useEffect(() => {
    if(!user?.token)return;
    let active=true;let inFlight=false;
    const refresh=async()=>{if(inFlight)return;inFlight=true;try{
      const value=await supportChatClient.getConversation();
      if(active){setConversation(value);}
    }catch(e){if(active)setDeliveryError(e instanceof Error?e.message:'Could not load support replies');}finally{inFlight=false}};
    void refresh();const timer=setInterval(refresh,isSupportChatOpen?6000:15000);return()=>{active=false;clearInterval(timer)};
  },[isSupportChatOpen,user?.token,activeStoreUrl]);
  useEffect(()=>{
    if(isSupportChatOpen){messagesEndRef.current?.scrollIntoView({behavior:'smooth'});if(conversation?.unreadByCustomer)void supportChatClient.markAsReadByCustomer(conversation.id).catch(()=>{});}
  },[isSupportChatOpen,conversation?.messages.length]);
  const handleSendMessage=async(e:React.FormEvent)=>{
    e.preventDefault();if(!messageText.trim()||sending)return;
    const text=messageText.trim();setSending(true);setDeliveryError('');
    try{const value=conversation?await supportChatClient.sendMessage(conversation.id,text):await supportChatClient.getOrCreateConversation({initialMessage:text});
      if(!value)throw Error('Support did not confirm delivery');setConversation(value);setMessageText('');
    }catch(e){setDeliveryError(e instanceof Error?e.message:'Message was not delivered. Please retry.');}finally{setSending(false)}
  };
  const handleResolve=async()=>{if(!conversation||sending)return;setSending(true);try{await supportChatClient.resolveConversation(conversation.id);setConversation(await supportChatClient.getConversation());}catch(e){setDeliveryError(e instanceof Error?e.message:'Could not close conversation')}finally{setSending(false)}};

  if (!isSupportChatOpen) {
    return null;
  }

  return (
    <Drawer open={isSupportChatOpen} onClose={closeSupportChat} width="md" title={<span className="flex items-center gap-3"><Headphones className="w-5 h-5" />ZAMERIA Support</span>} bodyClassName="pos-support-body" footer={
      <div className="w-full space-y-3">
        {deliveryError && <p role="alert" className="text-sm text-danger">{deliveryError}</p>}
        <form onSubmit={handleSendMessage} className="pos-support-composer flex items-stretch gap-2">
          <label className="flex-1 min-w-0 flex"><span className="sr-only">Message to support</span><textarea rows={2} value={messageText} onChange={event=>setMessageText(event.target.value)} placeholder={conversation?.status === 'Resolved' ? 'Type to reopen conversation…' : 'Write your message…'} className="block w-full resize-none rounded-md border border-outline-variant bg-surface px-3 py-2 text-sm text-on-surface focus:outline-none focus:border-accent" /></label>
          <Button type="submit" loading={sending} disabled={!messageText.trim() || sending} aria-label="Send message" className="pos-support-send" icon={<Send className="w-4 h-4" />} />
        </form>
      </div>
    }>
      <div className="flex items-start justify-between gap-3 p-5 border-b border-outline-variant shrink-0">
        <div className="min-w-0"><p className="text-sm font-semibold text-on-surface truncate">{businessName}</p><p className="text-xs text-on-surface-variant mt-1">{source} · {conversation?.status || 'New conversation'}</p></div>
        {conversation && conversation.status !== 'Resolved' && <Button size="sm" variant="secondary" disabled={sending} onClick={handleResolve}>Resolve</Button>}
      </div>
      <div className="flex-1 min-h-0 overflow-y-auto p-5 space-y-5 bg-surface-container-low" role="log" aria-label="Support messages" aria-live="polite">
        {!conversation?.messages.length ? <div className="text-center py-16 px-4 text-on-surface-variant"><Headphones className="w-9 h-9 mx-auto mb-4 opacity-50" /><h3 className="text-base font-semibold text-on-surface">How can we help?</h3><p className="text-sm mt-2">Describe what happened. Your store context is included so our team can help.</p></div> : conversation.messages.map(message=>{
          const own = message.senderType === 'customer';
          return <div key={message.id} className={`flex flex-col gap-1.5 ${own ? 'items-end' : 'items-start'}`}><p className="text-xs text-on-surface-variant">{own ? 'You' : message.senderName || 'ZAMERIA Support'} · {new Date(message.createdAt).toLocaleTimeString([], {hour:'2-digit',minute:'2-digit'})}</p><div className={`max-w-[88%] rounded-2xl px-4 py-3 text-sm whitespace-pre-wrap break-words ${own ? 'bg-primary text-on-primary rounded-br-sm' : 'bg-surface text-on-surface border border-outline-variant rounded-bl-sm'}`}>{message.message}</div></div>;
        })}
        <div ref={messagesEndRef} />
      </div>
    </Drawer>
  );
};
