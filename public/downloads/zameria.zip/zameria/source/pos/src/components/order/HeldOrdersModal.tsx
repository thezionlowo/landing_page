import React, { useState } from 'react';
import { useLiveQuery } from 'dexie-react-hooks';
import { Clock, ShoppingBag, Trash2, ArrowRight, User, AlertCircle, AlertTriangle } from 'lucide-react';
import { toast } from 'sonner';
import { db } from '@/db';
import { useCartStore } from '@/store/cartStore';
import { useAuthStore } from '@/store/authStore';
import { isOrderAccessibleToUser } from '@/services/auth/orderAccess';
import { formatMoney } from '@/lib';
import { Modal, Button, Badge } from '@/components/ui';
import type { Order, OrderItem } from '@/types';

interface HeldOrdersModalProps {
  open: boolean;
  onClose: () => void;
  onOrderResumed?: (order: Order) => void;
}

export const HeldOrdersModal: React.FC<HeldOrdersModalProps> = ({
  open,
  onClose,
  onOrderResumed,
}) => {
  const { user } = useAuthStore();
  const cart = useCartStore();

  const [confirmResumeOrder, setConfirmResumeOrder] = useState<Order | null>(null);
  const [orderToDiscard, setOrderToDiscard] = useState<Order | null>(null);
  const [isProcessing, setIsProcessing] = useState(false);

  // Live query for all on-hold orders, filtered by author/user accessibility
  const heldOrders = useLiveQuery(async () => {
    const orders = await db.orders
      .where('status')
      .equals('on-hold')
      .reverse()
      .sortBy('createdAt');

    return orders.filter((o) => isOrderAccessibleToUser(o, user));
  }, [user]);

  // Live query for all items of held orders
  const heldItems = useLiveQuery(async () => {
    if (!heldOrders || heldOrders.length === 0) return new Map<number, OrderItem[]>();
    const orderIds = heldOrders.map((o) => o.id);
    const items = await db.orderItems.where('orderId').anyOf(orderIds).toArray();
    const map = new Map<number, OrderItem[]>();
    for (const item of items) {
      if (!map.has(item.orderId)) map.set(item.orderId, []);
      map.get(item.orderId)!.push(item);
    }
    return map;
  }, [heldOrders]);

  const handleResumeClick = (order: Order) => {
    if (cart.items.length > 0) {
      setConfirmResumeOrder(order);
    } else {
      executeResume(order);
    }
  };

  const executeResume = async (order: Order) => {
    setIsProcessing(true);
    try {
      const res = await cart.loadOrderIntoCart(order.id);
      if (res.success) {
        if (res.warnings && res.warnings.length > 0) {
          toast.warning(res.warnings.join(' '));
        }
        toast.success(`Resumed order ${order.orderNumber} into active basket`);
        onOrderResumed?.(order);
        onClose();
      } else {
        toast.error('Could not resume order: ' + (res.warnings?.join(' ') || 'Unknown error'));
      }
    } catch {
      toast.error('Failed to load held order into cart');
    } finally {
      setIsProcessing(false);
      setConfirmResumeOrder(null);
    }
  };

  const executeDiscard = async (order: Order) => {
    setIsProcessing(true);
    try {
      await db.transaction('rw', db.orders, db.orderItems, async () => {
        await db.orderItems.where('orderId').equals(order.id).delete();
        await db.orders.delete(order.id);
      });
      toast.info(`Held order ${order.orderNumber} discarded`);
    } catch {
      toast.error('Failed to discard held order');
    } finally {
      setIsProcessing(false);
      setOrderToDiscard(null);
    }
  };

  return (
    <>
      <Modal
        open={open}
        onClose={onClose}
        title={
          <div className="flex items-center gap-2">
            <Clock className="w-5 h-5 text-primary" />
            <span>Held Orders</span>
            {heldOrders && heldOrders.length > 0 && (
              <Badge variant="warning" size="sm">
                {heldOrders.length}
              </Badge>
            )}
          </div>
        }
        size="lg"
      >
        <div className="space-y-4 max-h-[70vh] flex flex-col">
          {!heldOrders || heldOrders.length === 0 ? (
            <div className="py-12 flex flex-col items-center justify-center text-center text-surface-400">
              <ShoppingBag className="w-12 h-12 mb-3 stroke-[1.5] text-surface-300" />
              <p className="text-sm font-semibold text-on-surface">No Orders on Hold</p>
              <p className="text-xs text-surface-500 mt-1 max-w-[280px]">
                Orders saved as on-hold from the cart will appear here so you can continue them anytime.
              </p>
            </div>
          ) : (
            <div className="overflow-y-auto space-y-3 pr-1 divide-y divide-surface-100">
              {heldOrders.map((order) => {
                const items = heldItems?.get(order.id) || [];
                const d = new Date(order.createdAt);
                const timeStr = d.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
                const dateStr = d.toLocaleDateString([], { month: 'short', day: 'numeric' });

                return (
                  <div
                    key={order.id}
                    className="pt-3 first:pt-0 pb-1 flex flex-col sm:flex-row sm:items-center justify-between gap-3 group"
                  >
                    <div className="space-y-1.5 flex-1 min-w-0">
                      <div className="flex items-center gap-2 flex-wrap">
                        <span className="font-mono text-xs font-bold text-on-surface">
                          {order.orderNumber}
                        </span>
                        <Badge variant="warning" size="sm">
                          On-Hold
                        </Badge>
                        <span className="text-xs text-surface-400 flex items-center gap-1">
                          <Clock className="w-3 h-3" /> {dateStr} at {timeStr}
                        </span>
                      </div>

                      <div className="flex items-center gap-3 text-xs text-surface-600">
                        <span className="flex items-center gap-1 font-medium text-on-surface">
                          <User className="w-3.5 h-3.5 text-surface-400" />
                          {order.customerName || 'Walk-in Customer'}
                        </span>
                        <span>•</span>
                        <span>{order.itemCount} item{order.itemCount === 1 ? '' : 's'}</span>
                        <span>•</span>
                        <span className="font-bold text-on-surface tabular-nums">
                          {formatMoney(order.total)}
                        </span>
                      </div>

                      {/* Items list preview */}
                      {items.length > 0 && (
                        <div className="flex items-center gap-1.5 flex-wrap pt-0.5">
                          {items.slice(0, 3).map((it) => (
                            <span
                              key={it.id}
                              className="text-xs px-1.5 py-0.5 bg-surface-100 dark:bg-surface-800 text-surface-700 dark:text-surface-300 rounded border border-surface-200 dark:border-surface-700 truncate max-w-[140px]"
                            >
                              {it.quantity}x {it.name}
                            </span>
                          ))}
                          {items.length > 3 && (
                            <span className="text-xs text-surface-400 font-medium">
                              +{items.length - 3} more
                            </span>
                          )}
                        </div>
                      )}
                    </div>

                    <div className="flex items-center gap-2 flex-shrink-0 self-end sm:self-center pt-1 sm:pt-0">
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => setOrderToDiscard(order)}
                        className="text-danger hover:bg-danger-container hover:text-danger h-8 px-2.5"
                        title="Discard this held order"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                        <span className="text-xs">Discard</span>
                      </Button>
                      <Button
                        variant="primary"
                        size="sm"
                        onClick={() => handleResumeClick(order)}
                        className="h-8 px-3.5 font-bold shadow-xs flex items-center gap-1.5"
                      >
                        <span>Resume</span>
                        <ArrowRight className="w-3.5 h-3.5" />
                      </Button>
                    </div>
                  </div>
                );
              })}
            </div>
          )}

          <div className="pt-3 border-t border-surface-200 flex justify-end">
            <Button variant="secondary" size="sm" onClick={onClose}>
              Close
            </Button>
          </div>
        </div>
      </Modal>

      {/* CONFIRM REPLACE BASKET MODAL */}
      <Modal
        open={Boolean(confirmResumeOrder)}
        onClose={() => setConfirmResumeOrder(null)}
        title="Active Sale in Progress"
        size="sm"
      >
        <div className="space-y-4">
          <div className="flex items-start gap-3">
            <AlertTriangle className="w-5 h-5 text-amber-600 flex-shrink-0 mt-0.5" />
            <p className="text-xs text-surface-600 leading-relaxed">
              You currently have an active basket with {cart.items.length} item
              {cart.items.length === 1 ? '' : 's'}. Continuing held order{' '}
              <strong>{confirmResumeOrder?.orderNumber}</strong> will replace your active basket.
            </p>
          </div>
          <div className="flex justify-end gap-2 pt-2">
            <Button
              variant="secondary"
              size="sm"
              onClick={() => setConfirmResumeOrder(null)}
              disabled={isProcessing}
            >
              Cancel
            </Button>
            <Button
              variant="primary"
              size="sm"
              onClick={() => confirmResumeOrder && executeResume(confirmResumeOrder)}
              loading={isProcessing}
              className="font-bold"
            >
              Replace &amp; Resume
            </Button>
          </div>
        </div>
      </Modal>

      {/* CONFIRM DISCARD MODAL */}
      <Modal
        open={Boolean(orderToDiscard)}
        onClose={() => setOrderToDiscard(null)}
        title="Discard Held Order"
        size="sm"
      >
        <div className="space-y-4">
          <div className="flex items-start gap-3">
            <AlertCircle className="w-5 h-5 text-danger flex-shrink-0 mt-0.5" />
            <p className="text-xs text-surface-600 leading-relaxed">
              Are you sure you want to discard order{' '}
              <strong>{orderToDiscard?.orderNumber}</strong>? This will remove the held order
              permanently.
            </p>
          </div>
          <div className="flex justify-end gap-2 pt-2">
            <Button
              variant="secondary"
              size="sm"
              onClick={() => setOrderToDiscard(null)}
              disabled={isProcessing}
            >
              Keep Order
            </Button>
            <Button
              variant="destructive"
              size="sm"
              onClick={() => orderToDiscard && executeDiscard(orderToDiscard)}
              loading={isProcessing}
              className="font-bold"
            >
              Discard Order
            </Button>
          </div>
        </div>
      </Modal>
    </>
  );
};
