import React from 'react';
import { cn } from '@/lib';

export type CardVariant = 'outlined' | 'elevated' | 'filled';

export interface CardProps extends React.HTMLAttributes<HTMLDivElement> {
  variant?: CardVariant;
  children: React.ReactNode;
}

export function Card({ variant = 'outlined', className, children, ...props }: CardProps) {
  const variantClass = {
    outlined: 'm3-card-outlined',
    elevated: 'm3-card-elevated',
    filled: 'm3-card-filled',
  }[variant];

  return (
    <div className={cn('overflow-hidden', variantClass, className)} {...props}>
      {children}
    </div>
  );
}

export function CardHeader({ className, children, ...props }: React.HTMLAttributes<HTMLDivElement>) {
  return (
    <div className={cn('px-4 py-3 border-b border-surface-200 dark:border-surface-200/40 flex items-center justify-between', className)} {...props}>
      {children}
    </div>
  );
}

export function CardTitle({ className, children, ...props }: React.HTMLAttributes<HTMLHeadingElement>) {
  return (
    <h3 className={cn('text-xs font-bold text-surface-900 dark:text-surface-800 tracking-tight', className)} {...props}>
      {children}
    </h3>
  );
}

export function CardDescription({ className, children, ...props }: React.HTMLAttributes<HTMLParagraphElement>) {
  return (
    <p className={cn('text-[11px] text-surface-500 font-normal mt-0.5', className)} {...props}>
      {children}
    </p>
  );
}

export function CardContent({ className, children, ...props }: React.HTMLAttributes<HTMLDivElement>) {
  return (
    <div className={cn('p-4', className)} {...props}>
      {children}
    </div>
  );
}

export function CardFooter({ className, children, ...props }: React.HTMLAttributes<HTMLDivElement>) {
  return (
    <div className={cn('px-4 py-3 border-t border-surface-200 dark:border-surface-200/40 bg-surface-50/50 dark:bg-surface-200/20 flex items-center justify-between', className)} {...props}>
      {children}
    </div>
  );
}
