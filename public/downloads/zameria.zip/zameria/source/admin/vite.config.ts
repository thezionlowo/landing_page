import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';
import tailwindcss from '@tailwindcss/vite';
import path from 'path';

export default defineConfig({
  base: './',
  plugins: [
    react(),
    tailwindcss(),
  ],
  resolve: {
    alias: {
      '@': path.resolve(__dirname, './src'),
    },
  },
  server: {
    port: 5182,
    host: '0.0.0.0',
    open: false,
  },
  build: {
    outDir: process.env.ZAMERIA_ADMIN_OUT_DIR || path.resolve(__dirname, '../plugin/zameria/admin-app'),
    emptyOutDir: true,
    manifest: true,
  },
});
