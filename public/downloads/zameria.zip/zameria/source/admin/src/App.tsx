import React, { useState, useEffect } from 'react';
import { PluginTab, PosDevice, AuthoritativeEntitlement } from '@/types/plugin';
import { adminAction } from '@/lib/admin-api';
import { PluginHeader } from '@/components/layout/PluginHeader';
import { PluginNav } from '@/components/layout/PluginNav';
import { ConnectStoreScreen } from '@/components/screens/ConnectStoreScreen';
import { DashboardScreen } from '@/components/screens/DashboardScreen';
import { DevicesScreen } from '@/components/screens/DevicesScreen';
import { StaffScreen } from '@/components/screens/StaffScreen';
import { AccountScreen } from '@/components/screens/AccountScreen';
import { SettingsScreen } from '@/components/screens/SettingsScreen';
import { licensingOffEntitlement, normalizeWpEntitlement, resolveScreenForEntitlement } from '@/lib/lifecycleData';
import { LICENSING_ENABLED, zameriaBackendClient } from '@/lib/zameriaBackendClient';

export function App() {
  const runtime = (typeof window !== 'undefined' && (window as any).ZAMERIA_ADMIN) || {};

  // Hydrate initial live entitlement authoritatively from cache or WordPress runtime
  const [liveEntitlement, setLiveEntitlement] = useState<AuthoritativeEntitlement>(() => {
    if (!LICENSING_ENABLED) return licensingOffEntitlement();
    const cached = zameriaBackendClient.getCachedEntitlement();
    if (cached) return cached;
    if (runtime.entitlement) {
      return normalizeWpEntitlement(runtime.entitlement, runtime.storeUrl, runtime.storeName);
    }
    return normalizeWpEntitlement(null, runtime.storeUrl, runtime.storeName);
  });

  const [activeTab, setActiveTab] = useState<PluginTab>(() => {
    if (typeof window !== 'undefined') {
      const params = new URLSearchParams(window.location.search);
      const tabParam = params.get('tab');
      if (tabParam && ['overview', 'devices', 'staff', 'subscription', 'settings'].includes(tabParam)) {
        return tabParam as PluginTab;
      }
      const pageParam = params.get('page');
      if (pageParam === 'zameria-devices') return 'devices';
      if (pageParam === 'zameria-staff') return 'staff';
      if (pageParam === 'zameria-subscription' || pageParam === 'zameria-account' || pageParam === 'zameria-license') return 'subscription';
      if (pageParam === 'zameria-settings') return 'settings';
    }
    if (runtime.initialTab) return runtime.initialTab;
    return 'overview';
  });

  const handleSelectTab = (tab: PluginTab) => {
    setActiveTab(tab);
    if (typeof window !== 'undefined' && window.history && window.history.replaceState) {
      const url = new URL(window.location.href);
      if (tab === 'overview') {
        url.searchParams.set('page', 'zameria');
        url.searchParams.delete('tab');
      } else {
        url.searchParams.set('page', `zameria-${tab}`);
      }
      window.history.replaceState({}, '', url.toString());
    }
  };
  const [devices, setDevices] = useState<PosDevice[]>(() => runtime.devices || []);
  const [connectionError,setConnectionError]=useState<string|null>(null);
  const [requiresReconnect, setRequiresReconnect] = useState(runtime.storeAccessReady === false && ['trial_active', 'paid_active', 'gifted_active'].includes(runtime.entitlement?.status));

  // Poll / refresh live backend entitlement on initial mount
  const refreshEntitlementFromBackend = async () => {
    if (!LICENSING_ENABLED) return;
    const storeTarget = runtime.storeUrl || (typeof window !== 'undefined' ? window.location.origin : '');
    const res = await zameriaBackendClient.getEntitlement(storeTarget);
    if (res.success && res.entitlement) {
      setLiveEntitlement(res.entitlement);
      if (!res.isOffline) setRequiresReconnect(false);
    } else if (res.requiresReconnect) {
      setRequiresReconnect(true);
    }
  };

  useEffect(() => {
    refreshEntitlementFromBackend();
  }, []);

  // Strict connector connection determination:
  // Fresh install / trial_not_started / unactivated = NOT CONNECTED
  const isConnected = Boolean(
    !requiresReconnect &&
    liveEntitlement &&
    liveEntitlement.status !== 'unactivated' &&
    (liveEntitlement.status as any) !== 'trial_not_started' &&
    (
      liveEntitlement.status === 'trial_active' ||
      liveEntitlement.status === 'paid_active' ||
      (liveEntitlement.status as any) === 'gifted_active' ||
      liveEntitlement.status === 'trial_expired' ||
      (liveEntitlement.status as any) === 'paid_expired' ||
      liveEntitlement.status === 'licensing_off'
    )
  );

  const rawPlanStr = String(
    liveEntitlement.plan ||
    liveEntitlement.subscription?.plan_name ||
    liveEntitlement.plan_name ||
    runtime.entitlement?.plan ||
    ''
  ).toLowerCase();

  const isBusinessPlan = rawPlanStr.includes('business');
  const isStarter = !isBusinessPlan && (
    rawPlanStr.includes('starter') ||
    liveEntitlement.status === 'trial_active'
  );
  const maxDevices = isBusinessPlan || liveEntitlement.status === 'trial_active' ? null : (isStarter ? 2 : null);

  useEffect(() => {
    if (!isConnected) return;
    let stopped = false;
    let refreshing = false;
    const refresh = async () => {
      if (refreshing) return;
      refreshing = true;
      try {
        const result = await adminAction<{ devices: PosDevice[] }>('zameria_admin_get_devices');
        if (!stopped && Array.isArray(result.devices)) setDevices(result.devices);
      } catch { /* Keep the last server snapshot; explicit refresh reports errors. */ }
      finally { refreshing = false; }
    };
    void refresh();
    const timer = setInterval(() => void refresh(), 30_000);
    window.addEventListener('focus', refresh);
    return () => { stopped = true; clearInterval(timer); window.removeEventListener('focus', refresh); };
  }, [isConnected]);

  const getPosLaunchUrl = () => {
    const runtimeConfig = (typeof window !== 'undefined' && (window as any).ZAMERIA_ADMIN) || {};
    if (runtimeConfig.posUrl) return runtimeConfig.posUrl;
    if (runtimeConfig.localPosUrl) return runtimeConfig.localPosUrl;

    let rawStoreUrl =
      liveEntitlement?.store_url ||
      (typeof window !== 'undefined' ? window.location.origin : '');

    let cleanStoreUrl = rawStoreUrl.trim();
    if (!/^https?:\/\//i.test(cleanStoreUrl)) {
      cleanStoreUrl = `https://${cleanStoreUrl}`;
    }

    if (typeof window !== 'undefined' && (window.location.hostname === 'localhost' || window.location.hostname === '127.0.0.1')) {
      return `http://localhost:5176/?store_url=${encodeURIComponent(cleanStoreUrl)}`;
    }

    return `/pos/?store_url=${encodeURIComponent(cleanStoreUrl)}`;
  };

  const handleOpenPOS = () => {
    const launchUrl = getPosLaunchUrl();
    window.open(launchUrl, '_blank', 'noopener,noreferrer');
  };

  const handleConnected = (newEntitlement: AuthoritativeEntitlement) => {
    setLiveEntitlement(newEntitlement);
    setRequiresReconnect(false);
    handleSelectTab('overview');
  };

  const handleDisconnect = async () => {
    setConnectionError(null);
    try { await zameriaBackendClient.disconnect(); }
    catch(error) { setConnectionError(error instanceof Error?error.message:'Could not disconnect this store. Please retry.');return; }
    const reset = normalizeWpEntitlement(null, runtime.storeUrl, runtime.storeName);
    setLiveEntitlement(reset);
    handleSelectTab('overview');
  };

  // Determine current screen content
  const renderContent = () => {
    // 1. Unconnected / fresh onboarding state
    if (!isConnected) {
      return (
        <ConnectStoreScreen
          onConnected={handleConnected}
        />
      );
    }

    // 2. Connected state: Tabs
    if (activeTab === 'devices') {
      return (
        <DevicesScreen
          devices={devices}
          onDevicesChange={setDevices}
          entitlement={liveEntitlement}
          onNavigateTab={handleSelectTab}
          onOpenPOS={handleOpenPOS}
        />
      );
    }

    if (activeTab === 'staff') {
      return (
        <StaffScreen
          entitlement={liveEntitlement}
          onNavigateTab={handleSelectTab}
        />
      );
    }

    if (activeTab === 'subscription' || activeTab === 'account' || activeTab === 'license') {
      return (
        <AccountScreen
          entitlement={liveEntitlement}
          onNavigateTab={handleSelectTab}
        />
      );
    }

    if (activeTab === 'settings' || activeTab === 'help' || activeTab === 'connection' || activeTab === 'sync') {
      return (
        <SettingsScreen
          onDisconnect={handleDisconnect}
        />
      );
    }

    // Overview Screen (Default when connected)
    return (
      <DashboardScreen
        currentScreen={resolveScreenForEntitlement(liveEntitlement)}
        liveEntitlement={liveEntitlement}
        deviceCount={devices.length}
        deviceLimit={maxDevices}
        onNavigateTab={handleSelectTab}
        onOpenPOS={handleOpenPOS}
        onActivateTrial={() => handleSelectTab('subscription')}
        onRefreshEntitlement={refreshEntitlementFromBackend}
        onDisconnect={handleDisconnect}
      />
    );
  };

  return (
    <div className={`zameria-admin zm-workspace ${isConnected ? '' : 'zm-workspace-onboarding'}`}>
      {isConnected && <aside className="zm-sidebar">
        <div className="zm-sidebar-brand"><img src={`${runtime.assetsUrl || './'}zameria-logo.png`} alt="ZAMERIA" /><span>STORE WORKSPACE</span></div>
        <PluginNav activeTab={activeTab} onSelectTab={handleSelectTab} deviceCount={devices.length} deviceLimit={maxDevices} />
        <div className="zm-sidebar-footer"><span>WOOCOMMERCE CONNECTOR</span><strong>{runtime.storeName || liveEntitlement.store_name || 'Your store'}</strong><small>Plugin {runtime.version || '—'}</small></div>
      </aside>}
      <div className="zm-workspace-main">
        <PluginHeader isConnected={isConnected} entitlement={liveEntitlement} currentScreen={resolveScreenForEntitlement(liveEntitlement)} onOpenPOS={handleOpenPOS} />
        <main className="zm-content" id="zm-main-content">
          {requiresReconnect && <p role="alert" className="zm-notice zm-notice-warning">Finish updating your store connection: sign in below with your existing ZAMERIA account. This restores POS access using your current subscription.</p>}
          {connectionError && <p role="alert" className="zm-notice zm-notice-error">{connectionError}</p>}
          {renderContent()}
        </main>
      </div>
    </div>
  );
}

export default App;
