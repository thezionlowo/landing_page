import React from 'react';
/** The portal uses its own secure session. Never pass credentials or tokens in a URL. */
export function websiteAccountUrl(): string {
  const env = (import.meta as any).env || {};
  const custom = env.VITE_ACCOUNT_PORTAL_URL;
  if (custom) return custom;
  if (env.DEV && typeof window !== 'undefined' && ['localhost', '127.0.0.1'].includes(window.location.hostname)) return 'http://localhost:5174/account';
  return 'https://zameria.co/account';
}
export function WebsiteAccountLink({ email }: { email?: string }) {
  return <aside className="rounded-xl border border-blue-200 bg-blue-50 p-5 text-left space-y-2" aria-label="Your ZAMERIA website account">
    <h2 className="text-base font-bold text-[#071A31]">Your account is also on the ZAMERIA website</h2>
    <p className="text-sm text-slate-600 leading-relaxed">Manage your subscription, billing and store settings at zameria.co. Log in with the same ZAMERIA email and password you used here{email ? ` (${email})` : ''}. You do not need to create another account.</p>
    <a href={websiteAccountUrl()} target="_blank" rel="noopener noreferrer" className="inline-flex font-semibold text-sm text-blue-700 underline underline-offset-4">Manage my ZAMERIA account <span className="sr-only">(opens in a new tab)</span></a>
  </aside>;
}
