import React, { useState } from 'react';
import {
  Sliders,
  CheckCircle2,
  AlertCircle,
  Mail,
  ExternalLink,
  ShieldCheck,
  Check,
  FileText,
  Server,
} from 'lucide-react';
import { Card, CardHeader, CardTitle, CardDescription, CardContent } from '@/components/ui/Card';
import { Button } from '@/components/ui/Button';
import { Badge } from '@/components/ui/Badge';
import { adminAction } from '@/lib/admin-api';

interface SettingsScreenProps {
  onDisconnect?: () => void;
}

export function SettingsScreen({ onDisconnect }: SettingsScreenProps) {
  const runtime = (typeof window !== 'undefined' && (window as any).ZAMERIA_ADMIN) || {};
  const [paymentMethods, setPaymentMethods] = useState(runtime.paymentMethods || '');
  const [receiptFooter, setReceiptFooter] = useState(runtime.receiptFooter || '');
  const [isSaving, setIsSaving] = useState(false);
  const [saveMessage, setSaveMessage] = useState<{ type: 'success' | 'error'; text: string } | null>(null);

  const health = runtime.health || {};
  const checks = health.checks || {};

  const handleSave = async () => {
    setIsSaving(true);
    setSaveMessage(null);
    try {
      await adminAction<any>('zameria_admin_save_settings', {
        payment_methods: paymentMethods,
        receipt_footer: receiptFooter,
      });
      if (runtime) {
        runtime.paymentMethods = paymentMethods;
        runtime.receiptFooter = receiptFooter;
      }
      setSaveMessage({ type: 'success', text: 'POS payment methods and receipt footer saved successfully.' });
      setTimeout(() => setSaveMessage(null), 4000);
    } catch (error) {
      setSaveMessage({
        type: 'error',
        text: error instanceof Error ? error.message : 'Unable to save settings.',
      });
    } finally {
      setIsSaving(false);
    }
  };

  return (
    <div className="space-y-6 max-w-4xl mx-auto">
      {/* HEADER */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-xl sm:text-2xl font-bold tracking-tight text-[#071A31]">
            Plugin & POS Settings
          </h2>
          <p className="text-xs text-[#64748B] mt-1">
            Configure till payment options, receipt footer, and review system bridge diagnostics.
          </p>
        </div>

        {onDisconnect && (
          <Button variant="outline" size="sm" onClick={onDisconnect}>
            Disconnect store
          </Button>
        )}
      </div>

      {saveMessage && (
        <div
          className={`p-3.5 rounded-xl border text-xs font-medium flex items-center gap-2 animate-in fade-in ${
            saveMessage.type === 'success'
              ? 'bg-emerald-50 border-emerald-200 text-emerald-800'
              : 'bg-rose-50 border-rose-200 text-rose-800'
          }`}
        >
          {saveMessage.type === 'success' ? (
            <CheckCircle2 className="w-4 h-4 text-emerald-600 flex-shrink-0" />
          ) : (
            <AlertCircle className="w-4 h-4 text-rose-600 flex-shrink-0" />
          )}
          <span>{saveMessage.text}</span>
        </div>
      )}

      {/* POS REGISTER SETTINGS CARD */}
      <Card className="shadow-xs">
        <CardHeader className="py-4 px-5 border-b border-slate-100">
          <div>
            <CardTitle className="text-sm font-bold text-[#071A31]">Register & Receipt Configuration</CardTitle>
            <CardDescription className="text-xs text-[#64748B] mt-0.5">
              These options apply to all connected ZAMERIA POS registers on this store.
            </CardDescription>
          </div>
        </CardHeader>
        <CardContent className="p-5 sm:p-6 space-y-5">
          <div className="space-y-1.5">
            <label className="block text-xs font-bold text-[#071A31]">
              Accepted Payment Methods
            </label>
            <p className="text-[11px] text-[#64748B]">
              Enter one payment method per line (e.g. Cash, Card, Bank Transfer, POS Terminal).
            </p>
            <textarea
              rows={4}
              value={paymentMethods}
              onChange={(e) => setPaymentMethods(e.target.value)}
              className="mt-1 block w-full rounded-xl border border-slate-200 bg-white px-3.5 py-2.5 font-mono text-xs text-[#071A31] outline-none focus:border-blue-400 focus:ring-2 focus:ring-blue-100 transition-all"
            />
          </div>

          <div className="space-y-1.5">
            <label className="block text-xs font-bold text-[#071A31]">
              Printed Receipt Footer
            </label>
            <p className="text-[11px] text-[#64748B]">
              Text printed at the bottom of customer receipts (e.g. "Thank you for shopping with us! No refunds after 7 days.").
            </p>
            <input
              type="text"
              value={receiptFooter}
              onChange={(e) => setReceiptFooter(e.target.value)}
              placeholder="Thank you for shopping with us!"
              className="mt-1 block w-full rounded-xl border border-slate-200 bg-white px-3.5 py-2 text-xs text-[#071A31] outline-none focus:border-blue-400 focus:ring-2 focus:ring-blue-100 transition-all"
            />
          </div>

          <div className="pt-2 flex items-center gap-3">
            <Button
              variant="primary"
              size="md"
              loading={isSaving}
              onClick={handleSave}
            >
              Save POS Settings
            </Button>
          </div>
        </CardContent>
      </Card>

      {/* SYSTEM ENVIRONMENT & DIAGNOSTICS */}
      <Card className="shadow-xs">
        <CardHeader className="py-4 px-5 border-b border-slate-100">
          <div className="flex items-center justify-between w-full">
            <CardTitle className="text-sm font-bold text-[#071A31]">System Diagnostics</CardTitle>
            <Badge variant={health.ready !== false ? 'connected' : 'warning'} dot size="sm">
              {health.ready !== false ? 'Environment Ready' : 'Check Required'}
            </Badge>
          </div>
        </CardHeader>
        <CardContent className="p-0 divide-y divide-slate-100">
          <div className="px-5 py-3.5 flex items-center justify-between text-xs">
            <span className="font-medium text-[#64748B]">ZAMERIA Plugin Version</span>
            <div className="flex items-center gap-2">
              <span className="font-mono font-bold text-[#071A31] bg-slate-100 px-2 py-0.5 rounded">
                v{runtime.version || '0.2.4'}
              </span>
              <span className="text-[11px] text-emerald-600 font-semibold">Active</span>
            </div>
          </div>

          <div className="px-5 py-3.5 flex items-center justify-between text-xs">
            <span className="font-medium text-[#64748B]">WooCommerce Core</span>
            <div className="flex items-center gap-1.5 text-[#071A31] font-medium">
              <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" />
              <span>Installed & Active</span>
            </div>
          </div>

          <div className="px-5 py-3.5 flex items-center justify-between text-xs">
            <span className="font-medium text-[#64748B]">WordPress Pretty Permalinks</span>
            <div className="flex items-center gap-1.5 text-[#071A31] font-medium">
              {checks.permalinks !== false ? (
                <>
                  <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" />
                  <span>Enabled (REST API Supported)</span>
                </>
              ) : (
                <span className="text-amber-600">Standard / Plain permalinks in use</span>
              )}
            </div>
          </div>

          <div className="px-5 py-3.5 flex items-center justify-between text-xs">
            <span className="font-medium text-[#64748B]">Self-Hosted POS Fallback Build</span>
            <div className="flex items-center gap-1.5 text-[#071A31] font-medium">
              {checks.posBuild !== false ? (
                <>
                  <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" />
                  <span>Compiled at /pos/</span>
                </>
              ) : (
                <span className="text-amber-600">Hosted fallback active</span>
              )}
            </div>
          </div>
        </CardContent>
      </Card>

      {/* SUPPORT & ASSISTANCE CARD */}
      <Card className="bg-linear-to-r from-blue-50/40 via-white to-white border-blue-200/70">
        <CardContent className="p-5 sm:p-6 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div className="space-y-1">
            <h4 className="text-sm font-bold text-[#071A31]">Need Assistance with ZAMERIA POS?</h4>
            <p className="text-xs text-[#64748B]">
              Our technical support and merchant onboarding team is available to assist you.
            </p>
          </div>
          <div className="flex items-center gap-2.5 flex-shrink-0">
            <a
              href="mailto:support@zameria.co"
              className="inline-flex items-center gap-1.5 px-3.5 py-2 text-xs font-semibold rounded-lg bg-white border border-slate-200 hover:bg-slate-50 text-[#071A31] transition-colors shadow-2xs"
            >
              <Mail className="w-3.5 h-3.5 text-blue-600" />
              <span>support@zameria.co</span>
            </a>
            <a
              href="https://zameria.co/docs"
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center gap-1.5 px-3.5 py-2 text-xs font-semibold rounded-lg bg-[#071A31] text-white hover:bg-slate-800 transition-colors shadow-xs"
            >
              <FileText className="w-3.5 h-3.5" />
              <span>Documentation</span>
            </a>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
