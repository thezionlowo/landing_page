import { STARTER_STAFF_LIMIT } from '@/lib/planLimits';
import { useState } from 'react';
import { Users, RefreshCw, LogOut, MonitorSmartphone, ShieldCheck, ArrowUpRight } from 'lucide-react';
import { Button } from '@/components/ui/Button';
import { PosDevice, AuthoritativeEntitlement, PluginTab } from '@/types/plugin';
import { adminAction } from '@/lib/admin-api';

interface DevicesScreenProps {
  devices: PosDevice[];
  onDevicesChange: (devices: PosDevice[]) => void;
  entitlement: AuthoritativeEntitlement;
  onNavigateTab: (tab: PluginTab) => void;
  onOpenPOS: () => void;
}
export function DevicesScreen({ devices, onDevicesChange, entitlement, onNavigateTab, onOpenPOS }: DevicesScreenProps) {
  const [refreshing, setRefreshing] = useState(false);
  const [revoking, setRevoking] = useState<number | null>(null);
  const [feedback, setFeedback] = useState<{ error: boolean; text: string } | null>(null);
  const starter = entitlement.status !== 'trial_active' && String(entitlement.plan || entitlement.subscription?.plan_name || entitlement.plan_name || '').toLowerCase().includes('starter');
  const max = starter ? STARTER_STAFF_LIMIT : null;
  const refresh = async () => {
    setRefreshing(true); setFeedback(null);
    try { const result = await adminAction<{ devices: PosDevice[] }>('zameria_admin_get_devices'); onDevicesChange(result.devices); }
    catch (error) { setFeedback({ error: true, text: error instanceof Error ? error.message : 'Could not refresh users.' }); }
    finally { setRefreshing(false); }
  };
  const revoke = async (device: PosDevice) => {
    if (!window.confirm(`Sign ${device.userName} out of the POS on ${device.name}? They will need to sign in again to continue.`)) return;
    setRevoking(device.id); setFeedback(null);
    try {
      const result = await adminAction<{ devices: PosDevice[] }>('zameria_admin_revoke_device', { device_id: String(device.id) });
      onDevicesChange(result.devices); setFeedback({ error: false, text: `${device.userName} has been signed out.` });
    } catch (error) { setFeedback({ error: true, text: error instanceof Error ? error.message : 'Could not sign out this user.' }); }
    finally { setRevoking(null); }
  };
  const date = (value: string | null) => value && Number.isFinite(Date.parse(value)) ? new Date(value).toLocaleString(undefined, { dateStyle: 'medium', timeStyle: 'short' }) : 'Not available';
  return <div className="zm-overview">
    <div className="zm-page-heading"><div><span className="zm-eyebrow">TEAM ACCESS</span><h1>Active users</h1><p>See who is signed in and manage their current session.</p></div><Button variant="secondary" icon={<RefreshCw />} loading={refreshing} onClick={refresh}>Refresh users</Button></div>
    {feedback && <div role={feedback.error ? 'alert' : 'status'} className={`zm-notice ${feedback.error ? 'zm-notice-error' : 'zm-notice-success'}`}>{feedback.text}</div>}
    <section className="zm-session-summary"><div className="zm-session-icon"><Users /></div><div><h2>{devices.length}{max != null ? ` of ${max}` : ''} active {devices.length === 1 ? 'user' : 'users'}</h2><p>Each WordPress account counts once. A new login ends that account’s previous session.</p></div>{starter && <Button variant="secondary" onClick={() => onNavigateTab('subscription')}>View plan</Button>}</section>
    <section className="zm-panel"><div className="zm-panel-heading"><h2>Signed-in accounts</h2><span className="zm-muted">One session per account</span></div>
      {devices.length ? <ul className="zm-user-list">{devices.map(device => <li key={device.id}><div className="zm-user-avatar" aria-hidden="true">{device.userName.charAt(0).toUpperCase()}</div><div className="zm-user-details"><strong>{device.userName}</strong><span>{device.email || device.username || `Account #${device.userId}`}</span><small><MonitorSmartphone />{device.name} · Last seen {date(device.lastSeenAt)}</small></div><span className="zm-status">Signed in</span><Button variant="outline" icon={<LogOut />} loading={revoking === device.id} disabled={revoking !== null && revoking !== device.id} onClick={() => revoke(device)}>Sign out</Button></li>)}</ul> : <div className="zm-empty"><Users /><h3>No users signed in</h3><p>Sign in to the POS with a WordPress staff account to start a session.</p><Button onClick={onOpenPOS} icon={<ArrowUpRight />}>Open POS</Button></div>}
      <div className="zm-panel-footer"><ShieldCheck /><span>Online devices check session access every 15 seconds and when reopened. Offline devices are checked when they reconnect.</span></div>
    </section>
  </div>;
}
