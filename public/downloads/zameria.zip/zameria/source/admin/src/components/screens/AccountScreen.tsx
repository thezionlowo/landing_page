import { WebsiteAccountLink } from '../account/WebsiteAccountLink';
import React, { useState } from 'react';
import {
  CheckCircle2,
  Sparkles,
  ExternalLink,
  RefreshCw,
  AlertCircle,
  Building2,
  Mail,
  ShieldCheck,
  Globe,
} from 'lucide-react';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/Card';
import { Button } from '@/components/ui/Button';
import { Badge } from '@/components/ui/Badge';
import { ProgressBar } from '@/components/ui/ProgressBar';
import { AuthoritativeEntitlement, ScreenId, PluginTab } from '@/types/plugin';
import { zameriaBackendClient } from '@/lib/zameriaBackendClient';

interface AccountScreenProps {
  entitlement: AuthoritativeEntitlement;
  onNavigateTab?: (tab: PluginTab) => void;
  onSelectScreen?: (screen: ScreenId) => void;
}

export function AccountScreen({
  entitlement,
  onNavigateTab,
  onSelectScreen,
}: AccountScreenProps) {
  const [isVerifying, setIsVerifying] = useState(false);
  const [verifyMessage, setVerifyMessage] = useState<string | null>(null);

  const isPaid = entitlement.status === 'paid_active';
  const isGifted = (entitlement.status as any) === 'gifted_active';
  const isPaidOrGifted = isPaid || isGifted;
  const isCancelled = (entitlement.status === 'paid_cancelled' || (entitlement.status as any) === 'cancelled') && !isPaidOrGifted;
  const isTrialActive = entitlement.status === 'trial_active' && !isPaidOrGifted;
  const isTrialExpired = (entitlement.status === 'trial_expired' || (entitlement.status as any) === 'paid_expired' || (entitlement.status as any) === 'gifted_expired') && !isPaidOrGifted;
  const isLicensingOff = entitlement.status === 'licensing_off';
  const runtime = (typeof window !== 'undefined' && (window as any).ZAMERIA_ADMIN) || {};

  const handleVerifyEntitlement = async () => {
    setIsVerifying(true);
    setVerifyMessage(null);
    try {
      const storeDomain =
        entitlement.store_domain ||
        entitlement.store_url ||
        (typeof window !== 'undefined' ? window.location.origin : '');
      const res = await zameriaBackendClient.getEntitlement(storeDomain);
      setIsVerifying(false);
      if (res.success && res.entitlement) {
        setVerifyMessage(
          `Status verified: ${res.entitlement.status.replace(/_/g, ' ').toUpperCase()} (Synced with ZAMERIA Cloud)`
        );
      } else {
        setVerifyMessage(res.error || 'Could not verify status with ZAMERIA Cloud.');
      }
    } catch {
      setIsVerifying(false);
      setVerifyMessage('Network error contacting ZAMERIA Cloud.');
    }
    setTimeout(() => setVerifyMessage(null), 5000);
  };

  const accountIdentifier =
    entitlement.account_id ||
    runtime.accountEmail ||
    'Connected Store';

  return (
    <div className="space-y-6 max-w-4xl mx-auto">
      <WebsiteAccountLink />
      {/* 1. TOP ENTITLEMENT CARD */}
      <Card className="shadow-xs overflow-hidden border-[#E2E8F0]">
        <div className="p-6 sm:p-7 border-b border-[#E2E8F0] bg-slate-50/50 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div className="space-y-1">
            <div className="flex items-center gap-2">
              <span className="text-[11px] font-bold uppercase tracking-wider text-blue-700 bg-blue-50 px-2.5 py-0.5 rounded border border-blue-200/80">
                Connected Account
              </span>
              {accountIdentifier && (
                <span className="text-xs text-slate-600 font-medium">
                  {accountIdentifier}
                </span>
              )}
            </div>
            <h2 className="text-xl sm:text-2xl font-bold tracking-tight text-[#071A31]">
              ZAMERIA Subscription & Account
            </h2>
            <p className="text-xs text-[#64748B] max-w-xl leading-relaxed">
              Subscriptions, plans, and store entitlements are managed authoritatively in your ZAMERIA cloud account.
            </p>
          </div>

          {!isLicensingOff && (
            <div className="flex items-center gap-2 self-start sm:self-auto">
              <Button
                variant="secondary"
                size="sm"
                loading={isVerifying}
                icon={<RefreshCw className="w-3.5 h-3.5" />}
                onClick={handleVerifyEntitlement}
              >
                Verify with Cloud
              </Button>
            </div>
          )}
        </div>

        {verifyMessage && (
          <div className="bg-emerald-50 border-b border-emerald-200 px-6 py-2.5 text-xs text-emerald-800 font-medium flex items-center gap-2 animate-in fade-in">
            <CheckCircle2 className="w-4 h-4 text-emerald-600" />
            <span>{verifyMessage}</span>
          </div>
        )}

        <CardContent className="p-6 sm:p-7 space-y-6 bg-white">
          {/* A. TRIAL ACTIVE */}
          {isTrialActive && entitlement.trial && (
            <div className="space-y-6">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-5 border-b border-slate-100">
                <div className="space-y-1">
                  <div className="flex items-center gap-2">
                    <span className="text-xs font-bold uppercase tracking-wider text-slate-500">
                      Current Plan
                    </span>
                    <Badge variant="brand" dot size="sm">
                      7-Day Free Trial
                    </Badge>
                  </div>
                  <div className="text-2xl sm:text-3xl font-black text-[#071A31] tracking-tight">
                    {entitlement.trial.days_remaining} {entitlement.trial.days_remaining === 1 ? 'day' : 'days'} remaining
                  </div>
                  <p className="text-xs text-[#64748B]">
                    Trial expires on: <strong>{entitlement.trial.expires_at}</strong>
                  </p>
                </div>
              </div>

              {/* Progress bar */}
              <div className="space-y-1.5">
                <ProgressBar
                  value={(entitlement.trial.days_remaining / 7) * 100}
                  color={entitlement.trial.days_remaining <= 2 ? 'amber' : 'brand'}
                  className="h-2.5"
                />
                <div className="flex justify-between text-[11px] text-[#64748B]">
                  <span>Started {entitlement.trial.started_at}</span>
                  <span className="font-semibold text-[#071A31]">
                    Day {7 - entitlement.trial.days_remaining + 1} of 7
                  </span>
                </div>
              </div>

              <div className="flex flex-wrap items-center gap-3 pt-2">
                <a
                  href="https://zameria.co/account"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="inline-flex items-center gap-1.5 px-4 py-2.5 text-xs font-semibold rounded-xl bg-[#071A31] text-white hover:bg-slate-800 transition-colors shadow-xs"
                >
                  <Sparkles className="w-3.5 h-3.5 text-blue-400" />
                  <span>Manage Plan on ZAMERIA Cloud</span>
                  <ExternalLink className="w-3.5 h-3.5 ml-1 text-slate-400" />
                </a>
              </div>
            </div>
          )}

          {/* B. PAID SUBSCRIPTION OR GIFTED PLAN ACTIVE */}
          {isPaidOrGifted && entitlement.subscription && (
            <div className="space-y-6">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-5 border-b border-slate-100">
                <div className="space-y-1">
                  <div className="flex items-center gap-2">
                    <span className="text-xs font-bold uppercase tracking-wider text-slate-500">
                      Subscribed Tier
                    </span>
                    <Badge variant="active" dot size="sm">
                      {isGifted ? 'Gifted Plan' : 'Active Subscription'}
                    </Badge>
                  </div>
                  <div className="text-2xl sm:text-3xl font-black text-[#071A31] tracking-tight">
                    {entitlement.subscription.plan_name}
                  </div>
                  <div className={`text-sm font-semibold ${isGifted ? 'text-purple-700' : 'text-emerald-600'}`}>
                    {entitlement.subscription.price}
                  </div>
                </div>

                <div className="flex sm:flex-col items-start sm:items-end gap-1">
                  <span className="text-[11px] font-medium text-slate-500">
                    {isGifted ? 'Expiry Date' : 'Renewal Date'}
                  </span>
                  <span className="text-xs font-bold text-[#071A31]">
                    {entitlement.subscription.next_billing_date}
                  </span>
                  <span className={`text-[10px] font-semibold ${isGifted ? 'text-purple-600' : 'text-emerald-600'}`}>
                    {isGifted ? 'Complimentary Access' : 'Auto-renews annually'}
                  </span>
                </div>
              </div>

              <div className="flex flex-wrap items-center gap-3 pt-1">
                <a
                  href="https://zameria.co/account"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="inline-flex items-center gap-1.5 px-4 py-2.5 text-xs font-semibold rounded-xl bg-[#071A31] text-white hover:bg-slate-800 transition-colors shadow-xs"
                >
                  <span>Manage Billing & Invoices on ZAMERIA.co</span>
                  <ExternalLink className="w-3.5 h-3.5 ml-1 text-slate-400" />
                </a>
              </div>
            </div>
          )}

          {/* C. TRIAL EXPIRED */}
          {isTrialExpired && (
            <div className="space-y-4">
              <div className="p-4 bg-rose-50 border border-rose-200 rounded-xl space-y-2">
                <div className="flex items-center gap-2 text-rose-700 font-bold text-sm">
                  <AlertCircle className="w-4 h-4 text-rose-600" />
                  <span>Your Access Period Has Ended</span>
                </div>
                <p className="text-xs text-[#64748B] leading-relaxed">
                  Renew or subscribe to a plan on your ZAMERIA cloud account to continue using Point of Sale registers.
                </p>
              </div>

              <div className="flex items-center gap-3 pt-2">
                <a
                  href="https://zameria.co/account"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="inline-flex items-center gap-1.5 px-4 py-2.5 text-xs font-semibold rounded-xl bg-[#071A31] text-white hover:bg-slate-800 transition-colors shadow-xs"
                >
                  <Sparkles className="w-3.5 h-3.5 text-blue-400" />
                  <span>Choose a Plan on ZAMERIA Cloud</span>
                  <ExternalLink className="w-3.5 h-3.5 ml-1 text-slate-400" />
                </a>
              </div>
            </div>
          )}

          {/* D. CANCELLED / SUSPENDED */}
          {isCancelled && (
            <div className="space-y-4">
              <div className="p-4 bg-amber-50 border border-amber-200 rounded-xl space-y-2">
                <div className="flex items-center gap-2 text-amber-900 font-bold text-sm">
                  <AlertCircle className="w-4 h-4 text-amber-600" />
                  <span>Subscription Cancelled</span>
                </div>
                <p className="text-xs text-amber-800 leading-relaxed">
                  Your store subscription is currently inactive. You can reactivate your subscription anytime on your ZAMERIA dashboard.
                </p>
              </div>

              <div className="pt-2">
                <a
                  href="https://zameria.co/account"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="inline-flex items-center gap-1.5 px-4 py-2.5 text-xs font-semibold rounded-xl bg-[#071A31] text-white hover:bg-slate-800 transition-colors shadow-xs"
                >
                  <span>Reactivate Subscription</span>
                  <ExternalLink className="w-3.5 h-3.5 ml-1 text-slate-400" />
                </a>
              </div>
            </div>
          )}
        </CardContent>
      </Card>

      {/* 2. STORE BRIDGE DETAILS CARD */}
      <Card className="shadow-xs border-[#E2E8F0]">
        <CardHeader className="py-4 px-5 border-b border-slate-100">
          <CardTitle className="text-sm font-bold text-[#071A31]">WooCommerce Store Connection</CardTitle>
        </CardHeader>
        <CardContent className="p-5 space-y-3 text-xs">
          <div className="flex items-center justify-between py-2 border-b border-slate-100">
            <span className="text-slate-500">Connected Store URL</span>
            <span className="font-mono font-semibold text-slate-900">
              {entitlement.store_url || 'Connected Store'}
            </span>
          </div>
          <div className="flex items-center justify-between py-2 border-b border-slate-100">
            <span className="text-slate-500">Cloud Sync Status</span>
            <span className="text-emerald-700 font-semibold flex items-center gap-1.5">
              <span className="w-1.5 h-1.5 rounded-full bg-emerald-500"></span>
              Synchronized with ZAMERIA Cloud
            </span>
          </div>
          <div className="flex items-center justify-between py-2">
            <span className="text-slate-500">Billing Management</span>
            <a
              href="https://zameria.co/account"
              target="_blank"
              rel="noopener noreferrer"
              className="text-blue-600 hover:text-blue-700 font-semibold flex items-center gap-1"
            >
              <span>Manage Billing</span>
              <ExternalLink className="w-3.5 h-3.5 ml-1 text-slate-400" />
            </a>
          </div>
        </CardContent>
      </Card>

      {/* 3. AUTHORITATIVE PLAN TIERS & REGISTER LIMITS */}
      <Card className="shadow-xs border-[#E2E8F0]">
        <CardHeader className="py-4 px-5 border-b border-slate-100">
          <CardTitle className="text-sm font-bold text-[#071A31]">Authoritative Plans & Register Entitlements</CardTitle>
        </CardHeader>
        <CardContent className="p-5 space-y-4 text-xs">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="p-3.5 rounded-xl border border-slate-200 bg-slate-50/50 space-y-2">
              <div className="flex items-center justify-between">
                <span className="font-bold text-slate-900 text-sm">Starter Plan</span>
                <span className="font-extrabold text-[#071A31]">₦200,000 / year</span>
              </div>
              <ul className="text-slate-600 space-y-1.5 text-[11.5px]">
                <li className="flex items-center gap-1.5">
                  <span className="w-1.5 h-1.5 rounded-full bg-blue-600"></span>
                  <span>Maximum 2 active registers</span>
                </li>
                <li className="flex items-center gap-1.5">
                  <span className="w-1.5 h-1.5 rounded-full bg-blue-600"></span>
                  <span>Up to 500 catalog products</span>
                </li>
              </ul>
            </div>
            <div className="p-3.5 rounded-xl border border-blue-200 bg-blue-50/30 space-y-2">
              <div className="flex items-center justify-between">
                <span className="font-bold text-blue-950 text-sm">Business Plan</span>
                <span className="font-extrabold text-[#071A31]">₦300,000 / year</span>
              </div>
              <ul className="text-slate-600 space-y-1.5 text-[11.5px]">
                <li className="flex items-center gap-1.5">
                  <span className="w-1.5 h-1.5 rounded-full bg-emerald-600"></span>
                  <span>Unlimited active registers</span>
                </li>
                <li className="flex items-center gap-1.5">
                  <span className="w-1.5 h-1.5 rounded-full bg-emerald-600"></span>
                  <span>Unlimited catalog products</span>
                </li>
              </ul>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
