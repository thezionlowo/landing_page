import React from 'react';
import { Badge } from '@/components/ui/Badge';
import { ScreenId, AuthoritativeEntitlement } from '@/types/plugin';

interface PluginHeaderProps {
  currentScreen?: ScreenId;
  isConnected?: boolean;
  entitlement?: AuthoritativeEntitlement;
  onOpenPOS?: () => void;
}

export function PluginHeader({
  currentScreen,
  isConnected = false,
  entitlement,
  onOpenPOS,
}: PluginHeaderProps) {
  const getStatusBadge = () => {
    // 1. Unconnected / fresh install state
    if (
      !isConnected ||
      !entitlement ||
      entitlement.status === 'unactivated' ||
      (entitlement.status as any) === 'trial_not_started' ||
      currentScreen === 'state_1_unactivated' ||
      currentScreen === 'screen_activation'
    ) {
      return (
        <Badge variant="neutral" dot size="md">
          Store Not Connected
        </Badge>
      );
    }

    // 2. Authoritative entitlement checks
    const status = entitlement.status;
    const daysRemaining = entitlement.trial?.days_remaining ?? 7;

    if (status === 'paid_active' || (status as any) === 'gifted_active') {
      return (
        <Badge variant="connected" dot size="md">
          Store Connected
        </Badge>
      );
    }

    if (status === 'trial_active') {
      return (
        <Badge
          variant={daysRemaining <= 2 ? 'warning' : 'connected'}
          dot
          pulsing={daysRemaining <= 2}
          size="md"
        >
          Trial Active ({daysRemaining}d)
        </Badge>
      );
    }

    if (status === 'trial_expired' || (status as any) === 'paid_expired') {
      return (
        <Badge variant="expired" dot size="md">
          {status === 'paid_expired' ? 'Subscription Expired' : 'Trial Expired'}
        </Badge>
      );
    }

    if (status === 'paid_cancelled' || (status as any) === 'cancelled') {
      return (
        <Badge variant="disconnected" dot size="md">
          Subscription Inactive
        </Badge>
      );
    }

    if (status === 'backend_unavailable') {
      return (
        <Badge variant="warning" dot size="md">
          Cloud Offline
        </Badge>
      );
    }

    if (status === 'licensing_off') {
      return (
        <Badge variant="connected" dot size="md">
          Bridge Active
        </Badge>
      );
    }

    return (
      <Badge variant="connected" dot size="md">
        Store Connected
      </Badge>
    );
  };

  const statusBadge = getStatusBadge();

  const runtime = (window as any).ZAMERIA_ADMIN || {};
  return <header className="zm-topbar">
    <div className="zm-topbar-store">
      {!isConnected && <strong className="zm-wordmark">ZAMERIA</strong>}
      <span className="zm-topbar-caption">{isConnected ? 'Your connected store' : 'WooCommerce connector'}</span>
      <strong>{runtime.storeName || entitlement?.store_name || 'Store workspace'}</strong>
    </div>
    <div className="zm-topbar-actions">{statusBadge}{isConnected && onOpenPOS && <button className="zm-launch" type="button" onClick={onOpenPOS}>Open POS <span aria-hidden="true">↗</span></button>}</div>
  </header>;
}
