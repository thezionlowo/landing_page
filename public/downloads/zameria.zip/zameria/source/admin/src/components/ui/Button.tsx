import React from 'react';
import { Loader2 } from 'lucide-react';
import { cn } from '@/lib/utils';

export type ButtonVariant =
  | 'primary'
  | 'tonal'
  | 'secondary'
  | 'outline'
  | 'ghost'
  | 'destructive';

export type ButtonSize = 'sm' | 'md' | 'lg';

export interface ButtonProps extends React.ButtonHTMLAttributes<HTMLButtonElement> {
  variant?: ButtonVariant;
  size?: ButtonSize;
  loading?: boolean;
  icon?: React.ReactNode;
  children?: React.ReactNode;
}

const variantClasses: Record<ButtonVariant, string> = {
  primary:
    'bg-[#071A31] hover:bg-[#0C2340] active:bg-[#040E1B] text-white border border-transparent shadow-xs transition-all duration-150',
  tonal:
    'bg-blue-50 text-[#071A31] hover:bg-blue-100/90 active:bg-blue-200/80 border border-blue-200/60 transition-all duration-150',
  secondary:
    'bg-white hover:bg-slate-50 active:bg-slate-100 text-slate-700 border border-slate-200 shadow-xs transition-all duration-150',
  outline:
    'border border-slate-200 hover:border-slate-300 bg-white/80 hover:bg-slate-50 text-slate-700 transition-all duration-150',
  ghost:
    'bg-transparent hover:bg-slate-100/80 text-slate-600 hover:text-slate-900 transition-colors duration-150',
  destructive:
    'bg-rose-600 hover:bg-rose-700 active:bg-rose-800 text-white border border-transparent shadow-xs transition-all duration-150',
};

const sizeClasses: Record<ButtonSize, string> = {
  sm: 'h-8 px-3 text-xs gap-1.5 rounded-lg font-medium',
  md: 'h-9 px-4 text-xs font-semibold gap-2 rounded-lg',
  lg: 'h-10.5 px-5 text-sm font-semibold gap-2.5 rounded-lg',
};

export function Button({
  variant = 'primary',
  size = 'md',
  loading = false,
  icon,
  children,
  className,
  disabled,
  ...props
}: ButtonProps) {
  return (
    <button
      className={cn(
        'zm-button inline-flex items-center justify-center select-none cursor-pointer font-sans transition-colors',
        'focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#60A5FA] focus-visible:ring-offset-1',
        'disabled:opacity-45 disabled:cursor-not-allowed disabled:pointer-events-none',
        variantClasses[variant],
        sizeClasses[size],
        className
      )}
      disabled={disabled || loading}
      {...props}
    >
      {loading ? <Loader2 className="w-3.5 h-3.5 animate-spin flex-shrink-0" /> : icon}
      {children}
    </button>
  );
}
