import { useState } from 'react';
import { ArrowUpRight, Package, Users, UserRoundCog, RefreshCw, Activity, ArrowRight, ShieldCheck, CheckCircle2, AlertTriangle } from 'lucide-react';
import { websiteAccountUrl } from '../account/WebsiteAccountLink';
import { Button } from '@/components/ui/Button';
import { ScreenId, PluginTab, AuthoritativeEntitlement } from '@/types/plugin';
import { normalizeWpEntitlement } from '@/lib/lifecycleData';
import { zameriaBackendClient } from '@/lib/zameriaBackendClient';
import { adminAction } from '@/lib/admin-api';

interface DashboardScreenProps {
  currentScreen: ScreenId;
  liveEntitlement?: AuthoritativeEntitlement;
  deviceCount?: number;
  deviceLimit?: number | null;
  onNavigateTab: (tab: PluginTab) => void;
  onOpenPOS: () => void;
  onActivateTrial?: () => void;
  onRefreshEntitlement?: () => void;
  onDisconnect?: () => void;
}
export function DashboardScreen({ liveEntitlement, deviceCount = 0, deviceLimit = null, onNavigateTab, onOpenPOS, onRefreshEntitlement }: DashboardScreenProps) {
  const runtime = (window as any).ZAMERIA_ADMIN || {};
  const entitlement = liveEntitlement || normalizeWpEntitlement(runtime.entitlement, runtime.storeUrl, runtime.storeName);
  const [syncing, setSyncing] = useState(false);
  const [checking, setChecking] = useState(false);
  const [feedback, setFeedback] = useState<{ error: boolean; text: string } | null>(null);
  const [snapshot, setSnapshot] = useState(runtime);
  const expired = ['trial_expired', 'paid_expired', 'gifted_expired', 'paid_cancelled'].includes(entitlement.status);
  const trial = entitlement.status === 'trial_active';
  const unavailable = entitlement.status === 'backend_unavailable';
  const days = entitlement.trial?.days_remaining;
  const planName = trial ? 'Free trial' : entitlement.status === 'licensing_off' ? 'Local connector' : `${entitlement.plan || entitlement.subscription?.plan_name || 'Your'} plan`;
  const expiry = trial ? entitlement.trial?.expires_at : entitlement.license_expires_at || entitlement.subscription?.next_billing_date;
  const formatDate = (value?: string) => value && Number.isFinite(Date.parse(value)) ? new Date(value).toLocaleDateString(undefined, { day: 'numeric', month: 'short', year: 'numeric' }) : 'Not available';
  const activities: { id: string; title: string; details?: string; time?: string }[] = snapshot.activity || [];
  const sync = async () => {
    setSyncing(true); setFeedback(null);
    try {
      const result = await adminAction<{ message?: string; data?: Record<string, unknown> }>('zameria_admin_sync_catalog');
      if (result.data) { Object.assign(runtime, result.data); setSnapshot({ ...runtime }); }
      setFeedback({ error: false, text: result.message || 'Catalogue refresh queued for connected POS devices.' });
    } catch (error) { setFeedback({ error: true, text: error instanceof Error ? error.message : 'Could not refresh catalogue.' }); }
    finally { setSyncing(false); }
  };
  const retry = async () => {
    setChecking(true); setFeedback(null);
    try {
      const result = await zameriaBackendClient.getEntitlement(entitlement.store_url);
      if (!result.success || result.isOffline) throw new Error('Could not reach ZAMERIA Cloud. Please try again.');
      onRefreshEntitlement?.(); setFeedback({ error: false, text: 'Connected to ZAMERIA Cloud.' });
    } catch (error) { setFeedback({ error: true, text: error instanceof Error ? error.message : 'Connection check failed.' }); }
    finally { setChecking(false); }
  };
  return <div className="zm-overview">
    <div className="zm-page-heading"><div><span className="zm-eyebrow">STORE MANAGEMENT</span><h1>Store overview</h1><p>Your team, catalogue and connection in one place.</p></div><Button variant="secondary" icon={<RefreshCw />} loading={syncing} onClick={sync}>Refresh catalogue</Button></div>
    {feedback && <div role={feedback.error ? 'alert' : 'status'} className={`zm-notice ${feedback.error ? 'zm-notice-error' : 'zm-notice-success'}`}>{feedback.error ? <AlertTriangle /> : <CheckCircle2 />}{feedback.text}</div>}
    {unavailable && <div className="zm-notice zm-notice-warning"><span>ZAMERIA Cloud is currently unavailable.</span><Button variant="outline" loading={checking} onClick={retry}>Check connection</Button></div>}
    {expired && <div role="alert" className="zm-notice zm-notice-warning"><span>Your {entitlement.status === 'trial_expired' ? 'free trial has ended' : 'subscription is inactive'}. Renew your plan to restore POS access.</span><Button onClick={() => onNavigateTab('subscription')}>View subscription</Button></div>}
    <section className="zm-store-banner" aria-label="Point of sale">
      <div><span className="zm-eyebrow">YOUR POINT OF SALE</span><h2>{snapshot.storeName || entitlement.store_name || 'Your store'}</h2><p>{(snapshot.storeUrl || entitlement.store_url || '').replace(/^https?:\/\//, '').replace(/\/$/, '')}</p><span className="zm-banner-caption">Sell in store. Manage everything in WooCommerce.</span></div>
      <Button variant="tonal" size="lg" icon={<ArrowUpRight />} onClick={expired ? () => onNavigateTab('subscription') : onOpenPOS}>{expired ? 'Renew subscription' : 'Launch point of sale'}</Button>
    </section>
    <div className="zm-metrics">
      <button className="zm-metric" type="button" onClick={() => onNavigateTab('devices')}><span className="zm-metric-label">Active users <Users /></span><strong>{deviceCount}<small>{deviceLimit == null ? ' / unlimited' : ` / ${deviceLimit}`}</small></strong><span>One account, one active session <ArrowRight /></span></button>
      <div className="zm-metric"><span className="zm-metric-label">Product catalogue <Package /></span><strong>{new Intl.NumberFormat().format(snapshot.productCount ?? entitlement.sync?.products_synced ?? 0)}</strong><span>Published products in WooCommerce</span></div>
      <button className="zm-metric" type="button" onClick={() => onNavigateTab('staff')}><span className="zm-metric-label">Cashiers & staff <UserRoundCog /></span><strong>{snapshot.staff?.length ?? 0}</strong><span>Staff accounts with POS access <ArrowRight /></span></button>
    </div>
    <div className="zm-overview-columns">
      <section className="zm-panel zm-activity"><div className="zm-panel-heading"><div><span className="zm-panel-icon"><Activity /></span><h2>Recent activity</h2></div><span className="zm-muted">Latest store events</span></div>
        {activities.length ? <ul className="zm-activity-list">{activities.slice(0, 5).map(item => <li key={item.id}><span className="zm-activity-dot" /><div><strong>{item.title}</strong><p>{item.details}</p></div><time dateTime={item.time}>{formatDate(item.time)}</time></li>)}</ul> : <div className="zm-empty"><Activity /><h3>No recent activity</h3><p>Catalogue refreshes and connection events will appear here.</p></div>}
        <div className="zm-panel-footer"><ShieldCheck /><span>WooCommerce remains the source for your store data.</span></div>
      </section>
      <section className="zm-panel zm-plan"><div className="zm-panel-heading"><h2>Your subscription</h2><span className={`zm-status ${expired ? 'zm-status-warning' : ''}`}>{expired ? 'Inactive' : trial ? 'Trial' : unavailable ? 'Unavailable' : 'Connected'}</span></div><div className="zm-plan-body"><span className="zm-eyebrow">CURRENT PLAN</span><h3>{planName}</h3><p>{trial && days != null ? `${days} ${days === 1 ? 'day' : 'days'} remaining` : entitlement.status === 'gifted_active' ? 'Complimentary access' : 'Manage your plan and billing online.'}</p>{expiry && <dl><dt>{trial ? 'Trial ends' : 'Renewal / expiry'}</dt><dd>{formatDate(expiry)}</dd></dl>}<dl><dt>Active users</dt><dd>{deviceCount}{deviceLimit != null ? ` of ${deviceLimit}` : ' · unlimited'}</dd></dl><div className="zm-capacity-track" aria-hidden="true"><span style={{ width: deviceLimit ? `${Math.min(100, deviceCount / deviceLimit * 100)}%` : '100%' }} /></div><p className="zm-plan-note">Signing in on another device replaces the same account’s previous session.</p><Button variant="secondary" onClick={() => onNavigateTab('subscription')}>Manage subscription <ArrowRight /></Button></div></section>
    </div>
    <a className="zm-account-link" href={websiteAccountUrl()} target="_blank" rel="noopener noreferrer"><div><strong>Your ZAMERIA account</strong><span>Manage billing and subscriptions with your existing ZAMERIA login.</span></div><span>Go to account <ArrowUpRight /><span className="sr-only">(opens in a new tab)</span></span></a>
  </div>;
}
