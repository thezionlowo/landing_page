import React, { useState } from 'react';
import {
  Users,
  UserCheck,
  UserPlus,
  ExternalLink,
  Shield,
  RefreshCw,
  CheckCircle2,
  AlertCircle,
  Key,
} from 'lucide-react';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/Card';
import { Button } from '@/components/ui/Button';
import { Badge } from '@/components/ui/Badge';
import { PosStaffMember, AuthoritativeEntitlement, PluginTab } from '@/types/plugin';
import { adminAction } from '@/lib/admin-api';

interface StaffScreenProps {
  entitlement: AuthoritativeEntitlement;
  onNavigateTab: (tab: PluginTab) => void;
}

export function StaffScreen({ entitlement, onNavigateTab }: StaffScreenProps) {
  const runtime = (typeof window !== 'undefined' && (window as any).ZAMERIA_ADMIN) || {};
  const [staffList, setStaffList] = useState<PosStaffMember[]>(runtime.staff || []);
  const [isRefreshing, setIsRefreshing] = useState(false);
  const [message, setMessage] = useState<string | null>(null);

  const rawPlanStr = String(
    entitlement.plan ||
    entitlement.subscription?.plan_name ||
    entitlement.plan_name ||
    runtime.entitlement?.plan ||
    ''
  ).toLowerCase();
  const isBusinessPlan = rawPlanStr.includes('business');
  const isStarter = !isBusinessPlan && (
    rawPlanStr.includes('starter') ||
    entitlement.status === 'trial_active'
  );
  const maxStaff = isBusinessPlan ? null : (isStarter ? 2 : null);
  const staffCount = staffList.length;

  const usersUrl = runtime.usersUrl || '/wp-admin/users.php';
  const newUserUrl = runtime.newUserUrl || '/wp-admin/user-new.php?role=zameria_cashier';

  const handleRefresh = async () => {
    setIsRefreshing(true);
    setMessage(null);
    try {
      const res = await adminAction<{ staff: PosStaffMember[]; usersUrl?: string; newUserUrl?: string }>('zameria_admin_get_staff');
      if (res && res.staff) {
        setStaffList(res.staff);
        if (runtime) runtime.staff = res.staff;
      }
    } catch (err) {
      setMessage(err instanceof Error ? err.message : 'Could not refresh staff members.');
    } finally {
      setIsRefreshing(false);
    }
  };

  return (
    <div className="space-y-6 max-w-5xl mx-auto">
      {/* Top Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <h2 className="text-xl sm:text-2xl font-bold tracking-tight text-[#071A31]">
              Staff & Cashiers
            </h2>
            <Badge variant="neutral" size="sm">
              {staffCount} {staffCount === 1 ? 'User' : 'Users'} with POS Access
            </Badge>
          </div>
          <p className="text-xs text-[#64748B] mt-1">
            WordPress users permitted to sign into ZAMERIA POS registers on this store.
          </p>
        </div>

        <div className="flex items-center gap-2.5 self-start sm:self-auto">
          <Button
            variant="secondary"
            size="sm"
            loading={isRefreshing}
            icon={<RefreshCw className="w-3.5 h-3.5" />}
            onClick={handleRefresh}
          >
            Refresh
          </Button>
          <a
            href={newUserUrl}
            target="_blank"
            rel="noopener noreferrer"
            className="inline-flex items-center justify-center gap-1.5 px-3.5 py-2 text-xs font-semibold rounded-lg bg-[#071A31] text-white hover:bg-slate-800 transition-colors shadow-xs"
          >
            <UserPlus className="w-3.5 h-3.5" />
            <span>Add New Cashier</span>
          </a>
        </div>
      </div>

      {message && (
        <div className="p-3.5 rounded-xl border bg-rose-50 border-rose-200 text-xs font-medium text-rose-800 flex items-center gap-2 animate-in fade-in">
          <AlertCircle className="w-4 h-4 text-rose-600 flex-shrink-0" />
          <span>{message}</span>
        </div>
      )}

      {/* Plan Staff Capacity Banner */}
      <div className="p-4 sm:p-5 rounded-2xl border bg-white border-slate-200/80 shadow-xs">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div className="flex items-start gap-3">
            <div className="w-9 h-9 rounded-xl bg-blue-50 text-blue-700 flex items-center justify-center flex-shrink-0 mt-0.5">
              <Users className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="text-xs font-bold text-[#071A31]">
                  Staff Tier: {isStarter ? 'Starter Plan (Up to 2 Staff)' : 'Business Plan (Unlimited Staff)'}
                </span>
                <span className="text-[10px] font-medium px-2 py-0.5 rounded-full bg-slate-100 text-slate-700">
                  {staffCount} active on store
                </span>
              </div>
              <p className="text-xs text-[#64748B] mt-0.5 leading-relaxed">
                {isStarter
                  ? 'Starter plan covers up to 2 staff members. Upgrade to Business for unlimited staff and multi-cashier teams.'
                  : 'Your Business plan includes unlimited staff accounts and unlimited simultaneous cashiers.'}
              </p>
            </div>
          </div>

          {isStarter && (
            <Button
              variant="secondary"
              size="sm"
              onClick={() => onNavigateTab('subscription')}
              className="flex-shrink-0 self-start sm:self-auto"
            >
              Upgrade Plan
            </Button>
          )}
        </div>
      </div>

      {/* Staff Table Card */}
      <Card className="shadow-xs overflow-hidden">
        <CardHeader className="bg-slate-50/50 border-b border-slate-100 py-3.5 px-5">
          <div className="flex items-center justify-between w-full">
            <div className="flex items-center gap-2">
              <UserCheck className="w-4 h-4 text-slate-500" />
              <CardTitle className="text-sm font-bold text-[#071A31]">
                Authorized POS Users ({staffList.length})
              </CardTitle>
            </div>
            <a
              href={usersUrl}
              target="_blank"
              rel="noopener noreferrer"
              className="text-xs font-semibold text-blue-600 hover:text-blue-800 inline-flex items-center gap-1 cursor-pointer"
            >
              <span>Manage in WordPress</span>
              <ExternalLink className="w-3 h-3" />
            </a>
          </div>
        </CardHeader>

        {staffList.length === 0 ? (
          <div className="p-8 text-center text-xs text-[#64748B] space-y-2">
            <Users className="w-8 h-8 text-slate-400 mx-auto" />
            <p>No users with POS access were found.</p>
          </div>
        ) : (
          <div className="divide-y divide-slate-100">
            {staffList.map((user) => (
              <div
                key={user.id}
                className="p-4 sm:p-5 flex flex-col sm:flex-row sm:items-center justify-between gap-4 hover:bg-slate-50/60 transition-colors"
              >
                <div className="flex items-center gap-3.5">
                  <div className="w-10 h-10 rounded-full bg-slate-100 text-slate-700 font-bold flex items-center justify-center text-sm flex-shrink-0">
                    {user.displayName.charAt(0).toUpperCase()}
                  </div>
                  <div className="space-y-0.5">
                    <div className="flex items-center gap-2 flex-wrap">
                      <span className="text-sm font-bold text-[#071A31]">
                        {user.displayName}
                      </span>
                      <span className="text-xs font-mono text-slate-500">
                        (@{user.username})
                      </span>
                      <span className="text-[10px] font-semibold px-2 py-0.5 rounded-full bg-slate-100 text-slate-700">
                        {user.roleLabel}
                      </span>
                    </div>
                    <div className="text-xs text-[#64748B]">
                      {user.email}
                    </div>
                  </div>
                </div>

                <div className="flex items-center gap-2.5 self-end sm:self-auto flex-shrink-0">
                  <Badge variant="connected" dot size="sm">
                    POS Enabled
                  </Badge>
                  <a
                    href={user.editUrl}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="text-xs font-semibold text-slate-600 hover:text-[#071A31] border border-slate-200 hover:bg-slate-50 px-2.5 py-1.5 rounded-lg transition-colors inline-flex items-center gap-1"
                  >
                    <span>Edit User</span>
                    <ExternalLink className="w-3 h-3 text-slate-400" />
                  </a>
                </div>
              </div>
            ))}
          </div>
        )}
      </Card>

      {/* POS Role Information Guide */}
      <Card className="bg-slate-50/50 border-slate-200">
        <CardContent className="p-5 sm:p-6 space-y-3">
          <h4 className="text-xs font-bold uppercase tracking-wider text-[#071A31]">
            Understanding POS Roles & Security
          </h4>
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 text-xs text-[#64748B]">
            <div className="p-3 bg-white border border-slate-200 rounded-xl space-y-1">
              <strong className="text-[#071A31] block">POS Cashier</strong>
              <p className="text-[11px] leading-relaxed">
                Dedicated role created by ZAMERIA. Cashiers can ring up sales, scan items, and add customer records without access to wp-admin.
              </p>
            </div>
            <div className="p-3 bg-white border border-slate-200 rounded-xl space-y-1">
              <strong className="text-[#071A31] block">Shop Manager</strong>
              <p className="text-[11px] leading-relaxed">
                Can operate registers, manage stock, view reports, and issue refunds directly in WooCommerce.
              </p>
            </div>
            <div className="p-3 bg-white border border-slate-200 rounded-xl space-y-1">
              <strong className="text-[#071A31] block">Administrator</strong>
              <p className="text-[11px] leading-relaxed">
                Has full store access, can revoke register sessions, change payment settings, and manage store connection.
              </p>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
