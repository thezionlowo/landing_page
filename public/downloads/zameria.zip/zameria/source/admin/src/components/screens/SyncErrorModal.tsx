import React from 'react';
import { X, AlertCircle, RefreshCw, CheckCircle2 } from 'lucide-react';
import { Button } from '@/components/ui/Button';
import { Badge } from '@/components/ui/Badge';

interface SyncErrorModalProps {
  isOpen: boolean;
  onClose: () => void;
  onRetry: () => void;
}

export function SyncErrorModal({ isOpen, onClose, onRetry }: SyncErrorModalProps) {
  if (!isOpen) return null;

  const failedItems = [
    { sku: 'GLW-8041', name: 'Hydrating Rose Water Toner 200ml', reason: 'Missing WooCommerce tax class mapping' },
    { sku: 'GLW-8042', name: 'Vitamin C Brightening Serum 30ml', reason: 'Duplicate SKU detected on store' },
    { sku: 'GLW-8099', name: 'Organic Bamboo Face Cloths (Pack of 3)', reason: 'Attribute value missing in WooCommerce' },
    { sku: 'GLW-8105', name: 'Gentle Foaming Cleanser 150ml', reason: 'Price format invalid (expected decimal)' },
  ];

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-[#071A31]/50 backdrop-blur-xs p-4 animate-in fade-in duration-200">
      <div className="bg-white rounded-xl border border-[#E2E8F0] shadow-xl max-w-lg w-full overflow-hidden">
        {/* Header */}
        <div className="px-5 py-4 border-b border-[#E2E8F0] flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-lg bg-rose-50 border border-rose-200 flex items-center justify-center text-rose-600">
              <AlertCircle className="w-4 h-4" />
            </div>
            <div>
              <h3 className="text-sm font-bold text-[#071A31]">Sync Issues Details</h3>
              <p className="text-xs text-[#64748B]">12 products could not be synchronized with WooCommerce</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="text-slate-400 hover:text-slate-600 p-1 rounded-md transition-colors"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Content */}
        <div className="p-5 space-y-3">
          <div className="flex items-center justify-between p-3 bg-slate-50 border border-slate-200 rounded-lg text-xs">
            <div className="flex items-center gap-2">
              <span className="font-semibold text-rose-600">12 Failed</span>
              <span className="text-slate-400">•</span>
              <span className="font-semibold text-emerald-600">236 Succeeded</span>
            </div>
            <span className="text-slate-500 font-medium">Last attempted 4 min ago</span>
          </div>

          <div className="text-xs font-semibold text-slate-700 pt-1">Sample affected products:</div>

          <div className="max-h-56 overflow-y-auto space-y-2 pr-1 divide-y divide-slate-100">
            {failedItems.map((item) => (
              <div key={item.sku} className="pt-2 first:pt-0">
                <div className="flex items-center justify-between">
                  <span className="font-medium text-[#071A31] text-xs">{item.name}</span>
                  <Badge variant="neutral" size="sm">{item.sku}</Badge>
                </div>
                <div className="text-[11px] text-rose-600 mt-0.5 flex items-center gap-1">
                  <span className="w-1 h-1 rounded-full bg-rose-500"></span>
                  {item.reason}
                </div>
              </div>
            ))}
          </div>

          <p className="text-[11px] text-[#64748B] bg-blue-50/60 p-2.5 rounded-lg border border-blue-100 mt-2">
            Tip: You can resolve product attributes and tax rates directly in WooCommerce, or edit them in ZAMERIA POS.
          </p>
        </div>

        {/* Footer */}
        <div className="px-5 py-3 bg-[#F8FAFC] border-t border-[#E2E8F0] flex items-center justify-end gap-2.5">
          <Button variant="secondary" size="sm" onClick={onClose}>
            Close
          </Button>
          <Button
            variant="primary"
            size="sm"
            icon={<RefreshCw className="w-3.5 h-3.5" />}
            onClick={() => {
              onRetry();
              onClose();
            }}
          >
            Retry Synchronization
          </Button>
        </div>
      </div>
    </div>
  );
}
