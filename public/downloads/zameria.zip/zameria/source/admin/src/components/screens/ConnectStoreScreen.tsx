import { WebsiteAccountLink } from '../account/WebsiteAccountLink';
import React, { useState, useEffect } from 'react';
import { ArrowRight, Globe, CheckCircle2 } from 'lucide-react';
import { Card } from '@/components/ui/Card';
import { Button } from '@/components/ui/Button';
import { Badge } from '@/components/ui/Badge';
import { AccountConnectionView } from './AccountConnectionView';
import { zameriaBackendClient, StoreDetectionResult } from '@/lib/zameriaBackendClient';
import { AuthoritativeEntitlement } from '@/types/plugin';

interface ConnectStoreScreenProps {
  onConnected: (entitlement: AuthoritativeEntitlement) => void;
}

export function ConnectStoreScreen({ onConnected }: ConnectStoreScreenProps) {
  const runtime = (typeof window !== 'undefined' && (window as any).ZAMERIA_ADMIN) || {};
  const detectedStoreUrl = runtime.storeUrl || (typeof window !== 'undefined' ? window.location.origin : 'yourstore.com');
  const detectedStoreName = runtime.storeName || 'WooCommerce Store';
  const detectedAdminEmail = runtime.adminEmail || '';

  // Mode: 'login' | 'register'
  const [createdAccountEmail, setCreatedAccountEmail] = useState('');
  const [mode, setMode] = useState<'login' | 'register'>('login');
  const [isDetecting, setIsDetecting] = useState<boolean>(true);
  const [detectionResult, setDetectionResult] = useState<StoreDetectionResult | null>(null);

  // Form Fields
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [storeName, setStoreName] = useState(detectedStoreName);
  const [storeUrl, setStoreUrl] = useState(detectedStoreUrl);

  // Status
  const [isLoading, setIsLoading] = useState(false);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const [connectedSuccess, setConnectedSuccess] = useState<{
    entitlement: AuthoritativeEntitlement;
    mode: string;
  } | null>(null);

  // Automatic store registration detection on plugin load
  useEffect(() => {
    let isMounted = true;
    const runDetection = async () => {
      try {
        const res = await zameriaBackendClient.determineStoreStatus(detectedStoreUrl, detectedAdminEmail);
        if (!isMounted) return;
        setDetectionResult(res);
        if (res.isOnZameria) {
          setMode('login');
          if (res.emailHint) {
            setEmail(res.emailHint);
          } else if (detectedAdminEmail) {
            setEmail(detectedAdminEmail);
          }
        } else {
          setMode('register');
          if (detectedAdminEmail) {
            setEmail(detectedAdminEmail);
          }
          setStoreName(detectedStoreName);
          setStoreUrl(detectedStoreUrl);
        }
      } catch {
        if (isMounted) {
          setMode('register');
          if (detectedAdminEmail) setEmail(detectedAdminEmail);
        }
      } finally {
        if (isMounted) {
          setIsDetecting(false);
        }
      }
    };

    runDetection();
    return () => {
      isMounted = false;
    };
  }, [detectedStoreUrl, detectedAdminEmail, detectedStoreName]);

  const handleLoginConnect = async (e: React.FormEvent) => {
    e.preventDefault();
    if (isLoading || isDetecting) return;
    if (!email.trim()) {
      setErrorMessage('Please enter your ZAMERIA account email.');
      return;
    }
    if (!password) {
      setErrorMessage('Please enter your account password.');
      return;
    }

    setIsLoading(true);
    setErrorMessage(null);

    try {
      const res = await zameriaBackendClient.loginCustomer(email, password, {
        url: detectedStoreUrl,
        name: detectedStoreName,
      });

      if (res.success && res.entitlement) {
        setConnectedSuccess({
          entitlement: res.entitlement,
          mode: res.mode || 'trial_started',
        });
      } else {
        setErrorMessage(res.error || 'Could not verify account. Please check your credentials.');
      }
    } catch (err: any) {
      setErrorMessage(err.message || 'Connection failed. Please try again.');
    } finally {
      setIsLoading(false);
    }
  };

  const handleRegisterConnect = async (e: React.FormEvent) => {
    e.preventDefault();
    if (isLoading || isDetecting) return;
    if (!storeName.trim()) {
      setErrorMessage('Please enter your store name.');
      return;
    }
    if (!storeUrl.trim()) {
      setErrorMessage('Please enter your WooCommerce store URL.');
      return;
    }
    if (!email.trim() || !email.includes('@')) {
      setErrorMessage('Please enter a valid email address.');
      return;
    }
    if (!password || password.length < 8) {
      setErrorMessage('Password must be at least 8 characters long.');
      return;
    }

    setIsLoading(true);
    setErrorMessage(null);

    try {
      const res = await zameriaBackendClient.registerCustomer(
        {
          email: email.trim(),
          password,
          businessName: storeName.trim() || detectedStoreName,
          storeUrl: storeUrl.trim() || detectedStoreUrl,
        },
        {
          url: detectedStoreUrl,
          name: detectedStoreName,
        }
      );

      if (res.success && res.entitlement) {
        setConnectedSuccess({
          entitlement: res.entitlement,
          mode: 'trial_started',
        });
      } else {
        if (res.accountCreated) { setCreatedAccountEmail(email.trim().toLowerCase()); setMode('login'); setPassword(''); }
        setErrorMessage(res.error || 'Could not create account.');
      }
    } catch (err: any) {
      setErrorMessage(err.message || 'Registration failed. Please try again.');
    } finally {
      setIsLoading(false);
    }
  };

  // SUCCESS STATE: Clean, decisive confirmation with [ Open ZAMERIA ]
  if (connectedSuccess) {
    const isTrial = connectedSuccess.entitlement.status === 'trial_active';
    const planName = connectedSuccess.entitlement.plan_name || 'Active Plan';

    return (
      <div className="max-w-xl mx-auto py-10 sm:py-16 space-y-6">
        <Card className="shadow-sm border-[#E2E8F0] overflow-hidden text-center p-8 sm:p-10 space-y-6">
          <div className="w-16 h-16 rounded-full bg-emerald-50 text-emerald-600 border border-emerald-200/60 mx-auto flex items-center justify-center shadow-xs">
            <CheckCircle2 className="w-8 h-8" />
          </div>

          <div className="space-y-2">
            <Badge variant="connected" size="md" className="mb-1">
              Store Connected
            </Badge>
            <h1 className="text-2xl sm:text-3xl font-bold tracking-tight text-[#071A31]">
              You're connected!
            </h1>
            <p className="text-sm text-[#475569] max-w-md mx-auto leading-relaxed">
              {isTrial
                ? 'Your 7-day ZAMERIA trial has started automatically. Your WooCommerce store is connected and ready.'
                : `Your ${planName} has been restored and connected to this WooCommerce store.`}
            </p>
          </div>

          {/* Store Summary Pill */}
          <div className="p-3.5 bg-slate-50 border border-slate-200/80 rounded-xl text-xs max-w-sm mx-auto flex items-center justify-between text-left">
            <div className="flex items-center gap-2.5">
              <div className="w-8 h-8 rounded-lg bg-white border border-slate-200 flex items-center justify-center text-slate-700 shadow-2xs">
                <Globe className="w-4 h-4" />
              </div>
              <div>
                <span className="font-semibold text-slate-900 block">{detectedStoreName}</span>
                <span className="text-[11px] text-slate-500 font-mono block">{detectedStoreUrl}</span>
              </div>
            </div>
            <span className="text-[11px] font-semibold text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded border border-emerald-200">
              Active
            </span>
          </div>

          <div className="text-left text-sm text-slate-600 space-y-2">
            <p><strong>Next: connect your till.</strong> Go to the dashboard and choose Open POS on the device you will use to sell.</p>
            <p>Sign in with an authorised WordPress staff account, then let the initial catalogue sync finish. Your ZAMERIA account manages the store subscription.</p>
          </div>
          <WebsiteAccountLink email={email.trim().toLowerCase()} />
          {/* Primary CTA */}
          <div className="pt-2">
            <Button
              type="button"
              variant="primary"
              size="lg"
              onClick={() => onConnected(connectedSuccess.entitlement)}
              className="w-full sm:w-auto px-8 font-bold shadow-md"
              icon={<ArrowRight className="w-4 h-4" />}
            >
              Go to dashboard
            </Button>
          </div>
        </Card>
      </div>
    );
  }

  const changeMode = (next: 'login' | 'register') => {
    setMode(next);
    setPassword('');
    setShowPassword(false);
    setErrorMessage(null);
  };
  const changeField = (setter: (value: string) => void) => (value: string) => {
    setter(value);
    if (errorMessage) setErrorMessage(null);
  };
  return (
    <>
    <AccountConnectionView
      mode={mode} email={email} password={password} storeName={storeName} storeUrl={storeUrl}
      detectedStoreName={detectedStoreName} detectedStoreUrl={detectedStoreUrl}
      showPassword={showPassword} isLoading={isLoading} isDetecting={isDetecting}
      isRecognized={Boolean(detectionResult?.isOnZameria)} errorMessage={errorMessage}
      onModeChange={changeMode} onEmailChange={changeField(setEmail)} onPasswordChange={changeField(setPassword)}
      onStoreNameChange={changeField(setStoreName)} onStoreUrlChange={changeField(setStoreUrl)}
      onTogglePassword={() => setShowPassword(value => !value)}
      onSubmit={mode === 'login' ? handleLoginConnect : handleRegisterConnect}
    />
    {createdAccountEmail && <div className="max-w-4xl mx-auto mt-6"><WebsiteAccountLink email={createdAccountEmail} /></div>}
    </>
  );
}
