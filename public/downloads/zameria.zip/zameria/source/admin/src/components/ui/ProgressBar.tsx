import React from 'react';
import { cn } from '@/lib/utils';

export interface ProgressBarProps {
  value: number; // 0 to 100
  color?: 'brand' | 'amber' | 'emerald' | 'rose';
  className?: string;
}

export function ProgressBar({ value, color = 'brand', className }: ProgressBarProps) {
  const clampedValue = Math.min(100, Math.max(0, value));

  const colorStyles = {
    brand: 'bg-[#071A31]',
    amber: 'bg-amber-500',
    emerald: 'bg-emerald-500',
    rose: 'bg-rose-500',
  };

  return (
    <div className={cn('w-full bg-slate-100 rounded-full h-2 overflow-hidden border border-slate-200/60', className)}>
      <div
        className={cn('h-full rounded-full transition-all duration-500 ease-out', colorStyles[color])}
        style={{ width: `${clampedValue}%` }}
      />
    </div>
  );
}
