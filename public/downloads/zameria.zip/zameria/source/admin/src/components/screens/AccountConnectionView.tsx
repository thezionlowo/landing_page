import React from 'react';
import { ArrowRight, Check, Eye, EyeOff, Globe, Loader2, LockKeyhole, ShieldCheck, ShoppingBag, RefreshCw, AlertCircle } from 'lucide-react';

export interface AccountConnectionViewProps {
  mode: 'login' | 'register';
  storeName: string;
  storeUrl: string;
  detectedStoreName: string;
  detectedStoreUrl: string;
  email: string;
  password: string;
  showPassword: boolean;
  isLoading: boolean;
  isDetecting: boolean;
  isRecognized: boolean;
  errorMessage: string | null;
  onModeChange: (mode: 'login' | 'register') => void;
  onEmailChange: (value: string) => void;
  onPasswordChange: (value: string) => void;
  onStoreNameChange: (value: string) => void;
  onStoreUrlChange: (value: string) => void;
  onTogglePassword: () => void;
  onSubmit: (event: React.FormEvent) => void;
}

/** Presentation only: authentication and entitlement logic remain in the controller. */
export function AccountConnectionView(props: AccountConnectionViewProps) {
  const registering = props.mode === 'register';
  const busy = props.isLoading || props.isDetecting;
  const passwordId = registering ? 'reg-password' : 'login-password';
  let domain = props.detectedStoreUrl;
  try { domain = new URL(/^https?:\/\//i.test(domain) ? domain : `https://${domain}`).host; } catch {}

  return (
    <section className="zm-connect" aria-labelledby="zm-connect-title">
      <aside className="zm-connect-context">
        <div>
          <div className="zm-connect-eyebrow"><span className="zm-connect-brand-mark" aria-hidden="true">Z</span> ZAMERIA · STORE SETUP</div>
          <h2 className="zm-connect-context-title">Manage your in-store and website orders <span>in one place.</span></h2>
          <p className="zm-connect-context-copy">Keep your products, stock and customers in sync across your shop and website.</p>
          <ul className="zm-connect-benefits">
            <li><ShoppingBag aria-hidden="true" /><span>1. Create or log in to your ZAMERIA account</span></li>
            <li><RefreshCw aria-hidden="true" /><span>2. Connect this installed WordPress plugin</span></li>
            <li><ShieldCheck aria-hidden="true" /><span>3. Open POS, sign in as staff and finish sync</span></li>
          </ul>
        </div>
        <div className="zm-connect-store">
          <div className="zm-connect-store-icon"><Globe aria-hidden="true" /></div>
          <div className="zm-connect-store-details">
            <span className="zm-connect-store-caption">CONNECTING THIS STORE</span>
            <strong title={props.detectedStoreName}>{props.detectedStoreName}</strong>
            <span className="zm-connect-store-domain" title={props.detectedStoreUrl}>{domain}</span>
          </div>
        </div>
      </aside>

      <div className="zm-connect-main">
        <div className="zm-connect-switch" role="group" aria-label="Account access">
          <button type="button" aria-pressed={!registering} disabled={busy} onClick={() => props.onModeChange('login')}>Log in</button>
          <button type="button" aria-pressed={registering} disabled={busy} onClick={() => props.onModeChange('register')}>Create account</button>
        </div>

        <header className="zm-connect-heading">
          <h1 id="zm-connect-title">{registering ? 'Get started with ZAMERIA' : 'Connect to ZAMERIA'}</h1>
          <p>{registering ? 'New to ZAMERIA? Create one account here. Already registered on our website? Choose Log in and use that same account.' : 'Already registered on our website? Use that same ZAMERIA account to connect this store.'}</p>
          {props.isDetecting ? <span className="zm-connect-status" role="status"><Loader2 className="zm-connect-spinner" aria-hidden="true" />Checking your store…</span>
            : props.isRecognized && !registering ? <span className="zm-connect-status"><Check aria-hidden="true" />Existing ZAMERIA store</span> : null}
        </header>

        <form className="zm-connect-form" onSubmit={props.onSubmit} aria-busy={busy}>
          {registering && <>
            <div className="zm-field">
              <label htmlFor="reg-store-name">Store name</label>
              <input id="reg-store-name" name="business_name" type="text" autoComplete="organization" required value={props.storeName} onChange={event => props.onStoreNameChange(event.target.value)} placeholder="Your store name" disabled={busy} />
            </div>
            <div className="zm-field">
              <label htmlFor="reg-store-url">WooCommerce store URL</label>
              <input id="reg-store-url" name="store_url" type="text" inputMode="url" autoComplete="url" required spellCheck={false} value={props.storeUrl} onChange={event => props.onStoreUrlChange(event.target.value)} placeholder="https://yourstore.com" disabled={busy} aria-describedby="zm-store-url-hint" />
              <p id="zm-store-url-hint" className="zm-field-hint">The address of the WooCommerce store you’re connecting.</p>
            </div>
          </>}
          <div className="zm-field">
            <label htmlFor={registering ? 'reg-email' : 'login-email'}>Email address</label>
            <input id={registering ? 'reg-email' : 'login-email'} name="email" type="email" inputMode="email" autoComplete="username" autoCapitalize="none" spellCheck={false} required value={props.email} onChange={event => props.onEmailChange(event.target.value)} placeholder="you@yourbusiness.com" disabled={busy} />
          </div>
          <div className="zm-field">
            <label htmlFor={passwordId}>Password</label>
            <div className="zm-password-control">
              <input id={passwordId} name="password" type={props.showPassword ? 'text' : 'password'} autoComplete={registering ? 'new-password' : 'current-password'} minLength={registering ? 8 : undefined} required value={props.password} onChange={event => props.onPasswordChange(event.target.value)} placeholder={registering ? 'Create a password' : 'Enter your password'} disabled={busy} aria-describedby={registering ? 'zm-password-hint' : undefined} />
              <button className="zm-password-toggle" type="button" onClick={props.onTogglePassword} disabled={busy} aria-label={props.showPassword ? 'Hide password' : 'Show password'} aria-pressed={props.showPassword} aria-controls={passwordId}>{props.showPassword ? <EyeOff aria-hidden="true" /> : <Eye aria-hidden="true" />}</button>
            </div>
            {registering && <p id="zm-password-hint" className="zm-field-hint">Use at least 8 characters.</p>}
          </div>

          {props.errorMessage && <div className="zm-connect-error" role="alert"><AlertCircle aria-hidden="true" /><span>{props.errorMessage}</span></div>}

          {registering && <div className="zm-connect-trial"><span className="zm-connect-trial-label">7-DAY FREE TRIAL</span><p>Your 7-day trial starts automatically when your store is connected.</p><span>Available to eligible stores.</span></div>}

          <p className="zm-connect-disclosure">Connecting sends your ZAMERIA account credentials and store details to the account service, which checks store access during use. {registering && 'Registration also creates a signup record for onboarding follow-up. Continued POS access requires an active trial or plan. '}By {registering ? 'creating an account' : 'connecting'}, you agree to the <a href="https://www.zameria.co/terms" target="_blank" rel="noopener noreferrer">Terms of Service</a>. Read the <a href="https://www.zameria.co/privacy" target="_blank" rel="noopener noreferrer">Privacy Policy</a>.</p>

          <button className="zm-connect-submit" type="submit" disabled={busy}>
            {props.isLoading ? <><Loader2 className="zm-connect-spinner" aria-hidden="true" /><span>{registering ? 'Creating your account…' : 'Connecting your store…'}</span></>
              : <><span>{registering ? 'Create Account & Connect Store' : 'Connect to ZAMERIA'}</span><ArrowRight aria-hidden="true" /></>}
          </button>
          <p className="zm-connect-security"><LockKeyhole aria-hidden="true" />Secure connection to your ZAMERIA account</p>
        </form>

        <div className="zm-connect-footer">
          {registering ? <button type="button" disabled={busy} onClick={() => props.onModeChange('login')}>Already have a ZAMERIA account? Log in</button>
            : <><span>New to ZAMERIA?</span><button type="button" disabled={busy} onClick={() => props.onModeChange('register')}>Create an account <ArrowRight aria-hidden="true" /></button></>}
        </div>
      </div>
    </section>
  );
}
