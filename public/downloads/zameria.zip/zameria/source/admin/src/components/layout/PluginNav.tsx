import { LayoutDashboard, Users, UserRoundCog, CreditCard, Sliders } from 'lucide-react';
import { PluginTab } from '@/types/plugin';

interface PluginNavProps {
  activeTab: PluginTab;
  onSelectTab: (tab: PluginTab) => void;
  deviceCount?: number;
  deviceLimit?: number | null;
}
export function PluginNav({ activeTab, onSelectTab, deviceCount = 0, deviceLimit }: PluginNavProps) {
  const items = [
    { id: 'overview', label: 'Overview', Icon: LayoutDashboard, aliases: ['dashboard'] },
    { id: 'devices', label: 'Active users', Icon: Users, aliases: [] },
    { id: 'staff', label: 'Cashiers & staff', Icon: UserRoundCog, aliases: [] },
    { id: 'subscription', label: 'Subscription', Icon: CreditCard, aliases: ['account', 'license'] },
    { id: 'settings', label: 'Settings', Icon: Sliders, aliases: ['connection', 'sync', 'help'] },
  ];
  return <nav className="zm-navigation" aria-label="ZAMERIA workspace">
    <span className="zm-nav-label">MANAGE YOUR STORE</span>
    {items.map(({ id, label, Icon, aliases }) => <button key={id} type="button" aria-current={activeTab === id || aliases.includes(activeTab) ? 'page' : undefined} onClick={() => onSelectTab(id as PluginTab)}>
      <Icon aria-hidden="true" /><span>{label}</span>{id === 'devices' && <small>{deviceCount}{deviceLimit != null ? ` / ${deviceLimit}` : ''}</small>}
    </button>)}
  </nav>;
}
