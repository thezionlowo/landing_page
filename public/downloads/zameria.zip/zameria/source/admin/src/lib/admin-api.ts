type AdminRuntime = {
  ajaxUrl?: string;
  nonce?: string;
  entitlement?: any;
};

export async function adminAction<T>(action: string, data?: Record<string, string>): Promise<T> {
  const runtime = (window as Window & { ZAMERIA_ADMIN?: AdminRuntime }).ZAMERIA_ADMIN || {};
  const params = new URLSearchParams({ action, nonce: runtime.nonce || '', ...(data || {}) });
  const response = await fetch(runtime.ajaxUrl || '/wp-admin/admin-ajax.php', {
    method: 'POST',
    headers: { 'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8' },
    body: params.toString(),
  });
  const payload = await response.json();
  if (!response.ok || !payload.success) {
    throw Object.assign(new Error(payload?.data?.message || 'The request could not be completed.'), { status: response.status, requiresReconnect: payload?.data?.requires_reconnect === true });
  }
  return payload.data as T;
}

export function extractPlanFromEntitlement(entitlement: any): {
  plan: 'Starter' | 'Business';
  planName: string;
  licenseKey: string;
  licenseExpiresAt: string;
  status: string;
} {
  if (!entitlement) {
    return {
      plan: 'Starter',
      planName: 'Starter Plan',
      licenseKey: '',
      licenseExpiresAt: '',
      status: 'trial_not_started',
    };
  }

  const status = entitlement.status || 'trial_not_started';
  const sub = entitlement.subscription;
  const rawSubPlan = String(
    sub?.plan_name ||
    sub?.plan ||
    entitlement.plan_name ||
    entitlement.plan ||
    entitlement.license?.plan_name ||
    entitlement.license?.plan ||
    entitlement.licenses?.[0]?.plan_name ||
    entitlement.licenses?.[0]?.plan ||
    ''
  ).toLowerCase();
  const isGifted = status === 'gifted_active' || (entitlement as any).access_type === 'gifted' || sub?.price === 'Gifted Plan' || Boolean((entitlement as any).isGifted);

  const isStarter =
    rawSubPlan.includes('starter') ||
    (!rawSubPlan.includes('business') && status === 'trial_active');

  const plan: 'Starter' | 'Business' = isStarter ? 'Starter' : 'Business';
  let planName = sub?.plan_name || entitlement.plan_name || entitlement.license?.plan_name;
  if (!planName) {
    if (isGifted) {
      planName = `${plan} (Gifted Plan)`;
    } else if (status === 'trial_active') {
      planName = 'Free Trial (7 Days)';
    } else {
      planName = `${plan} Plan`;
    }
  }

  const licenseKey =
    entitlement.license_key ||
    entitlement.licenseKey ||
    entitlement.license?.key ||
    entitlement.licenses?.[0]?.key ||
    sub?.license_key ||
    sub?.license_key_masked ||
    '';

  const licenseExpiresAt =
    entitlement.license_expires_at ||
    entitlement.licenseExpiresAt ||
    entitlement.license?.expires_at ||
    entitlement.licenses?.[0]?.expires_at ||
    sub?.next_billing_date ||
    entitlement.next_billing_date ||
    '';

  return { plan, planName, licenseKey, licenseExpiresAt, status };
}

export async function syncEntitlementToWordPress(entitlement: any): Promise<void> {
  if (typeof window === 'undefined' || !(window as any).ZAMERIA_ADMIN) return;
  try {
    const { plan, planName, licenseKey, licenseExpiresAt, status } = extractPlanFromEntitlement(entitlement);
    await adminAction('zameria_admin_set_entitlement', {
      status,
      plan,
      plan_name: planName,
      trial_start: entitlement.trial_start || entitlement.trial?.start_date || entitlement.trial?.started_at || entitlement.started_at || '',
      trial_end: entitlement.trial_end || entitlement.trial?.end_date || entitlement.trial?.expires_at || entitlement.expires_at || '',
      license_key: licenseKey,
      license_expires_at: licenseExpiresAt,
    });
  } catch (err) {
    console.warn('Could not sync entitlement to WordPress options:', err);
    throw err;
  }
}

export async function cloudAccountRequest(operation: string, payload: unknown = {}): Promise<any> {
  return adminAction('zameria_cloud_account', { operation, payload: JSON.stringify(payload) });
}
