import { AuthoritativeEntitlement, ScreenId } from '@/types/plugin';
import { licensingOffEntitlement, normalizeWpEntitlement } from './lifecycleData';
import { cloudAccountRequest, syncEntitlementToWordPress } from './admin-api';
import { migrateAccountCaches, verifiedEntitlement, withoutCredentials } from './accountSecurity';

// The Scoreflip cloud backend (trials, plans, licences):
// Configured via VITE_SCOREFLIP_BACKEND_URL or VITE_BACKEND_URL
const BACKEND_BASE_URL: string =
  (typeof import.meta !== 'undefined' &&
    ((import.meta as any).env?.VITE_SCOREFLIP_BACKEND_URL ||
      (import.meta as any).env?.VITE_BACKEND_URL ||
      (import.meta as any).env?.VITE_ZAMERIA_BACKEND_URL)) ||
  // The distributed WordPress plugin must not silently disable licensing when
  // a local build omitted a Vite env file.
  'https://scoreflip-go-hwsgspeycq-uc.a.run.app/api/v1/zameria';

export const LICENSING_ENABLED = BACKEND_BASE_URL !== '';

export interface StoreDetectionResult {
  isOnZameria: boolean;
  emailHint?: string;
  storeName?: string;
  planName?: string;
  status?: string;
  source: 'cloud_account' | 'cloud_trial' | 'local_registry' | 'wp_entitlement' | 'fresh_store';
}

const NOT_CONFIGURED = 'ZAMERIA plans and licences are not switched on yet.';

export function maskLicenseKey(key: string): string {
  if (!key) return '';
  const clean = key.trim().toUpperCase();
  if (clean.length <= 8) return clean;
  const parts = clean.split('-');
  if (parts.length >= 3) {
    return `${parts[0]}-••••-••••-${parts[parts.length - 1]}`;
  }
  return `${clean.substring(0, 4)}-••••-••••-${clean.slice(-4)}`;
}

export function resolveStoreUrl(): string {
  if (typeof window !== 'undefined' && window.location.hostname && !['localhost', '127.0.0.1'].includes(window.location.hostname)) {
    return (window as any).ZAMERIA_ADMIN?.storeUrl || window.location.origin;
  }
  return typeof window !== 'undefined' ? (window as any).ZAMERIA_ADMIN?.storeUrl || window.location.origin : '';
}

export class ZameriaBackendClient {
  private static instance: ZameriaBackendClient;

  public static getInstance(): ZameriaBackendClient {
    migrateAccountCaches();
    if (!ZameriaBackendClient.instance) {
      ZameriaBackendClient.instance = new ZameriaBackendClient();
    }
    return ZameriaBackendClient.instance;
  }

  /**
   * Fetches the authoritative entitlement for a store from the ZAMERIA cloud.
   * Preserves offline authorization if the network temporarily drops.
   */
  public async getEntitlement(storeUrl = resolveStoreUrl()): Promise<{
    success: boolean; entitlement: AuthoritativeEntitlement; isOffline?: boolean; error?: string; requiresReconnect?: boolean;
  }> {
    try {
      const data = await cloudAccountRequest('entitlement');
      const entitlement = verifiedEntitlement(data.entitlement, storeUrl);
      await syncEntitlementToWordPress(entitlement);
      this.cacheEntitlement(entitlement);
      return { success: true, entitlement };
    } catch (error) {
      const rejected = [401, 403, 404].includes((error as any)?.status);
      if (rejected) {
        localStorage.removeItem('zameria_cached_entitlement_v2');
        localStorage.removeItem('zameria_cached_entitlement');
      }
      const cached = rejected ? null : this.getCachedEntitlement();
      return { success: Boolean(cached), isOffline: true, requiresReconnect: (error as any)?.requiresReconnect === true,
        entitlement: cached || normalizeWpEntitlement({ status: 'backend_unavailable' }, storeUrl),
        error: error instanceof Error ? error.message : 'Unable to verify account access.' };
    }
  }

  public getCachedEntitlement(): AuthoritativeEntitlement | null {
    try {
      const raw = localStorage.getItem('zameria_cached_entitlement_v2');
      if (!raw) return null;
      const cached = JSON.parse(raw);
      // Only bounded, previously verified authorization may survive a network failure.
      if (!cached.verifiedAt || Date.now() - cached.verifiedAt > 24 * 3600000) return null;
      const entitlement = verifiedEntitlement(cached.entitlement, resolveStoreUrl());
      return ['trial_active', 'paid_active', 'gifted_active'].includes(entitlement.status) ? entitlement : null;
    } catch { return null; }
  }

  private cacheEntitlement(entitlement: AuthoritativeEntitlement): void {
    const validated = verifiedEntitlement(entitlement, resolveStoreUrl());
    localStorage.removeItem('zameria_cached_entitlement');
    localStorage.setItem('zameria_cached_entitlement_v2', JSON.stringify({ verifiedAt: Date.now(), entitlement: validated }));
  }

  /**
   * Intelligently inspects the merchant's store URL and admin email to determine
   * if the website is already registered on ZAMERIA (so the plugin can present
   * Log In) or is a brand-new store (so it presents Sign Up / Start 7-Day Free Trial).
   */
  public async determineStoreStatus(
    storeUrl: string,
    adminEmail?: string
  ): Promise<StoreDetectionResult> {
    const cleanHost = (storeUrl || '')
      .replace(/^https?:\/\//i, '')
      .replace(/\/.*$/, '')
      .toLowerCase()
      .trim();
    const cleanEmail = (adminEmail || '').trim().toLowerCase();

    // 1. Check local WordPress runtime entitlement if already licensed
    if (typeof window !== 'undefined') {
      const runtime = (window as any).ZAMERIA_ADMIN;
      const wpEnt = runtime?.entitlement;
      if (
        wpEnt &&
        (wpEnt.is_licensed ||
          ['trial_active', 'paid_active', 'gifted_active', 'trial_expired'].includes(wpEnt.status))
      ) {
        return {
          isOnZameria: true,
          emailHint: cleanEmail,
          storeName: runtime?.storeName || 'WooCommerce Store',
          planName: wpEnt.plan_name || 'Active Plan',
          status: wpEnt.status,
          source: 'wp_entitlement',
        };
      }
    }

    // Before authentication, do not infer account existence from browser storage or public license APIs.
    // 4. Fresh store: not registered on ZAMERIA yet
    return {
      isOnZameria: false,
      source: 'fresh_store',
    };
  }

  /**
   * Unified Authentication: Logs in an existing ZAMERIA customer, connects the store,
   * and automatically activates their 7-day trial (or restores their existing trial / paid / gifted plan).
   */
  private async connectVerifiedAccount(data: any, storeData?: { id?: string; name?: string; url?: string }) {
    const store = storeData?.url || resolveStoreUrl();
    const name = storeData?.name || 'WooCommerce Store';
    const customer = withoutCredentials(data.account);
    if (!customer?.id) throw new Error('The account service returned an invalid response.');
    if (data.connection_error) throw new Error(data.connection_error.message || 'The store connection could not be completed.');
    const connectedOnServer = data.connection_complete === true;
    const remote = connectedOnServer ? data : await cloudAccountRequest('entitlement');
    let entitlement = remote.entitlement;
    if (!connectedOnServer && (!entitlement || ['unactivated', 'trial_not_started'].includes(entitlement.status))) {
      const paid = customer.licenses?.find((license: any) => !license.is_trial && String(license.status).toLowerCase() === 'active');
      let code = paid?.license_key || paid?.licenseKey || paid?.code || customer.trial?.activationCode || customer.activationCode;
      if (!code) {
        // The server decides eligibility, including whether this store already used a trial.
        const trial = await cloudAccountRequest('trial/request', { business_name: name, store_url: store });
        code = trial.trial_code;
      }
      if (!code) throw new Error('No server-issued activation code is available.');
      const activation = await cloudAccountRequest('trial/activate', { license_key: code, store_url: store });
      entitlement = activation.entitlement;
      if (!entitlement) entitlement = (await cloudAccountRequest('entitlement')).entitlement;
    }
    entitlement = verifiedEntitlement(entitlement, store, name);
    if (!connectedOnServer) await syncEntitlementToWordPress(entitlement);
    this.cacheEntitlement(entitlement);
    localStorage.setItem('zameria_customer_session_v3', JSON.stringify(customer));
    const mode = entitlement.status === 'paid_active' ? 'paid_restored'
      : entitlement.status === 'gifted_active' ? 'gifted_restored' : 'trial_restored';
    return { success: true, entitlement, customer, mode } as const;
  }

  public async loginCustomer(email: string, pass: string, storeData?: { id?: string; name?: string; url?: string }): Promise<{
    success: boolean; entitlement?: AuthoritativeEntitlement; customer?: any;
    mode?: 'trial_started' | 'trial_restored' | 'paid_restored' | 'gifted_restored'; error?: string;
  }> {
    if (!email.trim().includes('@') || !pass) return { success: false, error: 'Enter your account email and password.' };
    try {
      const data = await cloudAccountRequest('login', { email: email.trim().toLowerCase(), password: pass });
      return await this.connectVerifiedAccount(data, storeData);
    } catch (error) { return { success: false, error: error instanceof Error ? error.message : 'Sign-in could not be verified.' }; }
  }

  public async registerCustomer(data: { fullName?: string; email: string; password: string; businessName?: string; storeAddress?: string; storeUrl?: string }, storeData?: { id?: string; name?: string; url?: string }): Promise<{
    success: boolean; entitlement?: AuthoritativeEntitlement; customer?: any; error?: string; accountCreated?: boolean;
  }> {
    if (!data.email.includes('@') || data.password.length < 8) return { success: false, error: 'Enter a valid email and a password of at least 8 characters.' };
    try {
      const registered = await cloudAccountRequest('register', { full_name: data.fullName || data.businessName,
        business_name: data.businessName || storeData?.name, email: data.email.trim().toLowerCase(), password: data.password,
        store_url: data.storeUrl || storeData?.url, store_address: data.storeAddress || '' });
      if (!registered.account?.id) throw new Error('The account service returned an invalid response.');
      try { return await this.connectVerifiedAccount(registered, storeData); }
      catch (error) {
        return { success: false, accountCreated: true, customer: withoutCredentials(registered.account),
          error: `Your ZAMERIA account was created. Log in with the same email and password to retry connecting this store. ${error instanceof Error ? error.message : 'Store connection could not be verified.'}` };
      }
    } catch (error) { return { success: false, error: error instanceof Error ? error.message : 'Registration could not be verified.' }; }
  }

  /**
   * Activates the 7-day trial using a valid Trial Activation Code or Paid License Key.
   */
  public async activateTrial(
    code: string,
    storeData?: { id?: string; name?: string; url?: string }
  ): Promise<{
    success: boolean;
    entitlement?: AuthoritativeEntitlement;
    error?: string;
    code?: string;
    authorizedDomain?: string;
    isOffline?: boolean;
  }> {
    if (!LICENSING_ENABLED) {
      return { success: false, error: NOT_CONFIGURED, code: 'NOT_CONFIGURED' };
    }
    try {
      const data = await cloudAccountRequest('trial/activate', { license_key: code.trim(), store_url: storeData?.url || resolveStoreUrl() });
      const raw = data.entitlement || (await cloudAccountRequest('entitlement')).entitlement;
      const entitlement = verifiedEntitlement(raw, storeData?.url || resolveStoreUrl(), storeData?.name);
      await syncEntitlementToWordPress(entitlement);
      this.cacheEntitlement(entitlement);
      return { success: true, entitlement };
    } catch (error) {
      return { success: false, error: error instanceof Error ? error.message : 'Activation could not be verified.', code: 'ACTIVATION_FAILED' };
    }
  }

  /**
   * Validates and activates a Paid Software License Key against the authoritative cloud backend.
   */
  public async validateLicense(
    licenseKey: string,
    storeData?: { id?: string; name?: string; url?: string }
  ): Promise<{
    success: boolean;
    entitlement?: AuthoritativeEntitlement;
    error?: string;
    code?: string;
    authorizedDomain?: string;
    isOffline?: boolean;
  }> {
    return this.activateTrial(licenseKey, storeData);
  }

  /**
   * Dev testing helper: Request backend simulation state change.
   */
  public async setSimulationState(state: string, accountId?: string): Promise<AuthoritativeEntitlement | null> {
    if (!(import.meta as any).env?.DEV) return null;
    if (!LICENSING_ENABLED) return null;
    try {
      const res = await fetch(`${BACKEND_BASE_URL}/simulation/state`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ state, accountId }),
      });
      if (res.ok) {
        const data = await res.json();
        return data.entitlement;
      }
    } catch {
      // ignore
    }
    return null;
  }

  /**
   * Dev testing helper: Upgrade to Paid Business Plan
   */
  public async upgradeSubscription(accountId?: string, planName = 'Business', price = '₦300,000 / year') {
    if (!(import.meta as any).env?.DEV) return { success: false, error: 'Use verified checkout to change a plan.' };
    try {
      const res = await fetch(`${BACKEND_BASE_URL}/subscription/upgrade`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ accountId, planName, price }),
      });
      return await res.json();
    } catch {
      return { success: false, error: 'Network error' };
    }
  }

  /**
   * Disconnects this WooCommerce store from ZAMERIA cloud.
   * Disables the cloud connection first, then clears the browser account cache.
   */
  public async disconnect(): Promise<void> {
    const result=await cloudAccountRequest('store/disconnect');
    if(result.success!==true)throw new Error('Store disconnection was not confirmed.');
    if(typeof localStorage!=='undefined'){
      localStorage.removeItem('zameria_cached_entitlement');
      localStorage.removeItem('zameria_cached_entitlement_v2');
      localStorage.removeItem('zameria_customer_session_v3');
    }
  }
}

export const zameriaBackendClient = ZameriaBackendClient.getInstance();
