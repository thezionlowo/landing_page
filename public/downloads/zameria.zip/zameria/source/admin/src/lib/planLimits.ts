// Keep aligned with Settings::STARTER_STAFF_LIMIT and the account service.
export const STARTER_STAFF_LIMIT = 5;
