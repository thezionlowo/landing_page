import { AuthoritativeEntitlement, ScreenId } from '@/types/plugin';

export function maskLicenseKey(key: string): string {
  if (!key) return '';
  const clean = key.trim().toUpperCase();
  if (clean.length <= 8) return clean;
  const parts = clean.split('-');
  if (parts.length >= 3) {
    return `${parts[0]}-••••-••••-${parts[parts.length - 1]}`;
  }
  return `${clean.substring(0, 4)}-••••-••••-${clean.slice(-4)}`;
}

/**
 * Converts a WordPress-provided entitlement (e.g. from Settings::get_entitlement())
 * into the authoritative frontend AuthoritativeEntitlement interface.
 */
export function normalizeWpEntitlement(
  wp: any,
  storeUrl?: string,
  storeName?: string
): AuthoritativeEntitlement {
  const store = storeUrl || (typeof window !== 'undefined' && (window as any).ZAMERIA_ADMIN?.storeUrl) || '';
  const name = storeName || (typeof window !== 'undefined' && (window as any).ZAMERIA_ADMIN?.storeName) || 'WooCommerce Store';
  const status = wp?.status || 'unactivated';

  // 1. ACTIVE PAID SUBSCRIPTION
  if (status === 'paid_active') {
    const rawPlan = String(wp.plan || wp.plan_name || '').toLowerCase();
    const isBusiness = rawPlan.includes('business');
    const isStarter = rawPlan.includes('starter') && !isBusiness;
    const resolvedPlan: 'Starter' | 'Business' = isStarter ? 'Starter' : 'Business';
    const planName = wp.plan_name || `${resolvedPlan} Plan`;
    const isUSD = wp.currency === 'USD' || (typeof wp.price === 'string' && wp.price.includes('$'));
    const defaultPrice = isUSD
      ? (resolvedPlan === 'Starter' ? '$250 / year' : '$400 / year')
      : (resolvedPlan === 'Starter' ? '₦200,000 / year' : '₦350,000 / year');
    const price = wp.price || defaultPrice;
    const rawKey = wp.license_key || '';
    const maskedKey = rawKey ? maskLicenseKey(rawKey) : (wp.license_key_masked || '');

    return {
      account_id: wp.account_id || '',
      store_id: wp.store_id || '',
      store_name: name,
      store_url: store,
      store_domain: store,
      status: 'paid_active',
      plan: resolvedPlan,
      plan_name: planName,
      license_key: rawKey || undefined,
      license_expires_at: wp.license_expires_at || undefined,
      subscription: {
        plan_name: planName,
        price,
        billing_cycle: 'Annual',
        status: 'active',
        next_billing_date: wp.license_expires_at || '',
        license_key_masked: maskedKey,
        license_status: 'active',
      },
    };
  }

  // 2. ACTIVE GIFTED PLAN
  if (status === 'gifted_active') {
    const rawPlan = String(wp.plan || wp.plan_name || '').toLowerCase();
    const isBusiness = rawPlan.includes('business');
    const isStarter = rawPlan.includes('starter') && !isBusiness;
    const resolvedPlan: 'Starter' | 'Business' = isStarter ? 'Starter' : 'Business';
    const planName = wp.plan_name || `${resolvedPlan} (Gifted Plan)`;
    const rawKey = wp.license_key || '';
    const maskedKey = rawKey ? maskLicenseKey(rawKey) : (wp.license_key_masked || '');

    return {
      account_id: wp.account_id || '',
      store_id: wp.store_id || '',
      store_name: name,
      store_url: store,
      store_domain: store,
      status: 'gifted_active',
      plan: resolvedPlan,
      plan_name: planName,
      license_key: rawKey || undefined,
      license_expires_at: wp.license_expires_at || undefined,
      subscription: {
        plan_name: planName,
        price: 'Gifted Plan',
        billing_cycle: 'Annual',
        status: 'active',
        next_billing_date: wp.license_expires_at || '',
        license_key_masked: maskedKey,
        license_status: 'active',
      },
    };
  }

  // 3. ACTIVE TRIAL
  if (status === 'trial_active') {
    return {
      account_id: wp.account_id || '',
      store_id: wp.store_id || '',
      store_name: name,
      store_url: store,
      store_domain: store,
      status: 'trial_active',
      trial: {
        started_at: wp.trial_start || wp.trial?.started_at || '',
        expires_at: wp.trial_end || wp.trial?.expires_at || '',
        days_remaining: typeof wp.days_remaining === 'number' ? wp.days_remaining : (wp.trial?.days_remaining ?? 0),
        total_days: 7,
        activation_code_used: wp.activation_code || wp.trial?.activation_code_used || '',
      },
    };
  }

  // 4. EXPIRED STATES (trial_expired, paid_expired, gifted_expired)
  if (status === 'trial_expired' || status === 'paid_expired' || status === 'gifted_expired') {
    const isPaid = status === 'paid_expired' || status === 'gifted_expired';
    return {
      account_id: wp.account_id || '',
      store_id: wp.store_id || '',
      store_name: name,
      store_url: store,
      store_domain: store,
      status: isPaid ? 'paid_expired' : 'trial_expired',
      subscription: isPaid ? {
        plan_name: wp.plan_name || 'Business Plan',
        price: 'Expired',
        billing_cycle: 'Annual',
        status: 'cancelled',
        next_billing_date: wp.license_expires_at || 'Expired',
        license_key_masked: '••••-••••',
        license_status: 'revoked',
      } : undefined,
    };
  }

  // Missing transport data must not invent a connected account or its sync totals.
  if (status === 'backend_unavailable') {
    return { account_id: wp.account_id || '', store_id: wp.store_id || '', store_name: name, store_url: store, store_domain: store, status: 'backend_unavailable' };
  }

  // 5. NO ACTIVE ENTITLEMENT (Unactivated / Trial Not Started)
  return {
    account_id: '',
    store_id: '',
    store_name: name,
    store_url: store,
    store_domain: store,
    status: 'unactivated',
  };
}

/**
 * Resolves the deterministic ScreenId for an AuthoritativeEntitlement.
 */
export function resolveScreenForEntitlement(entitlement: AuthoritativeEntitlement): ScreenId {
  if (entitlement.status === 'paid_active' || (entitlement.status as any) === 'gifted_active') {
    return 'state_7_paid_active';
  }
  if (entitlement.status === 'trial_active') {
    const days = entitlement.trial?.days_remaining ?? 7;
    if (days <= 1) return 'state_5_trial_1d';
    if (days <= 3) return 'state_4_trial_3d';
    if (days <= 5) return 'state_3_trial_5d';
    return 'state_2_trial_7d';
  }
  if (entitlement.status === 'trial_expired' || (entitlement.status as any) === 'paid_expired' || (entitlement.status as any) === 'gifted_expired') {
    return 'state_6_trial_expired';
  }
  if (entitlement.status === 'paid_cancelled' || (entitlement.status as any) === 'cancelled') {
    return 'state_8_subscription_cancelled';
  }
  if (entitlement.status === 'backend_unavailable') {
    return 'state_9_backend_unavailable';
  }
  return 'state_1_unactivated';
}

/**
 * Used when no ZAMERIA cloud is configured (see LICENSING_ENABLED): the store's real details from
 * WordPress, and nothing locked.
 */
export function licensingOffEntitlement(): AuthoritativeEntitlement {
  const runtime = (typeof window !== 'undefined' && (window as any).ZAMERIA_ADMIN) || {};
  const storeUrl: string = runtime.storeUrl || (typeof window !== 'undefined' ? window.location.origin : '');
  let storeName: string = runtime.storeName || '';
  if (!storeName) {
    try {
      storeName = new URL(storeUrl).hostname;
    } catch {
      storeName = 'Your store';
    }
  }
  return {
    account_id: '',
    store_id: '',
    store_name: storeName,
    store_url: storeUrl,
    status: 'licensing_off',
    sync: {
      status: 'healthy',
      last_synced: 'Automatic (on every change)',
      products_synced: runtime.productCount ?? 0,
      orders_synced: runtime.orderCount ?? 0,
      customers_synced: runtime.customerCount ?? 0,
      failed_items_count: 0,
    },
  };
}
