import type { AuthoritativeEntitlement } from '@/types/plugin';
import { normalizeWpEntitlement } from './lifecycleData';
export function withoutCredentials(value: any): any {
  if (Array.isArray(value)) return value.map(withoutCredentials);
  if (value && typeof value === 'object') return Object.fromEntries(Object.entries(value)
    .filter(([key]) => !/password|^(token|access_token|refresh_token|accessToken|refreshToken|authorization|secret)$/i.test(key))
    .map(([key, data]) => [key, withoutCredentials(data)]));
  return value;
}
export function migrateAccountCaches() {
  if (typeof localStorage === 'undefined') return;
  for (const key of ['zameria_customer_session', 'zameria_customer_session_v2', 'zameria_customer_session_v3', 'zameria_registered_customers_v2', 'zameria_registered_customers_v3']) {
    try { const raw = localStorage.getItem(key); if (raw) localStorage.setItem(key, JSON.stringify(withoutCredentials(JSON.parse(raw)))); }
    catch { localStorage.removeItem(key); }
  }
}
export function storeIdentity(value: string): string {
  try { const url = new URL(/^https?:\/\//i.test(value) ? value : `https://${value}`); return url.host.toLowerCase() + url.pathname.replace(/\/+$/, ''); } catch { return ''; }
}
export function verifiedEntitlement(raw: any, store: string, name = ''): AuthoritativeEntitlement {
  if (!raw?.status || !storeIdentity(store) || storeIdentity(raw.store_url || raw.store_domain || '') !== storeIdentity(store)) throw new Error('Entitlement belongs to another store or is incomplete.');
  const trialEnd = raw.trial?.expires_at || raw.trial_end;
  const paidEnd = raw.license_expires_at;
  if (raw.status === 'trial_active' && !Number.isFinite(Date.parse(trialEnd))) throw new Error('Trial expiry is missing.');
  if (['paid_active', 'gifted_active'].includes(raw.status) && !Number.isFinite(Date.parse(paidEnd))) throw new Error('License expiry is missing.');
  let status = raw.status;
  if (status === 'trial_active' && Date.parse(trialEnd) <= Date.now()) status = 'trial_expired';
  if (['paid_active', 'gifted_active'].includes(status) && Date.parse(paidEnd) <= Date.now()) status = status === 'paid_active' ? 'paid_expired' : 'gifted_expired';
  const normalized = normalizeWpEntitlement({ ...raw, status }, store, name);
  return { ...normalized, ...withoutCredentials(raw), status, trial: status === 'trial_active' ? { ...normalized.trial, ...raw.trial, expires_at: trialEnd } : undefined };
}
