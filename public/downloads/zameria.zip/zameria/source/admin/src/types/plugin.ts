export type PluginTab =
  | 'overview'
  | 'devices'
  | 'pos'
  | 'staff'
  | 'subscription'
  | 'settings'
  // Backward compatibility aliases
  | 'dashboard'
  | 'account'
  | 'license'
  | 'connection'
  | 'sync'
  | 'help';

export interface PosDevice {
  id: number;
  name: string;
  userId: number;
  userName: string;
  username?: string;
  email?: string;
  createdAt: string | null;
  lastSeenAt: string | null;
}

export interface PosStaffMember {
  id: number;
  displayName: string;
  username: string;
  email: string;
  roles: string[];
  roleLabel: string;
  editUrl: string;
}


export type ScreenId =
  // Authoritative Lifecycle States (from Section 26 of requirements)
  | 'screen_activation'               // First-time onboarding / activation screen
  | 'state_1_unactivated'             // Account connected — Trial Not Started
  | 'state_2_trial_7d'                // Trial Active — 7 days remaining
  | 'state_3_trial_5d'                // Trial Active — 5 days remaining
  | 'state_4_trial_3d'                // Trial Active — 3 days remaining
  | 'state_5_trial_1d'                // Trial Active — 1 day remaining (urgent prompt)
  | 'state_6_trial_expired'           // Trial Expired (restricted access, no fake days)
  | 'state_7_paid_active'             // Paid Subscription Active (Business Plan, Active License)
  | 'state_8_subscription_cancelled'  // Subscription Cancelled / Inactive License
  | 'state_9_backend_unavailable'     // Backend Temporarily Unavailable (Retry mechanism)
  | 'state_10_sync_error'             // WooCommerce Sync Issue
  // Legacy screen IDs for compatibility
  | 'screen_0_login'
  | 'screen_1_connected'
  | 'screen_2_license'
  | 'screen_3_connection'
  | 'screen_4_sync'
  | 'screen_5_disconnected'
  | 'screen_6_expiring'
  | 'screen_7_expired'
  | 'screen_8_sync_error'
  | 'screen_9_settings'
  | 'all_screens_matrix';

export type LicenseSubState = 'trial' | 'activation' | 'active';

export type LifecycleStatus =
  | 'unactivated'           // Account connected, trial not started
  | 'trial_not_started'     // Alias from WordPress / backend
  | 'trial_active'         // Free trial running (authoritative dates)
  | 'trial_expired'        // 7 days elapsed
  | 'paid_active'          // Paid subscription active, license issued
  | 'paid_cancelled'       // Subscription lapsed or cancelled
  | 'paid_expired'         // Paid subscription expired
  | 'gifted_active'        // Gifted Starter or Business plan active
  | 'gifted_expired'       // Gifted plan elapsed
  | 'backend_unavailable'   // Network/API timeout
  | 'licensing_off';        // No ZAMERIA cloud configured for this build: nothing to gate

export interface BackendTrialState {
  started_at: string;
  expires_at: string;
  days_remaining: number;
  total_days: 7; // strictly 7 days
  activation_code_used: string;
}

export interface BackendSubscriptionState {
  plan_name: string;        // e.g. "Business Plan"
  price: string;            // "₦350,000 / year"
  billing_cycle: string;    // "Monthly" | "Annual"
  status: 'active' | 'past_due' | 'cancelled';
  next_billing_date: string;
  // CRITICAL RULE: License is ONLY generated and returned for paid subscribers, never during free trial!
  license_key_masked: string; // e.g. "ZMR-••••-••••-8K2P"
  license_status: 'active' | 'suspended' | 'revoked';
}

export interface AuthoritativeEntitlement {
  account_id: string;
  store_id: string;
  store_name: string;
  store_url: string;
  store_domain?: string;
  status: LifecycleStatus;
  plan?: 'Starter' | 'Business';
  plan_name?: string;
  license_key?: string;
  license_expires_at?: string;
  trial?: BackendTrialState;
  subscription?: BackendSubscriptionState;
  sync?: {
    status: 'healthy' | 'issue' | 'syncing';
    last_synced: string;
    products_synced: number;
    orders_synced: number;
    customers_synced: number;
    failed_items_count: number;
  };
}

export interface StoreBranch {
  id: string;
  name: string;
  location: string;
  activeRegisters: number;
  isPrimary?: boolean;
}

export interface StoreSyncStats {
  productsCount: number;
  ordersCount: number;
  customersCount: number;
  lastSyncedText: string;
  lastSyncedSecondsAgo: number;
}

export interface SyncActivityItem {
  id: string;
  type: 'products' | 'orders' | 'customers' | 'connection' | 'inventory';
  title: string;
  timestamp: string;
  status: 'success' | 'warning' | 'error';
  details?: string;
  count?: number;
}

export interface StoreConnectionInfo {
  storeUrl: string;
  zameriaStoreName: string;
  status: 'connected' | 'disconnected' | 'reconnecting';
  lastPingMs: number;
  lastSuccessfulSync: string;
  wooCommerceVersion: string;
  wordpressVersion: string;
  pluginVersion: string;
  apiEndpoint: string;
}

export interface LicenseInfo {
  status: 'trial' | 'expiring' | 'expired' | 'active';
  planName: string;
  daysRemaining: number;
  totalTrialDays: number;
  expiryDate: string;
  licenseKeyMasked?: string;
  renewalDate: string;
}

export interface FailedSyncItem {
  id: string;
  sku: string;
  name: string;
  reason: string;
  type: 'product' | 'order';
}

