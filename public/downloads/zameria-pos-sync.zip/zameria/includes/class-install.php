<?php
/**
 * Activation, database tables and roles.
 *
 * @package Zameria
 */

namespace Zameria;

defined( 'ABSPATH' ) || exit;

class Install {

	const DB_VERSION = '1';
	const CAPABILITY = 'zameria_use_pos';

	public static function activate() {
		self::create_tables();
		self::add_roles();
		App_Server::add_rewrite_rules();
		flush_rewrite_rules();

		if ( ! wp_next_scheduled( 'zameria_daily' ) ) {
			wp_schedule_event( time() + HOUR_IN_SECONDS, 'daily', 'zameria_daily' );
		}

		update_option( 'zameria_db_version', self::DB_VERSION );
	}

	public static function deactivate() {
		wp_clear_scheduled_hook( 'zameria_daily' );
		flush_rewrite_rules();
	}

	/**
	 * Covers plugin updates that happen without re-activation.
	 */
	public static function maybe_upgrade() {
		if ( get_option( 'zameria_db_version' ) === self::DB_VERSION ) {
			return;
		}
		self::create_tables();
		self::add_roles();
		update_option( 'zameria_db_version', self::DB_VERSION );
	}

	private static function create_tables() {
		global $wpdb;

		require_once ABSPATH . 'wp-admin/includes/upgrade.php';

		$collate = $wpdb->get_charset_collate();

		// Append-only log of product/stock changes. Its auto-increment id is the sync cursor
		// devices use to fetch "everything that changed since I last looked".
		dbDelta(
			"CREATE TABLE {$wpdb->prefix}zameria_changes (
				id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
				object_id bigint(20) unsigned NOT NULL,
				changed_at datetime NOT NULL,
				PRIMARY KEY  (id),
				KEY changed_at (changed_at)
			) $collate;"
		);

		// One row per signed-in POS device (register). Only a hash of the token is stored.
		dbDelta(
			"CREATE TABLE {$wpdb->prefix}zameria_devices (
				id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
				user_id bigint(20) unsigned NOT NULL,
				name varchar(100) NOT NULL,
				token_hash char(64) NOT NULL,
				created_at datetime NOT NULL,
				last_seen_at datetime NULL,
				revoked_at datetime NULL,
				PRIMARY KEY  (id),
				UNIQUE KEY token_hash (token_hash),
				KEY user_id (user_id)
			) $collate;"
		);

		// Maps each offline sale's device-generated UUID to the WooCommerce order it became.
		// The primary key makes sale uploads idempotent: a retried upload never creates a second order.
		dbDelta(
			"CREATE TABLE {$wpdb->prefix}zameria_sales (
				uuid char(36) NOT NULL,
				order_id bigint(20) unsigned NOT NULL DEFAULT 0,
				device_id bigint(20) unsigned NOT NULL,
				created_at datetime NOT NULL,
				PRIMARY KEY  (uuid),
				KEY order_id (order_id)
			) $collate;"
		);
	}

	private static function add_roles() {
		foreach ( array( 'administrator', 'shop_manager' ) as $role_name ) {
			$role = get_role( $role_name );
			if ( $role ) {
				$role->add_cap( self::CAPABILITY );
			}
		}

		if ( ! get_role( 'zameria_cashier' ) ) {
			add_role(
				'zameria_cashier',
				__( 'POS Cashier', 'zameria' ),
				array(
					'read'           => true,
					self::CAPABILITY => true,
				)
			);
		}
	}
}
