<?php
/**
 * Records every product and stock change so devices can pull only what changed.
 *
 * Online orders, admin edits, CSV imports and POS sales all funnel through
 * WooCommerce's product/stock hooks, so listening here catches them all.
 *
 * @package Zameria
 */

namespace Zameria;

defined( 'ABSPATH' ) || exit;

class Change_Log {

	const RETENTION_DAYS = 30;
	const FLOOR_OPTION   = 'zameria_changes_floor';

	/** @var array<int, true> Product ids changed during this request. */
	private static $pending = array();

	public static function init() {
		$id_hooks = array(
			'woocommerce_new_product',
			'woocommerce_update_product',
			'woocommerce_new_product_variation',
			'woocommerce_update_product_variation',
			'woocommerce_product_set_stock_status',
			'woocommerce_variation_set_stock_status',
		);
		foreach ( $id_hooks as $hook ) {
			add_action( $hook, array( __CLASS__, 'queue_id' ), 10, 1 );
		}

		add_action( 'woocommerce_product_set_stock', array( __CLASS__, 'queue_product' ) );
		add_action( 'woocommerce_variation_set_stock', array( __CLASS__, 'queue_product' ) );

		foreach ( array( 'wp_trash_post', 'untrashed_post', 'before_delete_post' ) as $hook ) {
			add_action( $hook, array( __CLASS__, 'queue_post' ), 10, 1 );
		}

		// Written at shutdown, after every change in the request has landed, so a device can
		// never read a change-log row before the product data it points to is final.
		add_action( 'shutdown', array( __CLASS__, 'flush' ) );
		add_action( 'zameria_daily', array( __CLASS__, 'prune' ) );
	}

	public static function queue_id( $id ) {
		$id = absint( $id );
		if ( $id ) {
			self::$pending[ $id ] = true;
		}
	}

	public static function queue_product( $product ) {
		if ( $product instanceof \WC_Product ) {
			self::queue_id( $product->get_id() );
		}
	}

	public static function queue_post( $post_id ) {
		if ( in_array( get_post_type( $post_id ), array( 'product', 'product_variation' ), true ) ) {
			self::queue_id( $post_id );
		}
	}

	public static function flush() {
		if ( ! self::$pending ) {
			return;
		}

		global $wpdb;
		$now    = gmdate( 'Y-m-d H:i:s' );
		$values = array();
		foreach ( array_keys( self::$pending ) as $id ) {
			$values[] = $wpdb->prepare( '(%d, %s)', $id, $now );
		}
		self::$pending = array();

		// phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared -- values prepared above.
		$wpdb->query( "INSERT INTO {$wpdb->prefix}zameria_changes (object_id, changed_at) VALUES " . implode( ',', $values ) );
	}

	public static function current_cursor() {
		global $wpdb;
		return (int) $wpdb->get_var( "SELECT MAX(id) FROM {$wpdb->prefix}zameria_changes" );
	}

	/**
	 * Adds every published top-level product to the change feed.
	 *
	 * This is used by the merchant's "Sync now" action. POS devices receive the same complete
	 * product representation as they do for an ordinary product update, without overwriting sales
	 * or stock on the server.
	 *
	 * @return int Number of products queued.
	 */
	public static function queue_catalog() {
		$ids = get_posts(
			array(
				'post_type'      => 'product',
				'post_status'    => 'publish',
				'fields'         => 'ids',
				'posts_per_page' => -1,
				'no_found_rows'  => true,
			)
		);
		foreach ( $ids as $id ) {
			self::queue_id( $id );
		}
		self::flush();
		return count( $ids );
	}

	/**
	 * True when rows after $cursor have been pruned, so the device must re-download the catalogue.
	 */
	public static function is_expired( $cursor ) {
		return $cursor > 0 && $cursor < (int) get_option( self::FLOOR_OPTION, 0 );
	}

	/**
	 * @return array{ids: int[], cursor: int, more: bool}
	 */
	public static function since( $cursor, $limit ) {
		global $wpdb;

		$rows = $wpdb->get_results(
			$wpdb->prepare(
				"SELECT id, object_id, changed_at FROM {$wpdb->prefix}zameria_changes WHERE id > %d ORDER BY id ASC LIMIT %d",
				$cursor,
				$limit
			)
		);

		// Concurrent requests can commit ids out of order. Stop at the first row younger than a
		// couple of seconds so a lower id that is still being written is not skipped forever.
		$settled = gmdate( 'Y-m-d H:i:s', time() - 2 );
		$ids     = array();
		$next    = $cursor;
		foreach ( $rows as $row ) {
			if ( $row->changed_at > $settled ) {
				break;
			}
			$ids[ (int) $row->object_id ] = true;
			$next                         = (int) $row->id;
		}

		return array(
			'ids'    => array_keys( $ids ),
			'cursor' => $next,
			'more'   => count( $rows ) === $limit && $next !== $cursor,
		);
	}

	public static function prune() {
		global $wpdb;
		$cutoff = gmdate( 'Y-m-d H:i:s', time() - self::RETENTION_DAYS * DAY_IN_SECONDS );
		$max_id = (int) $wpdb->get_var(
			$wpdb->prepare( "SELECT MAX(id) FROM {$wpdb->prefix}zameria_changes WHERE changed_at < %s", $cutoff )
		);
		if ( ! $max_id ) {
			return;
		}
		$wpdb->query( $wpdb->prepare( "DELETE FROM {$wpdb->prefix}zameria_changes WHERE id <= %d", $max_id ) );
		update_option( self::FLOOR_OPTION, $max_id, false );
	}
}
