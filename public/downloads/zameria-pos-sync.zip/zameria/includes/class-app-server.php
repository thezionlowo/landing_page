<?php
/**
 * Serves the built POS app at https://yourstore.com/pos/.
 *
 * Serving from the store's own domain means no CORS setup, and the service worker's scope
 * covers /pos/ so the app opens with no internet once it has been loaded once.
 *
 * @package Zameria
 */

namespace Zameria;

defined( 'ABSPATH' ) || exit;

class App_Server {

	const QUERY_VAR = 'zameria_pos';
	const PATH_VAR  = 'zameria_pos_path';

	const MIME_TYPES = array(
		'html'        => 'text/html; charset=utf-8',
		'js'          => 'application/javascript; charset=utf-8',
		'css'         => 'text/css; charset=utf-8',
		'json'        => 'application/json',
		'webmanifest' => 'application/manifest+json',
		'svg'         => 'image/svg+xml',
		'png'         => 'image/png',
		'ico'         => 'image/x-icon',
		'woff2'       => 'font/woff2',
		'txt'         => 'text/plain; charset=utf-8',
	);

	public static function init() {
		add_action( 'init', array( __CLASS__, 'add_rewrite_rules' ) );
		add_filter( 'query_vars', array( __CLASS__, 'query_vars' ) );
		add_action( 'template_redirect', array( __CLASS__, 'maybe_serve' ), 0 );
	}

	public static function slug() {
		return trim( (string) apply_filters( 'zameria_app_slug', 'pos' ), '/' );
	}

	public static function url() {
		return home_url( '/' . self::slug() . '/' );
	}

	/**
	 * The POS is served by this plugin on the connected store's own /pos/ URL.
	 */
	public static function hosted_login_url() {
		return self::url();
	}

	public static function build_dir() {
		return ZAMERIA_DIR . 'pos-app/';
	}

	public static function add_rewrite_rules() {
		$slug = preg_quote( self::slug(), '#' );
		add_rewrite_rule( '^' . $slug . '/?$', 'index.php?' . self::QUERY_VAR . '=1', 'top' );
		add_rewrite_rule( '^' . $slug . '/(.+)$', 'index.php?' . self::QUERY_VAR . '=1&' . self::PATH_VAR . '=$matches[1]', 'top' );
	}

	public static function query_vars( $vars ) {
		$vars[] = self::QUERY_VAR;
		$vars[] = self::PATH_VAR;
		return $vars;
	}

	public static function maybe_serve() {
		if ( ! get_query_var( self::QUERY_VAR ) ) {
			return;
		}

		$path = ltrim( (string) get_query_var( self::PATH_VAR ), '/' );

		// The app uses relative asset paths, so /pos must become /pos/.
		$request_path = isset( $_SERVER['REQUEST_URI'] ) ? (string) wp_parse_url( wp_unslash( $_SERVER['REQUEST_URI'] ), PHP_URL_PATH ) : ''; // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized
		if ( '' === $path && '/' !== substr( $request_path, -1 ) ) {
			wp_safe_redirect( self::url(), 301 );
			exit;
		}

		$dir = self::build_dir();
		if ( ! is_file( $dir . 'index.html' ) ) {
			wp_die( esc_html__( 'The POS app has not been built yet. Run "npm run build" in the project root.', 'zameria' ), '', array( 'response' => 503 ) );
		}

		if ( '' === $path ) {
			$path = 'index.html';
		}

		$base = realpath( $dir );
		$file = realpath( $dir . $path );
		$safe = $file && is_file( $file ) && 0 === strpos( $file, $base . DIRECTORY_SEPARATOR );

		if ( ! $safe ) {
			// Missing files with an extension are real 404s (a JS file must never get HTML back).
			if ( pathinfo( $path, PATHINFO_EXTENSION ) ) {
				status_header( 404 );
				nocache_headers();
				exit;
			}
			$file = $dir . 'index.html';
		}

		self::send( $file );
		exit;
	}

	private static function send( $file ) {
		$ext  = strtolower( pathinfo( $file, PATHINFO_EXTENSION ) );
		$name = basename( $file );

		status_header( 200 );
		header( 'Content-Type: ' . ( self::MIME_TYPES[ $ext ] ?? 'application/octet-stream' ) );
		header( 'X-Content-Type-Options: nosniff' );

		if ( false !== strpos( $file, DIRECTORY_SEPARATOR . 'assets' . DIRECTORY_SEPARATOR ) ) {
			// Vite puts a content hash in every asset filename, so they never change.
			header( 'Cache-Control: public, max-age=31536000, immutable' );
		} else {
			// index.html, sw.js and the manifest must always be fresh so app updates roll out.
			nocache_headers();
			header( 'X-LiteSpeed-Cache-Control: no-cache' );
		}

		if ( 'index.html' === $name ) {
			echo self::render_index( $file ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
			return;
		}

		readfile( $file ); // phpcs:ignore WordPress.WP_Filesystem.AlternativeFunctions.file_system_read_readfile
	}

	/**
	 * Injects the store's API location so the same build works on any domain or sub-folder, and a
	 * <base> so the app's routes (/pos/sale, /pos/orders...) and relative assets resolve correctly.
	 */
	private static function render_index( $file ) {
		$config = array(
			'restRoot'  => esc_url_raw( rest_url() ),
			'apiRoot'   => esc_url_raw( rest_url( Rest_Controller::NAMESPACE_V1 . '/' ) ),
			'storeUrl'  => esc_url_raw( home_url( '/' ) ),
			'storeName' => wp_specialchars_decode( get_bloginfo( 'name' ), ENT_QUOTES ),
		);
		$base   = '<base href="' . esc_attr( (string) wp_parse_url( self::url(), PHP_URL_PATH ) ) . '">';
		$script = '<script>window.ZAMERIA_CONFIG=' . wp_json_encode( $config, JSON_HEX_TAG | JSON_UNESCAPED_SLASHES ) . ';</script>';
		$html   = (string) file_get_contents( $file ); // phpcs:ignore WordPress.WP_Filesystem.AlternativeFunctions.file_get_contents_file_get_contents

		// Swap the build's own <base href="/"> for the POS path; add one if the build has none.
		// It must come before any relative URL in the document.
		$html = preg_match( '/<base\s[^>]*>/i', $html )
			? preg_replace( '/<base\s[^>]*>/i', $base, $html, 1 )
			: preg_replace( '/<head>/i', '<head>' . $base, $html, 1 );
		return str_replace( '</head>', $script . '</head>', $html );
	}
}
