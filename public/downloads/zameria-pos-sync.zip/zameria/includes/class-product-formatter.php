<?php
/**
 * Turns WooCommerce products into the shape the POS stores offline: one record per product,
 * with a variable product's sellable variations nested inside it.
 *
 * @package Zameria
 */

namespace Zameria;

defined( 'ABSPATH' ) || exit;

class Product_Formatter {

	/**
	 * Top-level product types the POS can sell.
	 */
	public static function types() {
		return apply_filters( 'zameria_product_types', array( 'simple', 'variable' ) );
	}

	/**
	 * True when the product belongs in the POS catalogue.
	 */
	public static function is_listed( \WC_Product $product ) {
		return 'publish' === $product->get_status() && in_array( $product->get_type(), self::types(), true );
	}

	public static function format( \WC_Product $product ) {
		$data = array_merge(
			self::sellable_fields( $product ),
			array(
				'type'              => $product->get_type(),
				'status'            => $product->get_status(),
				'name'              => wp_specialchars_decode( $product->get_name(), ENT_QUOTES ),
				'slug'              => $product->get_slug(),
				'description'       => $product->get_description(),
				'short_description' => $product->get_short_description(),
				'weight'            => (string) $product->get_weight(),
				'dimensions'        => array(
					'length' => (string) $product->get_length(),
					'width'  => (string) $product->get_width(),
					'height' => (string) $product->get_height(),
				),
				'images'            => self::images( $product ),
				'category_ids'      => array_map( 'intval', $product->get_category_ids() ),
				'brand'             => self::brand( $product ),
				'date_created'      => wc_rest_prepare_date_response( $product->get_date_created() ),
				'date_modified'     => wc_rest_prepare_date_response( $product->get_date_modified() ),
				'attributes'        => array(),
				'variations'        => array(),
			)
		);

		if ( $product->is_type( 'variable' ) ) {
			$data['attributes'] = self::attributes( $product );
			foreach ( $product->get_children() as $variation_id ) {
				$variation = wc_get_product( $variation_id );
				if ( $variation && 'publish' === $variation->get_status() && '' !== $variation->get_price() ) {
					$data['variations'][] = self::format_variation( $variation );
				}
			}
		}

		return $data;
	}

	private static function format_variation( \WC_Product_Variation $variation ) {
		$attributes = array();
		foreach ( $variation->get_variation_attributes( false ) as $taxonomy => $value ) {
			$attributes[] = array(
				'name'   => wc_attribute_label( $taxonomy, $variation ),
				'option' => self::attribute_option_label( $taxonomy, $value ),
			);
		}

		$image_id = $variation->get_image_id( 'edit' );

		return array_merge(
			self::sellable_fields( $variation ),
			array(
				'attributes' => $attributes,
				'image'      => $image_id ? self::image( (int) $image_id, $variation->get_name() ) : null,
			)
		);
	}

	/**
	 * Price, stock and identifier fields shared by products and variations.
	 */
	private static function sellable_fields( \WC_Product $product ) {
		$decimals = wc_get_price_decimals();
		$sale     = $product->get_sale_price();

		return array(
			'id'                 => $product->get_id(),
			'sku'                => (string) $product->get_sku(),
			'barcode'            => self::barcode( $product ),
			'price'              => wc_format_decimal( $product->get_price(), $decimals ),
			'regular_price'      => wc_format_decimal( $product->get_regular_price(), $decimals ),
			'sale_price'         => '' === $sale ? null : wc_format_decimal( $sale, $decimals ),
			'on_sale'            => $product->is_on_sale(),
			'manage_stock'       => (bool) $product->managing_stock(),
			'stock_quantity'     => $product->managing_stock() ? wc_stock_amount( $product->get_stock_quantity() ) : null,
			// Variations can share their parent's stock; sales must be counted against the owner.
			'stock_owner_id'     => $product->get_stock_managed_by_id(),
			'stock_status'       => $product->get_stock_status(),
			'backorders_allowed' => $product->backorders_allowed(),
		);
	}

	private static function attributes( \WC_Product $product ) {
		$attributes = array();
		foreach ( $product->get_attributes() as $attribute ) {
			$options = $attribute->is_taxonomy()
				? wp_list_pluck( $attribute->get_terms() ? $attribute->get_terms() : array(), 'name' )
				: $attribute->get_options();

			$attributes[] = array(
				'id'        => $attribute->get_id(),
				'name'      => wc_attribute_label( $attribute->get_name(), $product ),
				'position'  => $attribute->get_position(),
				'visible'   => $attribute->get_visible(),
				'variation' => $attribute->get_variation(),
				'options'   => array_values( array_map( 'strval', $options ) ),
			);
		}
		return $attributes;
	}

	private static function attribute_option_label( $taxonomy, $value ) {
		if ( taxonomy_exists( $taxonomy ) ) {
			$term = get_term_by( 'slug', $value, $taxonomy );
			if ( $term && ! is_wp_error( $term ) ) {
				return $term->name;
			}
		}
		return (string) $value;
	}

	private static function images( \WC_Product $product ) {
		$ids = array_filter( array_merge( array( $product->get_image_id() ), $product->get_gallery_image_ids() ) );
		return array_values( array_filter( array_map( array( __CLASS__, 'image_for_product' ), array_unique( $ids ) ) ) );
	}

	private static function image_for_product( $attachment_id ) {
		return self::image( (int) $attachment_id, '' );
	}

	private static function image( $attachment_id, $fallback_name ) {
		$src = wp_get_attachment_image_url( $attachment_id, 'woocommerce_thumbnail' );
		if ( ! $src ) {
			return null;
		}
		return array(
			'id'   => $attachment_id,
			'src'  => $src,
			'name' => get_the_title( $attachment_id ) ? get_the_title( $attachment_id ) : $fallback_name,
			'alt'  => (string) get_post_meta( $attachment_id, '_wp_attachment_image_alt', true ),
		);
	}

	private static function barcode( \WC_Product $product ) {
		$barcode = '';
		// WooCommerce 9.2+ has a built-in "GTIN, UPC, EAN or ISBN" field.
		if ( method_exists( $product, 'get_global_unique_id' ) ) {
			$barcode = (string) $product->get_global_unique_id();
		}
		if ( '' === $barcode ) {
			$barcode = (string) $product->get_meta( '_zameria_barcode' );
		}
		return (string) apply_filters( 'zameria_product_barcode', $barcode, $product );
	}

	/**
	 * Retrieves the product's brand.
	 * Checks common brand taxonomies (product_brand, pwb-brand, yith_product_brand, brand, pa_brand)
	 * and falls back to WooCommerce product attribute 'brand'.
	 *
	 * @param \WC_Product $product
	 * @return array{id: int, name: string, slug: string, taxonomy: string}|null
	 */
	public static function brand( \WC_Product $product ) {
		$taxonomies = array( 'product_brand', 'pwb-brand', 'yith_product_brand', 'brand', 'pa_brand' );
		foreach ( $taxonomies as $tax ) {
			if ( taxonomy_exists( $tax ) ) {
				$terms = get_the_terms( $product->get_id(), $tax );
				if ( ! empty( $terms ) && ! is_wp_error( $terms ) ) {
					$term = reset( $terms );
					return array(
						'id'       => (int) $term->term_id,
						'name'     => wp_specialchars_decode( $term->name, ENT_QUOTES ),
						'slug'     => (string) $term->slug,
						'taxonomy' => $tax,
					);
				}
			}
		}

		// Fallback: check custom attribute named 'brand' or 'Brand'
		$brand_attr = $product->get_attribute( 'brand' );
		if ( ! empty( $brand_attr ) ) {
			return array(
				'id'       => 0,
				'name'     => wp_specialchars_decode( $brand_attr, ENT_QUOTES ),
				'slug'     => sanitize_title( $brand_attr ),
				'taxonomy' => 'attribute',
			);
		}

		return null;
	}
}
