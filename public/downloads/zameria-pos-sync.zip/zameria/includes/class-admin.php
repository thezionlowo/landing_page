<?php
/**
 * WooCommerce > Zameria POS settings screen.
 *
 * @package Zameria
 */

namespace Zameria;

defined( 'ABSPATH' ) || exit;

class Admin {

	const PAGE = 'zameria';

	const LICENSE_KEY_OPTION        = 'zameria_license_key';
	const INSTALLATION_TOKEN_OPTION = 'zameria_installation_token';

	public static function init() {
		add_action( 'admin_menu', array( __CLASS__, 'menu' ), 60 );
		add_action( 'admin_enqueue_scripts', array( __CLASS__, 'enqueue_assets' ) );
		add_action( 'admin_post_zameria_save_settings', array( __CLASS__, 'save_settings' ) );
		add_action( 'admin_post_zameria_revoke_device', array( __CLASS__, 'revoke_device' ) );
		add_action( 'wp_ajax_zameria_admin_status', array( __CLASS__, 'ajax_status' ) );
		add_action( 'wp_ajax_zameria_admin_save_settings', array( __CLASS__, 'ajax_save_settings' ) );
		add_action( 'wp_ajax_zameria_admin_sync_catalog', array( __CLASS__, 'ajax_sync_catalog' ) );
		add_action( 'wp_ajax_zameria_admin_health_check', array( __CLASS__, 'ajax_health_check' ) );
		add_action( 'wp_ajax_zameria_admin_save_license', array( __CLASS__, 'ajax_save_license' ) );
		add_action( 'wp_ajax_zameria_admin_get_entitlement', array( __CLASS__, 'ajax_get_entitlement' ) );
		add_action( 'wp_ajax_zameria_admin_set_entitlement', array( __CLASS__, 'ajax_set_entitlement' ) );
		add_filter( 'plugin_action_links_' . plugin_basename( ZAMERIA_FILE ), array( __CLASS__, 'action_links' ) );
	}

	public static function menu() {
		add_submenu_page( 'woocommerce', __( 'Zameria POS', 'zameria' ), __( 'Zameria POS', 'zameria' ), 'manage_woocommerce', self::PAGE, array( __CLASS__, 'render' ) );
	}

	public static function action_links( $links ) {
		array_unshift(
			$links,
			'<a href="' . esc_url( admin_url( 'admin.php?page=' . self::PAGE ) ) . '">' . esc_html__( 'Settings', 'zameria' ) . '</a>',
			'<a href="' . esc_url( App_Server::hosted_login_url() ) . '" target="_blank" rel="noopener">' . esc_html__( 'Open ZAMERIA POS', 'zameria' ) . '</a>'
		);
		return $links;
	}

	public static function render() {
		if ( ! current_user_can( 'manage_woocommerce' ) ) {
			wp_die( esc_html__( 'Not allowed.', 'zameria' ), '', array( 'response' => 403 ) );
		}
		?>
		<div class="wrap" id="zameria-admin-root"></div>
		<noscript><p><?php esc_html_e( 'Zameria POS requires JavaScript to display its dashboard.', 'zameria' ); ?></p></noscript>
		<?php
	}

	/** Loads the compiled React dashboard only on WooCommerce > Zameria POS. */
	public static function enqueue_assets( $hook ) {
		if ( 'woocommerce_page_' . self::PAGE !== $hook ) {
			return;
		}

		$manifest_file = ZAMERIA_DIR . 'admin-app/.vite/manifest.json';
		if ( ! is_readable( $manifest_file ) ) {
			add_action(
				'admin_notices',
				function () {
					echo '<div class="notice notice-error"><p>' . esc_html__( 'The Zameria dashboard assets have not been built. Run "npm run build:admin" from the project root.', 'zameria' ) . '</p></div>';
				}
			);
			return;
		}

		$manifest = json_decode( (string) file_get_contents( $manifest_file ), true ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents
		$entry    = is_array( $manifest ) ? ( $manifest['src/main.tsx'] ?? $manifest['index.html'] ?? null ) : null;
		if ( ! is_array( $entry ) || empty( $entry['file'] ) ) {
			add_action(
				'admin_notices',
				function () {
					echo '<div class="notice notice-error"><p>' . esc_html__( 'The Zameria dashboard build is invalid. Reinstall the latest Zameria plugin ZIP.', 'zameria' ) . '</p></div>';
				}
			);
			return;
		}

		foreach ( $entry['css'] ?? array() as $index => $css ) {
			wp_enqueue_style( 'zameria-admin-' . $index, ZAMERIA_URL . 'admin-app/' . ltrim( $css, '/' ), array(), ZAMERIA_VERSION );
		}
		wp_enqueue_script( 'zameria-admin', ZAMERIA_URL . 'admin-app/' . ltrim( $entry['file'], '/' ), array(), ZAMERIA_VERSION, true );
		// Vite emits an ES module (it uses import.meta). WordPress otherwise
		// prints a classic script tag, which prevents the dashboard from mounting.
		add_filter( 'script_loader_tag', array( __CLASS__, 'module_script_tag' ), 10, 3 );
		wp_add_inline_script( 'zameria-admin', 'window.ZAMERIA_ADMIN=' . wp_json_encode( self::dashboard_data(), JSON_HEX_TAG | JSON_UNESCAPED_SLASHES ) . ';', 'before' );
	}

	/** Marks the Vite dashboard bundle as an ES module while keeping the config inline script classic. */
	public static function module_script_tag( $tag, $handle, $src ) {
		if ( 'zameria-admin' !== $handle ) {
			return $tag;
		}
		return str_replace( '<script ', '<script type="module" ', $tag );
	}

	/** @return array<string, mixed> */
	private static function dashboard_data() {
		global $wpdb;

		$product_counts = wp_count_posts( 'product' );
		$users          = count_users();
		$order_query    = wc_get_orders(
			array(
				'limit'    => 1,
				'paginate' => true,
				'return'   => 'ids',
			)
		);
		$last_change    = $wpdb->get_var( "SELECT MAX(changed_at) FROM {$wpdb->prefix}zameria_changes" ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		$methods        = implode( "\n", wp_list_pluck( Settings::payment_methods(), 'label' ) );

		return array(
			'ajaxUrl'       => admin_url( 'admin-ajax.php' ),
			'nonce'         => wp_create_nonce( 'zameria_admin' ),
			'assetsUrl'     => ZAMERIA_URL . 'admin-app/',
			// "Open ZAMERIA POS" buttons: the hosted POS, with this store's address pre-filled.
			'posUrl'        => App_Server::hosted_login_url(),
			// The same app served by this site at /pos/ (health checks, offline fallback).
			'localPosUrl'   => App_Server::url(),
			'storeUrl'      => home_url( '/' ),
			// Licence credentials live with the site, not in one browser: the
			// installation token is issued once and cannot be asked for again.
			'licenseKey'        => (string) get_option( self::LICENSE_KEY_OPTION, '' ),
			'installationToken' => (string) get_option( self::INSTALLATION_TOKEN_OPTION, '' ),
			'storeName'     => wp_specialchars_decode( get_bloginfo( 'name' ), ENT_QUOTES ),
			'productCount'  => (int) ( $product_counts->publish ?? 0 ),
			'orderCount'    => isset( $order_query->total ) ? (int) $order_query->total : 0,
			'customerCount' => (int) ( $users['avail_roles']['customer'] ?? 0 ),
			'deviceCount'   => count( Auth::active_devices() ),
			'lastChange'    => $last_change ? mysql_to_rfc3339( $last_change ) : null,
			'health'        => self::health_data(),
			'activity'      => self::activity(),
			'paymentMethods'=> $methods,
			'receiptFooter' => Settings::receipt_footer(),
			'entitlement'   => Settings::get_entitlement(),
			'version'       => ZAMERIA_VERSION,
		);
	}

	/** @return array<string, mixed> */
	private static function health_data() {
		$checks = array(
			'woocommerce' => class_exists( 'WooCommerce' ),
			'permalinks'  => (bool) get_option( 'permalink_structure' ),
			'posBuild'     => is_file( App_Server::build_dir() . 'index.html' ),
		);
		return array(
			'ready'  => ! in_array( false, $checks, true ),
			'checks' => $checks,
		);
	}

	/** @return array<int, array<string, mixed>> */
	private static function activity() {
		$activity = get_option( 'zameria_admin_activity', array() );
		return is_array( $activity ) ? array_slice( $activity, 0, 20 ) : array();
	}

	private static function record_activity( $title, $details, $status = 'success' ) {
		$activity   = self::activity();
		$activity[] = array(
			'id'      => wp_generate_uuid4(),
			'title'   => sanitize_text_field( $title ),
			'details' => sanitize_text_field( $details ),
			'status'  => 'success' === $status ? 'success' : 'warning',
			'time'    => current_time( 'mysql', true ),
		);
		update_option( 'zameria_admin_activity', array_slice( array_reverse( $activity ), 0, 20 ), false );
	}

	public static function ajax_status() {
		check_ajax_referer( 'zameria_admin', 'nonce' );
		if ( ! current_user_can( 'manage_woocommerce' ) ) {
			wp_send_json_error( array( 'message' => __( 'Not allowed.', 'zameria' ) ), 403 );
		}
		wp_send_json_success( self::dashboard_data() );
	}

	/**
	 * Stores the licence key and the installation token the licensing service
	 * returns on activation. The token is shown exactly once, so losing it means
	 * re-activating; keeping it in site options survives a browser that forgets.
	 * An empty payload clears both, which is how the dashboard disconnects.
	 */
	public static function ajax_save_license() {
		check_ajax_referer( 'zameria_admin', 'nonce' );
		if ( ! current_user_can( 'manage_woocommerce' ) ) {
			wp_send_json_error( array( 'message' => __( 'Not allowed.', 'zameria' ) ), 403 );
		}
		$license_key = sanitize_text_field( wp_unslash( $_POST['license_key'] ?? '' ) );
		$token       = sanitize_text_field( wp_unslash( $_POST['installation_token'] ?? '' ) );

		if ( '' === $license_key || '' === $token ) {
			delete_option( self::LICENSE_KEY_OPTION );
			delete_option( self::INSTALLATION_TOKEN_OPTION );
			wp_send_json_success( array( 'stored' => false ) );
		}

		update_option( self::LICENSE_KEY_OPTION, $license_key, false );
		update_option( self::INSTALLATION_TOKEN_OPTION, $token, false );
		wp_send_json_success( array( 'stored' => true ) );
	}

	public static function ajax_get_entitlement() {
		check_ajax_referer( 'zameria_admin', 'nonce' );
		if ( ! current_user_can( 'manage_woocommerce' ) ) {
			wp_send_json_error( array( 'message' => __( 'Not allowed.', 'zameria' ) ), 403 );
		}
		wp_send_json_success( array( 'entitlement' => Settings::get_entitlement() ) );
	}

	public static function ajax_set_entitlement() {
		check_ajax_referer( 'zameria_admin', 'nonce' );
		if ( ! current_user_can( 'manage_woocommerce' ) ) {
			wp_send_json_error( array( 'message' => __( 'Not allowed.', 'zameria' ) ), 403 );
		}

		$status             = isset( $_POST['status'] ) ? sanitize_text_field( wp_unslash( $_POST['status'] ) ) : 'trial_not_started';
		$plan               = isset( $_POST['plan'] ) ? sanitize_text_field( wp_unslash( $_POST['plan'] ) ) : 'Starter';
		$plan_name          = isset( $_POST['plan_name'] ) ? sanitize_text_field( wp_unslash( $_POST['plan_name'] ) ) : 'Starter Plan';
		$trial_start        = isset( $_POST['trial_start'] ) ? sanitize_text_field( wp_unslash( $_POST['trial_start'] ) ) : null;
		$trial_end          = isset( $_POST['trial_end'] ) ? sanitize_text_field( wp_unslash( $_POST['trial_end'] ) ) : null;
		$license_key        = isset( $_POST['license_key'] ) ? sanitize_text_field( wp_unslash( $_POST['license_key'] ) ) : null;
		$license_expires_at = isset( $_POST['license_expires_at'] ) ? sanitize_text_field( wp_unslash( $_POST['license_expires_at'] ) ) : null;

		$entitlement = array(
			'status'             => $status,
			'plan'               => $plan,
			'plan_name'          => $plan_name,
			'trial_start'        => $trial_start,
			'trial_end'          => $trial_end,
			'license_key'        => $license_key,
			'license_expires_at' => $license_expires_at,
		);

		Settings::set_entitlement( $entitlement );

		self::record_activity(
			__( 'Entitlement updated', 'zameria' ),
			sprintf( __( 'Store status set to %s (%s).', 'zameria' ), $status, $plan_name )
		);

		wp_send_json_success( array( 'entitlement' => Settings::get_entitlement() ) );
	}

	public static function ajax_save_settings() {
		check_ajax_referer( 'zameria_admin', 'nonce' );
		if ( ! current_user_can( 'manage_woocommerce' ) ) {
			wp_send_json_error( array( 'message' => __( 'Not allowed.', 'zameria' ) ), 403 );
		}
		Settings::save_payment_methods( wp_unslash( $_POST['payment_methods'] ?? '' ) ); // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized
		update_option( Settings::RECEIPT_FOOTER_OPTION, sanitize_text_field( wp_unslash( $_POST['receipt_footer'] ?? '' ) ) );
		wp_send_json_success( self::dashboard_data() );
	}

	public static function ajax_sync_catalog() {
		check_ajax_referer( 'zameria_admin', 'nonce' );
		if ( ! current_user_can( 'manage_woocommerce' ) ) {
			wp_send_json_error( array( 'message' => __( 'Not allowed.', 'zameria' ) ), 403 );
		}
		$count = Change_Log::queue_catalog();
		self::record_activity(
			__( 'Catalogue refresh queued', 'zameria' ),
			sprintf( _n( '%d product was added to the POS change feed.', '%d products were added to the POS change feed.', $count, 'zameria' ), $count )
		);
		wp_send_json_success(
			array(
				'message' => sprintf( _n( '%d product queued for connected POS devices.', '%d products queued for connected POS devices.', $count, 'zameria' ), $count ),
				'data'    => self::dashboard_data(),
			)
		);
	}

	public static function ajax_health_check() {
		check_ajax_referer( 'zameria_admin', 'nonce' );
		if ( ! current_user_can( 'manage_woocommerce' ) ) {
			wp_send_json_error( array( 'message' => __( 'Not allowed.', 'zameria' ) ), 403 );
		}
		$health = self::health_data();
		wp_send_json_success(
			array(
				'health'  => $health,
				'message' => $health['ready'] ? __( 'WooCommerce, pretty permalinks, and the POS build are ready.', 'zameria' ) : __( 'The local POS bridge needs attention. Review the failed checks below.', 'zameria' ),
			)
		);
	}

	public static function save_settings() {
		if ( ! current_user_can( 'manage_woocommerce' ) ) {
			wp_die( esc_html__( 'Not allowed.', 'zameria' ), '', array( 'response' => 403 ) );
		}
		check_admin_referer( 'zameria_save_settings' );

		Settings::save_payment_methods( wp_unslash( $_POST['payment_methods'] ?? '' ) ); // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- sanitised per line.
		update_option( Settings::RECEIPT_FOOTER_OPTION, sanitize_text_field( wp_unslash( $_POST['receipt_footer'] ?? '' ) ) );

		wp_safe_redirect( admin_url( 'admin.php?page=' . self::PAGE . '&updated=1' ) );
		exit;
	}

	public static function revoke_device() {
		$device_id = absint( $_POST['device_id'] ?? 0 );
		if ( ! current_user_can( 'manage_woocommerce' ) ) {
			wp_die( esc_html__( 'Not allowed.', 'zameria' ), '', array( 'response' => 403 ) );
		}
		check_admin_referer( 'zameria_revoke_device_' . $device_id );

		Auth::revoke( $device_id );

		wp_safe_redirect( admin_url( 'admin.php?page=' . self::PAGE . '&updated=1' ) );
		exit;
	}
}
