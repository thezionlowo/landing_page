<?php
/**
 * Turns sales recorded on a POS device (often offline, hours earlier) into WooCommerce orders.
 *
 * Rules:
 * - Idempotent: each sale carries a device-generated UUID; uploading it twice returns the first order.
 * - Never refuse a real sale: the money has already changed hands. If a product was deleted
 *   or is out of stock online, the order is still created and flagged with a note.
 * - Stock is reduced by quantity sold (not set to an absolute number), so sales made online
 *   and offline at the same time both count.
 *
 * @package Zameria
 */

namespace Zameria;

defined( 'ABSPATH' ) || exit;

class Sale_Importer {

	/** An unfinished import older than this is assumed to have crashed and may be retried. */
	const STALE_CLAIM_SECONDS = 10 * MINUTE_IN_SECONDS;

	/**
	 * @return array{uuid: string, status: string, order_id?: int, order_number?: string, message?: string}
	 */
	public static function import( array $sale, $device ) {
		global $wpdb;
		$table = "{$wpdb->prefix}zameria_sales";
		$uuid  = isset( $sale['uuid'] ) ? strtolower( sanitize_text_field( $sale['uuid'] ) ) : '';

		if ( ! wp_is_uuid( $uuid ) ) {
			return self::result( $uuid, 'error', array( 'message' => 'Invalid sale id.' ) );
		}
		if ( empty( $sale['lines'] ) || ! is_array( $sale['lines'] ) ) {
			return self::result( $uuid, 'error', array( 'message' => 'Sale has no items.' ) );
		}

		// The UUID row alone does not serialize a stale-claim takeover: two PHP workers could
		// otherwise both create WooCommerce orders before either writes order_id. A MySQL advisory
		// lock covers the complete order creation section and is released automatically if PHP dies.
		$lock_name = 'zameria_sale_' . substr( hash( 'sha256', $uuid ), 0, 40 );
		$locked    = (int) $wpdb->get_var( $wpdb->prepare( 'SELECT GET_LOCK(%s, %d)', $lock_name, 30 ) );
		if ( 1 !== $locked ) {
			return self::result( $uuid, 'pending', array( 'message' => 'Sale is already being processed.' ) );
		}

		try {

		// Claim the UUID first. The primary key guarantees only one request can win the claim.
		$claimed = $wpdb->query(
			$wpdb->prepare(
				"INSERT IGNORE INTO {$table} (uuid, order_id, device_id, created_at) VALUES (%s, 0, %d, %s)",
				$uuid,
				$device->id,
				gmdate( 'Y-m-d H:i:s' )
			)
		);

		if ( ! $claimed ) {
			$existing = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$table} WHERE uuid = %s", $uuid ) );
			if ( $existing && $existing->order_id ) {
				return self::result( $uuid, 'duplicate', self::order_fields( (int) $existing->order_id ) );
			}
			if ( $existing && strtotime( $existing->created_at . ' UTC' ) > time() - self::STALE_CLAIM_SECONDS ) {
				return self::result( $uuid, 'pending', array( 'message' => 'Sale is already being processed.' ) );
			}
			// A previous attempt died mid-way (e.g. PHP timeout) without creating an order. Take it over.
			$wpdb->update( $table, array( 'created_at' => gmdate( 'Y-m-d H:i:s' ) ), array( 'uuid' => $uuid ) );
		}

		try {
			list( $order, $notes ) = self::build_order( $sale, $device );
			$order->save();
		} catch ( \Throwable $e ) {
			$wpdb->delete( $table, array( 'uuid' => $uuid ) );
			return self::result( $uuid, 'error', array( 'message' => $e->getMessage() ) );
		}

		$wpdb->update( $table, array( 'order_id' => $order->get_id() ), array( 'uuid' => $uuid ) );

		// The order exists and is mapped from here on, so a failure below must not cause a retry.
		foreach ( $notes as $note ) {
			$order->add_order_note( $note );
		}
		try {
			// Moving to "completed" makes WooCommerce reduce stock and fire its usual order hooks.
			$order->update_status( 'completed' );
			wc_maybe_reduce_stock_levels( $order->get_id() );
		} catch ( \Throwable $e ) {
			$order->add_order_note( 'Zameria: could not complete order automatically: ' . $e->getMessage() );
		}

		return self::result( $uuid, 'created', self::order_fields( $order->get_id() ) );
		} finally {
			$wpdb->get_var( $wpdb->prepare( 'SELECT RELEASE_LOCK(%s)', $lock_name ) );
		}
	}

	/**
	 * Product ids whose stock a sale touches, so the caller can send fresh stock back.
	 *
	 * @return int[]
	 */
	public static function affected_item_ids( array $sale ) {
		$ids = array();
		foreach ( (array) ( $sale['lines'] ?? array() ) as $line ) {
			if ( ! empty( $line['item_id'] ) ) {
				$ids[] = absint( $line['item_id'] );
			}
		}
		return $ids;
	}

	private static function build_order( array $sale, $device ) {
		$order    = new \WC_Order();
		$decimals = wc_get_price_decimals();
		$order->set_created_via( 'zameria' );
		$order->set_currency( get_woocommerce_currency() );
		$order->set_prices_include_tax( 'yes' === get_option( 'woocommerce_prices_include_tax' ) );

		$sold_at = isset( $sale['created_at'] ) ? strtotime( (string) $sale['created_at'] ) : false;
		// Keep the real sale time from the device, unless its clock is clearly in the future.
		if ( ! $sold_at || $sold_at > time() + HOUR_IN_SECONDS ) {
			$sold_at = time();
		}
		$order->set_date_created( $sold_at );
		$order->set_date_paid( $sold_at );
		$order->set_date_completed( $sold_at );

		self::set_customer( $order, isset( $sale['customer'] ) && is_array( $sale['customer'] ) ? $sale['customer'] : array() );
		if ( ! empty( $sale['note'] ) ) {
			$order->set_customer_note( sanitize_textarea_field( $sale['note'] ) );
		}

		$lines   = self::normalise_lines( $sale['lines'] );
		$coupons = self::normalise_coupons( $sale['coupons'] ?? array() );
		$lines   = self::spread_discount( $lines, array_sum( wp_list_pluck( $coupons, 'discount' ) ), $decimals );

		$notes = array();
		foreach ( $lines as $line ) {
			$product = $line['item_id'] ? wc_get_product( $line['item_id'] ) : null;
			$totals  = array(
				'subtotal' => $line['subtotal'],
				'total'    => $line['total'],
			);

			if ( $product ) {
				// The price the cashier charged wins over today's online price.
				$order->add_product( $product, $line['quantity'], $totals );
				if ( $product->managing_stock() && ! $product->backorders_allowed() && $product->get_stock_quantity() < $line['quantity'] ) {
					$notes[] = sprintf( '"%s" was sold offline but online stock was only %s. Please recount.', $product->get_name(), wc_stock_amount( $product->get_stock_quantity() ) );
				}
			} else {
				$item = new \WC_Order_Item_Product();
				$item->set_props( array_merge( $totals, array( 'name' => $line['name'], 'quantity' => $line['quantity'] ) ) );
				$order->add_item( $item );
				$notes[] = sprintf( '"%s" no longer exists online; recorded without stock change.', $line['name'] );
			}
		}

		if ( ! $order->get_items() ) {
			throw new \RuntimeException( 'Sale has no valid items.' );
		}

		// Coupon lines are recorded for reporting and usage limits; the discount itself is already
		// in the line totals above, exactly as the till calculated it.
		foreach ( $coupons as $coupon ) {
			$item = new \WC_Order_Item_Coupon();
			$item->set_props(
				array(
					'code'     => $coupon['code'],
					'discount' => $coupon['discount'],
				)
			);
			$order->add_item( $item );
		}

		foreach ( (array) ( $sale['fees'] ?? array() ) as $fee ) {
			$amount = (float) wc_format_decimal( $fee['total'] ?? 0 );
			if ( $amount ) {
				$item = new \WC_Order_Item_Fee();
				$item->set_props(
					array(
						'name'       => sanitize_text_field( $fee['name'] ?? __( 'Fee', 'zameria' ) ),
						'total'      => $amount,
						'tax_status' => 'none',
					)
				);
				$order->add_item( $item );
			}
		}

		self::set_payment( $order, isset( $sale['payment'] ) && is_array( $sale['payment'] ) ? $sale['payment'] : array() );

		$uuid           = strtolower( $sale['uuid'] );
		$receipt_number = sanitize_text_field( $sale['receipt_number'] ?? '' );
		$cashier        = wp_get_current_user();
		$attended_by    = sanitize_text_field( $sale['attended_by'] ?? $cashier->display_name );

		$order->update_meta_data( '_zameria_uuid', $uuid );
		$order->update_meta_data( '_zameria_device_id', (int) $device->id );
		$order->update_meta_data( '_zameria_receipt_number', $receipt_number );
		// Read by the POS app when it lists orders, to recognise its own sales.
		$order->update_meta_data( '_zameria_pos_order', 'yes' );
		$order->update_meta_data( '_zameria_transaction_id', $uuid );
		$order->update_meta_data( '_zameria_attended_by', $attended_by );
		$order->update_meta_data( '_zameria_attended_by_user_id', (string) $cashier->ID );
		$order->update_meta_data( '_zameria_created_by_user_id', (string) $cashier->ID );

		// TODO: tax. Totals are taken as charged at the till; tax lines are not calculated yet.
		$order->calculate_totals( false );

		array_unshift(
			$notes,
			sprintf( 'POS sale %1$s at "%2$s" by %3$s.', $receipt_number, $device->name, $attended_by )
		);

		$client_total = isset( $sale['total'] ) ? (float) wc_format_decimal( $sale['total'] ) : null;
		if ( null !== $client_total && abs( $client_total - (float) $order->get_total() ) > 0.01 ) {
			$notes[] = sprintf( 'Till total was %s but the order total is %s. Please review.', $client_total, $order->get_total() );
		}

		// Notes can only be attached once the order has been saved.
		return array( $order, $notes );
	}

	/**
	 * @return array<int, array{item_id: int, name: string, quantity: int|float, subtotal: float, total: float}>
	 */
	private static function normalise_lines( array $lines ) {
		$normalised = array();
		foreach ( $lines as $line ) {
			$quantity = wc_stock_amount( $line['quantity'] ?? 0 );
			if ( $quantity <= 0 ) {
				continue;
			}
			$unit_price = (float) wc_format_decimal( $line['unit_price'] ?? 0 );
			$subtotal   = isset( $line['subtotal'] ) ? (float) wc_format_decimal( $line['subtotal'] ) : $unit_price * $quantity;
			// Line total is after any per-item discount given at the till.
			$total = isset( $line['total'] ) ? (float) wc_format_decimal( $line['total'] ) : $subtotal;

			$normalised[] = array(
				'item_id'  => absint( $line['item_id'] ?? 0 ),
				'name'     => sanitize_text_field( $line['name'] ?? __( 'Unknown item', 'zameria' ) ),
				'quantity' => $quantity,
				'subtotal' => $subtotal,
				'total'    => max( 0, min( $total, $subtotal ) ),
			);
		}
		return $normalised;
	}

	private static function normalise_coupons( $coupons ) {
		$normalised = array();
		foreach ( (array) $coupons as $coupon ) {
			$code     = wc_format_coupon_code( $coupon['code'] ?? '' );
			$discount = (float) wc_format_decimal( $coupon['discount'] ?? 0 );
			if ( '' !== $code && $discount > 0 ) {
				$normalised[] = array(
					'code'     => $code,
					'discount' => $discount,
				);
			}
		}
		return $normalised;
	}

	/**
	 * Spreads a whole-cart discount across line totals in proportion to each line, so WooCommerce
	 * reports see it per product. Rounding leftovers go to the last line.
	 */
	private static function spread_discount( array $lines, $discount, $decimals ) {
		$base = array_sum( wp_list_pluck( $lines, 'total' ) );
		if ( $discount <= 0 || $base <= 0 ) {
			return $lines;
		}
		$discount  = min( $discount, $base );
		$remaining = $discount;
		$last      = count( $lines ) - 1;
		foreach ( $lines as $i => $line ) {
			$share               = $i === $last ? $remaining : round( $discount * $line['total'] / $base, $decimals );
			$share               = min( $share, $line['total'] );
			$lines[ $i ]['total'] = round( $line['total'] - $share, $decimals );
			$remaining          -= $share;
		}
		return $lines;
	}

	private static function set_customer( \WC_Order $order, array $customer ) {
		$customer_id = absint( $customer['id'] ?? 0 );
		if ( $customer_id && get_userdata( $customer_id ) ) {
			$order->set_customer_id( $customer_id );
		}
		if ( ! empty( $customer['name'] ) ) {
			$parts = explode( ' ', sanitize_text_field( $customer['name'] ), 2 );
			$order->set_billing_first_name( $parts[0] );
			$order->set_billing_last_name( $parts[1] ?? '' );
		}
		if ( ! empty( $customer['email'] ) && is_email( $customer['email'] ) ) {
			$order->set_billing_email( sanitize_email( $customer['email'] ) );
		}
		if ( ! empty( $customer['phone'] ) ) {
			$order->set_billing_phone( sanitize_text_field( $customer['phone'] ) );
		}
	}

	private static function set_payment( \WC_Order $order, array $payment ) {
		$method = sanitize_key( $payment['method'] ?? 'cash' );
		$title  = sanitize_text_field( $payment['title'] ?? '' );

		$order->set_payment_method( 'zameria_' . $method );
		$order->set_payment_method_title( '' !== $title ? $title : Settings::payment_method_label( $method ) );

		if ( isset( $payment['amount_tendered'] ) ) {
			$order->update_meta_data( '_zameria_amount_tendered', wc_format_decimal( $payment['amount_tendered'] ) );
		}

		$splits = array();
		foreach ( (array) ( $payment['splits'] ?? array() ) as $split ) {
			$splits[] = array(
				'method' => sanitize_key( $split['method'] ?? '' ),
				'title'  => sanitize_text_field( $split['title'] ?? '' ),
				'amount' => wc_format_decimal( $split['amount'] ?? 0 ),
			);
		}
		if ( $splits ) {
			$order->update_meta_data( '_zameria_payment_splits', $splits );
		}
	}

	private static function order_fields( $order_id ) {
		$order = wc_get_order( $order_id );
		return array(
			'order_id'     => (int) $order_id,
			'order_number' => $order ? (string) $order->get_order_number() : (string) $order_id,
		);
	}

	private static function result( $uuid, $status, array $extra = array() ) {
		return array_merge(
			array(
				'uuid'   => $uuid,
				'status' => $status,
			),
			$extra
		);
	}
}
