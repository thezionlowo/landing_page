<?php
/**
 * Device sign-in and token authentication.
 *
 * Each POS device signs in once with a WordPress username/password and receives a long-lived
 * token, so it keeps working through days offline. Tokens travel in a custom header because
 * many shared hosts (Apache/cPanel) strip the Authorization header before PHP sees it.
 *
 * @package Zameria
 */

namespace Zameria;

defined( 'ABSPATH' ) || exit;

class Auth {

	const HEADER           = 'X-Zameria-Token';
	const MAX_ATTEMPTS     = 5;
	const LOCKOUT_SECONDS  = 15 * MINUTE_IN_SECONDS;
	const SEEN_INTERVAL    = 5 * MINUTE_IN_SECONDS;

	/** @var object|null Device row for the current request. */
	private static $device = null;

	public static function init() {
		// Lets a signed-in device call WooCommerce's own REST API (wc/v3, wp/v2/media) as its user,
		// so no store-wide consumer keys ever live in the browser.
		add_filter( 'determine_current_user', array( __CLASS__, 'determine_current_user' ), 30 );
		add_filter( 'woocommerce_rest_check_permissions', array( __CLASS__, 'grant_pos_permissions' ), 10, 4 );
		add_filter( 'woocommerce_rest_customer_query', array( __CLASS__, 'customer_query' ) );
	}

	public static function determine_current_user( $user_id ) {
		if ( $user_id || ! self::is_rest_request() ) {
			return $user_id;
		}
		$token = isset( $_SERVER['HTTP_X_ZAMERIA_TOKEN'] ) ? sanitize_text_field( wp_unslash( $_SERVER['HTTP_X_ZAMERIA_TOKEN'] ) ) : '';
		if ( '' === $token ) {
			return $user_id;
		}
		$device = self::device_for_token( $token );
		if ( ! $device ) {
			return $user_id;
		}
		$user = get_user_by( 'id', $device->user_id );
		if ( ! $user || ! self::user_can_use_pos( $user ) ) {
			return $user_id;
		}
		self::$device = $device;
		return (int) $user->ID;
	}

	/**
	 * Cashiers get the read access the till needs (products, coupons, orders, customers) and may
	 * add customers, but only on requests made from a POS device. Shop managers and admins
	 * already have these through their own WooCommerce capabilities.
	 */
	public static function grant_pos_permissions( $permission, $context, $object_id, $type ) {
		if ( $permission || ! self::$device || ! current_user_can( Install::CAPABILITY ) ) {
			return $permission;
		}

		$readable = array( 'product', 'product_variation', 'product_cat', 'product_tag', 'shop_coupon', 'shop_order' );
		if ( 'read' === $context && in_array( $type, $readable, true ) ) {
			return true;
		}

		if ( 'user' === $type || 'customer' === $type ) {
			if ( 'create' === $context ) {
				return true;
			}
			// Customer listing is narrowed to the customer role in customer_query().
			if ( 'read' === $context && ! $object_id ) {
				return true;
			}
			// A single account may be read or edited only if it is a plain customer, so a cashier
			// can never see or change a staff login.
			if ( in_array( $context, array( 'read', 'edit' ), true ) && $object_id ) {
				$target = get_userdata( $object_id );
				return $target && array( 'customer' ) === array_values( $target->roles );
			}
		}

		return $permission;
	}

	/**
	 * Staff without list_users only ever see customer accounts in wc/v3/customers.
	 */
	public static function customer_query( $args ) {
		if ( self::$device ) {
			if ( ! current_user_can( 'list_users' ) ) {
				unset( $args['role__in'] );
				$args['role'] = 'customer';
			} elseif ( isset( $args['role'] ) && 'all' === $args['role'] ) {
				// 'all' is a WooCommerce REST query pseudo-role; WP_User_Query has no 'all' role.
				unset( $args['role'] );
			}
		}
		return $args;
	}

	private static function is_rest_request() {
		if ( defined( 'REST_REQUEST' ) && REST_REQUEST ) {
			return true;
		}
		// determine_current_user can run before REST_REQUEST is defined; fall back to the URL.
		$uri    = isset( $_SERVER['REQUEST_URI'] ) ? wp_unslash( $_SERVER['REQUEST_URI'] ) : ''; // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized
		$prefix = '/' . rest_get_url_prefix() . '/';
		return false !== strpos( $uri, $prefix ) || false !== strpos( $uri, 'rest_route=' );
	}

	private static function device_for_token( $token ) {
		global $wpdb;
		return $wpdb->get_row(
			$wpdb->prepare(
				"SELECT * FROM {$wpdb->prefix}zameria_devices WHERE token_hash = %s AND revoked_at IS NULL",
				hash( 'sha256', $token )
			)
		);
	}

	public static function user_can_use_pos( $user ) {
		return user_can( $user, Install::CAPABILITY ) || user_can( $user, 'manage_woocommerce' );
	}

	/**
	 * @return array|\WP_Error
	 */
	public static function login( $username, $password, $device_name ) {
		$throttle_key = 'zameria_login_' . md5( strtolower( $username ) . '|' . self::client_ip() );
		$attempts     = (int) get_transient( $throttle_key );
		if ( $attempts >= self::MAX_ATTEMPTS ) {
			return new \WP_Error( 'zameria_too_many_attempts', __( 'Too many failed sign-in attempts. Try again in 15 minutes.', 'zameria' ), array( 'status' => 429 ) );
		}

		// Verify store entitlement before issuing device tokens
		$entitled = Settings::is_entitled();
		if ( is_wp_error( $entitled ) ) {
			return $entitled;
		}

		// Enforce plan device limits (Starter: max 2 active registers)
		$limits = Settings::plan_limits();
		if ( null !== $limits['max_devices'] ) {
			$active_count = count( self::active_devices() );
			if ( $active_count >= $limits['max_devices'] ) {
				return new \WP_Error(
					'zameria_plan_limit_exceeded',
					sprintf(
						__( 'Starter plan device limit reached (maximum %d active registers). Please revoke an existing register or upgrade to the Business plan for unlimited registers.', 'zameria' ),
						$limits['max_devices']
					),
					array( 'status' => 403, 'limit_type' => 'devices', 'max' => $limits['max_devices'] )
				);
			}
		}

		$user = wp_authenticate( $username, $password );
		if ( is_wp_error( $user ) ) {
			set_transient( $throttle_key, $attempts + 1, self::LOCKOUT_SECONDS );
			return new \WP_Error( 'zameria_invalid_login', __( 'Incorrect username or password.', 'zameria' ), array( 'status' => 401 ) );
		}
		delete_transient( $throttle_key );

		if ( ! self::user_can_use_pos( $user ) ) {
			return new \WP_Error( 'zameria_forbidden', __( 'This account is not allowed to use the POS. Ask the store owner to give you the POS Cashier role.', 'zameria' ), array( 'status' => 403 ) );
		}

		global $wpdb;
		$token = bin2hex( random_bytes( 32 ) );
		$now   = gmdate( 'Y-m-d H:i:s' );
		$wpdb->insert(
			"{$wpdb->prefix}zameria_devices",
			array(
				'user_id'      => $user->ID,
				'name'         => $device_name,
				'token_hash'   => hash( 'sha256', $token ),
				'created_at'   => $now,
				'last_seen_at' => $now,
			)
		);

		return array(
			'token'  => $token,
			'device' => array(
				'id'   => (int) $wpdb->insert_id,
				'name' => $device_name,
			),
			'user'   => self::user_payload( $user ),
			'store'  => Settings::store(),
		);
	}

	/**
	 * REST permission callback for every authenticated route.
	 *
	 * @return true|\WP_Error
	 */
	public static function authenticate( \WP_REST_Request $request ) {
		$token = (string) $request->get_header( self::HEADER );
		if ( '' === $token ) {
			return new \WP_Error( 'zameria_unauthorized', __( 'Sign in required.', 'zameria' ), array( 'status' => 401 ) );
		}

		// Enforce store license entitlement
		$entitled = Settings::is_entitled();
		if ( is_wp_error( $entitled ) ) {
			return $entitled;
		}

		global $wpdb;
		$device = self::device_for_token( $token );
		if ( ! $device ) {
			return new \WP_Error( 'zameria_unauthorized', __( 'This device has been signed out. Please sign in again.', 'zameria' ), array( 'status' => 401 ) );
		}

		$user = get_user_by( 'id', $device->user_id );
		if ( ! $user || ! self::user_can_use_pos( $user ) ) {
			return new \WP_Error( 'zameria_forbidden', __( 'This account can no longer use the POS.', 'zameria' ), array( 'status' => 403 ) );
		}

		wp_set_current_user( $user->ID );
		self::$device = $device;

		if ( ! $device->last_seen_at || strtotime( $device->last_seen_at . ' UTC' ) < time() - self::SEEN_INTERVAL ) {
			$wpdb->update(
				"{$wpdb->prefix}zameria_devices",
				array( 'last_seen_at' => gmdate( 'Y-m-d H:i:s' ) ),
				array( 'id' => $device->id )
			);
		}

		return true;
	}

	public static function current_device() {
		return self::$device;
	}

	public static function revoke( $device_id ) {
		global $wpdb;
		$wpdb->update(
			"{$wpdb->prefix}zameria_devices",
			array( 'revoked_at' => gmdate( 'Y-m-d H:i:s' ) ),
			array( 'id' => (int) $device_id )
		);
	}

	public static function active_devices() {
		global $wpdb;
		return $wpdb->get_results(
			"SELECT d.*, u.display_name FROM {$wpdb->prefix}zameria_devices d
			LEFT JOIN {$wpdb->users} u ON u.ID = d.user_id
			WHERE d.revoked_at IS NULL ORDER BY d.last_seen_at DESC"
		);
	}

	/**
	 * Who is signed in and what they may do. The app uses this for its menus; the server still
	 * enforces every permission itself.
	 */
	public static function user_payload( $user ) {
		$roles = array_values( $user->roles );
		if ( in_array( 'zameria_cashier', $roles, true ) ) {
			$roles[] = 'cashier';
		}

		$capabilities = array();
		foreach ( array( 'manage_options', 'edit_products', 'publish_products', 'edit_shop_orders', 'list_users' ) as $cap ) {
			$capabilities[ $cap ] = user_can( $user, $cap );
		}

		return array(
			'id'           => (int) $user->ID,
			'name'         => $user->display_name,
			'username'     => $user->user_login,
			'email'        => $user->user_email,
			'roles'        => $roles,
			'capabilities' => $capabilities,
		);
	}

	private static function client_ip() {
		return isset( $_SERVER['REMOTE_ADDR'] ) ? sanitize_text_field( wp_unslash( $_SERVER['REMOTE_ADDR'] ) ) : '';
	}
}
