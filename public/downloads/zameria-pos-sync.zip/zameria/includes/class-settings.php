<?php
/**
 * Store settings exposed to the POS app.
 *
 * @package Zameria
 */

namespace Zameria;

defined( 'ABSPATH' ) || exit;

class Settings {

	const PAYMENT_METHODS_OPTION = 'zameria_payment_methods';
	const RECEIPT_FOOTER_OPTION  = 'zameria_receipt_footer';
	const ENTITLEMENT_OPTION     = 'zameria_entitlement';

	/**
	 * Returns the store's authoritative ZAMERIA entitlement data.
	 * Evaluates trial and paid expiration dynamically based on UTC timestamps.
	 *
	 * @return array<string, mixed>
	 */
	public static function get_entitlement() {
		$data = get_option( self::ENTITLEMENT_OPTION );
		if ( ! is_array( $data ) || empty( $data ) ) {
			return array(
				'status'             => 'trial_not_started',
				'plan'               => null,
				'plan_name'          => 'None (Trial Eligible)',
				'trial_start'        => null,
				'trial_end'          => null,
				'days_remaining'     => 7,
				'license_key'        => null,
				'license_expires_at' => null,
				'max_products'       => 500,
				'max_devices'        => 2,
				'is_licensed'        => false,
			);
		}

		$status = $data['status'] ?? 'trial_not_started';
		$now    = time();

		// Dynamic UTC timestamp checks to ensure expiration cannot be bypassed
		if ( 'trial_active' === $status && ! empty( $data['trial_end'] ) ) {
			$end_timestamp = strtotime( $data['trial_end'] );
			if ( $end_timestamp && $end_timestamp <= $now ) {
				$status = 'trial_expired';
				$data['status'] = 'trial_expired';
				$data['days_remaining'] = 0;
			} else if ( $end_timestamp ) {
				$data['days_remaining'] = max( 0, (int) ceil( ( $end_timestamp - $now ) / DAY_IN_SECONDS ) );
			}
		} elseif ( 'paid_active' === $status && ! empty( $data['license_expires_at'] ) ) {
			$exp_timestamp = strtotime( $data['license_expires_at'] );
			if ( $exp_timestamp && $exp_timestamp <= $now ) {
				$status = 'paid_expired';
				$data['status'] = 'paid_expired';
			}
		}

		// A trial is full capability for its week: the licensing service issues it
		// with no product or register ceiling, and the site promises full access
		// to evaluate ZAMERIA. Only a paid Starter plan is capped — defaulting a
		// trial to Starter stopped a second till signing in during the trial.
		// While a trial is running it is the plan, whatever a previous record
		// said: a store that once held Starter must not carry its ceilings into
		// the trial it is now on.
		$is_trial   = 'trial_active' === $status;
		$plan       = $is_trial ? 'Trial' : ( $data['plan'] ?? ( 'paid_active' === $status ? 'Business' : 'Starter' ) );
		$is_starter = ! $is_trial && 'Starter' === $plan;

		return array(
			'status'             => $status,
			'plan'               => $plan,
			'plan_name'          => $data['plan_name'] ?? ( $is_trial ? 'Free Trial' : ( $is_starter ? 'Starter Plan' : ( 'paid_active' === $status ? 'Business Plan' : 'Free Trial' ) ) ),
			'trial_start'        => $data['trial_start'] ?? null,
			'trial_end'          => $data['trial_end'] ?? null,
			'days_remaining'     => $data['days_remaining'] ?? 0,
			'license_key'        => $data['license_key'] ?? null,
			'license_expires_at' => $data['license_expires_at'] ?? null,
			'max_products'       => $is_starter ? 500 : null,
			'max_devices'        => $is_starter ? 2 : null,
			'is_licensed'        => in_array( $status, array( 'trial_active', 'paid_active' ), true ),
		);
	}

	/**
	 * Persists updated authoritative entitlement to WordPress options.
	 *
	 * @param array<string, mixed> $data
	 * @return bool
	 */
	public static function set_entitlement( $data ) {
		if ( ! is_array( $data ) ) {
			return false;
		}
		// Merge over what is stored, not over get_entitlement()'s answer. That
		// answer fills in defaults — a missing plan reads as Starter, and the
		// capacity ceilings follow from it — and writing those back pinned a
		// store to Starter for good, so a later trial or Business licence kept
		// Starter's two-register limit.
		$stored = get_option( self::ENTITLEMENT_OPTION );
		$merged = array_merge( is_array( $stored ) ? $stored : array(), $data );

		// Derived every time they are read; storing them only lets them go stale.
		unset( $merged['max_products'], $merged['max_devices'], $merged['is_licensed'] );
		if ( empty( $merged['plan'] ) ) {
			unset( $merged['plan'] );
		}

		$merged['updated_at'] = gmdate( 'Y-m-d H:i:s' );
		return update_option( self::ENTITLEMENT_OPTION, $merged );
	}

	/**
	 * Checks whether the current store is authorized to execute POS REST operations.
	 *
	 * @return true|\WP_Error
	 */
	public static function is_entitled() {
		// Allow explicit local bypass only if environment flag is set
		if ( defined( 'ZAMERIA_DISABLE_LICENSING' ) && ZAMERIA_DISABLE_LICENSING ) {
			return true;
		}

		$entitlement = self::get_entitlement();
		$status      = $entitlement['status'];

		if ( 'trial_active' === $status ) {
			return true;
		}

		if ( 'paid_active' === $status ) {
			return true;
		}

		if ( 'trial_not_started' === $status ) {
			return new \WP_Error(
				'zameria_trial_not_started',
				__( 'ZAMERIA trial has not started yet. Enter your Trial Activation Code in the WordPress admin to begin your 7-day trial.', 'zameria' ),
				array( 'status' => 403, 'entitlement_status' => $status )
			);
		}

		if ( 'trial_expired' === $status ) {
			return new \WP_Error(
				'zameria_license_expired',
				__( 'Your 7-day ZAMERIA free trial has ended. Please upgrade to an annual plan to continue using the Point of Sale.', 'zameria' ),
				array( 'status' => 403, 'entitlement_status' => $status )
			);
		}

		if ( 'paid_expired' === $status ) {
			return new \WP_Error(
				'zameria_license_expired',
				__( 'Your ZAMERIA annual license has expired. Please renew your subscription to restore POS functionality.', 'zameria' ),
				array( 'status' => 403, 'entitlement_status' => $status )
			);
		}

		return new \WP_Error(
			'zameria_unauthorized',
			__( 'No active ZAMERIA entitlement found for this store. Please connect a valid license.', 'zameria' ),
			array( 'status' => 403, 'entitlement_status' => $status )
		);
	}

	/**
	 * Returns Starter and Business plan capacity limits.
	 *
	 * @return array{max_products: int|null, max_devices: int|null}
	 */
	public static function plan_limits() {
		$entitlement = self::get_entitlement();
		// get_entitlement has already resolved a trial to an uncapped plan; read
		// its answer rather than defaulting to Starter a second time here.
		return array(
			'max_products' => $entitlement['max_products'],
			'max_devices'  => $entitlement['max_devices'],
		);
	}

	/**
	 * @return array<int, array{id: string, label: string}>
	 */
	public static function payment_methods() {
		$methods = get_option( self::PAYMENT_METHODS_OPTION );
		if ( ! is_array( $methods ) || ! $methods ) {
			$methods = array(
				array(
					'id'    => 'cash',
					'label' => __( 'Cash', 'zameria' ),
				),
				array(
					'id'    => 'transfer',
					'label' => __( 'Bank transfer', 'zameria' ),
				),
				array(
					'id'    => 'card',
					'label' => __( 'Card (POS terminal)', 'zameria' ),
				),
			);
		}
		return $methods;
	}

	/**
	 * Parses the admin textarea (one label per line) into payment methods.
	 */
	public static function save_payment_methods( $text ) {
		$methods = array();
		foreach ( preg_split( '/\r\n|\r|\n/', (string) $text ) as $line ) {
			$label = sanitize_text_field( $line );
			$id    = sanitize_key( str_replace( ' ', '_', strtolower( $label ) ) );
			if ( '' === $label || '' === $id ) {
				continue;
			}
			$methods[ $id ] = array(
				'id'    => $id,
				'label' => $label,
			);
		}
		update_option( self::PAYMENT_METHODS_OPTION, array_values( $methods ) );
	}

	public static function payment_method_label( $id ) {
		foreach ( self::payment_methods() as $method ) {
			if ( $method['id'] === $id ) {
				return $method['label'];
			}
		}
		return $id;
	}

	public static function receipt_footer() {
		return (string) get_option( self::RECEIPT_FOOTER_OPTION, __( 'Thank you for your patronage!', 'zameria' ) );
	}

	public static function store() {
		$address = array_filter(
			array(
				get_option( 'woocommerce_store_address' ),
				get_option( 'woocommerce_store_address_2' ),
				get_option( 'woocommerce_store_city' ),
			)
		);

		$logo_id  = get_theme_mod( 'custom_logo' );
		$logo_url = $logo_id ? wp_get_attachment_image_url( $logo_id, 'full' ) : get_site_icon_url();

		return array(
			'name'           => wp_specialchars_decode( get_bloginfo( 'name' ), ENT_QUOTES ),
			'address'        => implode( ', ', $address ),
			'receipt_footer' => self::receipt_footer(),
			'logo'           => $logo_url ? $logo_url : '',
		);
	}

	public static function currency() {
		return array(
			'code'               => get_woocommerce_currency(),
			'symbol'             => html_entity_decode( get_woocommerce_currency_symbol(), ENT_QUOTES, 'UTF-8' ),
			'position'           => get_option( 'woocommerce_currency_pos', 'left' ),
			'decimals'           => wc_get_price_decimals(),
			'decimal_separator'  => wc_get_price_decimal_separator(),
			'thousand_separator' => wc_get_price_thousand_separator(),
		);
	}

	public static function categories() {
		$terms = get_terms(
			array(
				'taxonomy'   => 'product_cat',
				'hide_empty' => true,
			)
		);
		if ( is_wp_error( $terms ) ) {
			return array();
		}
		return array_map(
			function ( $term ) {
				return array(
					'id'     => (int) $term->term_id,
					'name'   => wp_specialchars_decode( $term->name, ENT_QUOTES ),
					'parent' => (int) $term->parent,
				);
			},
			$terms
		);
	}

	/**
	 * Detects the active brand taxonomy used on the WooCommerce store.
	 * Supports official WooCommerce Brands (product_brand), Perfect Brands (pwb-brand),
	 * YITH Brands (yith_product_brand), generic brand, and product attribute pa_brand.
	 *
	 * @return string Active taxonomy slug.
	 */
	public static function brand_taxonomy() {
		$candidates = array( 'product_brand', 'pwb-brand', 'yith_product_brand', 'brand', 'pa_brand' );
		foreach ( $candidates as $tax ) {
			if ( taxonomy_exists( $tax ) ) {
				return $tax;
			}
		}
		return 'product_brand';
	}

	/**
	 * Retrieves all brands from the detected brand taxonomy.
	 *
	 * @return array<int, array{id: int, name: string, slug: string, taxonomy: string, count: int, description: string}>
	 */
	public static function brands() {
		$tax = self::brand_taxonomy();
		if ( ! taxonomy_exists( $tax ) ) {
			return array();
		}

		$terms = get_terms(
			array(
				'taxonomy'   => $tax,
				'hide_empty' => false,
			)
		);

		if ( is_wp_error( $terms ) || ! is_array( $terms ) ) {
			return array();
		}

		return array_values(
			array_map(
				function ( $term ) use ( $tax ) {
					return array(
						'id'          => (int) $term->term_id,
						'name'        => wp_specialchars_decode( $term->name, ENT_QUOTES ),
						'slug'        => (string) $term->slug,
						'taxonomy'    => $tax,
						'count'       => (int) $term->count,
						'description' => (string) $term->description,
					);
				},
				$terms
			)
		);
	}
}
