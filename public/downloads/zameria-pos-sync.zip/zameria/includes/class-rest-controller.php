<?php
/**
 * REST API used by the POS app: /wp-json/zameria/v1/...
 *
 *   POST /auth/login     username, password, device_name -> token
 *   POST /auth/logout    revoke this device's token
 *   GET  /bootstrap      store info, currency, payment methods, categories, user, cursor
 *   GET  /products       full catalogue, paged (first sync / resync)
 *   GET  /changes        products changed since a cursor (every sync after that)
 *   POST /sales          upload sales made on the device (idempotent)
 *
 * A signed-in device may also call WooCommerce's own wc/v3 API with its token (see Auth::init).
 *
 * @package Zameria
 */

namespace Zameria;

defined( 'ABSPATH' ) || exit;

class Rest_Controller {

	const NAMESPACE_V1 = 'zameria/v1';

	public static function init() {
		add_action( 'rest_api_init', array( __CLASS__, 'register_routes' ) );
		add_filter( 'rest_post_dispatch', array( __CLASS__, 'no_cache' ), 10, 3 );
		add_filter( 'rest_allowed_cors_headers', array( __CLASS__, 'allow_token_header' ) );
		add_action( 'woocommerce_rest_insert_product_object', array( __CLASS__, 'handle_product_rest_brand' ), 10, 3 );
	}

	/**
	 * The hosted POS app (e.g. on Vercel) calls this store from another domain. WordPress already
	 * answers cross-origin REST requests; it only needs to accept the device-token header too.
	 * No cookies are involved (the app sends credentials: 'omit'), so this grants nothing extra.
	 */
	public static function allow_token_header( $headers ) {
		$headers[] = Auth::HEADER;
		return $headers;
	}

	public static function register_routes() {
		$auth = array( Auth::class, 'authenticate' );

		register_rest_route(
			self::NAMESPACE_V1,
			'/auth/login',
			array(
				'methods'             => 'POST',
				'callback'            => array( __CLASS__, 'login' ),
				'permission_callback' => '__return_true',
				'args'                => array(
					'username'    => array(
						'type'     => 'string',
						'required' => true,
					),
					'password'    => array(
						'type'     => 'string',
						'required' => true,
					),
					'device_name' => array(
						'type'    => 'string',
						'default' => 'Register',
					),
				),
			)
		);

		register_rest_route(
			self::NAMESPACE_V1,
			'/auth/logout',
			array(
				'methods'             => 'POST',
				'callback'            => array( __CLASS__, 'logout' ),
				'permission_callback' => $auth,
			)
		);

		register_rest_route(
			self::NAMESPACE_V1,
			'/bootstrap',
			array(
				'methods'             => 'GET',
				'callback'            => array( __CLASS__, 'bootstrap' ),
				'permission_callback' => $auth,
			)
		);

		register_rest_route(
			self::NAMESPACE_V1,
			'/products',
			array(
				'methods'             => 'GET',
				'callback'            => array( __CLASS__, 'products' ),
				'permission_callback' => $auth,
				'args'                => array(
					'page'     => array(
						'type'    => 'integer',
						'default' => 1,
						'minimum' => 1,
					),
					'per_page' => array(
						'type'    => 'integer',
						'default' => 100,
						'minimum' => 1,
						'maximum' => 200,
					),
				),
			)
		);

		register_rest_route(
			self::NAMESPACE_V1,
			'/changes',
			array(
				'methods'             => 'GET',
				'callback'            => array( __CLASS__, 'changes' ),
				'permission_callback' => $auth,
				'args'                => array(
					'since' => array(
						'type'     => 'integer',
						'required' => true,
						'minimum'  => 0,
					),
					'limit' => array(
						'type'    => 'integer',
						'default' => 200,
						'minimum' => 1,
						'maximum' => 500,
					),
				),
			)
		);

		register_rest_route(
			self::NAMESPACE_V1,
			'/sales',
			array(
				'methods'             => 'POST',
				'callback'            => array( __CLASS__, 'sales' ),
				'permission_callback' => $auth,
			)
		);

		register_rest_route(
			self::NAMESPACE_V1,
			'/customers',
			array(
				'methods'             => 'GET',
				'callback'            => array( __CLASS__, 'customers' ),
				'permission_callback' => $auth,
				'args'                => array(
					'page'     => array(
						'type'    => 'integer',
						'default' => 1,
						'minimum' => 1,
					),
					'per_page' => array(
						'type'    => 'integer',
						'default' => 100,
						'minimum' => 1,
						'maximum' => 200,
					),
					'search'   => array(
						'type'    => 'string',
						'default' => '',
					),
				),
			)
		);

		register_rest_route(
			self::NAMESPACE_V1,
			'/brands',
			array(
				'methods'             => 'GET',
				'callback'            => array( __CLASS__, 'brands' ),
				'permission_callback' => $auth,
			)
		);
	}

	public static function login( \WP_REST_Request $request ) {
		$device_name = sanitize_text_field( $request['device_name'] );
		$result      = Auth::login(
			(string) $request['username'],
			(string) $request['password'],
			'' !== $device_name ? substr( $device_name, 0, 100 ) : 'Register'
		);
		return is_wp_error( $result ) ? $result : rest_ensure_response( $result );
	}

	public static function logout() {
		Auth::revoke( Auth::current_device()->id );
		return rest_ensure_response( array( 'ok' => true ) );
	}

	public static function bootstrap() {
		$device = Auth::current_device();
		return rest_ensure_response(
			array(
				'store'           => Settings::store(),
				'currency'        => Settings::currency(),
				'payment_methods' => Settings::payment_methods(),
				'categories'      => Settings::categories(),
				'brands'          => Settings::brands(),
				// Starting point for /changes when a device downloads the catalogue for the first time.
				'cursor'          => Change_Log::current_cursor(),
				'user'            => Auth::user_payload( wp_get_current_user() ),
				'device'          => array(
					'id'   => (int) $device->id,
					'name' => $device->name,
				),
			)
		);
	}

	public static function products( \WP_REST_Request $request ) {
		$page = (int) $request['page'];
		$per_page = (int) $request['per_page'];

		// Enforce plan product limits (Starter: max 500 products)
		$limits = Settings::plan_limits();
		$max_allowed_products = $limits['max_products']; // 500 for Starter, null for Business

		if ( null !== $max_allowed_products && ( ( $page - 1 ) * $per_page ) >= $max_allowed_products ) {
			return rest_ensure_response(
				array(
					'products'    => array(),
					'page'        => $page,
					'total_pages' => (int) ceil( $max_allowed_products / $per_page ),
					'cursor'      => null,
					'plan_limit'  => $max_allowed_products,
				)
			);
		}

		// Taken before reading products: anything that changes while the device is still
		// downloading will be picked up by the first /changes call after this cursor.
		$cursor = 1 === $page ? Change_Log::current_cursor() : null;

		$result = wc_get_products(
			array(
				'status'   => 'publish',
				'type'     => Product_Formatter::types(),
				'limit'    => $per_page,
				'page'     => $page,
				'orderby'  => 'ID',
				'order'    => 'ASC',
				'paginate' => true,
			)
		);

		$products = array();
		$current_offset = ( $page - 1 ) * $per_page;
		foreach ( $result->products as $product ) {
			if ( null !== $max_allowed_products && ( $current_offset + count( $products ) ) >= $max_allowed_products ) {
				break;
			}
			$products[] = Product_Formatter::format( $product );
		}

		$total_pages = (int) $result->max_num_pages;
		if ( null !== $max_allowed_products ) {
			$total_pages = min( $total_pages, (int) ceil( $max_allowed_products / $per_page ) );
		}

		return rest_ensure_response(
			array(
				'products'    => $products,
				'page'        => $page,
				'total_pages' => $total_pages,
				'cursor'      => $cursor,
				'plan_limit'  => $max_allowed_products,
			)
		);
	}

	public static function changes( \WP_REST_Request $request ) {
		$since = (int) $request['since'];

		if ( Change_Log::is_expired( $since ) ) {
			return rest_ensure_response( array( 'reset' => true ) );
		}

		$batch = Change_Log::since( $since, (int) $request['limit'] );
		$diff  = self::products_for_ids( $batch['ids'] );

		return rest_ensure_response(
			array(
				'reset'    => false,
				'products' => $diff['products'],
				'removed'  => $diff['removed'],
				'cursor'   => $batch['cursor'],
				'more'     => $batch['more'],
			)
		);
	}

	public static function sales( \WP_REST_Request $request ) {
		$sales = $request->get_param( 'sales' );
		if ( ! is_array( $sales ) ) {
			return new \WP_Error( 'zameria_invalid_sales', 'Expected a "sales" array.', array( 'status' => 400 ) );
		}
		if ( count( $sales ) > 50 ) {
			return new \WP_Error( 'zameria_too_many_sales', 'Send at most 50 sales per request.', array( 'status' => 400 ) );
		}

		$device   = Auth::current_device();
		$results  = array();
		$affected = array();
		foreach ( $sales as $sale ) {
			if ( ! is_array( $sale ) ) {
				continue;
			}
			$results[] = Sale_Importer::import( $sale, $device );
			$affected  = array_merge( $affected, Sale_Importer::affected_item_ids( $sale ) );
		}

		// Send back fresh stock for what was just sold so the till never shows stale numbers.
		$diff = self::products_for_ids( array_unique( $affected ), true );

		return rest_ensure_response(
			array(
				'results'  => $results,
				'products' => $diff['products'],
			)
		);
	}

	/**
	 * Resolves changed product or variation ids to whole products (a changed variation sends its
	 * parent with all variations), or to removals when a product left the catalogue.
	 *
	 * @param int[] $ids
	 * @param bool  $refresh Re-read products, bypassing caches (used right after a stock change).
	 * @return array{products: array[], removed: int[]}
	 */
	private static function products_for_ids( array $ids, $refresh = false ) {
		$parents = array();
		$removed = array();

		foreach ( $ids as $id ) {
			if ( $refresh ) {
				clean_post_cache( $id );
			}
			$product = wc_get_product( $id );
			if ( $product && $product->is_type( 'variation' ) ) {
				$parent_id = $product->get_parent_id();
				if ( $refresh ) {
					clean_post_cache( $parent_id );
				}
				$product = wc_get_product( $parent_id );
				$id      = $parent_id;
			}

			if ( $product && Product_Formatter::is_listed( $product ) ) {
				$parents[ $product->get_id() ] = $product;
			} elseif ( ! $product || ! $product->is_type( 'variation' ) ) {
				$removed[] = (int) $id;
			}
		}

		return array(
			'products' => array_values( array_map( array( Product_Formatter::class, 'format' ), $parents ) ),
			'removed'  => array_values( array_unique( array_diff( $removed, array_keys( $parents ) ) ) ),
		);
	}

	public static function customers( \WP_REST_Request $request ) {
		$page     = (int) $request['page'];
		$per_page = (int) $request['per_page'];
		$search   = sanitize_text_field( (string) $request['search'] );

		$args = array(
			'role__in' => array( 'customer' ),
			'number'   => $per_page,
			'paged'    => $page,
			'orderby'  => 'ID',
			'order'    => 'ASC',
		);

		if ( '' !== $search ) {
			$args['search']         = '*' . $search . '*';
			$args['search_columns'] = array( 'user_login', 'user_nicename', 'user_email', 'display_name' );
		}

		$query       = new \WP_User_Query( $args );
		$total_users = (int) $query->get_total();
		$total_pages = $total_users > 0 ? (int) ceil( $total_users / $per_page ) : 1;

		$customers = array();
		foreach ( $query->get_results() as $user ) {
			$first_name = (string) get_user_meta( $user->ID, 'billing_first_name', true );
			$last_name  = (string) get_user_meta( $user->ID, 'billing_last_name', true );
			$billing    = array(
				'first_name' => $first_name,
				'last_name'  => $last_name,
				'company'    => (string) get_user_meta( $user->ID, 'billing_company', true ),
				'address_1'  => (string) get_user_meta( $user->ID, 'billing_address_1', true ),
				'address_2'  => (string) get_user_meta( $user->ID, 'billing_address_2', true ),
				'city'       => (string) get_user_meta( $user->ID, 'billing_city', true ),
				'state'      => (string) get_user_meta( $user->ID, 'billing_state', true ),
				'postcode'   => (string) get_user_meta( $user->ID, 'billing_postcode', true ),
				'country'    => (string) get_user_meta( $user->ID, 'billing_country', true ) ?: 'NG',
				'email'      => (string) get_user_meta( $user->ID, 'billing_email', true ) ?: $user->user_email,
				'phone'      => (string) get_user_meta( $user->ID, 'billing_phone', true ),
			);

			$last_update = get_user_meta( $user->ID, 'last_update', true );

			$customers[] = array(
				'id'            => (int) $user->ID,
				'date_created'  => wc_rest_prepare_date_response( $user->user_registered ),
				'date_modified' => wc_rest_prepare_date_response( $last_update ?: $user->user_registered ),
				'email'         => $user->user_email,
				'first_name'    => $user->first_name ?: $first_name,
				'last_name'     => $user->last_name ?: $last_name,
				'role'          => 'customer',
				'username'      => $user->user_login,
				'billing'       => $billing,
				'avatar_url'    => get_avatar_url( $user->ID ),
			);
		}

		return rest_ensure_response(
			array(
				'customers'   => $customers,
				'page'        => $page,
				'total_pages' => $total_pages,
				'total_items' => $total_users,
			)
		);
	}

	public static function brands() {
		return rest_ensure_response(
			array(
				'brands' => Settings::brands(),
			)
		);
	}

	/**
	 * Intercepts product creation and updates via WooCommerce REST API to assign brand terms
	 * to whichever brand taxonomy is currently active on the store.
	 *
	 * @param \WC_Product      $product  The product object.
	 * @param \WP_REST_Request $request  The REST request.
	 * @param bool             $creating True when creating a product, false when updating.
	 */
	public static function handle_product_rest_brand( $product, $request, $creating ) {
		$brand_id = null;

		if ( ! empty( $request['brands'] ) && is_array( $request['brands'] ) ) {
			$first = reset( $request['brands'] );
			$brand_id = is_array( $first ) && isset( $first['id'] ) ? (int) $first['id'] : (int) $first;
		} elseif ( isset( $request['brand_id'] ) ) {
			$brand_id = (int) $request['brand_id'];
		}

		if ( null !== $brand_id ) {
			$tax = Settings::brand_taxonomy();
			if ( taxonomy_exists( $tax ) ) {
				if ( $brand_id > 0 ) {
					wp_set_object_terms( $product->get_id(), array( $brand_id ), $tax, false );
				} else {
					wp_set_object_terms( $product->get_id(), array(), $tax, false );
				}
			}
		}
	}

	/**
	 * Stops page caches (LiteSpeed on most cPanel hosts, Cloudflare, etc.) from serving stale stock.
	 */
	public static function no_cache( $response, $server, $request ) {
		if ( 0 === strpos( $request->get_route(), '/' . self::NAMESPACE_V1 ) && $response instanceof \WP_REST_Response ) {
			$response->header( 'Cache-Control', 'no-store, no-cache, must-revalidate, max-age=0' );
			$response->header( 'X-LiteSpeed-Cache-Control', 'no-cache' );
		}
		return $response;
	}
}
