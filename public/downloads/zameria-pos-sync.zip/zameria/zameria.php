<?php
/**
 * Plugin Name:       Zameria POS
 * Description:       Offline-first point of sale for WooCommerce. Sell in your shop with or without internet — stock stays in sync with your online store.
 * Version:           0.3.1
 * Requires at least: 6.3
 * Requires PHP:      7.4
 * Requires Plugins:  woocommerce
 * Author:            Zameria
 * License:           GPL-2.0-or-later
 * License URI:       https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain:       zameria
 * WC requires at least: 8.0
 *
 * @package Zameria
 */

defined( 'ABSPATH' ) || exit;

define( 'ZAMERIA_VERSION', '0.3.1' );
define( 'ZAMERIA_FILE', __FILE__ );
define( 'ZAMERIA_DIR', plugin_dir_path( __FILE__ ) );
define( 'ZAMERIA_URL', plugin_dir_url( __FILE__ ) );
// The plugin serves the POS from the merchant's own /pos/ URL. This keeps the
// store session and its REST API on one origin and removes the hosted-app dependency.

require_once ZAMERIA_DIR . 'includes/class-install.php';
require_once ZAMERIA_DIR . 'includes/class-settings.php';
require_once ZAMERIA_DIR . 'includes/class-change-log.php';
require_once ZAMERIA_DIR . 'includes/class-auth.php';
require_once ZAMERIA_DIR . 'includes/class-product-formatter.php';
require_once ZAMERIA_DIR . 'includes/class-sale-importer.php';
require_once ZAMERIA_DIR . 'includes/class-rest-controller.php';
require_once ZAMERIA_DIR . 'includes/class-app-server.php';
require_once ZAMERIA_DIR . 'includes/class-admin.php';

register_activation_hook( __FILE__, array( 'Zameria\\Install', 'activate' ) );
register_deactivation_hook( __FILE__, array( 'Zameria\\Install', 'deactivate' ) );

add_action(
	'before_woocommerce_init',
	function () {
		if ( class_exists( \Automattic\WooCommerce\Utilities\FeaturesUtil::class ) ) {
			\Automattic\WooCommerce\Utilities\FeaturesUtil::declare_compatibility( 'custom_order_tables', ZAMERIA_FILE, true );
		}
	}
);

add_action(
	'plugins_loaded',
	function () {
		if ( ! class_exists( 'WooCommerce' ) ) {
			add_action(
				'admin_notices',
				function () {
					echo '<div class="notice notice-error"><p>' . esc_html__( 'Zameria POS needs WooCommerce to be installed and active.', 'zameria' ) . '</p></div>';
				}
			);
			return;
		}

		Zameria\Install::maybe_upgrade();
		Zameria\Auth::init();
		Zameria\Change_Log::init();
		Zameria\Rest_Controller::init();
		Zameria\App_Server::init();
		Zameria\Admin::init();
	}
);
