<?php
/**
 * Removes Zameria's tables and settings when the plugin is deleted.
 * WooCommerce orders created by the POS are kept.
 *
 * @package Zameria
 */

defined( 'WP_UNINSTALL_PLUGIN' ) || exit;

global $wpdb;

foreach ( array( 'zameria_changes', 'zameria_devices', 'zameria_sales' ) as $table ) {
	$wpdb->query( "DROP TABLE IF EXISTS {$wpdb->prefix}{$table}" ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
}

foreach ( array( 'zameria_db_version', 'zameria_changes_floor', 'zameria_payment_methods', 'zameria_receipt_footer' ) as $option ) {
	delete_option( $option );
}

remove_role( 'zameria_cashier' );
foreach ( array( 'administrator', 'shop_manager' ) as $role_name ) {
	$role = get_role( $role_name );
	if ( $role ) {
		$role->remove_cap( 'zameria_use_pos' );
	}
}

wp_clear_scheduled_hook( 'zameria_daily' );
